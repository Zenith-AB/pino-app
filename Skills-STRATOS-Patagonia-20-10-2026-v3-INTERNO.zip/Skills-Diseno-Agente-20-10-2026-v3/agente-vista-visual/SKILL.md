---
name: agente-vista-visual
description: "Diseña la vista del agente: inicio, compositor, orbe, tablero de evidencia, estados y animación; utiliza referencias visuales Patagonia con perfil STRATOS cuando se solicite. No impone siete secciones a otro producto."
---

# Vista visual del agente

Lee [composición y movimiento](references/vista.md) antes de implementar. El snapshot Patagonia incluye
AgentChat, App, Cards, Kit, Charts y estilos para inspeccionar mecánica y acabado; no obliga a copiar su
navegación, datos de demo, logotipo ni temporizadores. Para perfil STRATOS usa sus tokens en destino.

## Resultado esperado

Un agente que organiza evidencia en el lienzo de trabajo, con conversación accesible y breve.
En inicio: identidad discreta, tarea clara, compositor protagonista, contexto/centro/fuente visibles y
pocas sugerencias ejecutables. En resultado: conclusión acotada, evidencia visual y controles de exploración.
Evitar convertir todo el dashboard en una conversación larga o desplegar una pared de cards equivalentes.

## Estados visibles

Reposo → enviando → interpretando/consultando sólo si sucede → resultado, aclaración o fallo.
Mostrar progreso de trabajo real sin revelar ni simular cadena de pensamiento. No copiar THINK_MS=2100
ni el carrusel de frases temporizadas como prueba de trabajo real. Reemplazarlo con eventos del runtime.
Cancelar queda disponible en curso; errores y aclaraciones no se repliegan automáticamente.

La respuesta propone componentes registrados y enlaza fuentes. No cambia la sección por sorpresa.
Puede enfocar una entidad mediante acción explícita; si el usuario pidió navegar, esa petición ya autoriza
el foco correspondiente. Nunca mostrar evidencia del centro anterior como si perteneciera al actual.

## Calidad

Mantener composer, orbe, dock y contenido en una misma jerarquía de material y ritmo. Orbe exclusivo
de IA; no convertir cada control en un botón luminoso. El estado ocupado se distingue por texto, no
sólo por giro. La animación no retrasa datos listos ni reacomoda la UI con cada token.
Verificar primera pregunta, seguimiento, datos parciales, respuesta extensa, error, cancelar y volver.

Índice de código y assets: [references/INDICE.md](references/INDICE.md).

Antes de adaptar, leer [storyboard y composición implementable](references/storyboard.md).
