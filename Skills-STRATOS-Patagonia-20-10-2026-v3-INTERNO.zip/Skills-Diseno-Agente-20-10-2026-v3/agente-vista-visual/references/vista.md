# Anatomía de la vista y coreografía

## Tres composiciones

Inicio: centro de lectura despejado, pregunta principal/compositor, contexto persistente y sugerencias
pertinentes a capacidades conectadas. Sin cifras falsas de bienvenida. Si ya existe selección del mapa,
el agente inicia sobre ella; no reinicia entidad ni periodo sin acción del usuario.

Trabajando: conserva consulta y contexto; muestra verbo real de tarea («Consultando observaciones»)
y cancelar. Skeleton sólo donde llegarán datos; no borrar toda la vista. Si dura, mostrar fuente pendiente
y permitir continuar con evidencia parcial. No fingir porcentajes de progreso sin medición.

Resultado: una conclusión principal con periodo/entidad; uno o dos instrumentos pertinentes; evidencia
y límites; acciones de seguimiento que realmente se pueden ejecutar. El dock queda accesible y no tapa
ejes, leyendas o controles de video. Un resultado parcial se ve terminado como UI, con límite explícito.

## Contrato del compositor

Enter envía, Shift+Enter nueva línea, respetar composición IME. Etiqueta accesible, enviar deshabilitado
si vacío, texto preservado ante fallo recuperable. El botón pasa a detener durante trabajo. Foco visible
y devolución de foco al terminar o al cerrar panel. aria-live polite sólo para cambios significativos;
no anunciar cada fotograma ni fragmentos repetidos. Evidencia expandible con teclado.

## Coreografía de nuevas piezas

Hover 120 ms; dock/panel 200–280 ms; cambio de evidencia 180–240 ms. Entrada corta de contenido
con opacidad y 4–8 px de desplazamiento; carcasa conserva posición. Una revelación inicial contenida
puede ser más expresiva; consultas repetidas no repiten toda la entrada. Sin rebotes funcionales.
Si comparte lienzo STRATOS, usar stageTiming/fadeFlight para sus transiciones existentes.

Orbe: identidad y estado ocupado. Animar transform/opacity, no filtros enormes; pausar al ocultar
pestaña/panel. No mostrar «pensando» cuando se está esperando red ni etiquetar mock como inferencia.
Reduced-motion mantiene estados con texto y cambios instantáneos/discretos.

## Tabla de actualización

| Evento | Cambia | Conserva |
|---|---|---|
| Nueva consulta | turno, evidencia pertinente | contexto elegido y estructura |
| Cambio de centro | selección/contextVersion | pregunta en borrador; historial separado |
| Filtro temporal | periodo y evidencia recalculada | entidad y capacidad conectada |
| Respuesta tardía | nada si contextVersion no coincide | vista actual |
| Fallo de fuente | aviso y estado parcial | datos anteriores con fecha/etiqueta propia |
| Cerrar video | panel y reproducción | escena/centro y timestamp seleccionado |

## Referencia Patagonia frente a adaptación

AgentHome/AgentDock/AgentOrb/AvisoAgente son mecánicas valiosas. Urbanist, StatementCard azul,
rejilla de puntos, numeral fino y decimales grises pertenecen a su perfil. Si se usa STRATOS, conservar
Source Sans 3 y semántica cromática; adoptar composición y mecánicas sin mezclar marcas.
No copiar arrays NAV, métricas empresariales, datos sintéticos ni temporizadores de demo a producción.
