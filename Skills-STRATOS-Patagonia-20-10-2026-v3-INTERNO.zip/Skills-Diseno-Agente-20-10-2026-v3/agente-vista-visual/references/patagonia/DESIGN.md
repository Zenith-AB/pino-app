# Patagonia ERP · sistema de diseño operativo

Actualizado: 5 de octubre de 2026. Este documento gobierna el tablero del Agente, Ventas, Rentabilidad, Cobranza, Inventario, Reportes y Vistas guardadas. La demostración conserva sus datos rotulados; UCI Online Retail II conecta el Agente y Ventas a PostgreSQL para probar el recorrido completo. El propósito es ayudar a decidir y actuar con contexto. La fuente y Clef-Flash se describen en el [traspaso técnico](datos_prueba/CONTEXTO_PARA_SIGUIENTE_AGENTE.md).

**Regla cero:** la vista del agente («Ventas por sucursal») es la referencia interna. Sus numerales finos con decimales en gris, el fondo de puntos del gráfico, la franja de hitos y las tarjetas translúcidas son el lenguaje que las demás vistas heredan. Ninguna vista contradice esa vista; si algo nuevo funciona mejor, se lleva también al agente.

**Tablero UCI del Agente.** Conserva la composición de tres columnas, las familias de tarjetas, el gráfico central y la superficie azul del Agente. Clef solo puede elegir `periodo`, `comparacion`, `listado` y `foco` del catálogo validado; no entrega componentes, colores, HTML, posiciones ni cifras. Una respuesta válida se aplica sin confirmación y las cifras se vuelven a consultar a PostgreSQL. Durante la consulta solo se atenúan las cifras, el gráfico y el detalle que cambian; la estructura permanece visible. Si falla la actualización, se conservan los datos previos con un aviso explícito. El chat se repliega al dock después de responder para dejar el tablero legible. La demostración conserva su tablero y no mezcla sus cifras con UCI.

## 1. Investigación y referencias

La investigación sobre jerarquía de indicadores y recorridos en SAP S/4HANA, Oracle Fusion y Dynamics 365 está en [ERP_KPI_RESEARCH.md](ERP_KPI_RESEARCH.md). Sus rankings son hipótesis para validar con responsables comerciales e industriales antes de alterar esta interfaz. Las fuentes de datos candidatas están en [ERP_DATASET_RESEARCH.md](ERP_DATASET_RESEARCH.md) y el MER transaccional en 3FN con arquitectura políglota propuesta está en [ARQUITECTURA_DATOS.md](ARQUITECTURA_DATOS.md).

Los casos de RonDesignLab son relatos del estudio: sus porcentajes de mejora no son mediciones independientes ni metas de Patagonia. Distinguimos lo que muestran de la decisión que tomamos.

| Fuente | Qué muestra | Decisión para Patagonia |
| --- | --- | --- |
| [Geotab Insurance](https://rondesignlab.com/cases/geotab-insurance-saas-dashboard-ux-ui-design) | Cuatro colores con función: casi negro, blanco, gris claro y **un solo azul vibrante** que marca marca y atención. Bloques azules grandes con tarjeta de vidrio esmerilado encima de un dibujo lineal. Barras grises rayadas = antes/histórico, azul sólido = después/actual; valor sobre una línea-tapa con marcador cuadrado. Matrices de puntos para densidad de riesgo. Etiquetas negras «■ Market Size». | Un azul, un verde, un naranja. Rayado = comparación, proyección o tránsito; sólido = dato actual. Su vidrio sobre azul se probó y se descartó; la superficie azul usa la tarjeta del agente (`StatementCard`). Matriz de puntos para antigüedad de cartera. |
| Sankey de referencia (azul → verde → naranja) | Flujos con degradado del color de origen al de destino; nodos rectos con etiqueta dentro. | `Sankey`: estado de resultados (venta → EBITDA) y movimientos de inventario. Lo que cae hacia abajo es deducción o pérdida, en naranja. |
| Barras «Historical vs. Projected» | Pares de columnas: rayado gris y azul sólido, eje con extremos marcados, valor grande sobre la barra. | `Columns` pareadas: 2025 vs. 2026 por trimestre, 2T vs. 3T por sucursal. |
| Daxa «Overview Panel» | Histogramas de líneas finas con un tick destacado; medidor de ticks; tarjeta de insight glass apilada. | `TickBars` (recaudación diaria con promedio móvil) y `TickGauge` (meta del trimestre). |
| Payments «funnel» | Columnas de etapa con encabezado y valor; barras rayadas unidas por bandas; la etapa elegida en azul con degradado; tooltip glass en píldora «48,6k · Conversión 89 % · Caída −11 %». | `Funnel` en Cobranza y el formato de todas las etiquetas hover (`Tip`). |
| [Salesforce CRM](https://rondesignlab.com/cases/salesforce-crm-saas-software-ux-ui-design) | Números grandes y finos, una pieza dominante, poco color intenso. Su stepper de etapas funciona porque describe un proceso real de venta. | Tomamos la escala tipográfica. **No** copiamos el stepper con checks: los trimestres no son etapas. Se reemplazó por columnas 2025/2026 con la meta del 4T rayada. |
| [xTiles CRM](https://rondesignlab.com/cases/xtiles-crm-resource-saas-ui-ux-design) | Filas-píldora con contadores «! 24» y lista → foco. | Inventario: lista de SKU críticos con píldoras de stock y fecha de quiebre; elegir uno cambia la proyección. |
| [Katana MRP](https://rondesignlab.com/blog/work-in-progress/katana-mrp-production-management-web-dashboard-and-ux-ui-design), [NetSuite](https://rondesignlab.com/cases/netsuite-crm-dashboard-ui-ux-design) | Estado → excepción → entidad; stock de seguridad y reposición visibles. | Cobranza agrupa por día; Inventario muestra stock proyectado contra punto de pedido y stock de seguridad. |

### Lecciones de esta ronda (correcciones del usuario)

1. **Gráficos genéricos = feos.** Dumbbells sobre azul, barras horizontales planas y bullets repetidos se leían como plantilla. Cada tarjeta usa una forma con carácter (rayado/sólido, puntos, ticks, flujo) y la forma responde a la pregunta.
2. **Nada de checks decorativos.** Se quitaron el stepper con ✓, los ✓/! dentro de anillos y chips. El estado se dice con color de marca + texto.
3. **El tiempo en Inventario es la proyección de stock**, no un Gantt de barras: día a día, cuándo llega a cero y cuándo entra la recepción.
4. **Un inventario debe parecer un inventario:** SKU, unidades, venta diaria, punto de pedido, stock de seguridad, órdenes de compra, movimientos entre bodegas. El plano de racks con porcentajes no respondía ninguna pregunta y se retiró.
5. **Demasiados azules y verdes.** Había `#0B2FC2`, `#B1C1FF`, `#DFE6FF`, `#E0E8FF`, `#007A4D`, `#99E7CA`, `#D6F5EA`, `#FFD2B9`… Ahora existe uno de cada uno; lo demás es transparencia.

## 2. Propósito y flujos

Patagonia sirve a responsables comerciales, finanzas y bodega. En una visita breve deben responder **qué cambió, dónde, cuánto importa y qué hago ahora**.

| Área | Pregunta | Recorrido |
| --- | --- | --- |
| Ventas | ¿Qué parte de pedidos y ventas se aparta de la meta? | Período → órdenes y trimestres → canal/meta → sucursal/vendedor. |
| Rentabilidad | ¿Dónde se pierde margen frente al trimestre anterior y la meta? | Margen por sucursal → brecha → venta a EBITDA → descuentos y categorías. |
| Cobranza | ¿Qué recuperamos, qué vence pronto y qué caso exige atención? | Embudo de recuperación → semana → día → cliente → antigüedad y acciones. |
| Inventario | ¿Qué SKU se quedará sin stock antes de recibir reposición? | SKU crítico → proyección y recepción → movimientos → cobertura y recepciones. |
| Reportes | ¿Qué información necesito y con qué contexto? | Solicitud → parámetros → revisión → generación o programación cuando exista soporte real. |

El mismo dato conserva período, unidad y denominador al ir del resumen al detalle. Un control sin efecto no debe prometer operaciones: se elimina, se deshabilita con motivo o se convierte en navegación verificable.

## 3. Color, superficies y tipografía

### Paleta única

| Token | Valor | Función |
| --- | --- | --- |
| `--blue` | `#1F4FFF` | Marca, navegación, selección, serie actual, ancla sólida. **El único azul.** |
| `--green` | `#00C27A` | Cumplimiento, mejora, resultado favorable (margen, EBITDA, ventas en el flujo). **El único verde.** |
| `--orange` | `#F26722` | Riesgo, atraso, quiebre, deducción o pérdida (descuentos, costo, merma, bajo la meta). **El único naranja.** |
| `--ink`, `--ink-2`, `--ink-3` | `#171922`, `#596273`, `#687386` | Texto principal, secundario y ejes. |
| Neutros `--n-*` | `#F5F7FA` … `#CDD4DE` | Fondo, pistas, rejillas. |

- Cualquier matiz adicional es `color-mix()` o `rgba()` de esos tres (p. ej. `--blue-100`, rayados, bandas). En JS se usa `tint(P.blue, α)` de `src/palette.js`; nunca un hex nuevo.
- **Texto de color:** verde y naranja no alcanzan 4,5:1 sobre blanco. El texto va en tinta; el color lo lleva una marca (flecha ▲▼, cuadrado, línea, anillo). El azul sí puede ir en texto.
- Sobre verde o naranja se escribe en tinta; sobre azul, en blanco.
- Degradados solo con significado: barras rayadas (Payments), transición origen → destino en el Sankey, columna elegida del embudo y relleno suave bajo las curvas. **Todo lo demás es plano**: barras sólidas, waffle, leyendas, barra de canales, desviaciones, nodos, filas elegidas. Nada de brillos ni sombras de color bajo elementos, y nunca mezclas con tinta oscura (ensucian naranjas y verdes).

### Superficies

- Fondo frío `#F5F7FA`; tarjetas blancas translúcidas (`--tile-bg`, como las del agente).
- **Una sola superficie saturada por vista**: la `StatementCard`, que usa el mismo lenguaje que la tarjeta del agente: bloque azul plano; título y subtítulo arriba; avance en dos trazos finos a la derecha; aire; fila de contexto con iniciales; frase grande en dos pesos (líneas ligeras + cierre regular) y aro con flecha para la acción. En Ventas, la superficie azul es la tarjeta de órdenes. Se descartó el bloque con tarjeta de vidrio y dibujo lineal: el usuario lo rechazó.
- **Glass** en todo lo que aparece con hover: `Tip` (píldora con segmentos separados por «|», sigue al cursor), tooltips de Highcharts (`.hc-card`, `.hc-tip`), popover de hitos y chips de recepción. Fondo `rgba(255,255,255,.56)`, `backdrop-filter: blur(14px) saturate(170%)`, borde blanco 82 %, sombra suave. Sobre azul, variante oscura al 16 %.

### Marca e identidad de la IA

- **Marca:** «Patagonia ERP» con Patagonia en peso regular (420, tinta) y ERP liviano (300, gris), 1,4 rem, junto al logo de 3 rem. El logo no lleva sombra (queda «pegado» a la página) y usa el mismo radio y esquina continua que las tarjetas.
- **Logo «Cumbre»** (`Logo` en `Icons.jsx`, `public/favicon.svg`, `public/patagonia-erp-logo.svg`): baldosa azul con una cresta de dos agujas en línea blanca (ambas bases en la misma línea, valle marcado); la cumbre derecha, más alta, es un nodo verde (dato o hallazgo). Se probaron y descartaron la montaña rellena con sol (ícono universal de «imagen») y las agujas facetadas (al usuario le gusta la versión de línea). Se lee a 16 px y sobre fondo oscuro.
- **Orbe del agente:** degradado azul → verde con luz especular, sombra interior y sombra exterior bicolor (`.orb`, `.circle-btn.ai`). Es la firma exclusiva de toda acción de IA (compositor, dock, prompt de reportes, «Crear con el agente», «Preguntar» en filas). Ningún otro botón usa degradado ni relieve; así la IA se reconoce de un vistazo. El degradado del orbe fluye en diagonal hacia la esquina inferior derecha bajo un brillo fijo (7 s, bucle sin cortes; se detiene con «reducir movimiento»).
- **Avatares de personas** (`Avatar` en `Kit.jsx`): base azul ↔ verde, con orientación estable según el nombre y relieve ligero. Sin naranja. Los participantes agrupados llevan un único contorno blanco de 1 px para separarlos. Solo perfiles (usuario, participantes, vendedores, dueños de vistas); sucursales, clientes y SKU usan iniciales planas, y el agente, su orbe.

### Tipografía

Urbanist Variable. Números principales en peso 240–300 con **decimales en gris** (`<Num>`, igual que los KPI del agente). Título de vista en dos pesos.

**Tamaño mínimo de texto: `--fs-min` = 0,8 rem** (12 px en la raíz mínima de 15 px, ~17 px en 4K). Ningún texto visible —ejes, unidades, leyendas, chips, avatares, tooltips— baja de ese valor; si no cabe, crece el contenedor o se omite el dato secundario (queda en el tooltip). El texto SVG que se escala con `viewBox` se pasa a HTML. Única excepción: el «®» de la marca. Se verifica recorriendo el DOM de todas las vistas a 390 y 1600 px. Cifras `es-CL`; `pp` para diferencias de tasas, `%` para participación, `MM$` para montos.

## 4. Gramática de gráficos

Antes de dibujar: pregunta, dato, unidad, período, escala y referencia. Todos los gráficos de vistas viven en `src/components/Charts.jsx`, se dibujan en SVG a tamaño real (sin deformar texto) y tienen `aria-label` con la conclusión.

**Convenciones comunes:** rayado = histórico, proyección, en tránsito; sólido = actual o confirmado. Valor con línea-tapa y marcador cuadrado. Base con puntos en los extremos. Meta en línea discontinua con su etiqueta fuera del área de barras. Rejilla punteada tenue. Barras crecen desde un cero común.

| Pregunta | Componente | Dónde |
| --- | --- | --- |
| ¿Cómo se compara este período con el anterior? | `Columns` pareadas (rayado gris vs. sólido) | Ventas por trimestre; margen por sucursal (sólido naranja si queda bajo la meta). |
| ¿Cómo se reparte cada semana/día? | `Columns stacked` | Órdenes cerradas/abiertas (sobre azul); recepciones confirmadas/en tránsito. |
| ¿Cómo evoluciona una tasa? | `HatchLine` (curva spline, área suave, tope, punto final) | Descuentos mensuales. |
| ¿Cómo se mueve semana a semana? | `SmoothTrend` (curva spline sobre rejilla de puntos, tramo anterior atenuado, meta, hover con guía) | Margen bruto semanal. |
| ¿Cómo se transforma un total? | `Sankey` de nodos finos, etiquetas afuera con valor y % del total, flujos al 18 % | Venta bruta → EBITDA (media fila); entradas → bodegas → salidas. |
| ¿Dónde se pierde en un proceso? | `Funnel` (etapa elegida en azul, glass con conversión y caída) | Recuperación de cartera vencida. |
| ¿Cuánto pesa cada tramo? | `DotField` (gráfico de unidades: 1 punto = 2 MM$, tramos de igual ancho) | Antigüedad de la cartera. |
| ¿Cómo se comporta el día a día? | `TickBars` (ticks finos, mes destacado, mejor día en verde, promedio móvil) | Recaudación diaria. |
| ¿Cuánto de la meta? | `TickGauge` (ticks azules, exceso en verde, meta marcada) | Meta del trimestre. |
| ¿Qué parte del todo? | `Waffle` 20×5 o `SplitBar` | Clientes recurrentes; venta por canal. |
| ¿Sobre o bajo la meta? | `Deviation` (cero = meta) | Margen por categoría. |
| ¿Dentro del rango sano? | `RangeRows` (banda verde, marca al valor) | Cobertura por categoría. |
| ¿Cuándo me quedo sin stock? | `StockProjection` (real sólido, proyección discontinua, azul→naranja bajo seguridad, rayado sin stock, recepciones con píldora, stock de seguridad en el eje) | Inventario por SKU. |

**Curvas:** toda tendencia usa spline Catmull-Rom (`spline()` en SVG, `spline`/`areaspline` en Highcharts): curvas suaves, «senoidales», que pasan por cada dato y no cruzan la base. Excepción: la proyección de stock, cuyo descenso es lineal y cuyas recepciones son saltos verticales reales.

Evitar: arcos como comodín, checks decorativos, barras sin cero, gradientes de volumen, áreas decorativas, comparaciones con escalas distintas, tarjetas pequeñas con el mismo dibujo.

### Detalle de ejecución (medido en la referencia Payments a 3×)

- **Barra rayada:** degradado diagonal de un solo tono, profundo arriba a la izquierda → vivo → casi blanco abajo; rayas blancas «/» de ~1,6 px cada ~8 px (escalan con la raíz). Rayado gris de Geotab: fondo `#EEF1F5`, líneas grises de 1 px y línea-tapa negra con cuadrado de 4 px.
- **Barra sólida:** degradado diagonal profundo → vivo → claro. Nunca plana ni con sombra.
- **Embudo:** cara lateral inclinada de la barra hacia la siguiente en azul translúcido con filete blanco; píldora brillante sobre cada barra no elegida; columna elegida con degradado vertical que se desliza (transform) al cambiar de etapa; encabezados grises salvo el elegido.
- **Tooltip:** píldora de 2,1 rem, degradado blanco → lavanda muy claro, borde blanco, anillo azul al 10 %, sombra azulada; segmentos `valor + etiqueta` separados por «|» gris; sigue al cursor y se voltea antes del borde. Sobre azul, la misma píldora en azul translúcido.
- **Etiquetas dentro del gráfico:** píldoras de 1,65 rem: oscura para «Hoy», naranja clara para «Sin stock», blanca con muestra rayada/sólida para recepciones, blanca para líneas de referencia. Las referencias (meta, tope) se rotulan en un margen derecho propio, nunca encima de las barras. Valores con halo del color de la tarjeta. Si dos etiquetas chocan, se desplaza la secundaria; si no hay espacio (móvil), se omite el valor comparativo y queda en el tooltip.
- **Geometría:** coordenadas enteras y líneas de 1 px en medio píxel: bordes nítidos a DPR 2 y 4K.

## 5. Interacción, estados y móvil

1. **Ver:** resumen con período y unidad; excepción antes de tabla completa.
2. **Entender:** hover en glass con valor, comparación y contexto (`Tip`).
3. **Elegir:** selección visible que cambia contenido (SKU → proyección, día → clientes, etapa → conversión).
4. **Actuar:** navegación a entidad, consulta al agente o función implementada. No mostrar envío/exportación/programación falsos.
5. **Volver:** conservar vista, período y selección cuando el recorrido lo permita.

**Movimiento del chat:** el dock mide 37 rem dentro de un contenedor de 42 rem; se levanta 10 px y crece 3,5 % al pasar el mouse, y se levanta 24 px y crece 7 % al recibir foco (con un anillo azul suave). Al volver al inicio, el dock se transforma en el compositor (morph); el compositor no reproduce su animación de entrada propia (dos animaciones a la vez producían un salto al final), y título y sugerencias solo aparecen con un fundido. Con movimiento reducido, las transiciones quedan desactivadas.

**Dashboard de agente en 1080p:** a 1536 px de ancho efectivo (1920×1080 con escala de Windows al 125 %) se conservan las tres columnas: decisión y conciliación, análisis, agente y sucursales. Entre 1451 y 1800 px las columnas laterales, los KPI y el titular del agente se compactan para reservar espacio legible al gráfico central. Por debajo de 1451 px el análisis ocupa una fila completa y las tarjetas secundarias pasan a dos columnas; en móvil se apilan.

En móvil se elige una entidad antes de ver detalle. Gráficos anchos (Sankey, embudo, margen por sucursal) se desplazan dentro de su tarjeta en lugar de comprimirse hasta ser ilegibles.

### Rendimiento (obligatorio)

Medido con trazas de Chrome a DPR 2 y CPU 4×. Tras esta ronda: script en hover −87 %, script al montar vistas −48 %, pintado en hover −61 %.

1. **Una animación de entrada por gráfico** (un grupo `scaleY` o una opacidad), iniciada por `IntersectionObserver` cuando el gráfico entra en pantalla. Nada de animaciones escalonadas por barra, celda o tick.
2. **SVG estático memorizado** (`useMemo`); el hover nunca re-renderiza ni repinta el SVG.
3. **Marcadores de hover en HTML** (`HoverBand`, `HoverLine`, velo) movidos con `transform`: los compone la GPU.
4. **Estado de hover solo al cambiar de elemento**; la posición del tooltip se escribe por `transform` en `requestAnimationFrame`.
5. **Sin `filter`/`drop-shadow` en SVG** ni `backdrop-filter` en superficies grandes. Brillos bajo nodos: `div` desenfocado con `will-change` (se rasteriza una vez).
6. **El SVG va en posición absoluta dentro de su contenedor**: el alto lo fija el CSS. Si el SVG participa del flujo, dos gráficos que se estiran en la misma fila se realimentan con el `ResizeObserver` y crecen sin fin.
7. Antes de entregar una vista, correr la medición de montaje/scroll/hover y comparar.

## 6. Contrato de implementación y revisión

- Paleta: `src/palette.js` (JS) y `:root` de `src/styles.css` (CSS). Highcharts toma la misma paleta en `src/components/highcharts.js`.
- Gráficos de vistas: `src/components/Charts.jsx`. Kit compartido (KPI, `Big`, `Num`, `StatementCard`, anillos, chips): `src/components/Kit.jsx`.
- Revisar con capturas a 390 px, 1600 px y 4K: etiquetas sin choques, hover glass legible, una sola superficie azul por vista.
- Contraste de texto ≥4,5:1, texto grande ≥3:1, controles ≥3:1. `aria-label` no repara un gráfico visualmente equívoco.
- Separar las cifras de demostración, las transacciones UCI (GBP o conversión analítica CLP) y el escenario sintético CLP. Nunca mezclar orígenes en una vista.

**Respuesta generada (6/10/2026).** El motor solo puede escoger una pestaña y variables de catálogos conocidos; un hallazgo verificado entra como texto en «Lectura del agente», sin crear tarjetas, alterar la rejilla ni cambiar los colores. El tablero mantiene las cifras anteriores atenuadas durante la actualización y revela las nuevas al terminar. Cada cifra declara escenario, período y moneda; el sintético nunca se rotula como dato real. El inicio del Agente conserva su iluminación suave y no muestra tarjetas resumen ni selector de escenario. Véase [orquestación de Clef](../servicios/clef/ORQUESTACION_ERP.md).
