import { esTableroEnlazado } from '../../../servicios/datos/src/tipos-escenario.js'
// Descripción de una propuesta de variables de Clef, compartida por la barra de variables y el chat.
import { VARIABLES_VENTAS } from '../../../servicios/datos/src/variables.js'
import { validarPresentacion } from '../../../servicios/datos/src/registro-cognitivo.js'
import { fmt } from './formato.js'

const rotulo = (variable, opcion, escenario) => esTableroEnlazado(escenario) && variable === 'listado' && opcion === 'paises'
  ? 'Sucursales' : VARIABLES_VENTAS[variable].opciones[opcion]?.rotulo ?? opcion
const sinPunto = (texto) => texto?.replace(/\.$/, '')

export function describirResolucion({ actual, anterior, motivo }) {
  return anterior ? `${actual} frente a ${anterior}` : `${actual} · ${sinPunto(motivo)}`
}

// respuesta: cuerpo de /variables/ventas/propuesta. Los cambios derivados no los propuso Clef: salen de la regla de
// coherencia (con foco en un país, el listado pasa a productos).
export function describirPropuesta(respuesta, solicitadas = respuesta.vigentes) {
  if (respuesta.response_plan?.presentacion) validarPresentacion(respuesta.response_plan.presentacion)
  const { cambios, variables } = respuesta.propuesta
  const filas = Object.entries(cambios).filter(([id]) => variables[id] !== solicitadas[id]).map(([id, c]) => ({
    id, nombre: VARIABLES_VENTAS[id].nombre, desde: rotulo(id, solicitadas[id], respuesta.escenario), hacia: rotulo(id, c.hacia, respuesta.escenario), nota: c.origen === 'calendario' ? 'fecha resuelta contra los registros y la cobertura' : `probabilidad relativa ${fmt(c.probabilidad, 2)}`,
  }))
  for (const id of Object.keys(VARIABLES_VENTAS)) {
    if (!cambios[id] && variables[id] !== solicitadas[id]) {
      filas.push({ id, nombre: VARIABLES_VENTAS[id].nombre, desde: rotulo(id, solicitadas[id], respuesta.escenario), hacia: rotulo(id, variables[id], respuesta.escenario), nota: 'consecuencia del cambio anterior' })
    }
  }
  const r = respuesta.resolucion.propuesta
  return {
    consulta: respuesta.consulta,
    filas,
    variables,
    vigentes: solicitadas,
    destino: respuesta.propuesta.destino ?? 'sin_cambio',
    intencion: respuesta.propuesta.intencion ?? 'navegar',
    analisis: respuesta.analisis ?? null,
    necesitaAclaracion: respuesta.propuesta.necesita_aclaracion ?? false,
    contexto: respuesta.contexto ?? null,
    // Solo un token firmado por el servidor; cualquier otra forma se ignora.
    vinculo: typeof respuesta.vinculo === 'string' ? respuesta.vinculo : null,
    versionDatos: respuesta.version_datos ?? null,
    decision: respuesta.decision ?? null,
    responsePlan: respuesta.response_plan ?? null,
    resultado: describirResolucion({ actual: r.actual, anterior: r.anterior, motivo: r.motivo_comparacion }),
    periodos: { actual: r.actual ?? null, anterior: r.anterior ?? null },
  }
}

// Una propuesta pertenece al escenario y a las variables con las que se pidió.
// Aplicarla tras un cambio manual reescribiría silenciosamente elecciones más recientes.
export function propuestaVigente(propuesta, escenarioId, actuales) {
  return propuesta?.escenarioId === escenarioId
    && Object.keys(VARIABLES_VENTAS).every((id) => propuesta.vigentes?.[id] === actuales[id])
}

export const NOTA_PROBABILIDAD = 'La probabilidad relativa compara solo las opciones ofrecidas; no es una confianza calibrada. Clef elige opciones del catálogo y no escribe cifras.'
