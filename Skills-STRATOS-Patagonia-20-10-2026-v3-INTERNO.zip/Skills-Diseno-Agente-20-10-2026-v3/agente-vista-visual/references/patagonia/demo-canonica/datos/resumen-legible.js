// Presentación compacta de la anotación existente. La evidencia y el chat permanecen exactos.
const formato = new Intl.NumberFormat('es-CL', { maximumFractionDigits: 2 })
const meses = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic']
function fecha(s) {
  const t=Date.parse(s)
  return Number.isFinite(t)&&new Date(t).toISOString().slice(0,10)===s ? {d:Number(s.slice(8)),m:Number(s.slice(5,7)),a:s.slice(0,4)} : null
}
const rotulo=f=>`${f.d} ${meses[f.m-1]} ${f.a}`
export function resumenLegible(original = '') {
  let texto=original.replace(/(\d{4}-\d{2}-\d{2}) a (\d{4}-\d{2}-\d{2})/g,(todo,a,b)=>{
    const x=fecha(a),y=fecha(b)
    if(!x||!y)return todo
    return x.a===y.a&&x.m===y.m?`${x.d}–${y.d} ${meses[x.m-1]} ${x.a}`:x.a===y.a?`${x.d} ${meses[x.m-1]}–${y.d} ${meses[y.m-1]} ${x.a}`:`${rotulo(x)}–${rotulo(y)}`
  }).replace(/\b\d{4}-\d{2}-\d{2}\b/g,s=>fecha(s)?rotulo(fecha(s)):s)
  texto=texto.replace(/(-?(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d+)?) CLP\b/g,(todo,n)=>{
    const valor=Number(n.replaceAll('.','').replace(',','.'))
    return Math.abs(valor)>=1e6?`${formato.format(valor/1e6)} millones CLP`:todo
  }).replace(/Ranking de (\w+) \((mayor a menor|menor a mayor)\):/g,(_,entidad,orden)=>`Ranking de ${entidad} ${orden==='mayor a menor'?'↓':'↑'} ·`)
    .replace(/Resto fuera del ranking:/g,'Resto:')
    .replace('Datos del escenario sintético; no representan una empresa real.','Datos sintéticos · no representan una empresa real.')
  const patron=/(-?[\d.,]+ (?:millones CLP|CLP|unidades|%))/g
  return {texto,partes:texto.split(patron).filter(Boolean).map(t=>({texto:t,destacado:/^-?[\d.,]+ (?:millones CLP|CLP|unidades|%)$/.test(t)}))}
}
