import { ThemeToggle, useTheme } from './components/ThemeToggle.jsx'
import { addTransitionType, startTransition, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { DASHBOARD, NAV } from './data.js'
import { FIRST_REPLY, message, replyTo } from './agent.js'
import { AgentCard, AnalyticsCard, BRANCH_LIST, BranchCard, DecisionCard, DetailCard, METRIC_LIST, MetricCard, ReconCard } from './components/Cards.jsx'
import { AgentDock, AgentHome, AvisoAgente, HistorialChat } from './components/AgentChat.jsx'
import { useHistorial, tituloConversacion, leerConversacionGuardada, guardarConversacion } from './datos/historial.js'
import { sugerenciasIniciales } from '../../servicios/datos/src/sugerencias-cognitivas.js'
import { ArrowLeft, Logo } from './components/Icons.jsx'
import { Avatar, Tile, KpiStrip } from './components/Kit.jsx'
import { Columns, nf } from './components/Charts.jsx'
// Tarjeta angosta: los mismos códigos de dos letras de las listas de sucursales; el nombre va en el tooltip.
import { iniciales } from './datos/ventas.js'
import { CollectionsView, InventoryView, ProfitView, ReportsView, SalesView, SavedView } from './components/Views.jsx'
import { SelectorEscenario } from './components/Escenario.jsx'
import { ProveedorEscenario, useEscenario } from './escenario.jsx'
import { ProveedorVariables, VariablesVista, useVariables } from './components/Variables.jsx'
import { ConversationSupervisor, controlTurn, newTurnId } from '../../servicios/datos/src/supervisor-conversacion.js'
import { propuestaVigente } from './datos/propuesta.js'
import { ProveedorModelos, useModelos } from './datos/modelos.jsx'

import { perfilLectura } from '../../servicios/datos/src/perfiles-lectura.js'
import { seleccionarPanorama } from './datos/panorama-general.js'
import { respuestaDelModelo } from './datos/resumen-agente.js'
import { precargarClef } from './datos/api.js'
import { cargarGraficos, ocultarTablero, revelarTablero } from './components/GraficosDiferidos.jsx'

// Índice de NAV → vista (0 es el agente)
const VIEWS = [null, SalesView, ProfitView, CollectionsView, InventoryView, SavedView, ReportsView]

const THINK_MS = 2100

function InicioDatos({ usuario, onStart, phase, messages, onStop, sugerencias = [] }) {
  const contenido = {
    title: perfilLectura(usuario.perfil_lectura)?.pregunta ?? '¿Qué quieres analizar hoy?',
    placeholder: 'Pregunta por ventas, margen, cobranza o inventario',
    sources: 'Pregúntale a Patagonia',
    note: perfilLectura(usuario.perfil_lectura)?.nombre ?? null,
    suggestions: sugerencias.map(s => s.texto),
  }
  return <AgentHome phase={phase} messages={messages} onStart={onStart} onStop={onStop} usuario={usuario} contenido={contenido} />
}

export default function App(props) {
  return <ProveedorEscenario><ProveedorVariables key={props.usuario.perfil_lectura ?? "sin_perfil"}><ProveedorModelos perfil={props.usuario.perfil_lectura}><Aplicacion {...props} /></ProveedorModelos></ProveedorVariables></ProveedorEscenario>
}

function Aplicacion({ usuario, onLogout, onPerfil }) {
  useTheme()
  const [cambiandoPerfil, setCambiandoPerfil] = useState(false)
  const [errorPerfil, setErrorPerfil] = useState('')
  async function cambiarPerfil(event) {
    setCambiandoPerfil(true); setErrorPerfil('')
    const id = event.target.value, perfil = perfilLectura(id)
    try {
      if (perfil?.escenarios && !perfil.escenarios.includes(escenario?.id)) {
        const fuente = disponibles.find(e => perfil.escenarios.includes(e.id))
        if (!fuente) throw new Error('La base lechera no está disponible. No se pudo activar este perfil.')
        await onPerfil(id)
        elegir(fuente.id)
      } else await onPerfil(id)
    } catch (e) { setErrorPerfil(e.message) }
    finally { setCambiandoPerfil(false) }
  }
  const { escenario, demostracion, errorServicio, disponibles, elegir } = useEscenario()
  const { variables, proponer, aplicarPropuesta, registrarDecision, limpiarContexto, respuesta } = useVariables()
  const sugerencias = respuesta?.responsePlan?.sugerencias ?? []
  const { modelos, consulta, metricasGrafico } = useModelos()
  const panorama = seleccionarPanorama(modelos?.agente, escenario ? respuestaDelModelo(respuesta, modelos?.agente, escenario) : null, metricasGrafico)
  const rankingSucursales = modelos?.agente?.resumenDatos?.sucursales
  const sucursales = rankingSucursales?.filas ?? []
  const [nav, setNav] = useState(0)
  // home: inicio del chat · thinking: el agente arma la vista · view: vista completa con el chat en el pie
  const [phase, setPhase] = useState('home')
  const clefEnChat = Boolean(escenario && !demostracion && nav <= 4 && (nav !== 0 || phase === 'view'))
  const [messages, setMessages] = useState([])
  const historial = useHistorial(usuario.id_usuario, escenario?.id ?? 'demostracion')
  // Guarda el registro de la conversación de la fuente activa. El primer render tras restaurar no escribe: aún
  // tendría los mensajes de la fuente anterior.
  const restaurandoRef = useRef(true)
  useEffect(() => {
    if (restaurandoRef.current) { restaurandoRef.current = false; return }
    if (escenario?.id && !demostracion) guardarConversacion(usuario.id_usuario, escenario.id, messages)
  }, [messages]) // eslint-disable-line react-hooks/exhaustive-deps
  // Turno que abrió cada conversación → su entrada del historial
  const entradasRef = useRef(new Map())
  const VISTAS_HISTORIAL = ['agente', 'ventas', 'rentabilidad', 'cobranza', 'inventario', 'vistas', 'reportes']
  const abrirEntrada = (pregunta, turnId) => { const id = historial.registrar(pregunta, { vista: VISTAS_HISTORIAL[nav] ?? 'agente', periodo: modelos?.periodo ?? null }); if (turnId) entradasRef.current.set(turnId, id); return id }
  const cerrarEntrada = (turnId, datos) => { const id = entradasRef.current.get(turnId); if (!id) return; entradasRef.current.delete(turnId); historial.cerrar(id, datos) }
  const [open, setOpen] = useState(false)
  const [typing, setTyping] = useState(false)
  const [diagnostico, setDiagnostico] = useState(null)
  // La respuesta conectada vigente (reevaluada con datos y filtros actuales) manda sobre la del último turno.
  const analisisVivo = (respuesta?.analisis ?? null) || diagnostico
  // Si el inicio aparece desde el dock, el morph ya lo mueve: sin animación de entrada propia (evita el salto)
  const [fromDock, setFromDock] = useState(false)
  const timers = useRef([])
  const navRef = useRef(null)
  const appRef = useRef(null)
  const navigationRef = useRef(0)
  const animationRef = useRef(null)
  const solicitudRef = useRef(0)
  const supervisorRef = useRef(null)
  const contextoRef = useRef(null)
  contextoRef.current = { escenarioId: escenario?.id, variables }

  // Animar la página real al cambiar de sección, sin capturas de ViewTransition que retengan datos viejos.
  // Solo la sección: la llegada de datos nuevos no vuelve a desvanecer el tablero.
  useLayoutEffect(() => {
    animationRef.current?.cancel()
    const page = appRef.current?.querySelector('main.page')
    if (!page || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const duration = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--duration-enter')) || 210
    animationRef.current = page.animate([{ opacity: 0, transform: 'translateY(0.35rem)' }, { opacity: 1, transform: 'none' }], { duration, easing: 'cubic-bezier(0.2, 0.7, 0.2, 1)' })
    return () => animationRef.current?.cancel()
  }, [nav])

  // Indicador de la sección activa: una sola píldora que se desliza entre pestañas.
  const [pill, setPill] = useState(null)
  useLayoutEffect(() => {
    const bar = navRef.current
    if (!bar) return undefined
    const measure = () => {
      const active = bar.querySelector('.is-on')
      if (!active) return
      // Medidas fraccionarias: la píldora calza exacto con el botón.
      const a = active.getBoundingClientRect(), b = bar.getBoundingClientRect()
      setPill((prev) => ({ x: a.left - b.left + bar.scrollLeft, w: a.width, ready: Boolean(prev) }))
    }
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(bar)
    return () => observer.disconnect()
  }, [nav])

  useEffect(() => {
    solicitudRef.current += 1
    supervisorRef.current?.interrupt()
    supervisorRef.current = null
    // Cambiar de fuente no olvida el vínculo de cada fuente: al volver, su respuesta conectada se reevalúa.
    limpiarContexto({ olvidarVinculo: false })
    // La conversación de cada fuente se restaura junto con su vínculo: el chat abre con su registro.
    restaurandoRef.current = true
    setMessages(demostracion || !escenario?.id ? [] : leerConversacionGuardada(usuario.id_usuario, escenario.id).map((m) => message(m.role, { text: m.text, ...(m.propuesta && { propuesta: m.propuesta }) })))
    setTyping(false)
    setOpen(false)
    setPhase('home')
    setDiagnostico(null)
    clearTimers()
  }, [escenario?.id])

  useEffect(() => () => { supervisorRef.current?.interrupt(); supervisorRef.current = null; clearTimers() }, [])

  // Highcharts va en un chunk aparte: se pide tras el primer render del inicio, antes de que haga falta el tablero.
  useEffect(() => { cargarGraficos() }, [])

  // Al volver al Agente con el tablero conservado: ajustar tamaño y reproducir la entrada de los gráficos antes de pintar.
  const tableroRef = useRef(null)
  const tableroVisible = !VIEWS[nav] && phase === 'view'
  // Contenedor del portal del tablero: se inserta en el anfitrión (antes que los efectos de layout del tablero, por
  // orden de commit entre hermanos) y se retira cuando el anfitrión se desmonta.
  const contenedorTablero = useMemo(() => Object.assign(document.createElement('div'), { className: 'tablero-portal' }), [])
  const anfitrionTablero = useCallback((nodo) => { if (nodo) nodo.appendChild(contenedorTablero); else { ocultarTablero(contenedorTablero); contenedorTablero.remove() } }, [contenedorTablero])
  // Oculto, el tablero recibe el mismo elemento del último render: React omite reconciliarlo al cambiar de sección.
  // Sus componentes siguen actualizándose por contexto (datos, filtros) y al volver se renderiza con props vigentes.
  const tableroElemento = useRef(null)
  if (phase !== 'view') tableroElemento.current = null
  // Solo el MISMO nodo que quedó oculto se revela; un tablero recién montado ya anima su entrada por sí mismo.
  const tableroRetenido = useRef(null)
  useLayoutEffect(() => {
    if (!tableroVisible) { tableroRetenido.current = tableroRef.current; return }
    if (tableroRef.current && tableroRef.current === tableroRetenido.current) revelarTablero(tableroRef.current)
    tableroRetenido.current = null
  }, [tableroVisible])

  // Con una fuente conectada, Clef se precarga al abrir y al volver a la pestaña.
  useEffect(() => {
    if (!escenario || demostracion) return undefined
    precargarClef()
    const alVolver = () => { if (document.visibilityState === 'visible') precargarClef() }
    document.addEventListener('visibilitychange', alVolver)
    return () => document.removeEventListener('visibilitychange', alVolver)
  }, [escenario, demostracion])

  useEffect(() => {
    const alignActive = () => {
      if (window.innerWidth > 760) return
      const bar = navRef.current
      const active = bar?.querySelector('.is-on')
      if (active) bar.scrollTo({ left: active.offsetLeft - bar.offsetLeft - (bar.clientWidth - active.clientWidth) / 2, behavior: 'smooth' })
    }
    alignActive()
    window.addEventListener('resize', alignActive)
    return () => window.removeEventListener('resize', alignActive)
  }, [nav])

  const later = (fn, ms) => timers.current.push(setTimeout(fn, ms))
  const clearTimers = () => { timers.current.forEach(clearTimeout); timers.current = [] }

  function start(prompt) {
    if (!demostracion) {
      // Reutilizar la espera del chat; la respuesta de Clef habilita la vista.
      setPhase('thinking')
      setFromDock(false)
      window.scrollTo({ top: 0 })
      sendClef(prompt, true)
      return
    }
    setFromDock(false)
    const entrada = abrirEntrada(prompt)
    setMessages([message('user', { text: prompt })])
    setPhase('thinking')
    later(() => historial.cerrar(entrada, { estado: 'respondida' }), THINK_MS)
    later(() => startTransition(() => {
      addTransitionType('agent-dock')
      setMessages((list) => [...list, message('agent', FIRST_REPLY)])
      setPhase('view')
    }), THINK_MS)
  }

  function stop() {
    solicitudRef.current += 1
    supervisorRef.current?.interrupt()
    supervisorRef.current = null
    limpiarContexto({ olvidarVinculo: false })
    setTyping(false)
    setOpen(false)
    clearTimers()
    setMessages([])
    setPhase('home')
  }

  // Clef elige variables del catálogo; si la respuesta sigue vigente se aplican al tablero de inmediato.
  function procesarClef(prompt, desdeInicio = false, signal, turnId, requestId) {
    const solicitud = ++solicitudRef.current
    const escenarioId = escenario?.id
    const desdeAgente = nav === 0
    setOpen(true)
    setTyping(true)
    return contextoRef.current.proponer(prompt, { signal, turn_id: turnId, vista: ['agente', 'ventas', 'rentabilidad', 'cobranza', 'inventario'][nav] ?? 'agente', anterior: messages.filter((m) => m.role === 'user').at(-1)?.text })
      .then((propuesta) => {
        if (signal.aborted || solicitud !== solicitudRef.current || escenarioId !== contextoRef.current.escenarioId) return { status: 'answer', state_after: {} }
        if (!propuestaVigente(propuesta, escenarioId, contextoRef.current.variables)) {
          setMessages((list) => [...list, message('agent', { text: 'Las variables cambiaron mientras procesaba tu pedido. Vuelve a pedir el ajuste con la vista actual.' })])
          if (desdeInicio) setPhase('conversation')
          else if (desdeAgente) { setOpen(true) }
          return
        }
        registrarDecision(propuesta)
        const aplicada = !propuesta.necesitaAclaracion && propuesta.filas.length > 0 && aplicarPropuesta(propuesta)
        cerrarEntrada(turnId, { estado: propuesta.necesitaAclaracion ? 'aclaracion' : aplicada ? 'aplicada' : 'respondida', dominio: propuesta.decision?.dominio ?? null, titulo: propuesta.necesitaAclaracion ? null : tituloConversacion(propuesta) })
        if (propuesta.analisis) setDiagnostico(propuesta.analisis)
        // El preset del resultado describe cómo representarlo; no autoriza navegar.
        // Al pasar al tablero, el compositor del inicio se guarda en el dock del pie.
        if (desdeInicio) {
          if (propuesta.necesitaAclaracion) setPhase('conversation')
          else startTransition(() => { addTransitionType('agent-dock'); setPhase('view') })
        }
        const texto = propuesta.analisis?.texto ?? (aplicada
          ? 'Ajusté estas variables del tablero con Clef. Los indicadores se recalculan desde el dataset:'
          : propuesta.filas.length
            ? 'Las variables cambiaron mientras procesaba la consulta. Repite el pedido con el tablero actual.'
            : 'No identifiqué un cambio de período, comparación, listado o foco; mantengo el tablero actual.')
        setMessages((list) => [...list, message('agent', { text: texto, turn_id: turnId, request_id: requestId, state_version: supervisorRef.current?.version + 1, propuesta: aplicada ? { ...propuesta, estado: 'aplicada' } : null })])
        // La respuesta queda a la vista en el chat compacto; solo al pasar del inicio al tablero se guarda.
        if (propuesta.necesitaAclaracion) setOpen(true)
        else if (desdeInicio) setOpen(false)
      })
      .catch((error) => {
        cerrarEntrada(turnId, { estado: 'error' })
        if (!signal.aborted && solicitud === solicitudRef.current && escenarioId === contextoRef.current.escenarioId) {
          if (desdeInicio) setPhase('conversation')
          else if (desdeAgente) { setOpen(true) }
        }
        error.user_message = `${error.message} Conservo las variables actuales y los datos visibles.`
        throw error
      })
      .then(() => ({ status: 'answer', state_after: {} }))
  }

  contextoRef.current.proponer = proponer
  contextoRef.current.procesarClef = procesarClef

  function sendClef(prompt, desdeInicio = false) {
    const turnId = newTurnId()
    // Solo la primera pregunta abre una conversación en el historial; las siguientes la continúan.
    if (!messages.length) abrirEntrada(prompt, turnId)
    setMessages((list) => [...list, message('user', { text: prompt, turn_id: turnId })])
    if (!supervisorRef.current) supervisorRef.current = new ConversationSupervisor({
      actor: String(usuario.id_usuario), scenario: escenario.id,
      limits: { turnMs: 65000 },
      run: (input) => {
        return contextoRef.current.procesarClef(input.message, input.metadata.desdeInicio, input.signal, input.turn_id, input.request_id)
      },
    })
    const supervisor = supervisorRef.current
    if (controlTurn(prompt) !== 'CONTINUE') limpiarContexto({ olvidarVinculo: controlTurn(prompt) === 'RESET_REQUEST' })
    setTyping(true)
    supervisor.submit({ message: prompt, turn_id: turnId, metadata: { desdeInicio } }).then((result) => {
      if (supervisor !== supervisorRef.current) return
      if (result.outcome !== 'RESPONDED') {
        cerrarEntrada(turnId, { estado: 'error' })
        setMessages((list) => [...list, message('agent', { text: result.response, turn_id: result.turn_id, request_id: result.request_id, state_version: result.state_version })])
        if (desdeInicio) setPhase('conversation')
      }
    }).finally(() => {
      if (supervisor === supervisorRef.current) setTyping(supervisor.snapshot().session.status === 'PROCESSING' || supervisor.snapshot().queue_depth > 0)
    })
  }

  function resolverPropuesta(id, aplicar) {
    const m = messages.find((x) => x.id === id)
    if (m?.propuesta?.estado !== 'pendiente') return
    const aplicada = aplicar && aplicarPropuesta(m.propuesta)
    const estado = aplicar ? (aplicada ? 'aplicada' : 'caducada') : 'descartada'
    setMessages((list) => list.map((x) => (x.id === id ? { ...x, propuesta: { ...x.propuesta, estado } } : x)))
  }

  function send(prompt) {
    if (!demostracion && escenario) return sendClef(prompt)
    setMessages((list) => [...list, message('user', { text: prompt })])
    setOpen(true)
    setTyping(true)
    later(() => {
      setMessages((list) => [...list, message('agent', replyTo(prompt))])
      setTyping(false)
    }, 1300)
  }

  function toggle() {
    setOpen((o) => !o)
  }

  function ask(prompt) {
    setOpen(true)
    if (typeof prompt === 'string' && prompt.trim()) send(prompt.trim())
    requestAnimationFrame(() => document.getElementById('dock-input')?.focus({ preventScroll: true }))
  }

  function reset() {
    limpiarContexto()
    clearTimers()
    solicitudRef.current += 1
    setDiagnostico(null)
    if (clefEnChat) {
      setMessages([])
      setTyping(false)
      setOpen(false)
      if (nav === 0) setPhase('home')
      return
    }
    startTransition(() => {
      addTransitionType('agent-undock')
      setFromDock(true)
      setOpen(false)
      setTyping(false)
      setMessages([])
      setPhase('home')
      setNav(0)
    })
  }

  function navigate(index) {
    const navigation = ++navigationRef.current
    animationRef.current?.cancel()
    if (index === nav) return
    solicitudRef.current += 1
    supervisorRef.current?.interrupt()
    setTyping(false)
    if (!demostracion && phase === 'thinking') stop()
    // Sin fundido de salida: la sección nueva entra de inmediato y el indicador se desliza.
    if (navigation !== navigationRef.current) return
    setFromDock(false)
    setNav(index)
    setOpen(false)
    window.scrollTo({ top: 0 })
  }

  // Abre la vista del agente ya armada (desde Vistas guardadas)
  function openAgentView() {
    startTransition(() => {
      if (phase !== 'view') {
        if (demostracion) setMessages([message('user', { text: 'Abrir la vista guardada «Ventas por sucursal»' }), message('agent', FIRST_REPLY)])
        setPhase('view')
      }
      setNav(0)
    })
    window.scrollTo({ top: 0 })
  }

  const View = VIEWS[nav]
  const showDock = nav !== 0 || phase === 'view'
  // El dock solo indica la pestaña sobre la que se itera; la fuente ya está en la cabecera de la vista.
  const dockContext = [NAV[nav]]

  return (
    <div className="app" ref={appRef}>
      <header className="topbar" style={{ viewTransitionName: 'topbar' }}>
        <a className="brand" href="#" aria-label="Patagonia ERP, inicio">
          <Logo className="brand-logo" title="" />
          <span className="brand-name"><b>Patagonia</b> ERP</span>
        </a>
        <nav className="nav" ref={navRef} aria-label="Secciones">
          {pill && <span className={`nav-pill ${pill.ready ? 'is-ready' : ''}`} aria-hidden="true" style={{ width: pill.w, transform: `translateX(${pill.x}px)` }} />}
          {NAV.map((n, i) => (
            <button key={n} className={nav === i ? 'is-on' : ''} aria-current={nav === i ? 'page' : undefined} onClick={() => navigate(i)}>
              {n}
            </button>
          ))}
        </nav>
        <div className="top-right">{usuario.perfiles_lectura?.length > 0 && <label className="perfil-selector" title="Contexto del análisis"><span>Ver como</span><select aria-label="Perfil de lectura" value={usuario.perfil_lectura ?? ""} onChange={cambiarPerfil} disabled={cambiandoPerfil}>{usuario.perfiles_lectura.filter(p => !p.escenarios || p.escenarios.some(id => disponibles.some(e => e.id === id)) || p.id === usuario.perfil_lectura).map(p => <option key={p.id} value={p.id}>{p.nombre}{p.escenarios && !p.escenarios.includes(escenario?.id) ? ' · base lechera' : ''}</option>)}</select></label>}{errorPerfil && <span role="alert">{errorPerfil}</span>}<ThemeToggle /><button className="logout-btn" onClick={onLogout}>Cerrar sesión</button><Avatar name={usuario.nombre_mostrado} initials={usuario.nombre_mostrado.split(/\s+/).map((part) => part[0]).slice(0, 2).join('').toUpperCase()} className="avatar" /></div>
      </header>

      {errorServicio && <p className="source-alert" role="alert">Servicio de datos no disponible. Se muestra la demostración; el dataset no está conectado en esta sesión.</p>}

      {nav > 0 && consulta?.estado === 'error' && <p className="source-alert" role="alert">{consulta.error}. Se conservan los últimos datos recibidos.</p>}

      {View && <View onAsk={ask} onOpenAgent={openAgentView} onNavigate={navigate} usuario={usuario} />}
      {!View && phase !== 'view' ? (
        <div className="chat-con-historial">
          <HistorialChat conversaciones={historial.lista} ocupado={phase === 'thinking'} onFijar={historial.fijar} onQuitar={historial.quitar}
            onAbrir={(pregunta) => { if (phase !== 'home') stop(); start(pregunta) }}
            onNueva={() => { stop(); requestAnimationFrame(() => document.getElementById('home-input')?.focus()) }} />
          {demostracion
            ? <AgentHome phase={phase} messages={messages} onStart={start} onStop={stop} arrived={fromDock} usuario={usuario} selector={<SelectorEscenario />} />
            : <InicioDatos usuario={usuario} onStart={start} phase={phase} messages={messages} onStop={stop} sugerencias={sugerencias.length ? sugerencias : sugerenciasIniciales(escenario)} />}
        </div>
      ) : phase === 'view' && (
        <>
          {/* El tablero del Agente se conserva vivo mientras se ve otra sección: React lo renderiza en un contenedor
              propio (portal) que solo está en el documento cuando se ve el Agente. Al volver no se recrean sus seis
              gráficos; las animaciones CSS de entrada se reinician al reinsertarse y revelarTablero reproduce la de
              los gráficos. Fuera del documento no duplica elementos para selectores, pruebas ni accesibilidad. */}
          {!View && <div ref={anfitrionTablero} className="tablero-anfitrion" />}
          {createPortal(View && tableroElemento.current ? tableroElemento.current : (tableroElemento.current = <main ref={tableroRef} className={`page page-agente ${consulta?.actualizando ? 'is-actualizando' : ''}`} aria-busy={consulta?.actualizando || undefined}>
            <div className="page-head">
              <div className="page-title">
                <button className="circle-btn solid" aria-label="Nueva conversación" onClick={reset}><ArrowLeft /></button>
                <h1>{modelos?.agente?.title ?? DASHBOARD.title}</h1>
              </div>
              <div className="capsule actions">
                {!demostracion && <SelectorEscenario />}
                {/* El período se dice una vez, aquí; las tarjetas no lo repiten */}
                {!demostracion && modelos?.periodo && <span className="period-label">{modelos.periodo}</span>}
                {!demostracion && <VariablesVista resolucion={{ actual: modelos?.agente?.timeline?.periodo?.corto ?? modelos?.periodo ?? 'Consultando', anterior: consulta?.modelo?.comparacion?.corto ?? consulta?.modelo?.variables?.anterior, motivoComparacion: 'Sin comparación disponible' }} />}
                <button className="dark-btn" onClick={ask}>Preguntar</button>
              </div>
            </div>

            {/* La respuesta vigente flota en la esquina inferior izquierda unos segundos; no ocupa espacio del tablero. */}
            <AvisoAgente clave={`${usuario.id_usuario}.${escenario?.id}`} analisis={analisisVivo && analisisVivo.periodo === modelos?.agente?.timeline?.periodo?.corto && !consulta?.actualizando ? analisisVivo : null} />
            {consulta?.estado === 'error' && <p role="alert">{consulta.error}. Se conservan los últimos datos recibidos.</p>}
            <div className="board">
              <div className="col col-left">
                <DecisionCard onAsk={ask} />
                <ReconCard />
                {!demostracion && <Tile title="Ventas por sucursal" sub={modelos ? rankingSucursales?.unidad ?? 'MM$' : 'Consultando datos…'}
                  sinMedicion={!rankingSucursales ? 'La fuente no expone un desglose de sucursales para esta vista.' : undefined}>
                  {sucursales.some(p=>p.valor>0) ? <Columns className="ch-sm" unit="" digits={0}
                    max={Math.max(1,...sucursales.map(p=>p.valor))*1.15}
                    groups={sucursales.map(p=>({label:iniciales(p.nombre.replace(/^Sucursal\s+/i,'')),bars:[{value:p.valor,tone:'blue',style:'solid'}]}))}
                    tip={(_,i)=><><span><b>{sucursales[i].nombre}</b></span><span>{nf(sucursales[i].valor,6)} {rankingSucursales.unidad}</span></>}
                    label={`Ventas por sucursal en ${modelos.periodo}: ${sucursales.map(p=>`${p.nombre}, ${nf(p.valor,6)} ${rankingSucursales.unidad}`).join('; ')}`} />
                    : <p>No se registraron ventas en este período.</p>}
                </Tile>}
                {!demostracion && <Tile className="panorama-general" title="Panorama general" sub={modelos ? 'Indicadores complementarios' : 'Consultando…'}
                  sinMedicion={!modelos ? 'Consultando indicadores de la fuente…' : !panorama.length ? 'La fuente no dispone de indicadores adicionales a los que ya aparecen en esta vista.' : undefined}>
                  <KpiStrip items={panorama} />
                </Tile>}
              </div>
              <div className="col col-center">
                <AnalyticsCard />
                <div className="metrics">
                  {(modelos?.agente?.metrics ?? (demostracion ? METRIC_LIST : METRIC_LIST.map((m) => ({ ...m, sub: 'Fuente seleccionada', sinMedicion: 'Consultando datos…', side: [] })))).map((m, i) => <MetricCard key={m.title} m={m} index={i} />)}
                </div>
                <DetailCard />
              </div>
              <div className="col col-right">
                <AgentCard onOpen={ask} />
                {(modelos?.agente?.branches ?? (demostracion ? BRANCH_LIST : BRANCH_LIST.map((b) => ({ ...b, code: 'Fuente seleccionada', title: 'Consultando datos', text: 'Esperando los registros del período.' })))).map((b, i) => <BranchCard key={b.rank} branch={b} index={i} />)}
              </div>
            </div>
          </main>), contenedorTablero)}
        </>
      )}
      {showDock && <AgentDock messages={messages} open={open} typing={typing} context={dockContext} onToggle={toggle} onOpen={() => setOpen(true)} onSend={send} onReset={reset} onPropuesta={resolverPropuesta} />}
    </div>
  )
}
