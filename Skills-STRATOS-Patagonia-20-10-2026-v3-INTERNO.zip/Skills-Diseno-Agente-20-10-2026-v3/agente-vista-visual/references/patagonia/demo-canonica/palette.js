import { getTheme } from './theme.js'

const dark = {
  blue: '#1450FF',
  green: '#00FF00',
  orange: '#FF4D00',
  ink: '#F5F5F7',
  ink2: '#B3B3B8',
  ink3: '#96969E',
  line: '#707076',
  grid: '#303036',
  white: '#FFFFFF',
  surface: '#08080A',
  hatch: '#242426',
}
const light = {
 blue: '#1F4FFF', green: '#00C27A', orange: '#F26722',
 ink: '#171922', ink2: '#596273', ink3: '#8290A3',
 line: '#CDD4DE', grid: '#E2E7EE', white: '#FFFFFF',
 surface: '#FCFDFE', hatch: '#EEF1F5',
}
export const P = Object.fromEntries(Object.keys(dark).map(key => [key, null]))
for (const key of Object.keys(dark)) Object.defineProperty(P, key, { get: () => (getTheme() === 'dark' ? dark : light)[key] })


// Misma tinta, distinta opacidad
export const tint = (hex, alpha) => {
  const n = parseInt(hex.slice(1), 16)
  return `rgba(${n >> 16}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`
}
