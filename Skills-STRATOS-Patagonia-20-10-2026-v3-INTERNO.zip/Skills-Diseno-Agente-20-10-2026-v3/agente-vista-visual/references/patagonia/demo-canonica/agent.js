// Conversación de demostración del agente. No hay modelo conectado: las respuestas se eligen por palabras clave.

export const HOME = {
  greeting: 'Hola, Manuel',
  title: '¿Qué quieres revisar hoy?',
  placeholder: 'Pregunta lo que quieras sobre tu negocio',
  sources: 'ERP · 4 fuentes',
  note: 'Datos de demostración. Verifica las cifras en el detalle de cada tarjeta.',
  suggestions: [
    'Compara las ventas por sucursal',
    '¿Por qué bajó el margen en Osorno?',
    'Proyecta el cierre de 2026',
    'Facturas que vencen esta semana',
  ],
}

export const THINKING = ['Leyendo fuentes del ERP', 'Comparando sucursales', 'Armando la vista']

export const FIRST_REPLY = {
  text: 'Armé «Ventas por sucursal» con datos al 30/09/26. La venta neta del trimestre fue 444,6 MM$, un 21,3 % más que el año anterior. Ojo con Puerto Montt: el margen bajó 3,1 pp.',
  steps: [
    'Leí 3 de 4 fuentes del ERP (Fuentes con retraso)',
    'Comparé 2 sucursales en 3 métricas',
    'Elegí 7 tarjetas con confianza 0,74',
  ],
}

const REPLIES = [
  {
    match: /margen|osorno|descuento/i,
    text: 'En Osorno el margen bajó 2,2 pp porque el descuento medio subió a 6,9 % desde el 18 de agosto. Lo marqué en el gráfico de ventas como hito.',
    steps: ['Crucé descuentos por semana con margen bruto'],
  },
  {
    match: /proyec|cierre|diciembre|estim/i,
    text: 'Si se mantiene la tendencia, el cuarto trimestre cerraría cerca de 470 MM$. Lo verás como línea clara después de «Hoy» en el gráfico.',
    steps: ['Proyección lineal de las últimas 12 semanas'],
  },
  {
    match: /factura|vence|cobr/i,
    text: 'Hay 64 documentos que vencen en 10 días; 12 están en disputa. ¿Quieres que agregue una tarjeta de cobranza a esta vista?',
    steps: ['Revisé la cartera por cobrar'],
  },
]

export function replyTo(prompt) {
  const found = REPLIES.find((r) => r.match.test(prompt))
  return found ?? {
    text: 'Listo, ajusté la vista con tu pedido. Si algo no calza, dime qué tarjeta cambiar.',
    steps: ['Actualicé las tarjetas afectadas'],
  }
}

let id = 0
export const message = (role, body) => ({ id: ++id, role, ...body })
