import { createContext, useContext, useLayoutEffect, useRef } from 'react'
import { ArrowUpRight, Trend } from './Icons.jsx'

export const FuenteMedicion = createContext(null)

export const fmt = (value, digits = 1) => value == null ? '—' : value.toLocaleString('es-CL', { minimumFractionDigits: digits, maximumFractionDigits: digits })

// Ajustar al ancho real sin abreviar, cortar cifras ni cambiar su unidad.
export function FitText({ as: Tag = 'span', className = '', children, title }) {
  const ref = useRef(null)
  useLayoutEffect(() => {
    const el = ref.current, contenido = el.firstElementChild
    let activo = true, frame = 0, escala = 1
    el.style.removeProperty('--fit-scale')
    const ajustar = () => {
      frame = 0
      if (!activo || !el.clientWidth) return
      const natural = contenido.getBoundingClientRect().width / escala
      const siguiente = Math.min(1, Math.max(0.01, el.clientWidth / (natural || 1)))
      if (Math.abs(siguiente - escala) > 0.002) {
        escala = siguiente
        el.style.setProperty('--fit-scale', escala)
        frame = requestAnimationFrame(ajustar)
      }
    }
    const observer = new ResizeObserver(() => { if (!frame) frame = requestAnimationFrame(ajustar) })
    observer.observe(el);ajustar()
    document.fonts.ready.then(ajustar)
    return () => { activo = false;observer.disconnect();cancelAnimationFrame(frame) }
  }, [children])
  return <Tag ref={ref} className={`fit-text ${className}`} title={title}><span className="fit-text-content">{children}</span></Tag>
}

// Número con decimales en gris, como en los KPI de la vista del agente
export function Num({ value }) {
  const [int, dec] = String(value).split(',')
  return <>{int}{dec != null && <span className="dec">,{dec}</span>}</>
}

// Título en dos pesos (Light + Medium) con controles a la derecha
export function ViewHead({ title, children }) {
  return (
    <div className="vhead">
      <h1 className="vtitle"><span>{title[0]}</span><b>{title[1]}</b></h1>
      {children && <div className="vhead-tools">{children}</div>}
    </div>
  )
}

// KPI sin cajas: etiqueta, numeral Light, unidad en superíndice
export function KpiStrip({ items }) {
  const fuente = useContext(FuenteMedicion)
  if (fuente) items = items.map((k) => ({ label: k.label, sinMedicion: fuente.motivo }))
  return (
    <dl className="kstrip">
      {items.map((k) => (
        <div key={k.label} className="kstrip-item">
          <dt>{k.label}</dt>
          {k.sinMedicion ? <dd className="kstrip-sin"><span>Sin medición</span><small>{k.sinMedicion}</small></dd> : <dd>
            <FitText className="kstrip-num" title={`${k.value} ${k.unit ?? ''}`}><Num value={k.value} />{k.unit && <sup>{k.unit}</sup>}</FitText>
            {k.suffix && <small>/ {k.suffix}</small>}
          </dd>}
          {k.delta && (
            <span className={`kstrip-delta tone-${k.tone ?? 'muted'}`}>
              {/^[+−-]/.test(k.delta) && <Trend dir={k.delta.startsWith('+') ? 'up' : 'down'} good={k.tone === 'green'} />}
              {k.delta}{k.vs && <small> {k.vs}</small>}
            </span>
          )}
        </div>
      ))}
    </dl>
  )
}

export function OutlineTabs({ items, value, onChange, label }) {
  return (
    <div className="otabs" role="tablist" aria-label={label}>
      {items.map((it) => (
        <button key={it} role="tab" aria-selected={value === it} className={value === it ? 'is-on' : ''} onClick={() => onChange(it)}>{it}</button>
      ))}
    </div>
  )
}

// Mosaico plano de color sólido
export function Tile({ tone = 'white', title, sub, go = false, className = '', style, children, onGo, sinMedicion, accion }) {
  const fuente = useContext(FuenteMedicion)
  const motivo = sinMedicion ?? fuente?.motivo
  if (fuente) sub = fuente.periodo
  return (
    <section className={`tile tile-${tone} ${className}`} style={style}>
      {(title || go) && (
        <header className="tile-head">
          {title && <div className="tile-titles"><h3>{title}</h3>{sub && <p>{sub}</p>}</div>}
          {go && onGo && <button className="tile-go" onClick={onGo} aria-label={`Abrir ${typeof title === 'string' ? title.toLowerCase() : 'detalle'}`}><ArrowUpRight /></button>}
        </header>
      )}
      {accion}
      {motivo ? <div className="chart-sin-medicion" role="status">{motivo}</div> : children}
    </section>
  )
}

export function Big({ value, unit, suffix }) {
  return <p className="big"><FitText className="big-num" title={`${value} ${unit ?? ''}`}><Num value={value} />{unit && <sup>{unit}</sup>}</FitText>{suffix && <small>/ {suffix}</small>}</p>
}

// Cada persona conserva una orientación propia dentro de la paleta azul y verde.
// El nombre es la semilla para que su avatar sea estable entre vistas.
const seed = (text) => { let h = 2166136261; for (const ch of text) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) } return h >>> 0 }
export function avatarFill(name) {
  const h = seed(name)
  const [c1, c2] = h & 1 ? ['var(--green)', 'var(--blue)'] : ['var(--blue)', 'var(--green)']
  const angle = 115 + ((h >>> 3) % 130)
  return `linear-gradient(${angle}deg, ${c1} 12%, ${c2} 92%)`
}

export function Avatar({ name, initials, className = '' }) {
  return <span className={`avatar-3d ${className}`} role="img" aria-label={name} title={name} style={{ '--av-fill': avatarFill(name) }}>{initials}</span>
}

// Tarjeta de lectura (lenguaje de la tarjeta del agente): bloque azul plano, título arriba,
// avance en dos trazos finos, aire, contexto con iniciales y una frase en dos pesos con su acción.
// progress: 0–1 · people: iniciales · soft: líneas en peso ligero · strong: cierre en peso regular
export function StatementCard({ title, sub, progress, meta, people = [], soft = [], strong, onGo, goLabel, className = '' }) {
  const fuente = useContext(FuenteMedicion)
  if (fuente) return <section className={`tile tile-accent statement ${className}`}><header className="agent-head"><div><h2>{title}</h2><p>{fuente.periodo}</p></div></header><div className="statement-foot" role="status">{fuente.motivo}</div></section>
  const frac = Math.min(Math.max(progress ?? 0, 0), 1)
  return (
    <section className={`tile tile-accent statement ${className}`}>
      <header className="agent-head">
        <div>
          <h2>{title}</h2>
          {sub && <p>{sub}</p>}
        </div>
        {progress != null && (
          <span className="agent-progress" role="img" aria-label={`${Math.round(frac * 100)} % de avance`}>
            <i style={{ width: `${Math.max(frac * 5.4, 0.3)}rem` }} />
            <i style={{ width: `${Math.max((1 - frac) * 5.4, 0.3)}rem` }} />
          </span>
        )}
      </header>
      <div className="statement-foot">
        {(meta || people.length > 0) && (
          <div className="agent-people">
            {meta}
            {people.length > 0 && (
              <span className="faces">
                {people.map((p, i) => <i key={p} className={`face face-${'abc'[i % 3]}`}>{p}</i>)}
              </span>
            )}
          </div>
        )}
        <div className="agent-line">
          <p className="agent-text">
            {soft.length > 0 && <span className="soft">{soft.map((l, i) => <span key={l}>{l}{i < soft.length - 1 && <br />}</span>)}</span>}
            {soft.length > 0 && <br />}
            {strong}
          </p>
          {onGo && <button className="ring" aria-label={goLabel} onClick={onGo}><ArrowUpRight /></button>}
        </div>
      </div>
    </section>
  )
}

// Matriz de puntos: rellenos = cerrados, contorno = abiertos
// group: puntos por fila dentro de cada columna (2 = dos puntos por semana, llena el ancho)
export function DotMatrix({ columns, group = 1, label }) {
  const step = 10
  const gap = group > 1 ? 7 : 0
  const colW = group * step + gap
  const rows = Math.ceil(Math.max(...columns.map(([f, o]) => f + o)) / group)
  const w = columns.length * colW - gap
  const h = rows * step
  return (
    <svg className="dots" viewBox={`0 0 ${w} ${h}`} role="img" aria-label={label} preserveAspectRatio="xMidYMax meet">
      {columns.map(([filled, open], ci) => Array.from({ length: filled + open }, (_, k) => (
        <circle key={`${ci}-${k}`} cx={ci * colW + (k % group) * step + step / 2} cy={h - Math.floor(k / group) * step - step / 2} r={step * 0.4}
          className={k < filled ? 'dot-on' : 'dot-off'} />
      )))}
    </svg>
  )
}

// Anillo de avance: el color dice si cumple; el número va al lado
export function Ring({ value, alert, size = 2.2 }) {
  const r = 15
  const c = 2 * Math.PI * r
  return (
    <span className={`ring-status ${alert ? 'is-alert' : ''}`} style={{ '--s': `${size}rem` }} aria-label={`${Math.round(value * 100)} %`}>
      <svg viewBox="0 0 36 36" aria-hidden="true">
        <circle cx="18" cy="18" r={r} className="ring-track" />
        <circle cx="18" cy="18" r={r} className="ring-bar" strokeDasharray={`${Math.min(value, 1) * c} ${c}`} />
      </svg>
    </span>
  )
}

// Secuencia de puntos por etapa (semanas)
export function DotSteps({ steps }) {
  return (
    <span className="dsteps" aria-label={`${steps.filter(Boolean).length} de ${steps.length} semanas sobre meta`}>
      {steps.map((on, i) => <span key={i} className={on ? 'is-on' : ''}><small>{i + 1}</small><i /></span>)}
    </span>
  )
}

export const CountChip = ({ alert, children }) => <span className={`cchip ${alert ? 'is-alert' : ''}`}><i />{children}</span>
export const Initials = ({ text, tone = 'mist' }) => <span className={`ini ini-${tone}`}>{text}</span>
export const Code = ({ children }) => <span className="code">{children}</span>
