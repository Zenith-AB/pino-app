import { ViewTransition, useEffect, useRef, useState } from 'react'
import { HOME, THINKING } from '../agent.js'
import { NOTA_PROBABILIDAD } from '../datos/propuesta.js'
import { ListaPropuesta } from './Variables.jsx'
import { resumenLegible } from '../datos/resumen-legible.js'
import { remRaiz } from '../escala.js'
import { ArrowUp, BarsIcon, Check, ChevronUp, Close, Coin, Compose, Database, FlujoOrbe, Layers, LineIcon, Mark, Pin, Plus } from './Icons.jsx'

export function AgentOrb({ busy = false, size = '' }) {
  return <span className={`orb ${size} ${busy ? 'is-busy' : ''}`} aria-hidden="true"><Mark /></span>
}

// Aviso flotante de la respuesta del agente: esquina inferior izquierda, el tiempo justo para leerla.
// Minimalista: el texto que genera el agente, una oración por línea y cifras en negrita; sin cabecera.
// Al terminar (o al cerrarlo) se contrae a un círculo azul plano en la misma esquina; tocarlo lo expande de nuevo.
// Solo un texto NUEVO (pregunta o vínculo reevaluado) lo abre solo: el último mostrado se recuerda por usuario y
// fuente, así cambiar de pestaña o recargar no lo vuelve a lanzar.
const oraciones = (texto) => texto.split(/(?<=\.)\s+(?=[A-ZÁÉÍÓÚÑ¿])/).filter(Boolean)
const CLAVE_AVISO = (clave) => `patagonia.aviso.${clave}`
const leerAviso = (clave) => { try { return clave ? localStorage.getItem(CLAVE_AVISO(clave)) : null } catch { return null } }
const guardarAviso = (clave, texto) => { try { if (clave) localStorage.setItem(CLAVE_AVISO(clave), texto) } catch { /* opcional */ } }
export function AvisoAgente({ analisis, clave }) {
  const texto = analisis?.texto ?? ''
  // oculto: sin respuesta vigente · abierto: tarjeta · cerrado: círculo
  const [estado, setEstado] = useState('oculto')
  const [pausa, setPausa] = useState(false)
  const [contenido, setContenido] = useState(null)
  const [apertura, setApertura] = useState(0)
  const restante = useRef(0), inicio = useRef(0)
  const duracionDe = (t) => Math.min(16000, Math.max(6000, 4000 + t.split(/\s+/).length * 300))
  const abrir = (t) => { restante.current = duracionDe(t); setPausa(false); setApertura((n) => n + 1); setEstado('abierto') }
  useEffect(() => {
    if (!texto) { setEstado('oculto'); return }
    setContenido(texto)
    if (texto === leerAviso(clave)) { setEstado((e) => e === 'abierto' ? e : 'cerrado'); return }
    guardarAviso(clave, texto)
    abrir(texto)
  }, [texto, clave]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (estado !== 'abierto' || pausa) return undefined
    inicio.current = Date.now()
    const t = setTimeout(() => setEstado('cerrado'), restante.current)
    return () => { clearTimeout(t); restante.current = Math.max(0, restante.current - (Date.now() - inicio.current)) }
  }, [estado, pausa])
  if (!contenido) return null
  const abierto = estado === 'abierto'
  return (
    <aside className={`aviso-agente is-${estado} ${pausa ? 'is-pausado' : ''}`} role="status" aria-live="polite" aria-label={contenido} title={abierto ? contenido : undefined}
      onPointerEnter={() => abierto && setPausa(true)} onPointerLeave={() => setPausa(false)} onFocus={() => abierto && setPausa(true)} onBlur={() => setPausa(false)}>
      <div className="aviso-contenido" aria-hidden={!abierto}>
        <button type="button" className="aviso-cerrar" aria-label="Contraer aviso" tabIndex={abierto ? 0 : -1} onClick={() => setEstado('cerrado')}><Close /></button>
        <div className="aviso-cuerpo">
          {oraciones(contenido).map((linea, i) => <p key={i}>{resumenLegible(linea).partes.map((p, j) => p.destacado ? <strong key={j}>{p.texto}</strong> : p.texto)}</p>)}
        </div>
        <span className="aviso-tiempo" aria-hidden="true">{abierto && <i key={apertura} style={{ animationDuration: `${duracionDe(contenido)}ms` }} />}</span>
      </div>
      <button type="button" className="aviso-reabrir" aria-label="Ver la respuesta del agente" tabIndex={estado === 'cerrado' ? 0 : -1} onClick={() => abrir(contenido)}><Mark /></button>
    </aside>
  )
}

// Envía con Enter; Shift+Enter agrega una línea
function useComposer(onSubmit) {
  const [text, setText] = useState('')
  const ref = useRef(null)
  const fit = () => {
    const el = ref.current
    if (!el || el.tagName !== 'TEXTAREA') return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, 12 * remRaiz())}px`
  }
  const submit = (event) => {
    event?.preventDefault()
    const value = text.trim()
    if (!value) return
    onSubmit(value)
    setText('')
    requestAnimationFrame(fit)
  }
  const bind = {
    ref,
    value: text,
    onChange: (event) => { setText(event.target.value); fit() },
    onKeyDown: (event) => { if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) submit(event) },
  }
  return { text, setText, bind, submit, ref }
}

function Message({ m, onPropuesta }) {
  if (m.role === 'user') return <p className="msg msg-user">{m.text}</p>
  return (
    <div className="msg msg-agent">
      <AgentOrb size="is-sm" />
      <div>
        <p>{m.text}</p>
        {m.propuesta && (
          <div className="msg-propuesta">
            <ListaPropuesta propuesta={m.propuesta} aplicada={m.propuesta.estado === 'aplicada'} />
            {m.propuesta.estado === 'pendiente' && onPropuesta ? (
              <div className="propuesta-acciones">
                <button className="dark-btn" onClick={() => onPropuesta(m.id, true)}>Aplicar</button>
                <button className="registros-mas" onClick={() => onPropuesta(m.id, false)}>Descartar</button>
              </div>
            ) : <p className="propuesta-nota">{m.propuesta.estado === 'aplicada' ? 'Aplicada a la vista.' : m.propuesta.estado === 'descartada' ? 'Descartada.' : 'Las variables cambiaron. Pide una propuesta nueva.'}</p>}
            <p className="propuesta-nota">{NOTA_PROBABILIDAD}</p>
          </div>
        )}
        {m.steps && (
          <ul className="msg-steps">
            {m.steps.map((s) => <li key={s}><Check />{s}</li>)}
          </ul>
        )}
      </div>
    </div>
  )
}

// Inicio minimalista: saludo, compositor y sugerencias
export function AgentHome({ phase, messages, onStart, onStop, arrived = false, usuario, contenido = HOME, resumen, selector }) {
  const thinking = phase === 'thinking'
  const { text, bind, submit, ref } = useComposer(onStart)
  const [step, setStep] = useState(0)

  useEffect(() => {
    if (!thinking) return undefined
    setStep(0)
    const timer = setInterval(() => setStep((s) => Math.min(s + 1, THINKING.length - 1)), 680)
    return () => clearInterval(timer)
  }, [thinking])

  useEffect(() => { if (!thinking) ref.current?.focus({ preventScroll: true }) }, [thinking, ref])


  return (
    <main className={`home ${thinking ? 'is-thinking' : ''} ${arrived ? 'is-arrived' : ''}`}>
      <div className="home-glow" aria-hidden="true" />
      <div className="home-col">
        {thinking || messages.length > 0 ? (
          <ViewTransition name="agent-thread" share="thread-store" default="none">
            <div className="home-thread" aria-live="polite">
              {messages.map((m) => <Message key={m.id} m={m} />)}
              {thinking && <div className="msg msg-agent">
                <AgentOrb size="is-sm" busy />
                <p className="thinking" key={step}>{THINKING[step]}…</p>
              </div>}
            </div>
          </ViewTransition>
        ) : (
          <header className="home-head">
            {selector && <div className="home-source">{selector}</div>}
            <p>Hola, {usuario?.nombre_mostrado?.split(/\s+/)[0] || 'equipo'}</p>
            <h1>{contenido.title}</h1>
          </header>
        )}

        <ViewTransition name="agent-composer" share="composer-morph" default="none">
          <form className="composer glass" onSubmit={submit}>
            <label className="sr-only" htmlFor="home-input">Mensaje para el agente</label>
            <textarea id="home-input" rows={1} placeholder={contenido.placeholder} {...bind} />
            <div className="composer-bar">
              <span className="tool-chip"><Database />{contenido.sources}</span>
              <span className="grow" />
              {thinking
                ? <button type="button" className="send is-stop" onClick={onStop} aria-label="Detener"><i /></button>
                : <button type="submit" className="send" disabled={!text.trim()} aria-label="Enviar"><ArrowUp /></button>}
            </div>
          </form>
        </ViewTransition>

        {!thinking && resumen}
        {!thinking && contenido.suggestions.length > 0 && (
          <ul className="suggestions" aria-label="Sugerencias">
            {contenido.suggestions.map((s) => (
              <li key={s}><button type="button" onClick={() => onStart(s)}>{s}</button></li>
            ))}
          </ul>
        )}
      </div>
      {contenido.note && <p className="home-note">{contenido.note}</p>}
    </main>
  )
}

// Chat guardado en el pie: en reposo es la esfera del agente; al tocarla se estira hasta el dock de vidrio.
export function AgentDock({ messages, open, typing, context = [], onToggle, onOpen, onSend, onReset, onPropuesta }) {
  const { text, bind, submit, ref } = useComposer(onSend)
  const [desplegado, setDesplegado] = useState(false)
  // Con la conversación abierta o un texto a medio escribir, el dock no se recoge.
  const expandido = desplegado || open || Boolean(text.trim())
  const [dismissed, setDismissed] = useState([])
  const contextKey = context.join('|')
  useEffect(() => { setDismissed([]) }, [contextKey])
  const chips = context.filter((c) => !dismissed.includes(c))
  const listRef = useRef(null)
  // Solo cuentan las respuestas del agente que llegaron con la conversación cerrada.
  const respuestas = messages.filter((m) => m.role === 'agent').length
  const [vistas, setVistas] = useState(respuestas)
  useEffect(() => { if (open || respuestas < vistas) setVistas(respuestas) }, [open, respuestas, vistas])
  const sinLeer = open ? 0 : Math.max(0, respuestas - vistas)

  useEffect(() => {
    const el = listRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [messages.length, typing, open])

  // Compacto: los últimos 4 mensajes (2 preguntas y 2 respuestas); el resto, a pedido.
  const [todo, setTodo] = useState(false)
  useEffect(() => { if (!open) setTodo(false) }, [open])
  const ocultos = todo ? 0 : Math.max(0, messages.length - 4)
  const visibles = messages.slice(ocultos)

  // Tocar la esfera despliega el dock y, si hay conversación, la abre.
  function desplegar(abrirChat = false) {
    setDesplegado(true)
    if (abrirChat && messages.length) onOpen?.()
    requestAnimationFrame(() => ref.current?.focus({ preventScroll: true }))
  }

  // Un clic real fuera del chat lo recoge. No se usa la pérdida de foco: en algunos navegadores
  // un botón no recibe foco al hacer clic y el dock se recogía antes de que el clic llegara.
  const wrapRef = useRef(null)
  const estadoRef = useRef({ open, text })
  estadoRef.current = { open, text, onToggle }
  useEffect(() => {
    const fuera = (event) => {
      if (wrapRef.current?.contains(event.target)) return
      const { open: abierto, text: escrito, onToggle: alternar } = estadoRef.current
      if (abierto) alternar()
      if (!escrito.trim()) setDesplegado(false)
    }
    document.addEventListener('pointerdown', fuera)
    return () => document.removeEventListener('pointerdown', fuera)
  }, [])

  // Con teclado: salir con Tab fuera del chat también lo recoge.
  function alSalir(event) {
    if (event.relatedTarget && !event.currentTarget.contains(event.relatedTarget) && !text.trim() && !open) setDesplegado(false)
  }

  return (
    <div className="dock-wrap" ref={wrapRef} onFocus={() => { if (!expandido) desplegar() }} onBlur={alSalir} onKeyDown={(e) => { if (e.key === 'Escape' && !open && !text.trim()) { setDesplegado(false); e.target.blur?.() } }}>
      {/* Siempre montado: abrir y cerrar es una transición de CSS y los mensajes no se reaniman. */}
      <section className={`chat-panel glass ${open ? 'is-open' : ''}`} aria-label="Conversación con el agente" inert={!open}>
        <header className="chat-head">
          <div>
            <b>Conversación</b>
            <small>{context.join(' · ') || 'Vista del agente'} · {messages.length} mensajes</small>
          </div>
          <button className="tool-btn" onClick={onReset} aria-label="Nueva conversación" title="Nueva conversación"><Compose /></button>
          <button className="tool-btn" onClick={onToggle} aria-label="Cerrar conversación"><Close /></button>
        </header>
        <div className="chat-list" ref={listRef} aria-live="polite">
          {ocultos > 0 && <button type="button" className="chat-mas" onClick={() => setTodo(true)}>Ver {ocultos === 1 ? 'el mensaje anterior' : `los ${ocultos} mensajes anteriores`}</button>}
          {visibles.map((m) => <div key={m.id}><Message m={m} onPropuesta={onPropuesta} /></div>)}
          {typing && <div className="msg msg-agent"><AgentOrb size="is-sm" busy /><span className="typing"><i /><i /><i /></span></div>}
        </div>
      </section>

      <ViewTransition name="agent-composer" share="composer-morph" default="none">
        <form className={`dock glass ${expandido ? 'is-expanded' : 'is-collapsed'}`} onSubmit={submit}>
          <button type="button" className={`orb dock-orb ${typing ? 'is-busy' : ''}`} onClick={expandido ? () => { if (messages.length) onOpen?.(); ref.current?.focus() } : () => desplegar(true)}
            tabIndex={expandido ? -1 : 0} aria-label="Abrir el chat del agente">
            <FlujoOrbe />
            <Mark />
            {!expandido && sinLeer > 0 && <span className="badge" aria-label={`${sinLeer} respuestas sin leer`}>{sinLeer}</span>}
          </button>
          <div className="dock-body" aria-hidden={!expandido || undefined}>
          {chips.length > 0 && (
            <span className="dock-ctx" aria-label="Contexto de la pregunta">
              {chips.map((c) => <span key={c} className="ctx sm">{c}<button type="button" aria-label={`Quitar ${c}`} onClick={() => setDismissed((d) => [...d, c])}><Close /></button></span>)}
            </span>
          )}
          <label className="sr-only" htmlFor="dock-input">Pide un ajuste al agente</label>
          <input id="dock-input" placeholder="Pide un ajuste a esta vista" autoComplete="off" {...bind} />
          <span className="dock-sep" aria-hidden="true" />
          <button type="button" className={`tool-btn dock-toggle ${open ? 'is-open' : ''}`} onClick={onToggle} aria-expanded={open} aria-label={open ? 'Ocultar conversación' : 'Ver conversación'}>
            <ChevronUp />
            {sinLeer > 0 && <span className="badge" aria-label={`${sinLeer} respuestas sin leer`}>{sinLeer}</span>}
          </button>
          <button type="submit" className="send" disabled={!text.trim()} aria-label="Enviar"><ArrowUp /></button>
          </div>
        </form>
      </ViewTransition>
    </div>
  )
}

// Historial de conversaciones junto al chat del inicio: cada tarjeta es una pregunta anterior.
// Al abrirla se vuelve a preguntar con los datos vigentes; no se reutilizan cifras guardadas.
const VISTAS = { agente: 'Agente', ventas: 'Ventas', rentabilidad: 'Rentabilidad', cobranza: 'Cobranza', inventario: 'Inventario' }
const MINIATURA = { ventas: BarsIcon, rentabilidad: LineIcon, cobranza: Coin, inventario: Layers }
const ESTADO = {
  aplicada: ['blue', 'Aplicada a la vista'], respondida: ['blue', 'Respondida'],
  aclaracion: ['orange', 'Por precisar'], error: ['orange', 'Sin respuesta'], pendiente: ['grey', 'Consultando…'],
}

export function HistorialChat({ conversaciones, onAbrir, onNueva, onFijar, onQuitar, ocupado = false }) {
  const [filtro, setFiltro] = useState('todas')
  const [editando, setEditando] = useState(false)
  const visibles = filtro === 'fijadas' ? conversaciones.filter((c) => c.fijada) : conversaciones
  return (
    <aside className="historial" aria-label="Dashboard: consultas anteriores">
      <header className="historial-head">
        <h2>Dashboard</h2>
        <span className="historial-count" aria-label={`${conversaciones.length} conversaciones`}>{conversaciones.length}</span>
      </header>
      <div className="historial-filtros" role="group" aria-label="Filtrar conversaciones">
        {[['todas', 'Todas'], ['fijadas', 'Fijadas']].map(([id, texto]) => (
          <button key={id} type="button" className={filtro === id ? 'is-on' : ''} aria-pressed={filtro === id} onClick={() => setFiltro(id)}>{texto}</button>
        ))}
        <button type="button" className="historial-nueva" onClick={onNueva} aria-label="Nueva conversación" title="Nueva conversación"><Plus /></button>
      </div>
      <ol className="historial-lista">
        {visibles.map((c) => {
          const Icono = MINIATURA[c.dominio ?? c.vista] ?? Mark
          const [tono, estado] = ESTADO[c.estado] ?? ESTADO.pendiente
          return (
            <li key={c.id} className={`historial-item ${editando ? 'is-editando' : ''}`}>
              <button type="button" className="historial-card" disabled={editando || ocupado} onClick={() => onAbrir(c.pregunta)} title={c.pregunta}>
                <span className="historial-thumb" aria-hidden="true"><Icono /></span>
                <span className="historial-texto">
                  <b>{c.titulo ?? c.pregunta}</b>
                  {c.titulo && <span className="historial-meta"><Compose />{c.pregunta}</span>}
                  <span className={`historial-estado tone-${tono}`}><i />{estado} · {VISTAS[c.vista] ?? 'Agente'}{c.fijada && <Pin className="historial-pin" />}</span>
                </span>
              </button>
              {editando && <span className="historial-acciones">
                <button type="button" onClick={() => onFijar(c.id)} aria-pressed={c.fijada} aria-label={c.fijada ? 'Quitar de fijadas' : 'Fijar conversación'}><Pin /></button>
                <button type="button" onClick={() => onQuitar(c.id)} aria-label="Quitar del historial"><Close /></button>
              </span>}
            </li>
          )
        })}
        {!visibles.length && <li className="historial-vacio">{filtro === 'fijadas' ? 'Fija una conversación con Editar para tenerla a mano.' : 'Tus preguntas aparecerán aquí.'}</li>}
      </ol>
      {conversaciones.length > 0 && <footer className="historial-pie">
        <button type="button" className="historial-editar" aria-pressed={editando} onClick={() => setEditando((e) => !e)}>{editando ? 'Listo' : 'Editar'}</button>
      </footer>}
    </aside>
  )
}
