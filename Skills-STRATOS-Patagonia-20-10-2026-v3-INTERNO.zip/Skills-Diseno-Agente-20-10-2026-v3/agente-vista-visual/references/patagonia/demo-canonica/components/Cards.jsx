import { Columns, SmoothTrend, nf } from './Charts.jsx'
import { RegistrosVentas } from './Registros.jsx'
import { useEffect, useState } from 'react'
import { AGENT as AGENT_DEMO, BRANCHES, BRANCH_DETAIL as DETAIL_DEMO, DASHBOARD, DECISION, KPIS as KPIS_DEMO, METRICS, RECON as RECON_DEMO, STATUS, CHART } from '../data.js'
import { ArrowUpRight, BarsIcon, Chevron, Gear, LineIcon, Trend } from './Icons.jsx'
import { TrendChart, ReconGauge, Sparkline } from './GraficosDiferidos.jsx'
import VoxelBuilding from './VoxelBuilding.jsx'
import { Avatar, FitText } from './Kit.jsx'
import { C } from './colores-graficos.js'
import { useModelos } from '../datos/modelos.jsx'
import { rangoTendencia } from '../datos/tendencia.js'
import { useVariables } from './Variables.jsx'
import { TABS, domainFor } from '../salesTimeline.js'
import { resumenAgente, resumenDesdeModelo, graficoAgente, respuestaDelModelo } from '../datos/resumen-agente.js'

// La respuesta de Clef manda cuando trae una cifra verificada; si no, se resume el período con datos de la fuente.
const resumenVigente = (resumen, agente, escenario) => resumen?.concluyente ? resumen : resumenDesdeModelo(agente?.resumenPeriodo, escenario?.naturaleza_datos === 'sintetico' ? 'Datos sintéticos' : 'Fuente de prueba') ?? resumen

function CardHead({ title, sub, children }) {
  return (
    <header className="card-head">
      <div className="card-titles">
        <h2>{title}</h2>
        {sub && <p>{sub}</p>}
      </div>
      {children && <div className="card-actions">{children}</div>}
    </header>
  )
}

const Fraction = ({ value, total }) => (
  <span className="fraction">
    {value}
    <small>/{total}</small>
  </span>
)

export function DecisionCard({ onAsk }) {
  const { demostracion, modelos, escenario } = useModelos()
  const { respuesta } = useVariables()
  const a = modelos?.agente
  const resumen = resumenVigente(resumenAgente(respuestaDelModelo(respuesta,a,escenario), escenario), a, escenario)
  const d = demostracion ? DECISION : resumen?.decision ?? { title: DECISION.title, sub: 'Esperando consulta', prefix: 'meta', score: '—', delta: 'Esperando consulta', fill: 0, cut: 1, labels: ['', '', ''], meta: true, rows: [] }
  return (
    <section className={`card decision${d.meta ? " decision-meta" : ""}`} style={{ '--i': 0 }}>
      <CardHead title={d.title} sub={d.sub}>
        <button className="circle-btn" aria-label="Ajustes del selector" onClick={() => { const filtros = document.querySelector('details.variables'); if (filtros) filtros.open = true; filtros?.querySelector('select')?.focus() }}><Gear /></button>
        <button className="circle-btn" aria-label="Ver respuesta del agente" onClick={() => onAsk?.()}><ArrowUpRight /></button>
      </CardHead>

      <div className="score">
        <span className="score-pre">{d.prefix}</span>
        <span className="score-num">{d.score}</span>
        <span className="chip chip-green">{d.delta}</span>
      </div>

      <div className="scale" role={d.meta && d.porcentaje != null ? 'progressbar' : undefined} aria-label={d.meta ? 'Cumplimiento de la meta' : undefined} aria-valuemin={d.meta ? 0 : undefined} aria-valuemax={d.meta ? 100 : undefined} aria-valuenow={d.meta && d.porcentaje != null ? Math.max(0, Math.min(100,d.porcentaje)) : undefined} aria-valuetext={d.meta && d.porcentaje != null ? d.score : undefined} aria-hidden={!d.meta || undefined}>
        <div className="scale-line">
          <span className="scale-fill" style={{ width: `${d.fill * 100}%` }} />
          <span className="scale-marker" style={{ left: `${d.cut * 100}%` }} />
        </div>
        <div className="scale-labels">
          <span>{d.labels[0]}</span>
          <span className="scale-cut" style={{ left: `${d.cut * 100}%` }}>{d.labels[1]}</span>
          <span>{d.labels[2]}</span>
        </div>
      </div>

      <ul className="trace">
        {d.rows.map((r) => (
          <li key={r.label} className="trace-row">
            <span className="trace-label"><i className={`dot dot-${r.status}`} />{r.label}</span>
            {r.total == null ? <span className="fraction" title={r.exacto} aria-label={r.exacto}>{r.value}</span> : <Fraction value={r.value} total={r.total} />}
            <span className={`status status-${r.status}`}>{r.badge ?? STATUS[r.status]}</span>
            <button className="more" aria-label={r.pregunta ?? `Más sobre ${r.label}`} onClick={() => onAsk?.(r.pregunta)}><i /><i /><i /></button>
          </li>
        ))}
      </ul>
    </section>
  )
}

export function AnalyticsCard() {
  const { modelos, demostracion, setMetricasGrafico } = useModelos()
  const a = modelos?.agente
  const timeline = a?.timeline
  const KPIS = demostracion ? KPIS_DEMO : a?.kpis ?? []
  const [tab, setTab] = useState(0)
  const [mode, setMode] = useState('line')
  const [period, setPeriod] = useState('year')
  useEffect(() => { setMetricasGrafico([['venta','costo'],['margen','descuento'],['unidades','promo']][tab]) }, [tab, setMetricasGrafico])
  const { presentacion } = useVariables()
  useEffect(() => {
    if (presentacion?.componente !== 'AnalyticsCard') return
    const props = presentacion.props
    const indice = ['venta', 'margen', 'unidades'].indexOf(props?.metrica)
    if (indice >= 0) setTab(indice)
    if (['line', 'bars'].includes(props?.modo)) setMode(props.modo)
    if (['year', 'quarter'].includes(props?.periodo)) setPeriod(props.periodo)
  }, [presentacion])
  const range = timeline ? rangoTendencia(timeline, tab, mode, period) : domainFor(tab, mode, period)
  return (
    <section className="card analytics" style={{ '--i': 1 }}>
      <CardHead title="Análisis de ventas" sub={a?.asOf ?? (demostracion ? DASHBOARD.asOf : 'Consultando datos…')}>
        <label className="select"><span className="sr-only">Período del gráfico</span><select value={period} onChange={(event) => setPeriod(event.target.value)}><option value="year">{timeline ? `${timeline.anio} disponible` : '2026 completo'}</option><option value="quarter">{timeline ? 'Período seleccionado' : 'Tercer trimestre'}</option></select><Chevron /></label>
        <button className={`circle-btn ${mode === 'line' ? 'is-on' : ''}`} onClick={() => setMode('line')} aria-label="Ver tendencia" aria-pressed={mode === 'line'}><LineIcon /></button>
        <button className={`circle-btn ${mode === 'bars' ? 'is-on' : ''}`} onClick={() => setMode('bars')} aria-label={timeline?.granularidad === 'diaria' ? 'Ver barras diarias' : 'Ver barras mensuales'} aria-pressed={mode === 'bars'}><BarsIcon /></button>
      </CardHead>

      <div className="kpis">
        {KPIS.map((k) => (
          <div className="kpi" key={k.label}>
            <div className="kpi-num">
              {/* Número, unidad y tendencia se leen juntos y se ajustan al ancho como una sola cifra */}
              <FitText className="kpi-digits" title={`${k.int}${k.dec != null ? `,${k.dec}` : ''} ${k.unit ?? ''}`}><span className="kpi-int">{k.int}</span><span className="kpi-dec">{k.dec != null && <>,{k.dec}</>}</span><sup className="kpi-unit">{k.unit}</sup>{k.trend && <Trend dir={k.trend} good={k.good} />}</FitText>
            </div>
            <p className="kpi-label">{k.label}</p>
            <p className={`kpi-vs ${k.good ? 'tone-green' : 'tone-blue'}`}>{k.vs}</p>
          </div>
        ))}
      </div>

      <div className="chart-head">
        <div className="tabs" role="tablist">
          {CHART.tabs.map((t, i) => (
            <button key={t} role="tab" aria-selected={tab === i} className={tab === i ? 'is-on' : ''} onClick={() => setTab(i)}>{t}</button>
          ))}
        </div>
        <div className="chart-key">
          <span className="key key-a">{TABS[tab].a.name}</span>
          <span className="key key-b">{TABS[tab].b.name}</span>
          <span className="key-range">Rango {range[0].toLocaleString('es-CL')}–{range[1].toLocaleString('es-CL')} {timeline?.unidad && tab === 0 ? timeline.unidad : TABS[tab].unit}/{timeline?.granularidad === 'diaria' ? 'día' : mode === 'line' && timeline?.granularidad !== 'mensual' ? 'sem.' : 'mes'}</span>
        </div>
      </div>
      {demostracion || timeline ? <TrendChart timeline={timeline} tab={tab} mode={mode} period={period} /> : <p className="chart sin-medicion">Consultando la fuente de ventas…</p>}
    </section>
  )
}

export function AgentCard({ onOpen }) {
  const { demostracion, modelos, escenario } = useModelos()
  const { respuesta } = useVariables()
  const vigente = respuestaDelModelo(respuesta,modelos?.agente,escenario)
  const resumen = resumenVigente(resumenAgente(vigente, escenario), modelos?.agente, escenario)
  const grafico = demostracion ? null : graficoAgente(vigente,modelos?.agente,escenario)
  const AGENT = demostracion ? AGENT_DEMO : { ...AGENT_DEMO, ...(resumen?.azul ?? { sub: 'Esperando consulta', people: 'Consulta los datos de esta vista' }) }
  return (
    <section className="card agent" style={{ '--i': 2 }}>
      <header className="agent-head">
        <div>
          <h2>{AGENT.title}</h2>
          <p>{AGENT.sub}</p>
        </div>
        <span className="agent-progress" aria-hidden="true"><i /><i /></span>
      </header>
      {grafico && <div>
        <p className="agent-people">{grafico.titulo}</p>
        {grafico.componente === 'Columns' && <Columns className="ch-sm" onBlue max={grafico.max} unit={grafico.unidad} digits={grafico.unidad==='un.'||grafico.unidad==='unidades'?0:2}
          groups={grafico.filas.map(f=>({label:f.label,bars:[{value:f.valor,tone:'white',style:'solid'}]}))}
          tip={(_,i)=><><span><b>{grafico.filas[i].nombre}</b></span><span>{nf(grafico.filas[i].valor,2)} {grafico.unidad}</span></>} label={grafico.titulo} />}
        {grafico.componente === 'SmoothTrend' && <SmoothTrend className="ch-sm on-blue" tone="white" unit={grafico.unidad} digits={2}
          points={grafico.puntos} min={grafico.min} max={grafico.max} ticks={[]}
          marks={grafico.puntos.map((p,i)=>({i,label:p.label.slice(5)})).filter((p,i,a)=>i===0||i===a.length-1)} label={grafico.titulo} />}
        {grafico.limite && <p className="agent-people">{grafico.limite}</p>}
      </div>}
      <div className="agent-foot">
        <div className="agent-people">
          {AGENT.people}
          {demostracion && <span className="faces">
            <Avatar className="face" name="Manuel Díaz" initials="MD" />
            <Avatar className="face" name="Carla González" initials="CG" />
            <Avatar className="face" name="Andrés Pérez" initials="AP" />
          </span>}
        </div>
        <div className="agent-line">
          <p className="agent-text" title={AGENT.texto}>
            <span className="soft">{AGENT.soft[0]}<br />{AGENT.soft[1]}</span>
            <br />
            {AGENT.strong}
          </p>
          <button className="ring" aria-label="Abrir conversación" onClick={onOpen}><ArrowUpRight /></button>
        </div>
      </div>
    </section>
  )
}

export function BranchCard({ branch, index }) {
  const [page, setPage] = useState(index === 0 ? 2 : 1)
  if (branch.macros) return <section className="card branch branch-connected" data-sucursal={branch.code} style={{ '--i': 3 + index }}>
    <header className="branch-head"><div className="card-titles"><h2>{branch.title}</h2><p>{branch.tipo ?? 'Sucursal'}</p></div></header>
    <div className="branch-identity">
      <VoxelBuilding variant={branch.tone === 'alert' ? 'blue' : 'green'} className="building" />
      <div><p className="branch-state"><i className={`dot dot-${branch.tone === 'alert' ? 'delayed' : branch.tone === 'muted' ? 'pending' : 'complete'}`} />{branch.estado}</p>{branch.variacion && <p className="branch-comparison">Venta: {branch.variacion}{branch.referencia && ` frente a ${branch.referencia}`}</p>}</div>
    </div>
    <dl className="branch-macros">{branch.macros.map(k=><div key={k.metrica}><dt>{k.label}</dt><dd title={k.exacto}><FitText>{k.value}{k.unit&&<small>{k.unit}</small>}</FitText></dd></div>)}</dl>
  </section>
  return (
    <section className="card branch" style={{ '--i': 3 + index }}>
      <header className="branch-head">
        <div className="card-titles">
          <h2>{branch.grafico ? branch.tipo : `${branch.tipo ?? 'Sucursal'} No.${branch.rank}`}</h2>
          <p>{branch.code}</p>
        </div>
        <div className="pager" role="group" aria-label="Páginas">
          {[0, 1, 2].map((n) => (
            <button key={n} className={page === n ? 'is-on' : ''} onClick={() => setPage(n)} aria-current={page === n}>{n + 1}</button>
          ))}
        </div>
      </header>
      <div className={branch.grafico ? undefined : "branch-body"}>
        {branch.grafico ? branch.grafico.puntos.length > 1 ? <SmoothTrend className="ch-sm" tone="green" unit={branch.grafico.unidad} digits={2}
          points={branch.grafico.puntos} min={0} max={Math.max(1,...branch.grafico.puntos.map(p=>p.v))*1.15} ticks={[]}
          marks={branch.grafico.puntos.map((p,i)=>({i,label:p.label.slice(5)})).filter((p,i,a)=>i===0||i===a.length-1)} label={branch.grafico.titulo} />
          : branch.grafico.puntos.length === 1 ? <Columns className="ch-sm" unit={branch.grafico.unidad} max={Math.max(1,...branch.grafico.puntos.map(p=>p.v))*1.15} groups={branch.grafico.puntos.map(p=>({label:p.label.slice(5),bars:[{value:p.v,tone:'green'}]}))} label={branch.grafico.titulo} />
          : <p>{branch.grafico.limite ?? 'No hay registros para este intervalo.'}</p>
          : <VoxelBuilding variant={branch.tone === 'alert' ? 'blue' : 'green'} className="building" />}
        <div className="branch-note">
          <h3><i className={`dot dot-${branch.tone === 'alert' ? 'delayed' : 'complete'}`} />{branch.title}</h3>
          <p>{branch.pages?.[page] ?? branch.text}</p>
        </div>
      </div>
    </section>
  )
}

export function ReconCard() {
  const { demostracion, modelos } = useModelos()
  const r = modelos?.agente?.recon
  const value = demostracion ? 15 : r?.value ?? 0
  const total = demostracion ? 18 : r?.total ?? 0
  const RECON = demostracion ? RECON_DEMO : { title: RECON_DEMO.title, sub: r?.sub ?? 'Sin fuente de conciliación', pct: total ? `${Math.round(value / total * 100)} %` : '—', items: [{ tone: 'ok', label: 'Cuadradas', value, total }, { tone: 'grey', label: 'Pendientes', value: total - value, total }] }
  return (
    <section className="card recon" style={{ '--i': 5 }}>
      <CardHead title={RECON.title} sub={RECON.sub}>
        <button className="circle-btn" aria-label="Abrir conciliación" onClick={() => document.querySelector('.detail')?.scrollIntoView({ behavior: 'smooth' })}><ArrowUpRight /></button>
      </CardHead>
      <div className="recon-body">
        <ul className="recon-list">
          {RECON.items.map((it) => (
            <li key={it.label}>
              <span className="recon-label"><i className={`dot dot-${it.tone === 'ok' ? 'complete' : 'active'}`} />{it.label}</span>
              <span className="recon-value"><Fraction value={it.value} total={it.total} /></span>
            </li>
          ))}
        </ul>
        <div className="gauge">
          {total > 0 ? <ReconGauge value={value} total={total} /> : <p>Sin medición</p>}
          <span className="chip chip-green gauge-pct">{RECON.pct}</span>
          <span className="gauge-frac"><Fraction value={value} total={total} /></span>
        </div>
      </div>
    </section>
  )
}

export function MetricCard({ m, index }) {
  const color = m.tone === 'alert' ? C.blue : C.green
  return (
    <section className={`card metric metric-${m.tone}`} style={{ '--i': 6 + index }}>
      <div className="card-titles">
        <h2>{m.title}</h2>
        <p>{m.sub}</p>
      </div>
      {m.sinMedicion ? <p className="wave sin-medicion">{m.sinMedicion}</p> : <Sparkline values={m.wave} mark={m.mark} color={color} label={m.title} labels={m.labels} unit={m.unit} granularidad={m.granularidad} />}
      <div className="metric-stats">
        {m.side.map((s, i) => (
          <div key={s.label} className={i === 1 ? 'main' : 'side'}>
            <span>{s.label}</span>
            <FitText as="b" title={String(s.value)}>{s.value}</FitText>
          </div>
        ))}
      </div>
    </section>
  )
}

export const BRANCH_LIST = BRANCHES
export const METRIC_LIST = METRICS

export function DetailCard() {
  const { modelos, demostracion, escenario } = useModelos()
  const { respuesta } = useVariables()
  const cobros = !demostracion && respuestaDelModelo(respuesta,modelos?.agente,escenario)?.decision?.dominio === 'cobranza'
  const [seleccion, setSeleccion] = useState(null)
  const a = modelos?.agente
  const listado = modelos?.ventas?.listado
  const filas = listado?.filas[listado.inicial] ?? []
  const elegida = filas.find((r) => r.key === seleccion)
  const BRANCH_DETAIL = demostracion ? DETAIL_DEMO : a?.detail ?? []
  return (
    <><section className="card detail" style={{ '--i': 10 }}>
      <CardHead title={cobros ? 'Cobros recibidos' : a?.detalleDimension ? `Detalle por ${a.detalleDimension.toLowerCase()}` : 'Detalle por sucursal'} sub={cobros ? `${Math.min(8,a.cobrosDetalle.length)} de ${a.cobrosCantidad} cobros, más recientes` : demostracion ? 'Tercer trimestre de 2026 · cifras ilustrativas' : a ? 'Venta, variación y margen' : 'Consultando datos…'}>
        <span className="detail-source">{demostracion ? 'Fuente de ejemplo · ERP' : 'Fuente conectada · ERP'}</span>
      </CardHead>
      <div className="detail-scroll">
        <table>
          <thead>{cobros ? <tr>{['Factura','Fecha de cobro','Cliente','Sucursal','Cobrado MM$','Estado'].map(t=><th key={t}>{t}</th>)}</tr> : <tr><th>{a?.detalleDimension ?? 'Sucursal'}</th><th>Venta neta</th><th>{demostracion ? 'Var. anual' : 'Variación'}</th><th>Margen bruto</th><th>Var. margen</th><th>Estado</th></tr>}</thead>
          <tbody>
            {cobros ? [...a.cobrosDetalle].sort((a,b)=>b.fecha.localeCompare(a.fecha)||b.id.localeCompare(a.id)).slice(0,8).map((p,i)=><tr key={`${p.id}-${p.fecha}-${i}`}><th>{p.id}</th><td>{p.fecha}</td><td>{p.cliente}</td><td>{p.sucursal}</td><td>{p.monto}</td><td><span className="detail-state complete"><i className="dot dot-complete" />Registrado</span></td></tr>) : BRANCH_DETAIL.map((branch) => <tr key={branch.name}><th>{listado?.dimensiones ? <button className="detail-row-button" onClick={() => setSeleccion(branch.key === seleccion ? null : branch.key)} aria-expanded={branch.key === seleccion}>{branch.name}</button> : branch.name}</th><td>{branch.sales} {a?.unidad ?? 'MM$'}</td><td>{branch.change}</td><td>{branch.margin}</td><td>{branch.marginChange}</td><td><span className={`detail-state ${branch.tone}`}><i className={`dot dot-${branch.tone}`} />{branch.state}</span></td></tr>)}
            <tr className="detail-total">{cobros ? <><th>Total</th><td>—</td><td>—</td><td>—</td><td>{a.cobrosTotal} MM$</td><td>{a.cobrosCantidad} cobros</td></> : <><th>Total</th><td>{demostracion ? '444,6' : a?.total?.sales ?? '—'} {a?.unidad ?? 'MM$'}</td><td>{demostracion ? '+21,3%' : a?.total?.change ?? '—'}</td><td>{demostracion ? '28,9%' : a?.total?.margin ?? 'Sin medición'}</td><td>—</td><td>{demostracion ? 2 : a?.total?.count ?? 0} {a?.detalleDimension?.toLowerCase() === 'producto' ? 'productos' : a?.detalleDimension?.toLowerCase() === 'productos' ? 'productos' : 'sucursales'}</td></>}</tr>
          </tbody>
        </table>
      </div>
    </section>
    {!cobros && elegida && listado?.dimensiones && <RegistrosVentas escenario={escenario} periodo={listado.periodoRegistros} etiquetaPeriodo={modelos.periodo} filtro={listado.filtroRegistros} dimension={listado.dimensiones[listado.inicial]} fila={elegida} />}</>
  )
}
