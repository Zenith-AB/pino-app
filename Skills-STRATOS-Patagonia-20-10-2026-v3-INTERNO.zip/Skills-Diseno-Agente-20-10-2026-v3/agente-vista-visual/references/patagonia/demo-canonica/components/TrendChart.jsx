import { tint } from '../palette.js'
import { datosTendencia, rangoTendencia } from '../datos/tendencia.js'
import { useMemo, useState } from 'react'
import { useTheme } from './ThemeToggle.jsx'
import { DISCOUNT_BAND, MILESTONES as DEMO_MILESTONES, TABS, TODAY as DEMO_TODAY, WINDOW as DEMO_WINDOW, YEAR_END as DEMO_END, domainFor, fmt, fmtDay, fmtMonth, fmtMonthShort, rowsFor, signed } from '../salesTimeline.js'
import { C, Highcharts, HighchartsReact, rem } from './highcharts.js'
import { Alert, CheckSquare, Coin, Lock, Megaphone, Store } from './Icons.jsx'

// Constante: un objeto nuevo en cada render haría que highcharts-react volviera a actualizar el gráfico.
const CONTENEDOR = { className: 'chart-plot' }
const ICONS = { check: CheckSquare, coin: Coin, campaign: Megaphone, store: Store, alert: Alert, lock: Lock }

const seriesColors = (color) => ({ solid: color, faded: tint(color, 0.7), proj: tint(color, 0.8), fill: tint(color, 0.13), fadedFill: tint(color, 0.05), projFill: tint(color, 0.06) })
const SERIES_COLORS = { get a() { return seriesColors(C.green) }, get b() { return seriesColors(C.blue) } }

const sameLayout = (a, b) => a && a.xs.length === b.xs.length && a.left === b.left && a.width === b.width && a.top === b.top && a.height === b.height && a.xs.every((x, i) => x === b.xs[i])

function tooltipHtml(points, rows, cfg, line, diaria = false) {
  const index = points[0].point.index
  const row = rows[index]
  const prev = rows[index - 1]
  const date = diaria ? `Día ${fmtDay(row.t)}` : line ? `Semana al ${fmtDay(row.t)}` : `${fmtMonth(row.t)} ${new Date(row.t).getUTCFullYear()}`
  const chip = row.projected ? '<span class="hc-chip is-est">Estimado</span>' : `<span class="hc-chip">${row[cfg.b.key] == null ? 'Sin medición de la segunda serie' : cfg.chip(row[cfg.a.key], row[cfg.b.key])}</span>`
  const pct = cfg.unit === '%'
  const body = [cfg.a, cfg.b].map((s, i) => {
    const value = row[s.key]
    if (value == null) return `<div class="hc-row"><div><b>${s.name}: sin medición</b></div></div>`
    const delta = prev?.[s.key] != null ? value - prev[s.key] : 0
    const rel = prev ? (delta / (prev[s.key] || 1)) * 100 : 0
    const deltaText = prev ? `${signed(delta, cfg.digits)} ${pct ? 'pp' : cfg.unit} vs ${diaria ? 'día' : line ? 'sem.' : 'mes'} ant.` : 'Primer registro'
    return `<div class="hc-row hc-row-${i ? 'b' : 'a'}">
      <i></i>
      <div><b>${fmt(value, cfg.digits)} ${cfg.unit}</b><small>${deltaText}</small></div>
      ${prev && !pct ? `<em>${signed(rel)} %</em>` : ''}
    </div>`
  }).join('<hr />')
  return `<div class="hc-card"><div class="hc-head"><span>${date}</span>${chip}</div>${body}</div>`
}

function MilestoneIcon({ icon }) {
  if (icon === 'today') return <span className="ms-dot" />
  if (icon === 'start') return <span className="ms-ring" />
  const Icon = ICONS[icon]
  return <Icon />
}

export default function TrendChart({ tab = 0, mode = 'line', period = 'year', timeline }) {
  const [layout, setLayout] = useState(null)
  const [hover, setHover] = useState(null)
  const [focus, setFocus] = useState(null)
  const TODAY = timeline ? Date.parse(timeline.corte) : DEMO_TODAY
  const YEAR_END = timeline ? TODAY : DEMO_END
  const MILESTONES = timeline?.hitos ?? DEMO_MILESTONES
  const WINDOW = timeline ? { year: { min: timeline.granularidad === 'diaria' ? Date.parse(timeline.periodo.desde) : Date.UTC(timeline.anio, 0, 1), start: null }, quarter: { min: Date.parse(timeline.periodo.desde), start: Date.parse(timeline.periodo.desde) } } : DEMO_WINDOW
  const cfg = timeline?.unidad && tab === 0 ? { ...TABS[tab], unit: timeline.unidad } : TABS[tab]
  const view = WINDOW[period]
  const line = mode === 'line'
  const diaria = timeline?.granularidad === 'diaria'
  const semanal = line && !diaria && timeline?.granularidad !== 'mensual'
  const tema = useTheme()
  const r = rem()
  // Opciones memorizadas: Highcharts solo se actualiza cuando cambian datos, vista, tema o escala. El estado de
  // hover/foco y los renders del padre ya no rehacen el gráfico completo (antes, cada punto bajo el puntero).
  const { rows, options } = useMemo(() => {
    const rows = timeline ? datosTendencia(timeline, mode) : rowsFor(mode)
    const [min, max] = timeline ? rangoTendencia(timeline, tab, mode, period) : domainFor(tab, mode, period)

    const lastActual = rows.filter((row) => !row.projected && row[cfg.a.key] != null).at(-1)?.t
    const markerAt = (t) => line && (t === lastActual || t === view.start)
      ? { enabled: true, radius: 3.5, lineWidth: 1.5, lineColor: '#FFFFFF' }
      : undefined

    const zones = (c) => [
      ...(view.start ? [{ value: view.start, color: c.faded, fillColor: c.fadedFill }] : []),
      { value: TODAY + 1, color: c.solid, fillColor: c.fill },
      { color: c.proj, fillColor: c.projFill },
    ]

    const makeSeries = (s, key) => ({
      type: line ? 'areaspline' : 'column',
      name: s.name,
      color: SERIES_COLORS[key].solid,
      zoneAxis: 'x',
      zones: zones(SERIES_COLORS[key]),
      data: rows.map((row) => ({ x: row.t, y: row[s.key], marker: markerAt(row.t) })),
    })

    const options = {
      chart: {
        spacing: [0.9 * r, 0.6 * r, 0.3 * r, 0.6 * r],
        plotBackgroundColor: { pattern: { path: { d: `M 0 0 h ${0.09 * r} v ${0.09 * r} h ${-0.09 * r} Z`, fill: C.ink4, strokeWidth: 0 }, width: 0.62 * r, height: 0.62 * r } },
        events: {
          render() {
            const axis = this.xAxis[0]
            const next = {
              left: this.plotLeft, width: this.plotWidth, top: this.plotTop, height: this.plotHeight,
              xs: MILESTONES.map((m) => Math.round(axis.toPixels(m.t))),
            }
            setLayout((prev) => (sameLayout(prev, next) ? prev : next))
          },
        },
      },
      accessibility: {
        description: `${cfg.a.name} y ${cfg.b.name} ${diaria ? 'diaria' : semanal ? 'semanal' : 'mensual'} de ${timeline?.anio ?? 2026}${timeline ? ', según registros disponibles' : ' con proyección hasta diciembre'}. Hitos: ${MILESTONES.filter((m) => !m.only || m.only === period).map((m) => `${fmtDay(m.t)}, ${m.title}`).join('; ')}.`,
      },
      xAxis: {
        type: 'datetime',
        min: diaria && view.min === YEAR_END ? view.min - 43200000 : view.min,
        max: diaria && view.min === YEAR_END ? YEAR_END + 43200000 : YEAR_END,
        lineWidth: 0,
        tickLength: 0,
        labels: { enabled: false },
        crosshair: { color: C.ink4, width: 1 },
        plotLines: [
          ...(view.start ? [{ value: view.start, color: C.ink4, width: 1.2, dashStyle: 'Dash', zIndex: 3 }] : []),
          { value: TODAY, color: C.ink4, width: 1.2, dashStyle: 'Dash', zIndex: 3 },
        ],
        plotBands: timeline ? [] : [{
          from: DISCOUNT_BAND[0],
          to: DISCOUNT_BAND[1],
          color: 'rgba(31, 79, 255, 0.07)',
        }],
      },
      yAxis: {
        title: { text: null },
        labels: { enabled: false },
        gridLineWidth: 0,
        min,
        max,
        startOnTick: false,
        endOnTick: false,
      },
      tooltip: {
        shared: true,
        hideDelay: 120,
        formatter() { return tooltipHtml(this.points, rows, cfg, semanal, diaria) },
        positioner(width, height, point) {
          const { chart } = this
          const x = point.plotX + chart.plotLeft
          const left = x + 14 + width > chart.chartWidth - 4 ? x - width - 14 : x + 14
          return { x: left, y: chart.plotTop + 4 }
        },
      },
      plotOptions: {
        series: {
          marker: { enabled: false, symbol: 'circle', states: { hover: { enabled: true, radius: 4.5, lineWidth: 2, lineColor: '#FFFFFF' } } },
          point: { events: { mouseOver() { setHover({ x: Math.round(this.series.xAxis.toPixels(this.x)), t: this.x }) } } },
          events: { mouseOut() { setHover(null) } },
        },
        areaspline: { threshold: null, lineWidth: 2 },
        column: { borderWidth: 0, borderRadius: 0.3 * r, maxPointWidth: 1.4 * r, pointPadding: 0.12, groupPadding: 0.2 },
      },
      series: [makeSeries(cfg.a, 'a'), makeSeries(cfg.b, 'b')],
    }
    return { rows, options }
  }, [timeline, tab, mode, period, tema, r]) // eslint-disable-line react-hooks/exhaustive-deps

  const visible = MILESTONES
    .map((m, i) => ({ ...m, i, x: layout?.xs[i] }))
    .filter((m) => layout && (!m.only || m.only === period) && m.x >= layout.left - 1 && m.x <= layout.left + layout.width + 1)
  const near = (x) => hover && Math.abs(hover.x - x) < 4.2 * r
  const active = visible.find((m) => m.i === focus)

  if (timeline && !rows.some((r) => Number.isFinite(r[cfg.a.key]))) return <div className="chart sin-medicion" role="status">Sin medición de {cfg.a.name.toLowerCase()} en esta fuente.</div>

  return (
    <div className="chart chart-rich" onMouseLeave={() => setHover(null)}>
      <HighchartsReact
        key={`${tab}-${mode}-${period}-${timeline?.corte ?? 'demo'}`}
        highcharts={Highcharts}
        options={options}
        allowChartUpdate={Boolean(timeline)}
        containerProps={CONTENEDOR}
      />
      {layout && (
        <>
          {active && <span className="ms-guide" style={{ left: active.x, top: layout.top, height: layout.height }} aria-hidden="true" />}
          <div className="ms-track" style={{ left: layout.left, width: layout.width }} aria-hidden="true" />
          <ol className="milestones" aria-label="Hitos del período">
            {visible.map((m) => {
              const edge = m.x > layout.left + layout.width - 3 * r ? 'is-right' : m.x < layout.left + 3 * r ? 'is-left' : ''
              return (
                <li key={m.i} className={`ms ms-${m.tone} ${edge} ${m.strong ? 'is-strong' : ''}`} style={{ left: m.x }}>
                  <button
                    className="ms-icon"
                    aria-label={`${m.title}, ${fmtDay(m.t)}: ${m.text}`}
                    onMouseEnter={() => setFocus(m.i)}
                    onMouseLeave={() => setFocus(null)}
                    onFocus={() => setFocus(m.i)}
                    onBlur={() => setFocus(null)}
                  >
                    <MilestoneIcon icon={m.icon} />
                  </button>
                  {m.label && !near(m.x) && <span className="ms-label">{m.label}</span>}
                </li>
              )
            })}
          </ol>
          {hover && (
            <span className="ms-hover" style={{ left: hover.x }} aria-hidden="true">
              {!visible.some((m) => Math.abs(m.x - hover.x) < 1.3 * r) && <i />}
              <b>{diaria || line ? fmtDay(hover.t) : fmtMonthShort(hover.t)}</b>
            </span>
          )}
          {active && (
            <div className={`ms-pop ${active.x > layout.left + layout.width - 9 * r ? 'is-right' : ''}`} style={{ left: active.x }} role="tooltip">
              <small>{fmtDay(active.t)} {new Date(active.t).getUTCFullYear()}</small>
              <b>{active.title}</b>
              <p>{active.text}</p>
            </div>
          )}
        </>
      )}
    </div>
  )
}
