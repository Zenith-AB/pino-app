const base = {
  width: '1em',
  height: '1em',
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.5,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  'aria-hidden': true,
}

const make = (paths) => (props) => <svg {...base} {...props}>{paths}</svg>

export const ArrowLeft = make(<path d="M19 12H5m5.5-5.5L5 12l5.5 5.5" />)
export const ArrowUpRight = make(<path d="M7.5 16.5 16.5 7.5M9 7.5h7.5V15" />)
export const Refresh = make(<><path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3" /><path d="M19.5 4.5v4h-4" /></>)
export const Plus = make(<path d="M12 5v14M5 12h14" />)
export const Chevron = make(<path d="m7 10 5 5 5-5" />)
export const Gear = make(<><circle cx="12" cy="12" r="2.8" /><path d="M10.3 3.6h3.4l.5 2.3 1.6.9 2.2-.8 1.7 2.9-1.7 1.6v1.9l1.7 1.6-1.7 2.9-2.2-.8-1.6.9-.5 2.3h-3.4l-.5-2.3-1.6-.9-2.2.8L4.3 16l1.7-1.6v-1.9L4.3 10.9 6 8l2.2.8 1.6-.9.5-2.3Z" /></>)
export const LineIcon = make(<><path d="M4 4v16h16" /><path d="m7.5 14.5 3.5-4 3 2.5 5-6" /></>)
export const BarsIcon = make(<><rect x="4.5" y="10" width="3" height="9" rx="1.2" /><rect x="10.5" y="5" width="3" height="14" rx="1.2" /><rect x="16.5" y="8" width="3" height="11" rx="1.2" /></>)
export const Bell = make(<><path d="M6.5 9.5a5.5 5.5 0 0 1 11 0c0 5.5 2 7 2 7h-15s2-1.5 2-7" /><path d="M10.2 19.5a2 2 0 0 0 3.6 0" /></>)
export const Mail = make(<><rect x="3.5" y="5.5" width="17" height="13" rx="3.5" /><path d="m7.5 10 4.5 3 4.5-3" /></>)


// Chat del agente
export const ArrowUp = make(<path d="M12 19V5m-5.5 5.5L12 5l5.5 5.5" />)
export const Mic = make(<><rect x="9" y="3.5" width="6" height="11" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v2.5" /></>)
export const Database = make(<><ellipse cx="12" cy="6.5" rx="6.5" ry="2.5" /><path d="M5.5 6.5v11c0 1.4 2.9 2.5 6.5 2.5s6.5-1.1 6.5-2.5v-11M5.5 12c0 1.4 2.9 2.5 6.5 2.5s6.5-1.1 6.5-2.5" /></>)
export const ChevronUp = make(<path d="m7 14 5-5 5 5" />)
export const Close = make(<path d="M7 7l10 10M17 7 7 17" />)
export const Compose = make(<><path d="M12 4.5H8A3.5 3.5 0 0 0 4.5 8v8A3.5 3.5 0 0 0 8 19.5h8a3.5 3.5 0 0 0 3.5-3.5v-4" /><path d="m10 14 .6-2.6 7.2-7.2a1.4 1.4 0 0 1 2 2l-7.2 7.2L10 14Z" /></>)
export const Check = make(<path d="m5.5 12.5 4 4 9-9" />)

// Vistas del ERP
export const Search = make(<><circle cx="11" cy="11" r="6" /><path d="m15.5 15.5 4 4" /></>)
export const Filter = make(<path d="M4.5 6h15M7.5 12h9M10.5 18h3" />)
export const Download = make(<path d="M12 4.5v10.5m-4.5-4.5L12 15l4.5-4.5M5 19.5h14" />)
export const Pin = make(<><path d="M9 4.5h6l-1 5 3 3v1.5H7V12.5l3-3Z" /><path d="M12 14v5.5" /></>)
export const Share = make(<><circle cx="17" cy="6.5" r="2.2" /><circle cx="7" cy="12" r="2.2" /><circle cx="17" cy="17.5" r="2.2" /><path d="m9 11 6-3.4M9 13l6 3.4" /></>)
export const Coin = make(<><circle cx="12" cy="12" r="8.5" /><path d="M14.5 9.5c-.4-.9-1.3-1.4-2.5-1.4-1.4 0-2.5.8-2.5 1.9 0 2.6 5 1.4 5 4 0 1.1-1.1 1.9-2.5 1.9-1.2 0-2.2-.6-2.6-1.5M12 6.6V8m0 8v1.4" /></>)
export const Megaphone = make(<><path d="M4.5 10.2v3.6h3l7 4.2V6l-7 4.2Z" /><path d="M7.5 13.8 8.6 19h2.2l-.9-4.4M18 9.6a3.4 3.4 0 0 1 0 4.8" /></>)
export const Bookmark = make(<path d="M7 4.5h10v15l-5-3.6-5 3.6Z" />)
export const Layers = make(<><path d="m12 4 8 4.5-8 4.5-8-4.5Z" /><path d="m4 12.5 8 4.5 8-4.5" /></>)

// Hitos del gráfico de ventas
export const CheckSquare = make(<><rect x="4.5" y="4.5" width="15" height="15" rx="4" /><path d="m8.8 12.2 2.3 2.3 4.3-4.6" /></>)
export const Store = make(<><path d="M4.5 9.5 6 5h12l1.5 4.5" /><path d="M4.5 9.5c0 1.4 1.1 2.5 2.5 2.5S9.5 10.9 9.5 9.5c0 1.4 1.1 2.5 2.5 2.5s2.5-1.1 2.5-2.5c0 1.4 1.1 2.5 2.5 2.5s2.5-1.1 2.5-2.5" /><path d="M6 12v7.5h12V12M10 19.5v-4h4v4" /></>)
export const Alert = make(<><circle cx="12" cy="12" r="8.5" /><path d="M12 7.8v5" /><path d="M12 16.2h.01" strokeWidth="2.2" /></>)
export const Lock = make(<><rect x="5.5" y="10.5" width="13" height="9" rx="2.5" /><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" /></>)

export const Mark = (props) => (
  <svg width="1em" height="1em" viewBox="0 0 24 24" aria-hidden="true" {...props}>
    <g fill="currentColor">
      <circle cx="8.2" cy="8.2" r="4.6" />
      <circle cx="15.8" cy="8.2" r="4.6" />
      <circle cx="8.2" cy="15.8" r="4.6" />
      <circle cx="15.8" cy="15.8" r="4.6" />
    </g>
    <path d="M12 9.2 14.8 12 12 14.8 9.2 12Z" fill="#fff" />
  </svg>
)

// La flecha indica la dirección; el color (good) indica si es bueno o malo para el negocio
export const Trend = ({ dir, good = dir === 'up' }) => (
  <svg className={`trend ${good ? 'is-good' : 'is-bad'}`} width="0.6em" height="0.8em" viewBox="0 0 10 13" aria-hidden="true">
    <path
      d={dir === 'up' ? 'M5 12V1.5M1.2 5.3 5 1.5l3.8 3.8' : 'M5 1v10.5M1.2 7.7 5 11.5l3.8-3.8'}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
)

// Logo «Cumbre» de Patagonia ERP: una cresta de dos agujas (Fitz Roy) en línea, con ambas bases en la misma
// línea; la cumbre derecha, más alta, es un nodo de dato verde. La baldosa no trae radio: lo pone el CSS
// con el mismo radio que las tarjetas.
export function Logo({ className, title = 'Patagonia ERP' }) {
  return (
    <svg className={className} viewBox="0 0 48 48" role={title ? 'img' : undefined} aria-label={title || undefined} aria-hidden={title ? undefined : true}>
      <rect width="48" height="48" fill="#1F4FFF" />
      <path d="M9 34 L18.5 19.5 L24 27.5 L31 14 L39 34" fill="none" stroke="#FFFFFF" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="31" cy="14" r="4.2" fill="#00C27A" stroke="#1F4FFF" strokeWidth="2.3" />
    </svg>
  )
}

// Capa móvil del degradado del orbe: se anima con transform en el compositor (sin repintar el hilo principal).
export const FlujoOrbe = () => <span className="orb-flujo" aria-hidden="true" />
