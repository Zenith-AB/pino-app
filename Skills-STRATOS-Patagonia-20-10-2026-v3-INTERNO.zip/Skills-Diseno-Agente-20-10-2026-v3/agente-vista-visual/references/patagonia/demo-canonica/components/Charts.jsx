import { useTheme } from './ThemeToggle.jsx'
import { escalaPuntos, rejillaPuntos } from '../datos/densidad-puntos.js'
import { dominioSerie, indicesEtiquetas } from '../datos/geometria-graficos.js'
import { remRaiz } from '../escala.js'
import { Fragment, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { P } from '../palette.js'

/* ==========================================================
   Gráficos de las vistas · gramática en DESIGN.md §4
   - Rayado = histórico, proyectado o en tránsito. Sólido = dato actual.
   - Barras con degradado de un solo tono (profundo → vivo → claro), como Payments.
   - Comparación histórica en gris rayado con línea-tapa y marcador cuadrado (Geotab).
   - Tooltip de vidrio que sigue al cursor; se mueve por transform, sin re-render.
   - Una sola animación de entrada por gráfico, cuando entra en pantalla.
   - Geometría en píxeles enteros: bordes y líneas de 1 px nítidos en 4K.
   ========================================================== */

export const nf = (v, d = 1) => v == null ? '—' : v.toLocaleString('es-CL', { minimumFractionDigits: d, maximumFractionDigits: d })
const remPx = remRaiz
const rd = Math.round
const crisp = (v) => Math.round(v) + 0.5
const TONE = { get blue() { return P.blue }, get green() { return P.green }, get orange() { return P.orange }, get ink() { return P.ink3 }, get white() { return P.white } }

// Variantes del mismo tono: mezcla con tinta (profundo) o con blanco (claro)
const hexRgb = (hex) => { const n = parseInt(hex.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255] }
const mix = (a, b, t) => { const x = hexRgb(a), y = hexRgb(b); return `rgb(${x.map((c, i) => rd(c + (y[i] - c) * t)).join(', ')})` }
const light = (hex) => mix(hex, '#FFFFFF', 0.24)
// Transparencia sobre el fondo de la tarjeta, como color sólido (la opacidad de grupo la usan las animaciones)
const over = (hex, a) => mix(P.surface, hex, a)

/* ---------- Infraestructura ---------- */

// Tamaño entero del contenedor + si ya entró en pantalla (para animar una sola vez)
export function useChartBox() {
  useTheme()
  const ref = useRef(null)
  const [box, setBox] = useState({ w: 0, h: 0 })
  const [seen, setSeen] = useState(false)
  useLayoutEffect(() => {
    const el = ref.current
    if (!el) return undefined
    const ro = new ResizeObserver(([entry]) => {
      // Fuera del documento (tablero conservado) el tamaño 0 no es real: se ignora y no se re-renderiza.
      if (!el.isConnected) return
      const w = rd(entry.contentRect.width)
      const h = rd(entry.contentRect.height)
      setBox((b) => (b.w === w && b.h === h ? b : { w, h }))
    })
    const io = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) { setSeen(true); io.disconnect() } }, { threshold: 0.2 })
    ro.observe(el)
    io.observe(el)
    return () => { ro.disconnect(); io.disconnect() }
  }, [])
  // Tablero conservado que vuelve a verse: repetir la entrada como al montarse (oculto → visto por el observador).
  useEffect(() => {
    let io = null
    const revelar = (evento) => {
      const el = ref.current
      if (!el || !evento.detail?.contains(el)) return
      setSeen(false); io?.disconnect()
      io = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) { setSeen(true); io.disconnect() } }, { threshold: 0.2 })
      io.observe(el)
    }
    window.addEventListener('patagonia:revelar-tablero', revelar)
    return () => { window.removeEventListener('patagonia:revelar-tablero', revelar); io?.disconnect() }
  }, [])
  return [ref, box, seen]
}

// Hover: el índice activo es estado (re-render solo al cambiar); la posición del tooltip va por transform
function useHover(limite = Infinity) {
  const [hover, setHover] = useState(null)
  const cur = useRef(null)
  const tipRef = useRef(null)
  const pos = useRef({ x: 0, y: 0, w: 0 })
  const frame = useRef(0)
  const place = () => {
    frame.current = 0
    const el = tipRef.current
    if (!el) return
    const { x, y, w } = pos.current
    const tw = el.offsetWidth
    const th = el.offsetHeight
    let tx = x + 16
    if (tx + tw > w) tx = x - 16 - tw
    if (tx < 0) tx = Math.min(Math.max(x - tw / 2, 0), Math.max(w - tw, 0))
    let ty = y - th - 14
    if (ty < -th * 0.6) ty = y + 22
    el.style.transform = `translate3d(${rd(tx)}px, ${rd(ty)}px, 0)`
  }
  const track = (e, pick) => {
    const r = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - r.left
    const y = e.clientY - r.top
    pos.current = { x, y, w: r.width }
    const next = pick(x, y, e) ?? null
    if (next !== cur.current) { cur.current = next; setHover(next) }
    if (!frame.current) frame.current = requestAnimationFrame(place)
  }
  const leave = () => { cur.current = null; setHover(null) }
  return { hover: typeof hover === 'number' && hover >= limite ? null : hover, setHover, tipRef, track, leave }
}

// Píldora de vidrio: segmentos <span> separados por «|»
function Tip({ tipRef, dark = false, children }) {
  const last = useRef(null)
  if (children) last.current = children
  return <div ref={tipRef} className={`tip${children ? ' is-on' : ''}${dark ? ' is-dark' : ''}`} aria-hidden="true">{last.current}</div>
}

const useSvgId = () => useId().replace(/[^a-zA-Z0-9]/g, '')

// Columna resaltada, línea guía y punto: HTML compuesto, el SVG no se repinta al pasar el mouse
const HoverBand = ({ x, width, top, height, dark }) => (
  <span className={`hv-band${x == null ? '' : ' is-on'}${dark ? ' is-dark' : ''}`} style={{ width, top, height, transform: `translate3d(${x ?? 0}px, 0, 0)` }} aria-hidden="true" />
)
const HoverLine = ({ x, y, top, height }) => (
  <>
    <span className={`hv-line${x == null ? '' : ' is-on'}`} style={{ top, height, transform: `translate3d(${x ?? 0}px, 0, 0)` }} aria-hidden="true" />
    <span className={`hv-dot${x == null || y == null ? '' : ' is-on'}`} style={{ transform: `translate3d(${x ?? 0}px, ${y ?? 0}px, 0)` }} aria-hidden="true" />
  </>
)

// Pinturas compartidas: degradados de un tono y rayas
function Paints({ id, r }) {
  const s = Math.max(6, rd(0.5 * r))
  const sw = Math.max(1.3, 0.1 * r)
  return (
    <>
      {['blue', 'green', 'orange'].map((t) => (
        <Fragment key={t}>
          <linearGradient id={`${id}-fade-${t}`} x1="0" y1="0" x2="0.2" y2="1">
            <stop offset="0" stopColor={TONE[t]} />
            <stop offset="0.45" stopColor={TONE[t]} stopOpacity="0.85" />
            <stop offset="1" stopColor={TONE[t]} stopOpacity="0.12" />
          </linearGradient>
          <linearGradient id={`${id}-side-${t}`} x1="0" y1="0" x2="0.6" y2="1">
            <stop offset="0" stopColor={TONE[t]} stopOpacity="0.34" />
            <stop offset="1" stopColor={TONE[t]} stopOpacity="0.03" />
          </linearGradient>
        </Fragment>
      ))}
      <linearGradient id={`${id}-solid-white`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#FFFFFF" />
        <stop offset="1" stopColor="#FFFFFF" stopOpacity="0.84" />
      </linearGradient>
      <pattern id={`${id}-stripe`} width={s} height={s} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2={s} stroke="#FFFFFF" strokeOpacity="0.86" strokeWidth={sw} />
      </pattern>
      <pattern id={`${id}-stripe-soft`} width={s} height={s} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2={s} stroke="#FFFFFF" strokeOpacity="0.62" strokeWidth={sw * 0.8} />
      </pattern>
      <pattern id={`${id}-stripe-ink`} width={s * 0.8} height={s * 0.8} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2={s * 0.8} stroke={P.ink3} strokeOpacity="0.62" strokeWidth="1" />
      </pattern>
      <pattern id={`${id}-stripe-orange`} width={s * 0.8} height={s * 0.8} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2={s * 0.8} stroke={P.orange} strokeOpacity="0.42" strokeWidth="1.2" />
      </pattern>
    </>
  )
}

// Una barra en la gramática del sistema
function Bar({ id, x, y, w, h, tone, style, onBlue }) {
  const X = rd(x)
  const W = Math.max(rd(x + w) - X, 1)
  const Y = rd(y)
  const H = Math.max(rd(y + h) - Y, 0)
  if (!H) return null
  const box = { x: X, y: Y, width: W, height: H }
  if (onBlue) {
    return style === 'hatch'
      ? <><rect {...box} fill="rgba(255,255,255,0.1)" /><rect {...box} fill={`url(#${id}-stripe-soft)`} /><line x1={X} x2={X + W} y1={Y + 0.5} y2={Y + 0.5} stroke="#FFFFFF" strokeOpacity="0.9" /></>
      : <rect {...box} fill={`url(#${id}-solid-white)`} />
  }
  if (style === 'hatch' && tone === 'ink') {
    return <><rect {...box} fill={P.hatch} /><rect {...box} fill={`url(#${id}-stripe-ink)`} /></>
  }
  if (style === 'hatch') return <><rect {...box} fill={`url(#${id}-fade-${tone})`} /><rect {...box} fill={`url(#${id}-stripe)`} /></>
  return <rect {...box} fill={TONE[tone]} />
}

// Línea-tapa con marcador cuadrado (Geotab)
const Cap = ({ x, w, y, color }) => (
  <g>
    <line x1={rd(x)} x2={rd(x + w)} y1={crisp(y) - 1} y2={crisp(y) - 1} stroke={color} strokeWidth="1" />
    <rect x={rd(x + w / 2) - 2} y={rd(y) - 3} width="4" height="4" fill={color} />
  </g>
)

// Etiqueta de referencia a la derecha del área (meta, tope)
const SideLabel = ({ x, y, label, r }) => {
  const [first, ...rest] = label.split(' ')
  return (
    <g className="ch-side">
      <text x={x} y={y - 0.2 * r}>{first}</text>
      <text x={x} y={y + 0.9 * r} className="is-strong">{rest.join(' ')}</text>
    </g>
  )
}

const Axis = ({ x1, x2, y }) => (
  <g className="ch-axis">
    <line x1={rd(x1)} x2={rd(x2)} y1={crisp(y)} y2={crisp(y)} />
    <circle cx={rd(x1)} cy={crisp(y)} r="2" />
    <circle cx={rd(x2)} cy={crisp(y)} r="2" />
  </g>
)

/* ---------- Columnas: simples, pareadas o apiladas ---------- */
// groups: [{ label, note, noteTone, bars: [{ value, tone, style: 'solid' | 'hatch', label }] }]
const ALL = () => true
export function Columns({ groups, max, ticks, unit = '', digits = 1, target, band, onBlue = false, stacked = false, showLabel = ALL, tip, label, className = '' }) {
  const [ref, { w, h }, seen] = useChartBox()
  const { hover, tipRef, track, leave } = useHover(groups.length)
  const id = useSvgId()
  const r = w ? remPx() : 16
  const hasNote = groups.some((g) => g.note)
  const padL = ticks ? 3.1 * r : 0
  const padR = target ? 4.6 * r : 0.2 * r
  const padT = 2.4 * r
  const padB = (hasNote ? 3.4 : 2.1) * r
  const pw = Math.max(w - padL - padR, 0)
  const ph = Math.max(h - padT - padB, 0)
  const base = rd(padT + ph)
  const y = (v) => base - (Math.min(v, max) / max) * ph
  const gw = pw / groups.length
  const ink = onBlue ? P.white : P.ink
  const indicesX = indicesEtiquetas(groups.map(g => g.label), pw, r)
  const indicesValor = indicesEtiquetas(groups.map((g,i) => showLabel(g,i) ? nf(Math.max(...g.bars.map(b=>b.value ?? 0)),digits) + unit : ''), pw, r)

  const layout = groups.map((g, gi) => {
    const cx = padL + gi * gw + gw / 2
    if (stacked) {
      const bw = Math.min(gw * 0.58, 3.6 * r)
      let acc = 0
      const bars = g.bars.map((b) => { const bottom = y(acc); acc += b.value; return { ...b, x: cx - bw / 2, w: bw, top: y(acc), bottom } })
      return { cx, bars, top: y(acc), total: acc, bw }
    }
    const tw = Math.min(gw * 0.78, g.bars.length * 4.4 * r)
    const bw = tw / g.bars.length
    const bars = g.bars.map((b, bi) => ({ ...b, x: cx - tw / 2 + bi * bw, w: bw - (g.bars.length > 1 ? 1 : 0), top: y(b.value), bottom: base }))
    return { cx, bars, top: Math.min(...bars.map((b) => b.top)), bw }
  })
  const pick = (x) => (x < padL || x > w - padR ? null : Math.min(Math.floor((x - padL) / gw), groups.length - 1))

  const svg = useMemo(() => w > 0 && h > 0 && (
        <svg width={w} height={h} role="img" aria-label={label}>
          <defs>
            <Paints id={id} r={r} />
          </defs>
          {ticks?.map((t) => (
            <g key={t}>
              {t > 0 && <line x1={padL} x2={w - padR} y1={crisp(y(t))} y2={crisp(y(t))} className="ch-grid" />}
              <text x={padL - 0.8 * r} y={y(t) + 0.28 * r} textAnchor="end" className="ch-tick">{nf(t, 0)}</text>
            </g>
          ))}
          {band && (
            <g className="ch-band">
              <rect x={rd(padL + band.from * gw)} y={rd(padT - 1.5 * r)} width={rd((band.to - band.from + 1) * gw)} height={rd(base - padT + 1.5 * r)} />
              <text x={padL + band.from * gw + 0.7 * r} y={padT - 0.55 * r}>{band.label}</text>
            </g>
          )}
          <g className={`ch-grow ${seen ? 'is-in' : ''}`} style={{ transformOrigin: `0px ${base}px` }}>
            {layout.map((g, gi) => g.bars.map((b, bi) => b.value != null && (
              <Bar key={`${gi}-${bi}`} id={id} x={b.x} y={b.top} w={b.w} h={b.bottom - b.top} tone={b.tone} style={b.style} onBlue={onBlue} />
            )))}
          </g>
          {target && (
            <g className="ch-target">
              <line x1={padL} x2={rd(w - padR + 0.3 * r)} y1={crisp(y(target.value))} y2={crisp(y(target.value))} />
              <rect x={rd(w - padR + 0.3 * r) - 2} y={rd(y(target.value)) - 2} width="5" height="5" />
              <SideLabel x={w - padR + 0.9 * r} y={y(target.value)} label={target.label} r={r} />
            </g>
          )}
          <g className={`ch-fade ${seen ? 'is-in' : ''}`}>
            {layout.map((g, gi) => {
              if (!indicesValor.has(gi)) return null
              if (stacked) {
                return (
                  <g key={gi}>
                    <Cap x={g.cx - g.bw / 2} w={g.bw} y={g.top} color={ink} />
                    <text x={g.cx} y={g.top - 0.65 * r} textAnchor="middle" className="ch-val">{nf(g.total, digits)}{unit && <tspan className="ch-unit" dx="2">{unit}</tspan>}</text>
                  </g>
                )
              }
              const tight = g.bars.length > 1 && g.bw < Math.max(3.4 * r, ...g.bars.map(b => (nf(b.value,digits).length * 0.58 + unit.length * 0.4 + 0.5) * r))
              return g.bars.map((b, bi) => b.value != null && b.label !== false && !(tight && b.style === 'hatch' && b.tone === 'ink') && (
                <g key={`${gi}-${bi}`}>
                  {b.style === 'hatch' && <Cap x={b.x} w={b.w} y={b.top} color={b.tone === 'ink' || onBlue ? ink : TONE[b.tone]} />}
                  <text x={b.x + b.w / 2} y={b.top - 0.65 * r} textAnchor="middle" className={`ch-val ${b.style === 'hatch' ? 'is-muted' : ''}`}>{nf(b.value, digits)}{unit && <tspan className="ch-unit" dx="2">{unit}</tspan>}</text>
                </g>
              ))
            })}
          </g>
          <Axis x1={padL} x2={w - padR} y={base} />
          {groups.map((g, gi) => indicesX.has(gi) && (
            <g key={gi}>
              <text x={layout[gi].cx} y={base + 1.4 * r} textAnchor="middle" className="ch-x">{g.label}</text>
              {g.note && (
                <text x={layout[gi].cx} y={base + 2.7 * r} textAnchor="middle" className="ch-note">
                  {g.noteTone && <tspan className={`ch-note-mark tone-${g.noteTone}`}>{g.noteTone === 'orange' ? '▼' : '▲'} </tspan>}{g.note}
                </text>
              )}
            </g>
          ))}
        </svg>
  ), [w, h, seen, groups, max, ticks, unit, digits, target, band, onBlue, stacked, showLabel, label, id, r, P.ink])

  return (
    <div ref={ref} className={`ch ${onBlue ? 'on-blue' : ''} ${className}`} onPointerMove={tip ? (e) => track(e, pick) : undefined} onPointerLeave={leave}>
      {tip && <HoverBand x={hover == null ? null : rd(padL + hover * gw)} width={rd(gw)} top={rd(padT - 1.6 * r)} height={rd(base - padT + 1.6 * r)} dark={onBlue} />}
      {svg}
      {tip && <Tip tipRef={tipRef} dark={onBlue}>{hover != null ? tip(groups[hover], hover) : null}</Tip>}
    </div>
  )
}

/* ---------- Embudo de etapas (Payments) ---------- */
export function Funnel({ stages, unit = 'MM$', ticks, initial = 0, label }) {
  ticks ??= Array.from({ length: 6 }, (_, i) => i * Math.max(1, Math.ceil(Math.max(...stages.map((s) => s.value)) / 5)))
  const [ref, { w, h }, seen] = useChartBox()
  const [sel, setSel] = useState(initial)
  const { hover, tipRef, track, leave } = useHover()
  const id = useSvgId()
  const r = w ? remPx() : 16
  const padL = 2.8 * r
  const n = stages.length
  const cw = Math.max((w - padL) / n, 0)
  const max = ticks.at(-1)
  const top = 1.9 * r
  const base = h
  const y = (v) => base - (v / max) * (base - top)
  const bx = (i) => rd(padL + i * cw) + 1
  const bw = rd(cw * 0.86)
  const active = hover ?? sel
  const pick = (x) => (x < padL ? null : Math.min(Math.floor((x - padL) / cw), n - 1))
  const at = (i) => {
    const s = stages[i]
    const prev = stages[i - 1]
    return [
      <span key="v"><b>{nf(s.value)}</b> {unit}</span>,
      prev ? <span key="c">Conversión: <b>{Math.round((s.value / prev.value) * 100)} %</b></span> : <span key="c">Punto de partida</span>,
      prev && <span key="d">Caída: <b>−{Math.round((1 - s.value / prev.value) * 100)} %</b></span>,
    ]
  }
  return (
    <div className="funnel" style={{ '--pad': `${padL}px`, '--cw': `${cw}px`, '--col': active }}>
      <span className="funnel-col" aria-hidden="true" />
      <div className="funnel-head">
        {stages.map((st, i) => (
          <button key={st.label} type="button" className={active === i ? 'is-on' : ''} aria-pressed={sel === i} onClick={() => setSel(i)}>
            <small>{st.label}</small>
            <b>{nf(st.value)}<sup>{unit}</sup></b>
          </button>
        ))}
      </div>
      <div ref={ref} className="ch funnel-plot" onPointerMove={(e) => track(e, pick)} onPointerLeave={leave} onClick={() => hover != null && setSel(hover)}>
        {w > 0 && h > 0 && (
          <svg width={w} height={h} role="img" aria-label={label}>
            <defs>
              <Paints id={id} r={r} />
              <linearGradient id={`${id}-pill`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor={light(P.blue)} stopOpacity="0.55" />
                <stop offset="1" stopColor={P.blue} stopOpacity="0.85" />
              </linearGradient>
            </defs>
            {ticks.map((t) => <text key={t} x={padL - 0.8 * r} y={y(t) + 0.28 * r} textAnchor="end" className="ch-tick">{nf(t, 0)}</text>)}
            <g className={`ch-grow ${seen ? 'is-in' : ''}`} style={{ transformOrigin: `0px ${base}px` }}>
              {stages.map((st, i) => i < n - 1 && (
                <polygon key={`s${i}`} fill={`url(#${id}-side-blue)`}
                  points={`${bx(i) + bw},${rd(y(st.value))} ${bx(i + 1)},${rd(y(stages[i + 1].value))} ${bx(i + 1)},${base} ${bx(i) + bw},${base}`} />
              ))}
              {stages.map((st, i) => (
                <Fragment key={st.label}>
                  <Bar id={id} x={bx(i)} y={y(st.value)} w={bw} h={base - y(st.value)} tone="blue" style={active === i ? 'solid' : 'hatch'} />
                  {i < n - 1 && <line x1={bx(i) + bw} y1={rd(y(st.value))} x2={bx(i + 1)} y2={rd(y(stages[i + 1].value))} className="funnel-edge" />}
                </Fragment>
              ))}
            </g>
            <g className={`ch-fade ${seen ? 'is-in' : ''}`}>
              {stages.map((st, i) => active !== i && (
                <g key={st.label} className="funnel-pill">
                  <rect x={rd(bx(i) + bw / 2 - 0.75 * r)} y={rd(y(st.value) - 0.95 * r)} width={rd(1.5 * r)} height={rd(0.4 * r)} rx={0.2 * r} fill={`url(#${id}-pill)`} />
                  <line x1={rd(bx(i) + bw / 2 - 0.55 * r)} x2={rd(bx(i) + bw / 2 + 0.55 * r)} y1={rd(y(st.value) - 0.95 * r) + 1.5} y2={rd(y(st.value) - 0.95 * r) + 1.5} />
                </g>
              ))}
            </g>
          </svg>
        )}
        <Tip tipRef={tipRef}>{hover != null ? at(hover) : null}</Tip>
      </div>
    </div>
  )
}

/* ---------- Sankey: nodos finos, etiquetas afuera, flujo con degradado entre tonos ---------- */
// nodes: [{ id, label, col, tone }]; links: [{ from, to, value }]; base: total para el % (p. ej. venta bruta)
export function Sankey({ nodes, links, unit = 'MM$', base, align = 'top', label, className = '' }) {
  const [ref, { w, h }, seen] = useChartBox()
  const { hover, tipRef, track, leave } = useHover()
  const id = useSvgId()
  const r = w ? remPx() : 16

  const g = useMemo(() => {
    if (!w || !h) return null
    const inSum = {}
    const outSum = {}
    links.forEach((l) => { outSum[l.from] = (outSum[l.from] ?? 0) + l.value; inSum[l.to] = (inSum[l.to] ?? 0) + l.value })
    const val = Object.fromEntries(nodes.map((n) => [n.id, Math.max(inSum[n.id] ?? 0, outSum[n.id] ?? 0)]))
    const cols = Math.max(...nodes.map((n) => n.col)) + 1
    const byCol = Array.from({ length: cols }, (_, c) => nodes.filter((n) => n.col === c))
    const gap = 1.6 * r
    const k = Math.min(...byCol.map((c) => (h - gap * (c.length - 1)) / c.reduce((s, n) => s + val[n.id], 0)))
    const nodeW = Math.max(rd(0.6 * r), 8)
    const labelW = 8.6 * r
    const colX = (c) => rd(c * ((w - labelW - nodeW) / (cols - 1)))
    const pos = {}
    byCol.forEach((c, ci) => {
      const total = c.reduce((s, n) => s + Math.max(val[n.id] * k, 3), 0) + gap * (c.length - 1)
      let yy = align === 'center' ? (h - total) / 2 : 0
      c.forEach((n) => { const hh = Math.max(val[n.id] * k, 3); pos[n.id] = { x: colX(ci), y: rd(yy), h: Math.max(rd(hh), 3) }; yy += hh + gap })
    })
    const tone = Object.fromEntries(nodes.map((n) => [n.id, n.tone === 'ink' ? P.ink3 : TONE[n.tone] ?? P.ink3]))
    const outOff = {}
    const inOff = {}
    const geo = links.map(() => ({}))
    const order = links.map((l, i) => ({ ...l, i }))
    order.slice().sort((a, b) => pos[a.to].y - pos[b.to].y).forEach((l) => { const o = outOff[l.from] ?? 0; geo[l.i].y0 = pos[l.from].y + o; outOff[l.from] = o + l.value * k })
    order.slice().sort((a, b) => pos[a.from].y - pos[b.from].y).forEach((l) => { const o = inOff[l.to] ?? 0; geo[l.i].y1 = pos[l.to].y + o; inOff[l.to] = o + l.value * k })
    const paths = links.map((l, i) => {
      const t = l.value * k
      const x0 = pos[l.from].x + nodeW
      const x1 = pos[l.to].x
      const xm = (x0 + x1) / 2
      const { y0, y1 } = geo[i]
      return { ...l, i, t, x0, x1, xm, y0, y1, d: `M${x0},${y0} C${xm},${y0} ${xm},${y1} ${x1},${y1} L${x1},${y1 + t} C${xm},${y1 + t} ${xm},${y0 + t} ${x0},${y0 + t} Z` }
    })
    return { val, outSum, cols, nodeW, pos, tone, paths }
  }, [nodes, links, w, h, r, align, P.ink])

  const name = Object.fromEntries(nodes.map((n) => [n.id, n.label]))
  const pct = (v, of) => `${nf((v / of) * 100)} %`
  const pick = (x, y, e) => {
    const t = e.target.closest?.('[data-k]')
    return t ? t.dataset.k : null
  }
  const [kind, idx] = hover ? hover.split(':') : []
  const activeLink = kind === 'l' ? g?.paths[+idx] : null
  const activeNode = kind === 'n' ? nodes[+idx] : null
  const lit = (p) => (activeLink ? p === activeLink : activeNode ? p.from === activeNode.id || p.to === activeNode.id : false)

  // Capa estática: nodos y etiquetas no dependen del hover
  const nodesLayer = useMemo(() => g && nodes.map((n, i) => {
    const p = g.pos[n.id]
    const tall = p.h >= 2.4 * r
    const lx = p.x + g.nodeW + 0.55 * r
    return (
      <g key={n.id} className={`sk-node tone-${n.tone}`} data-k={`n:${i}`}>
        <rect x={p.x} y={p.y} width={g.nodeW} height={p.h} rx="1.5" fill={g.tone[n.id]} />
        <rect x={p.x - 2} y={p.y} width={g.nodeW + 4 + 9.5 * r} height={Math.max(p.h, 2 * r)} fill="transparent" />
        {tall ? (
          <g className="sk-lbl">
            <text x={lx} y={p.y + 0.95 * r} className="sk-name">{n.label}</text>
            <text x={lx} y={p.y + 2.15 * r} className="sk-val">{nf(g.val[n.id])}<tspan className="sk-pct" dx="6">{base ? pct(g.val[n.id], base) : ''}</tspan></text>
          </g>
        ) : (
          <text x={lx} y={p.y + p.h / 2 + 0.3 * r} className="sk-lbl sk-name">{n.label} <tspan className="sk-val-sm">{nf(g.val[n.id])}</tspan>{base && <tspan className="sk-pct" dx="5">{pct(g.val[n.id], base)}</tspan>}</text>
        )}
      </g>
    )
  }), [g, nodes, r, base, P.ink])

  return (
    <div ref={ref} className={`ch sankey ${hover ? 'has-hover' : ''} ${className}`} onPointerMove={(e) => track(e, pick)} onPointerLeave={leave}>
      {g && (
        <svg width={w} height={h} role="img" aria-label={label}>
          <defs>
            {g.paths.map((p) => (
              <linearGradient key={p.i} id={`${id}-l${p.i}`} gradientUnits="userSpaceOnUse" x1={p.x0} x2={p.x1} y1="0" y2="0">
                <stop offset="0" stopColor={g.tone[p.from]} />
                <stop offset="1" stopColor={g.tone[p.to]} />
              </linearGradient>
            ))}
          </defs>
          <g className={`ch-fade ${seen ? 'is-in' : ''}`}>
            {g.paths.map((p) => (
              <path key={p.i} d={p.d} data-k={`l:${p.i}`} fill={`url(#${id}-l${p.i})`} className={`sk-link ${lit(p) ? 'is-on' : ''}`} />
            ))}
          </g>
          {nodesLayer}
        </svg>
      )}
      <Tip tipRef={tipRef}>
        {activeLink ? [
          <span key="a"><b>{name[activeLink.from]}</b> → <b>{name[activeLink.to]}</b></span>,
          <span key="b"><b>{nf(activeLink.value)}</b> {unit}</span>,
          <span key="c">{pct(activeLink.value, g.outSum[activeLink.from])} del origen</span>,
        ] : activeNode ? [
          <span key="a"><b>{activeNode.label}</b></span>,
          <span key="b"><b>{nf(g.val[activeNode.id])}</b> {unit}</span>,
          base && <span key="c">{pct(g.val[activeNode.id], base)} del total</span>,
        ] : null}
      </Tip>
    </div>
  )
}

/* ---------- Densidad de puntos por tramo (Geotab) ---------- */
// Tramos de igual ancho; cada celda = `per` unidades, apiladas de abajo hacia arriba (gráfico de unidades).

export function DotField({ segments, per = 2, unit = 'MM$', axis, label }) {
  const [ref, { w, h }, seen] = useChartBox()
  const { hover, tipRef, track, leave } = useHover(segments.length)
  const r = w ? remPx() : 16
  const n = segments.length
  const escala = escalaPuntos(segments, per)
  const counts = segments.map((s) => Math.max(Math.round(s.value / escala), 0))
  const padT = 4.4 * r
  const padB = 2 * r
  const sw = w / n
  const plotH = h - padT - padB - 0.5 * r
  const { rows, cell, cols: colsPer, dot } = rejillaPuntos(counts, Math.max(0,sw*0.84), Math.max(0,plotH))
  const base = rd(h - padB)
  const total = segments.reduce((s, x) => s + x.value, 0)
  const pick = (x) => Math.min(Math.max(Math.floor(x / sw), 0), n - 1)
  const svg = useMemo(() => w > 0 && h > 0 && (
        <svg width={w} height={h} role="img" aria-label={label}>
          {segments.map((s, si) => {
            const x0 = rd(si * sw)
            const gx = rd(x0 + (sw - colsPer * cell) / 2)
            const color = over(TONE[s.tone] ?? P.ink, s.alpha ?? 1)
            return (
              <g key={s.label}>
                {si > 0 && <line x1={crisp(x0)} x2={crisp(x0)} y1={0.2 * r} y2={base} className="df-guide" />}
                <rect x={x0 + 0.6 * r} y={rd(0.45 * r)} width="6" height="6" fill={color} />
                <text x={x0 + 0.6 * r + 11} y={0.45 * r + 6.5} className="df-name">{s.label}</text>
                <text x={x0 + 0.6 * r} y={2.35 * r} className="df-val">{nf(s.value)}<tspan className="ch-unit" dx="3">{unit}</tspan></text>
                <text x={x0 + 0.6 * r} y={3.7 * r} className="df-pct">{nf((s.value / (total || 1)) * 100)} % · {s.docs} doc.</text>
                <g className={`ch-fade ${seen ? 'is-in' : ''}`} fill={color}>
                  {Array.from({ length: counts[si] }, (_, c) => (
                    <rect key={c} x={gx + Math.floor(c / rows) * cell} y={base - 0.5 * r - (c % rows + 1) * cell} width={dot} height={dot} rx="1" />
                  ))}
                </g>
              </g>
            )
          })}
          <Axis x1={0} x2={w} y={base} />
          {axis?.map((t, i) => (
            <g key={t}>
              <line x1={crisp((i + 1) * sw)} x2={crisp((i + 1) * sw)} y1={base - 3} y2={base + 3} className="ch-axis-tick" />
              <text x={rd((i + 1) * sw)} y={base + 1.45 * r} textAnchor="middle" className={`ch-x ${i === 0 ? 'is-strong' : ''}`}>{t}</text>
            </g>
          ))}
        </svg>
  ), [w, h, seen, segments, per, unit, axis, label, r, P.ink])

  return (
    <div ref={ref} className="ch dot-field" onPointerMove={(e) => track(e, pick)} onPointerLeave={leave}>
      {svg}
      {hover != null && hover > 0 && <span className="hv-veil" style={{ left: 0, width: rd(hover * sw), bottom: rd(padB - 0.2 * r) }} aria-hidden="true" />}
      {hover != null && hover < n - 1 && <span className="hv-veil" style={{ left: rd((hover + 1) * sw), right: 0, bottom: rd(padB - 0.2 * r) }} aria-hidden="true" />}
      <Tip tipRef={tipRef}>{hover != null ? [
        <span key="a"><b>{segments[hover].label}</b></span>,
        <span key="b"><b>{nf(segments[hover].value)}</b> {unit}</span>,
        <span key="c"><b>{segments[hover].docs}</b> documentos</span>,
      ] : null}</Tip>
    </div>
  )
}

/* ---------- Histograma de ticks con promedio móvil (Daxa) ---------- */
// Spline Catmull-Rom: curva suave que pasa por cada punto (aspecto «senoidal»).
// Los puntos de control se acotan a [top, bottom] para que la curva no cruce la base.
export function spline(pts, top = -Infinity, bottom = Infinity, k = 1) {
  if (pts.length < 3) return pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x},${y}`).join(' ')
  const cy = (v) => Math.min(Math.max(v, top), bottom)
  let d = `M${pts[0][0]},${pts[0][1]}`
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] ?? pts[i]
    const p1 = pts[i]
    const p2 = pts[i + 1]
    const p3 = pts[i + 2] ?? p2
    const c1x = p1[0] + ((p2[0] - p0[0]) / 6) * k
    const c1y = cy(p1[1] + ((p2[1] - p0[1]) / 6) * k)
    const c2x = p2[0] - ((p3[0] - p1[0]) / 6) * k
    const c2y = cy(p2[1] - ((p3[1] - p1[1]) / 6) * k)
    d += ` C${c1x},${c1y} ${c2x},${c2y} ${p2[0]},${p2[1]}`
  }
  return d
}

export function TickBars({ days, highlight, unit = 'MM$', window = 5, label, className = '' }) {
  const [ref, { w, h }, seen] = useChartBox()
  const { hover, tipRef, track, leave } = useHover()
  const r = w ? remPx() : 16
  const padT = 2.3 * r
  const padB = 2 * r
  const padL = 2.4 * r
  const n = days.length
  const stepX = (w - padL) / n
  const max = Math.max(1, Math.ceil(Math.max(...days.map((d) => d.v)) * 1.1))
  const base = rd(h - padB)
  const y = (v) => base - (v / max) * (base - padT)
  const bw = Math.max(Math.min(rd(stepX * 0.3), 3), 2)
  const top = days.reduce((m, d, i) => (d.v > days[m].v ? i : m), 0)
  const avg = days.map((_, i) => { const s = days.slice(Math.max(0, i - window + 1), i + 1); return s.reduce((a, d) => a + d.v, 0) / s.length })
  const x = (i) => rd(padL + i * stepX + stepX / 2)
  const curve = w ? spline(avg.map((v, i) => [x(i), y(v)]), padT, base) : ''
  const months = days.reduce((acc, d, i) => (acc.at(-1)?.month === d.month ? acc : [...acc, { month: d.month, i }]), [])
  const ticks = [0, Math.round(max / 2), max]
  const pick = (px) => Math.min(Math.max(Math.floor((px - padL) / stepX), 0), n - 1)
  const svg = useMemo(() => w > 0 && h > 0 && (
        <svg width={w} height={h} role="img" aria-label={label}>
          {ticks.map((t) => (
            <g key={t}>
              {t > 0 && <line x1={padL} x2={w} y1={crisp(y(t))} y2={crisp(y(t))} className="ch-grid" />}
              <text x={padL - 0.7 * r} y={y(t) + 0.28 * r} textAnchor="end" className="ch-tick">{t}</text>
            </g>
          ))}
          {months.map((m) => (
            <g key={m.month}>
              {m.i > 0 && <line x1={crisp(padL + m.i * stepX)} x2={crisp(padL + m.i * stepX)} y1={padT - 1.3 * r} y2={base} className="ch-grid" />}
              <text x={padL + m.i * stepX + 0.4 * r} y={base + 1.4 * r} className={`ch-x ${m.month === highlight ? 'is-strong' : ''}`}>{m.month}</text>
            </g>
          ))}
          <g className={`ch-grow ${seen ? 'is-in' : ''}`} style={{ transformOrigin: `0px ${base}px` }}>
            {days.map((d, i) => (
              <rect key={i} x={x(i) - bw / 2} y={rd(y(d.v))} width={bw} height={base - rd(y(d.v))} rx={bw / 2}
                className={`tb-bar ${d.month === highlight ? 'is-hl' : ''} ${i === top ? 'is-top' : ''}`} />
            ))}
          </g>
          <g className={`ch-fade ${seen ? 'is-in' : ''}`}>
            <path d={curve} className="tb-avg" />
            <circle cx={x(top)} cy={rd(y(days[top].v)) - 0.45 * r} r="3.2" className="tb-top-dot" />
            <text x={x(top)} y={y(days[top].v) - 1 * r} textAnchor="middle" className="ch-val">{nf(days[top].v)}<tspan className="ch-unit" dx="2">{unit}</tspan></text>
          </g>
          <Axis x1={padL} x2={w} y={base} />
        </svg>
  ), [w, h, seen, days, highlight, unit, label, r, P.ink])

  return (
    <div ref={ref} className={`ch tick-bars ${className}`} onPointerMove={(e) => track(e, pick)} onPointerLeave={leave}>
      {svg}
      <HoverLine x={hover == null ? null : x(hover)} y={hover == null ? null : y(avg[hover])} top={rd(padT - 0.8 * r)} height={rd(base - padT + 0.8 * r)} />
      <Tip tipRef={tipRef}>{hover != null ? [
        <span key="a"><b>{days[hover].label}</b></span>,
        <span key="b"><b>{nf(days[hover].v)}</b> {unit}</span>,
        <span key="c">Promedio {window} días: <b>{nf(avg[hover])}</b></span>,
      ] : null}</Tip>
    </div>
  )
}

/* ---------- Línea con marcadores cuadrados y área rayada (Geotab) ---------- */
export function HatchLine({ points, min = 0, max, ticks, unit = '%', tone = 'blue', target, label, className = '' }) {
  const dominio = dominioSerie(points, min, max, target?.value)
  min = dominio.min;max = dominio.max
  const [ref, { w, h }, seen] = useChartBox()
  const { hover, tipRef, track, leave } = useHover(points.length)
  const id = useSvgId()
  const r = w ? remPx() : 16
  const padL = 3 * r
  const padR = target ? 4.6 * r : 1.2 * r
  const padT = 2.4 * r
  const padB = 2.1 * r
  const base = rd(h - padB)
  const n = points.length
  const inner = w - padL - padR - 1.6 * r
  const x = (i) => rd(padL + 0.8 * r + (n === 1 ? 0.5 : i / (n - 1)) * inner)
  const y = (v) => base - ((v - min) / (max - min)) * (base - padT)
  const color = TONE[tone]
  const line = w ? spline(points.map((p, i) => [x(i), y(p.v)]), padT, base) : ''
  const last = n - 1
  const indicesX = indicesEtiquetas(points.map(p=>p.label),inner,r)
  const pick = (px) => n ? Math.min(Math.max(Math.round(((px - padL - 0.8 * r) / inner) * (n - 1)), 0), n - 1) : null
  const svg = useMemo(() => w > 0 && h > 0 && n > 0 && (
        <svg width={w} height={h} role="img" aria-label={label}>
          <defs>
            <Paints id={id} r={r} />
            <linearGradient id={`${id}-area`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={color} stopOpacity="0.12" />
              <stop offset="1" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          {ticks.filter(t=>t>=min&&t<=max).map((t) => (
            <g key={t}>
              {t > min && <line x1={padL} x2={w - padR} y1={crisp(y(t))} y2={crisp(y(t))} className="ch-grid" />}
              <text x={padL - 0.8 * r} y={y(t) + 0.28 * r} textAnchor="end" className="ch-tick">{nf(t, 0)} {unit}</text>
            </g>
          ))}
          <g className={`ch-fade ${seen ? 'is-in' : ''}`}>
            <path d={`${line} L${x(last)},${base} L${x(0)},${base} Z`} fill={`url(#${id}-area)`} />
          </g>
          {target && (
            <g className="ch-target">
              <line x1={padL} x2={rd(w - padR + 0.3 * r)} y1={crisp(y(target.value))} y2={crisp(y(target.value))} />
              <rect x={rd(w - padR + 0.3 * r) - 2} y={rd(y(target.value)) - 2} width="5" height="5" />
              <SideLabel x={w - padR + 0.9 * r} y={y(target.value)} label={target.label} r={r} />
            </g>
          )}
          <g className={`ch-draw ${seen ? 'is-in' : ''}`}>
            <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
            <circle cx={x(last)} cy={y(points[last].v)} r="4" fill={P.surface} stroke={color} strokeWidth="2" />
            <text x={x(last)} y={y(points[last].v) - 1 * r} textAnchor="middle" className="ch-val">{nf(points[last].v)}<tspan className="ch-unit" dx="2">{unit}</tspan></text>
          </g>
          <Axis x1={padL} x2={w - padR} y={base} />
          {points.map((p, i) => indicesX.has(i) && <text key={p.label} x={x(i)} y={base + 1.4 * r} textAnchor={i===0?'start':i===n-1?'end':'middle'} className="ch-x">{p.label}</text>)}
        </svg>
  ), [w, h, seen, points, min, max, ticks, unit, tone, target, label, id, r, P.ink])

  return (
    <div ref={ref} className={`ch ${className}`} onPointerMove={(e) => track(e, pick)} onPointerLeave={leave}>
      {svg}
      <HoverLine x={hover == null ? null : x(hover)} y={hover == null ? null : rd(y(points[hover].v))} top={rd(padT - 0.8 * r)} height={rd(base - padT + 0.8 * r)} />
      <Tip tipRef={tipRef}>{hover != null ? [
        <span key="a"><b>{points[hover].label}</b></span>,
        <span key="b"><b>{nf(points[hover].v)}</b> {unit}</span>,
        hover > 0 && <span key="c">{points[hover].v >= points[hover - 1].v ? '+' : '−'}{nf(Math.abs(points[hover].v - points[hover - 1].v))} pp vs. mes ant.</span>,
      ] : null}</Tip>
    </div>
  )
}

/* ---------- Tendencia suave sobre rejilla de puntos (vista del agente / Consolidated budget) ---------- */
// points: [{ label, v }]; marks: [{ i, label }] etiquetas del eje; focus: índice desde el que el tramo es «actual»
export function SmoothTrend({ points, min, max, ticks, unit = '%', digits = 1, tone = 'blue', target, marks, focus = 0, focusLabel, tip, label, className = '' }) {
  const dominio = dominioSerie(points, min, max, target?.value)
  min = dominio.min;max = dominio.max
  const [ref, { w, h }, seen] = useChartBox()
  const { hover, tipRef, track, leave } = useHover(points.length)
  const id = useSvgId()
  const r = w ? remPx() : 16
  const padL = 3 * r
  const padR = target ? 4.6 * r : 0.8 * r
  const padT = 1.6 * r
  const padB = 2.2 * r
  const base = rd(h - padB)
  const n = points.length
  const inner = w - padL - padR
  const x = (i) => padL + (n === 1 ? 0.5 : i / (n - 1)) * inner
  const y = (v) => base - ((v - min) / (max - min)) * (base - padT)
  const color = TONE[tone]
  const pick = (px) => n ? Math.min(Math.max(Math.round(((px - padL) / inner) * (n - 1)), 0), n - 1) : null

  const svg = useMemo(() => {
    if (!w || !h || !n) return null
    const line = spline(points.map((p, i) => [x(i), y(p.v)]), padT, base)
    const area = `${line} L${x(n - 1)},${base} L${x(0)},${base} Z`
    const fx = rd(x(focus))
    const last = points[n - 1]
    return (
      <svg width={w} height={h} role="img" aria-label={label}>
        <defs>
          <pattern id={`${id}-dots`} width={rd(0.62 * r)} height={rd(0.62 * r)} patternUnits="userSpaceOnUse">
            <rect width="1.4" height="1.4" fill={P.line} />
          </pattern>
          <linearGradient id={`${id}-area`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={color} stopOpacity="0.16" />
            <stop offset="1" stopColor={color} stopOpacity="0" />
          </linearGradient>
          <clipPath id={`${id}-now`}><rect x={fx} y={0} width={Math.max(w - fx, 0)} height={h} /></clipPath>
          <clipPath id={`${id}-past`}><rect x={0} y={0} width={fx} height={h} /></clipPath>
        </defs>
        <rect x={padL} y={padT} width={rd(inner)} height={base - padT} fill={`url(#${id}-dots)`} />
        {ticks.filter(t=>t>=min&&t<=max).map((t) => <text key={t} x={padL - 0.8 * r} y={y(t) + 0.28 * r} textAnchor="end" className="ch-tick">{nf(t, 0)} {unit}</text>)}
        <g className={`ch-fade ${seen ? 'is-in' : ''}`}>
          <path d={area} fill={`url(#${id}-area)`} clipPath={`url(#${id}-now)`} />
          <path d={area} fill={`url(#${id}-area)`} clipPath={`url(#${id}-past)`} opacity="0.45" />
        </g>
        {target && (
          <g className="ch-target">
            <line x1={padL} x2={rd(w - padR + 0.3 * r)} y1={crisp(y(target.value))} y2={crisp(y(target.value))} />
            <rect x={rd(w - padR + 0.3 * r) - 2} y={rd(y(target.value)) - 2} width="5" height="5" />
            <SideLabel x={w - padR + 0.9 * r} y={y(target.value)} label={target.label} r={r} />
          </g>
        )}
        {focus > 0 && (
          <g className="st-focus">
            <line x1={crisp(fx)} x2={crisp(fx)} y1={padT - 0.4 * r} y2={base} />
            {focusLabel && <text x={fx + 0.5 * r} y={padT + 0.6 * r}>{focusLabel}</text>}
          </g>
        )}
        <g className={`ch-draw ${seen ? 'is-in' : ''}`}>
          <path d={line} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" clipPath={`url(#${id}-now)`} />
          <path d={line} fill="none" stroke={color} strokeWidth="1.75" strokeLinejoin="round" strokeLinecap="round" clipPath={`url(#${id}-past)`} opacity="0.4" />
          <circle cx={x(n - 1)} cy={y(last.v)} r="4" fill={P.surface} stroke={color} strokeWidth="2" />
          <text x={x(n - 1)} y={y(last.v) - 0.9 * r} textAnchor="end" className="ch-val">{nf(last.v, digits)}<tspan className="ch-unit" dx="2">{unit}</tspan></text>
        </g>
        <Axis x1={padL} x2={w - padR} y={base} />
        {marks?.map((m) => <text key={m.i} x={x(m.i)} y={base + 1.45 * r} textAnchor={m.i === 0 ? 'start' : 'middle'} className="ch-x">{m.label}</text>)}
      </svg>
    )
  }, [w, h, seen, points, min, max, ticks, unit, digits, tone, target, marks, focus, focusLabel, label, id, r, P.ink])

  return (
    <div ref={ref} className={`ch smooth-trend ${className}`} onPointerMove={(e) => track(e, pick)} onPointerLeave={leave}>
      {svg}
      <HoverLine x={hover == null ? null : rd(x(hover))} y={hover == null ? null : rd(y(points[hover].v))} top={rd(padT)} height={rd(base - padT)} />
      <Tip tipRef={tipRef}>{hover != null ? (tip ? tip(points[hover], hover) : [
        <span key="a"><b>{points[hover].label}</b></span>,
        <span key="b"><b>{nf(points[hover].v, digits)}</b> {unit}</span>,
      ]) : null}</Tip>
    </div>
  )
}

/* ---------- Medidor de ticks: avance, meta y exceso (Daxa) ---------- */
export function TickGauge({ value, max, target, unit = '%', label }) {
  const N = 61
  const cx = 160
  const cy = 150
  const r1 = 116
  const r2 = 140
  const pt = (a, rr) => [cx + rr * Math.cos(a), cy - rr * Math.sin(a)]
  const ta = Math.PI - (target / max) * Math.PI
  const [tx1, ty1] = pt(ta, r1 - 8)
  const [tx2, ty2] = pt(ta, r2 + 6)
  const [lx, ly] = pt(ta, r1 - 16)
  return (
    <div className="tgauge" role="img" aria-label={label}>
      <svg viewBox="0 0 320 166">
        {Array.from({ length: N }, (_, i) => {
          const t = (i / (N - 1)) * max
          const a = Math.PI - (t / max) * Math.PI
          const [x1, y1] = pt(a, r1)
          const [x2, y2] = pt(a, r2)
          const cls = t <= Math.min(value, target) ? 'is-on' : t <= value ? 'is-over' : ''
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} className={`tg-tick ${cls}`} />
        })}
        <line x1={tx1} y1={ty1} x2={tx2} y2={ty2} className="tg-target" />
      </svg>
      {/* Etiquetas en HTML: no se encogen con el SVG y respetan el tamaño mínimo de texto */}
      <span className={`tg-label is-strong ${ta < Math.PI / 2 ? 'is-end' : ''}`} style={{ left: `${(lx / 320) * 100}%`, top: `${(ly / 166) * 100}%` }}>Meta {nf(target, 0)} {unit}</span>
      <span className="tg-label is-center" style={{ left: `${((cx - (r1 + r2) / 2) / 320) * 100}%`, top: `${((cy + 10) / 166) * 100}%` }}>0</span>
      <span className="tg-label is-center" style={{ left: `${((cx + (r1 + r2) / 2) / 320) * 100}%`, top: `${((cy + 10) / 166) * 100}%` }}>{nf(max, 0)} {unit}</span>
      <p className="tgauge-value">{nf(value).split(',')[0]}<span>,{nf(value).split(',')[1]}</span><sup>{unit}</sup></p>
    </div>
  )
}

/* ---------- Gráficos HTML con hover de vidrio ---------- */
const pickIndex = (x, y, e) => {
  const el = e.target.closest?.('[data-i]')
  return el ? +el.dataset.i : null
}

// Waffle 20 × 5: una celda = 1 %
export function Waffle({ value, tone = 'green', label, on = 'Recurrentes', off = 'Otros', total, unit = 'MM$' }) {
  const { hover, tipRef, track, leave } = useHover()
  const part = (i) => (i === 1 ? { name: on, pct: value } : { name: off, pct: 100 - value })
  const cells = useMemo(() => (
    <div className={`waffle waffle-${tone}`} role="img" aria-label={label}>
      {Array.from({ length: 100 }, (_, i) => {
        const isOn = (i % 20) * 5 + (4 - Math.floor(i / 20)) < value
        return <i key={i} data-i={isOn ? 1 : 0} className={isOn ? 'is-on' : undefined} />
      })}
    </div>
  ), [value, tone, label, P.ink])
  return (
    <div className="waffle-wrap" data-hover={hover ?? undefined} onPointerMove={(e) => track(e, pickIndex)} onPointerLeave={leave}>
      {cells}
      <Tip tipRef={tipRef}>{hover != null ? [
        <span key="a"><b>{part(hover).name}</b></span>,
        <span key="b"><b>{part(hover).pct} %</b> de la venta</span>,
        total && <span key="c"><b>{nf((total * part(hover).pct) / 100)}</b> {unit}</span>,
      ] : null}</Tip>
    </div>
  )
}

// Barra segmentada + leyenda con cifras
export function SplitBar({ items, unit = 'MM$', label }) {
  const { hover, tipRef, track, leave } = useHover()
  const total = items.reduce((s, i) => s + i.value, 0)
  return (
    <div className={`split ${hover != null ? 'has-hover' : ''}`} onPointerMove={(e) => track(e, pickIndex)} onPointerLeave={leave}>
      <div className="split-bar" role="img" aria-label={label}>
        {items.map((it, i) => <i key={it.name} data-i={i} className={`seg tone-${it.tone} is-${it.style ?? 'solid'} ${hover === i ? 'is-hl' : ''}`} style={{ flexGrow: it.value }} />)}
      </div>
      <ul className="split-legend">
        {items.map((it, i) => (
          <li key={it.name} data-i={i} className={hover === i ? 'is-hl' : ''}>
            <span className="split-name"><i className={`sw sw-${it.style ?? 'solid'} sw-${it.tone}`} />{it.name}</span>
            <span className="split-pct">{Math.round((it.value / total) * 100)}<sup>%</sup></span>
            <span className="split-val">{nf(it.value)} {unit}</span>
            {it.change != null && <span className="split-change"><i className={it.change < 0 ? 'is-down' : 'is-up'}>{it.change < 0 ? '▼' : '▲'}</i>{it.change < 0 ? '−' : '+'}{nf(Math.abs(it.change))} % vs. 3T 2025</span>}
          </li>
        ))}
      </ul>
      <Tip tipRef={tipRef}>{hover != null ? [
        <span key="a"><b>{items[hover].name}</b></span>,
        <span key="b"><b>{nf(items[hover].value)}</b> {unit}</span>,
        <span key="c"><b>{nf((items[hover].value / total) * 100)} %</b> del total</span>,
      ] : null}</Tip>
    </div>
  )
}

// Desviación frente a la meta (cero = meta)
export function Deviation({ items, target, unit = '%', label }) {
  const { hover, tipRef, track, leave } = useHover()
  const sorted = [...items].sort((a, b) => b.value - a.value)
  const span = Math.max(...sorted.map((i) => Math.abs(i.value - target)))
  return (
    <div className={`dev ${hover != null ? 'has-hover' : ''}`} role="img" aria-label={label} onPointerMove={(e) => track(e, pickIndex)} onPointerLeave={leave}>
      <div className="dev-axis"><span>Bajo la meta</span><b>Meta {nf(target, 0)} {unit}</b><span>Sobre la meta</span></div>
      {sorted.map((it, i) => {
        const d = it.value - target
        return (
          <div key={it.name} data-i={i} className={`dev-row ${d < 0 ? 'is-down' : 'is-up'} ${hover === i ? 'is-hl' : ''}`}>
            <span className="dev-name">{it.name}</span>
            <span className="dev-track"><i style={{ width: `${(Math.abs(d) / span) * 50}%` }} /></span>
            <span className="dev-val"><b>{d < 0 ? '−' : '+'}{nf(Math.abs(d))} pp</b><small>{nf(it.value)} {unit}</small></span>
          </div>
        )
      })}
      <Tip tipRef={tipRef}>{hover != null ? [
        <span key="a"><b>{sorted[hover].name}</b></span>,
        <span key="b">Margen <b>{nf(sorted[hover].value)} {unit}</b></span>,
        <span key="c"><b>{sorted[hover].value < target ? '−' : '+'}{nf(Math.abs(sorted[hover].value - target))} pp</b> vs. meta</span>,
      ] : null}</Tip>
    </div>
  )
}

// Valor sobre escala común con rango sano
export function RangeRows({ items, band, max = 100, unit = 'd', label }) {
  const { hover, tipRef, track, leave } = useHover()
  const sorted = [...items].sort((a, b) => a.value - b.value)
  const pct = (v) => `${(v / max) * 100}%`
  const state = (v) => (v < band[0] ? 'is-low' : v > band[1] ? 'is-high' : 'is-ok')
  const text = { 'is-low': 'Bajo el rango', 'is-ok': 'En rango', 'is-high': 'Sobre el rango' }
  return (
    <div className={`rrows ${hover != null ? 'has-hover' : ''}`} role="img" aria-label={label} onPointerMove={(e) => track(e, pickIndex)} onPointerLeave={leave}>
      <div className="rrows-axis"><span /><span className="rrows-scale"><i style={{ left: pct(band[0]), width: `calc(${pct(band[1])} - ${pct(band[0])})` }}>Rango sano {band[0]}–{band[1]} {unit}</i></span><span /></div>
      {sorted.map((it, i) => (
        <div key={it.name} data-i={i} className={`rrow ${state(it.value)} ${hover === i ? 'is-hl' : ''}`}>
          <span className="rrow-name">{it.name}</span>
          <span className="rrow-track">
            <em style={{ left: pct(band[0]), width: `calc(${pct(band[1])} - ${pct(band[0])})` }} />
            <i style={{ width: pct(it.value) }} />
            <b style={{ left: pct(it.value) }} />
          </span>
          <span className="rrow-val">{it.value} {unit}</span>
        </div>
      ))}
      <div className="rrows-foot"><span /><span className="rrows-ticks">{Array.from({ length: 5 }, (_, i) => i * max / 4).map((t) => <i key={t} style={{ left: pct(t) }}>{nf(t, 0)}</i>)}</span><span /></div>
      <Tip tipRef={tipRef}>{hover != null ? [
        <span key="a"><b>{sorted[hover].name}</b></span>,
        <span key="b"><b>{sorted[hover].value}</b> días de cobertura</span>,
        <span key="c">{text[state(sorted[hover].value)]}</span>,
      ] : null}</Tip>
    </div>
  )
}

/* ---------- Proyección de stock de un SKU (inventario) ---------- */
// series: [{ day, stock }], arrivals: [{ day, qty, kind, doc }]. Octubre 2026 empieza en jueves.
const niceStep = (v) => { const p = 10 ** Math.floor(Math.log10(v)); const m = v / p; return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 2.5 ? 2.5 : m <= 5 ? 5 : 10) * p }
const singular = { cajas: 'caja', sacos: 'saco', tinetas: 'tineta' }
export const qty = (n, unit) => `${n.toLocaleString('es-CL')} ${n === 1 ? singular[unit] ?? unit : unit}`

export function StockProjection({ series, arrivals, today, reorder, safety, demand, unit = 'un.', label, corte }) {
  const dateDay = (day) => corte ? new Date(Date.parse(corte) + (day - 1) * 86400000).toLocaleDateString('es-CL', { day: 'numeric', month: 'short', timeZone: 'UTC' }) : `${day} oct.`
  const [ref, { w, h }, seen] = useChartBox()
  const { hover, tipRef, track, leave } = useHover()
  const id = useSvgId()
  const r = w ? remPx() : 16
  const padL = 3.2 * r
  const padR = 0.8 * r
  const padT = 3.6 * r
  const padB = 2.3 * r
  const base = rd(h - padB)
  const days = series.length
  const peak = Math.max(...series.map((s) => s.stock), reorder)
  const step = niceStep(peak / 3)
  const max = peak * 1.24
  const inner = w - padL - padR - 1.2 * r
  const dayW = inner / (days - 1)
  const x = (d) => rd(padL + 0.6 * r + (d - 1) * dayW)
  const y = (v) => rd(base - (v / max) * (base - padT))
  const path = (pts) => pts.map((s, i) => `${i ? 'L' : 'M'}${x(s.day)},${y(s.stock)}`).join(' ')
  const past = series.filter((s) => s.day <= today)
  const future = series.filter((s) => s.day >= today)
  const split = h ? y(safety) / h : 0
  const outRanges = series.filter((s) => s.stock <= 0).reduce((acc, s) => { const l = acc.at(-1); if (l && l[1] === s.day - 1) l[1] = s.day; else acc.push([s.day, s.day]); return acc }, [])
  const ticks = Array.from({ length: Math.floor((peak * 1.18) / step) + 1 }, (_, i) => i * step).filter((t) => Math.abs(y(t) - y(safety)) > 0.9 * r || t === 0)
  const pick = (px) => Math.min(Math.max(Math.round((px - padL - 0.6 * r) / dayW) + 1, 1), days)
  const hv = hover ? series[hover - 1] : null
  const now = series[today - 1]
  // Etiquetas sin choques: ancho estimado por caracteres; «Sin stock» se corre a la derecha de «Hoy»
  const est = (text) => text.length * 0.43 * r + 1.6 * r
  const todayText = `${corte ? 'Corte' : 'Hoy'} · ${dateDay(today)}`
  const todayW = est(todayText)
  const todayX = Math.max(x(today), todayW / 2)
  const notes = {
    today: todayX,
    todayText,
    out: outRanges.map(([a, b]) => {
      const text = corte ? `Sin stock · ${a === b ? dateDay(a) : `${dateDay(a)}–${dateDay(b)}`}` : `Sin stock · ${a === b ? a : `${a}–${b}`} oct.`
      const ow = est(text)
      let cx = (x(a) + x(b)) / 2
      if (Math.abs(cx - todayX) < (ow + todayW) / 2 + 6) cx = todayX + todayW / 2 + 6 + ow / 2
      return { key: a, text, cx: Math.min(cx, w - ow / 2) }
    }),
    arrivals: arrivals.map((a) => {
      const aw = est(`${a.doc} +${qty(a.qty, unit)} en tránsito`) + 0.8 * r
      const left = x(a.day) + 0.8 * r + aw > w ? x(a.day) - 0.8 * r - aw : x(a.day) + 0.8 * r
      return { a, left: Math.max(padL, Math.min(left, w - aw)) }
    }),
  }
  const svg = useMemo(() => w > 0 && h > 0 && (
        <svg width={w} height={h} role="img" aria-label={label}>
          <defs>
            <Paints id={id} r={r} />
            <linearGradient id={`${id}-stroke`} gradientUnits="userSpaceOnUse" x1="0" x2="0" y1="0" y2={h}>
              <stop offset={split} stopColor={P.blue} />
              <stop offset={split} stopColor={P.orange} />
            </linearGradient>
            <linearGradient id={`${id}-area`} gradientUnits="userSpaceOnUse" x1="0" x2="0" y1={padT} y2={base}>
              <stop offset="0" stopColor={P.blue} stopOpacity="0.16" />
              <stop offset="1" stopColor={P.blue} stopOpacity="0.01" />
            </linearGradient>
          </defs>
          {ticks.map((t) => (
            <g key={t}>
              {t > 0 && <line x1={padL} x2={w - padR} y1={crisp(y(t))} y2={crisp(y(t))} className="ch-grid" />}
              <text x={padL - 0.8 * r} y={y(t) + 0.28 * r} textAnchor="end" className="ch-tick">{t.toLocaleString('es-CL')}</text>
            </g>
          ))}
          <text x={padL - 0.8 * r} y={padT - 1.6 * r} textAnchor="end" className="ch-tick is-unit">{unit}</text>
          <rect x={padL} y={y(safety)} width={rd(w - padL - padR)} height={base - y(safety)} className="sp-safety" />
          <line x1={padL} x2={w - padR} y1={crisp(y(safety))} y2={crisp(y(safety))} className="sp-safety-line" />
          {safety > 0 && Math.abs(y(safety) - base) > 0.9 * r && <text x={padL - 0.8 * r} y={y(safety) + 0.28 * r} textAnchor="end" className="ch-tick is-safety">{safety.toLocaleString('es-CL')}</text>}
          {outRanges.map(([a, b]) => (
            <rect key={a} x={rd(x(a) - dayW / 2)} y={rd(padT - 1.2 * r)} width={rd(x(b) - x(a) + dayW)} height={rd(base - padT + 1.2 * r)} fill={`url(#${id}-stripe-orange)`} className="sp-out" />
          ))}
          <g className={`ch-fade ${seen ? 'is-in' : ''}`}>
            <path d={`${path(series)} L${x(days)},${base} L${x(1)},${base} Z`} fill={`url(#${id}-area)`} />
          </g>
          <line x1={padL} x2={w - padR} y1={crisp(y(reorder))} y2={crisp(y(reorder))} className="sp-reorder" />
          <g className={`ch-draw ${seen ? 'is-in' : ''}`}>
            <path d={path(past)} fill="none" stroke={`url(#${id}-stroke)`} strokeWidth="2.25" strokeLinejoin="round" />
            <path d={path(future)} fill="none" stroke={`url(#${id}-stroke)`} strokeWidth="2" strokeDasharray="6 4" strokeLinejoin="round" />
            {arrivals.map((a) => (
              <g key={a.doc} className={`sp-arrival is-${a.kind}`}>
                <line x1={crisp(x(a.day))} x2={crisp(x(a.day))} y1={y(series[a.day - 1].stock)} y2={base} />
                <circle cx={x(a.day)} cy={y(series[a.day - 1].stock)} r="4.5" />
              </g>
            ))}
            {outRanges.map(([a]) => <circle key={a} cx={x(a)} cy={base} r="4.5" className="sp-zero" />)}
          </g>
          <line x1={crisp(x(today))} x2={crisp(x(today))} y1={rd(padT - 1.2 * r)} y2={base} className="sp-today" />
          <circle cx={x(today)} cy={y(now.stock)} r="5" className={`sp-now ${now.stock < safety ? 'is-low' : ''}`} />
          <Axis x1={padL} x2={w - padR} y={base} />
          {series.filter((s) => s.day === today || ((s.day === 1 || s.day % 5 === 0) && Math.abs(x(s.day) - x(today)) > 2.2 * r)).map((s) => (
            <text key={s.day} x={x(s.day)} y={base + 1.45 * r} textAnchor="middle" className={`ch-x ${s.day === today ? 'is-strong' : ''}`}>{corte ? dateDay(s.day) : s.day === 1 ? '1 oct.' : s.day}</text>
          ))}
        </svg>
  ), [w, h, seen, series, arrivals, today, reorder, safety, unit, label, id, r, P.ink])

  return (
    <div ref={ref} className="ch stock-proj" onPointerMove={(e) => track(e, pick)} onPointerLeave={leave}>
      {svg}
      <HoverLine x={hv ? x(hv.day) : null} y={hv ? y(hv.stock) : null} top={rd(padT - 1.2 * r)} height={rd(base - padT + 1.2 * r)} />
      {w > 0 && (
        <div className="sp-notes" aria-hidden="true">
          <span className="note is-dark" style={{ left: notes.today, top: padT - 2.9 * r }}>{notes.todayText}</span>
          {notes.out.map((o) => <span key={o.key} className="note is-out" style={{ left: o.cx, top: padT - 2.9 * r }}>{o.text}</span>)}
          {notes.arrivals.map(({ a, left }) => (
            <span key={a.doc} className={`note is-arrival is-${a.kind}`} style={{ left, top: Math.max(y(series[a.day - 1].stock) - 1.05 * r, padT - 0.6 * r) }}>
              <i />{a.doc}<b>+{qty(a.qty, unit)}</b><small>{a.kind === 'transit' ? 'en tránsito' : 'confirmada'}</small>
            </span>
          ))}
          <span className="note is-line" style={{ right: padR + 0.4 * r, top: y(reorder) }}>Punto de pedido <b>{reorder.toLocaleString('es-CL')}</b></span>
        </div>
      )}
      <Tip tipRef={tipRef}>{hv ? [
        <span key="a"><b>{dateDay(hv.day)}</b>{hv.day > today ? ' proyectado' : hv.day === today ? corte ? ' al corte' : ' hoy' : ''}</span>,
        <span key="b">Stock <b>{qty(hv.stock, unit)}</b></span>,
        <span key="c">{hv.stock <= 0 ? <b>Sin stock</b> : <>Cobertura <b>{Math.floor(hv.stock / demand)} días</b></>}</span>,
      ] : null}</Tip>
    </div>
  )
}
