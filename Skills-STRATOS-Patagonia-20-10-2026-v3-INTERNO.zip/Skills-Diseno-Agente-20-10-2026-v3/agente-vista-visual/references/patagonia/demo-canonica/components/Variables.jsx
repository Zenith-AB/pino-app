import { esTableroEnlazado } from '../../../servicios/datos/src/tipos-escenario.js'
import { createContext, useContext, useEffect, useRef, useState } from 'react'
import { VARIABLES_VENTAS, validarVariables } from '../../../servicios/datos/src/variables.js'
import { useEscenario } from '../escenario.jsx'
import { pedirDatos } from '../datos/api.js'
import { describirPropuesta, describirResolucion, propuestaVigente } from '../datos/propuesta.js'
import { rutaPropuesta, rutaVinculo } from '../datos/ventas.js'
import { Chevron } from './Icons.jsx'

const CLAVE = (id) => `patagonia.variables.ventas.${id}`
// Vínculo vivo de la última respuesta conectada, por fuente. Es un token firmado sin cifras: el servidor lo reevalúa.
const CLAVE_VINCULO = (id) => `patagonia.vinculo.${id}`
const leerVinculo = (id) => { try { return localStorage.getItem(CLAVE_VINCULO(id)) } catch { return null } }
const guardarVinculo = (id, token) => { try { if (token) localStorage.setItem(CLAVE_VINCULO(id), token); else localStorage.removeItem(CLAVE_VINCULO(id)) } catch { /* preferencia opcional */ } }
const validarEscenario = (id, entrada) => validarVariables({ ...entrada, ...(esTableroEnlazado(id) && { foco: 'todos' }) })
const leer = (id) => {
  try { return validarEscenario(id, JSON.parse(localStorage.getItem(CLAVE(id)) ?? '{}')) } catch { return validarEscenario(id, {}) }
}

// Las variables se guardan como referencias (p. ej. «último trimestre completo»), nunca como fechas: al volver a abrir
// la vista se resuelven otra vez contra los datos. Hoy viven en este navegador; con el esquema negocio aplicado pasan a
// preferencia_usuario («vista:ventas»). La barra de la vista y el chat comparten este estado.
const Contexto = createContext(null)

export function ProveedorVariables({ children }) {
  const { escenario, demostracion, versionDatos } = useEscenario()
  const [inteligencia, setInteligencia] = useState(null)
  const memoriaRef = useRef(null)
  const [estado, setEstado] = useState(() => ({ id: escenario?.id, variables: leer(escenario?.id) }))
  const variables = estado.id === escenario?.id ? estado.variables : leer(escenario?.id)
  const actual = useRef(null)
  actual.current = { escenarioId: escenario?.id, variables }
  const epoca = useRef(0)
  const [vinculo, setVinculo] = useState(() => ({ id: escenario?.id, token: escenario?.id ? leerVinculo(escenario.id) : null }))
  const tokenVinculo = vinculo.id === escenario?.id ? vinculo.token : escenario?.id ? leerVinculo(escenario.id) : null
  // Nueva conversación olvida el vínculo; un cambio de fuente conserva el de cada fuente.
  const limpiarContexto = ({ olvidarVinculo = true } = {}) => {
    epoca.current += 1; memoriaRef.current = null; setInteligencia(null)
    if (olvidarVinculo && escenario?.id) { guardarVinculo(escenario.id, null); setVinculo({ id: escenario.id, token: null }) }
  }
  const guardar = (nuevas, { conservarRespuesta = false } = {}) => {
    const validas = validarEscenario(escenario.id, nuevas)
    try { localStorage.setItem(CLAVE(escenario.id), JSON.stringify(validas)) } catch { /* preferencia opcional */ }
    actual.current = { escenarioId: escenario.id, variables: validas }
    setEstado({ id: escenario.id, variables: validas })
    if (!conservarRespuesta) setInteligencia(prev => prev ? { ...prev, respuesta: null } : null)
  }
  // Pide a Clef una selección sobre las variables vigentes; se aplica solo si sigue vigente al recibirla.
  const proponer = async (consulta, contexto = {}) => {
    const epocaContexto = epoca.current
    // La memoria pendiente puede tener filtros candidatos todavía no aplicados.
    // La vigencia se mide contra la pantalla al enviar, no contra ese candidato.
    const solicitadas = { ...actual.current.variables }
    const respuesta = await pedirDatos(rutaPropuesta(escenario, consulta, solicitadas, { ...contexto, token: memoriaRef.current?.id === escenario.id ? memoriaRef.current.contexto : null }), { signal: contexto.signal })
    return { ...describirPropuesta(respuesta, solicitadas), escenarioId: escenario.id, epocaContexto }
  }
  const registrarDecision = (propuesta) => {
    if (propuesta.epocaContexto !== epoca.current || !propuestaVigente(propuesta, actual.current.escenarioId, actual.current.variables)) return false
    memoriaRef.current = { id: escenario.id, contexto: propuesta.contexto ?? null, presentacion: propuesta.responsePlan?.presentacion ?? null, respuesta: { ...propuesta, contexto: undefined } }
    setInteligencia(memoriaRef.current)
    // Una respuesta conectada reemplaza el vínculo; una aclaración o un «no soportado» no rompe el vigente.
    if (propuesta.vinculo) { guardarVinculo(escenario.id, propuesta.vinculo); setVinculo({ id: escenario.id, token: propuesta.vinculo }) }
    return true
  }
  // Reevaluación del vínculo: al llegar datos nuevos (versión) o al cambiar los filtros, el servidor vuelve a ejecutar
  // las mismas herramientas registradas con las variables vigentes. No consulta a Clef y no cambia de sección.
  const claveVariables = JSON.stringify(variables)
  useEffect(() => {
    if (!escenario?.id || demostracion || !tokenVinculo) return undefined
    const actualMem = memoriaRef.current?.id === escenario.id ? memoriaRef.current.respuesta : null
    // Una respuesta propia distinta (aclaración, no soportado) vigente con estas variables no se sobrescribe.
    if (actualMem && actualMem.vinculo !== tokenVinculo && Object.keys(VARIABLES_VENTAS).every((id) => variables[id] === (actualMem.necesitaAclaracion ? actualMem.vigentes : actualMem.variables)?.[id])) return undefined
    // Recién respondida por Clef con estas mismas variables y versión: no hace falta reevaluar.
    if (actualMem?.vinculo === tokenVinculo && actualMem.versionDatos === versionDatos && Object.keys(VARIABLES_VENTAS).every((id) => variables[id] === actualMem.variables?.[id])) return undefined
    const control = new AbortController(), epocaInicio = epoca.current, id = escenario.id
    pedirDatos(rutaVinculo(escenario, tokenVinculo, variables), { signal: control.signal })
      .then((r) => {
        if (control.signal.aborted || epocaInicio !== epoca.current || r.escenario !== id) return
        const previa = memoriaRef.current?.id === id ? memoriaRef.current.respuesta : null
        const respuesta = { ...(previa?.vinculo === tokenVinculo ? previa : {}), escenarioId: id, epocaContexto: epoca.current, vinculo: tokenVinculo, versionDatos: r.version_datos, vivo: { evaluado_en: r.evaluado_en, version: r.version_datos }, consulta: previa?.vinculo === tokenVinculo ? previa.consulta : r.vinculo.consulta, variables: r.variables, vigentes: r.variables, filas: [], necesitaAclaracion: false, analisis: r.analisis, decision: { ...(previa?.vinculo === tokenVinculo ? previa.decision : {}), dominio: r.vinculo.dominio, metrica: r.vinculo.metrica }, responsePlan: { ...(previa?.vinculo === tokenVinculo ? previa.responsePlan : {}), ...r.response_plan } }
        memoriaRef.current = { id, contexto: memoriaRef.current?.id === id ? memoriaRef.current.contexto : null, presentacion: r.response_plan.presentacion, respuesta }
        setInteligencia(memoriaRef.current)
      })
      .catch((error) => {
        if (control.signal.aborted) return
        // Vencido o ajeno a esta sesión: se olvida. Otros errores conservan lo visible y se reintenta con el próximo cambio.
        if (/vínculo/i.test(error.message)) { guardarVinculo(id, null); setVinculo({ id, token: null }) }
      })
    return () => control.abort()
  }, [escenario?.id, demostracion, tokenVinculo, versionDatos, claveVariables]) // eslint-disable-line react-hooks/exhaustive-deps
  const aplicarPropuesta = (propuesta) => {
    if (propuesta.epocaContexto !== epoca.current || !propuestaVigente(propuesta, actual.current.escenarioId, actual.current.variables)) return false
    guardar(propuesta.variables, { conservarRespuesta: true })
    return true
  }
  const respuesta = inteligencia && inteligencia.id === escenario?.id ? inteligencia.respuesta : null
  const respuestaVigente = respuesta && Object.keys(VARIABLES_VENTAS).every(id => variables[id] === (respuesta.necesitaAclaracion ? respuesta.vigentes : respuesta.variables)?.[id]) ? respuesta : null
  return <Contexto.Provider value={{ variables, guardar, proponer, aplicarPropuesta, registrarDecision, limpiarContexto, respuesta: respuestaVigente, presentacion: inteligencia && inteligencia.id === escenario?.id ? inteligencia.presentacion : null }}>{children}</Contexto.Provider>
}

export const useVariables = () => useContext(Contexto)

export function ListaPropuesta({ propuesta, aplicada = false }) {
  return (
    <>
      <ul className="propuesta-cambios">
        {propuesta.filas.map((f) => <li key={f.id}><b>{f.nombre}:</b> {f.desde} → {f.hacia} <small>{f.nota}</small></li>)}
      </ul>
      <p className="propuesta-resultado">{aplicada ? 'Ahora' : 'Quedaría'}: <b>{propuesta.resultado}</b>.</p>
    </>
  )
}

export function VariablesVista({ resolucion }) {
  const { escenario } = useEscenario()
  const sintetico = esTableroEnlazado(escenario?.id)
  const { variables, guardar } = useVariables()
  const menu = useRef(null)
  const rotulos = { ultimo_mes_completo: 'Último mes', ultimo_trimestre_completo: 'Último trimestre', ultimo_anio_completo: 'Último año', mismo_periodo_anio_anterior: 'Interanual' }
  useEffect(() => {
    const cerrar = (event) => {
      if (event.type === 'keydown' ? event.key === 'Escape' : !menu.current?.contains(event.target)) {
        if (menu.current?.open) {
          menu.current.open = false
          if (event.type === 'keydown') menu.current.querySelector('summary')?.focus()
        }
      }
    }
    document.addEventListener('pointerdown', cerrar)
    document.addEventListener('keydown', cerrar)
    return () => {
      document.removeEventListener('pointerdown', cerrar)
      document.removeEventListener('keydown', cerrar)
    }
  }, [])
  return (
    <details className="variables" ref={menu}>
      <summary className="pill-btn" title={describirResolucion({ actual: resolucion.actual, anterior: resolucion.anterior, motivo: resolucion.motivoComparacion })}>Filtros<Chevron /></summary>
      <section className="variables-menu" aria-label="Variables de la vista">
        <div className="variables-fila">
          {Object.entries(VARIABLES_VENTAS).filter(([id]) => !sintetico || id !== 'foco').map(([id, definicion]) => (
            <label key={id} className="variable">
              <span className="variable-nombre">{definicion.nombre}</span>
              <span className="select variable-select">
                <select title={definicion.opciones[variables[id]].rotulo} value={variables[id]} onChange={(event) => guardar({ ...variables, [id]: event.target.value })}>
                  {!Object.keys(definicion.opciones).includes(variables[id]) && <option value={variables[id]}>{definicion.opciones[variables[id]].rotulo}</option>}
                  {Object.entries(definicion.opciones).map(([opcion, o]) => <option key={opcion} value={opcion}>{sintetico && id === 'listado' && opcion === 'paises' ? 'Sucursales' : rotulos[opcion] ?? o.rotulo}</option>)}
                </select>
                <Chevron />
              </span>
            </label>
          ))}
        </div>
        <p className="variables-resuelto"><b>{describirResolucion({ actual: resolucion.actual, anterior: resolucion.anterior, motivo: resolucion.motivoComparacion })}</b>{resolucion.pais && <> · {resolucion.pais}</>}</p>
      </section>
    </details>
  )
}
