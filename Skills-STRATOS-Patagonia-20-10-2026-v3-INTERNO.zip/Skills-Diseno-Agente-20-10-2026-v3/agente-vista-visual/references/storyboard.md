# Storyboard de la vista del agente

## Anatomía implementable
`AgentWorkspace` conserva selección y periodo; `AgentHome` compone contexto y sugerencias; `AgentComposer` mantiene borrador; `AgentStatus` recibe eventos reales; `EvidenceCanvas` presenta componentes registrados; `SourceDrawer` abre procedencia; `AgentDock` sostiene seguimiento. Son roles recomendados para la adaptación, no nombres de componentes que ya existan en el destino.

En escritorio: inicio con compositor de ancho legible y espacio negativo; resultado con instrumento principal y conversación secundaria. El dock no tapa ejes. En estrecho: una columna, conversación replegable con estado visible. El historial preserva el contexto original de cada respuesta; al cambiar centro se etiqueta como anterior y no pasa a ser evidencia actual.

## Coreografía y estados
| Disparador real | Qué se ve | Movimiento y salida |
| --- | --- | --- |
| Abrir | contexto + borrador, orbe en reposo | entrada de panel 200–280 ms; foco en compositor |
| Enviar | consulta persistente y detener | respuesta inmediata del control; sin espera programada |
| tool.started | nombre humano de fuente/tarea | indicador local; no rehacer toda la pantalla |
| evidence.ready | instrumento con fecha y naturaleza | entrada 180–240 ms, opacidad/desplazamiento 4–8 px |
| clarification | pregunta concreta con opciones | mismo contexto; input operable |
| partial_result | evidencia utilizable + faltantes | UI estable; reintento por fuente |
| error/timeout | motivo útil + reintentar | borrador conservado, sin colapso automático |
| cancel | confirmación y trabajo detenido | retirar actividad inmediatamente; no presentar resultado tardío |
| context.changed | nueva entidad/periodo | invalidar turno incompatible antes de pintar |
| cerrar | retorna al lugar y zoom previos | restaurar foco al disparador; pausar trabajo visual oculto |

Los tiempos son propuestas para piezas nuevas. En STRATOS reutilizar stageTiming/fadeFlight y no duplicar temporizadores. El estado tiene que venir de eventos, nunca de un carrusel de frases que afirme trabajo no realizado. No presentar cadena de pensamiento; sí tareas, fuentes, estado y límites observables.

## Orbe y material
El orbe es firma del agente; su reposo debe ser silencioso. Ocupado puede tener respiración leve y texto; error requiere texto/acción, no sólo rojo. Transform/opacity, sin blur animado ni glow por todo el dashboard. Pausar al quedar fuera de vista; respetar preferencia reducida sin perder estados. No iniciar requestAnimationFrame permanente por un panel cerrado.

## Interacción
Enter envía salvo composición IME; Shift+Enter inserta línea. En vacío no enviar; en curso el mismo control detiene. El autoscroll sigue sólo si el usuario estaba al final; permitir leer historia. No anunciar cada token con aria-live. Evitar mover layout con la llegada de palabras; reservar el contenedor de la evidencia, no una grilla entera vacía.

Paneles modales: nombre, Escape, cierre visible, foco contenido y restaurado; contenido de fondo inert. Panel no modal: no fingir trampa de foco. Abrir fuentes debe mostrar fuente y límites de esa evidencia, nunca llevar a otra función por conveniencia. Las acciones generadas sólo pueden ser controles registrados con props validadas.

## Secuencia de demo de tres minutos
0:00 territorio y centro, capa/fecha visibles → seleccionar y acercar.
0:30 abrir escena mediante botón o doble click; explicar que es ilustración y qué sensor está vinculado.
1:00 preguntar por cambios; mostrar estado real o modo sintético explícito; una conclusión y un gráfico pertinente.
1:40 abrir procedencia: unidad, profundidad, periodo, método, QC, soporte y límites.
2:10 cambiar centro/periodo y comprobar que no aparecen resultados del contexto anterior.
2:30 abrir cámaras: clip autorizado si existe; vacío útil en caso contrario. Volver al mapa y recuperar contexto.

No memorizar una animación que sólo funcione con un guion: probar consulta extensa, error, fuente lenta, cancelar y teclado. Capturar inicio, resultado, parcial y submarina a tamaño real.
