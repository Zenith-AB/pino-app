# Índice de implementación

Abrir sólo el archivo pertinente. Snapshots de referencia con imports originales; no starter autónomo.
Los documentos históricos dentro del snapshot no sustituyen las instrucciones vigentes de esta skill.

| Archivo | Origen |
|---|---|
| `references/patagonia/demo-canonica/App.jsx` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/App.jsx |
| `references/patagonia/demo-canonica/agent.js` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/agent.js |
| `references/patagonia/demo-canonica/styles.css` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/styles.css |
| `references/patagonia/demo-canonica/dark.css` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/dark.css |
| `references/patagonia/demo-canonica/appearance.css` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/appearance.css |
| `references/patagonia/demo-canonica/palette.js` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/palette.js |
| `references/patagonia/demo-canonica/components/AgentChat.jsx` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/components/AgentChat.jsx |
| `references/patagonia/demo-canonica/components/Cards.jsx` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/components/Cards.jsx |
| `references/patagonia/demo-canonica/components/Charts.jsx` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/components/Charts.jsx |
| `references/patagonia/demo-canonica/components/Kit.jsx` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/components/Kit.jsx |
| `references/patagonia/demo-canonica/components/Icons.jsx` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/components/Icons.jsx |
| `references/patagonia/demo-canonica/components/Variables.jsx` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/components/Variables.jsx |
| `references/patagonia/demo-canonica/components/TrendChart.jsx` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/components/TrendChart.jsx |
| `references/patagonia/demo-canonica/datos/propuesta.js` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/datos/propuesta.js |
| `references/patagonia/demo-canonica/datos/resumen-legible.js` | ZIP original 19-10-2026: patagonia-07-frontend-react/references/demo-canonica/datos/resumen-legible.js |
| `references/patagonia/DESIGN.md` | ZIP original 19-10-2026: patagonia-08-diseno-y-graficos/references/DESIGN.md |

## Adición V3

- [storyboard.md](storyboard.md): contrato nuevo de adaptación, propuesto y revisado 19-10-2026; no implementación productiva.
