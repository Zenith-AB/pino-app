---
name: stratos-fuentes-explicables
description: "Integra fuentes ambientales STRATOS y explica su procedencia: mapas, corrientes CHONOS, boyas ACS, Copernicus, clorofila y meteorología. Incluye uso privado de credenciales; no promete causalidad universal ni validación biológica."
---

# Fuentes ambientales explicables

Lee [inventario](references/fuentes.md) para elegir conectores y [credenciales](references/credenciales.md)
para usar Marine/CDS. Revisa [contrato de evidencia](references/evidencia.md) antes de construir respuestas.
Código de conectores/registro/ingesta en `references/codigo/`; son implementaciones fechadas, no garantía
de que todos sus proveedores estén activos. No descargar datasets grandes al equipo local.

## Cadena de integración

Proveedor → captura/archivo de servidor → validación y contrato temporal → API autorizada/caché →
adaptador de vista → gráfico/card/explicación. No descargar Copernicus desde cada sesión del navegador.
Conservar último dato válido con fecha original; diferenciar vivo, antiguo, snapshot, demo y ausente.
Un refresco HTTP no vuelve reciente una observación antigua.

Conserva source, dataset/version, entity/location, spatialSupport, depth, variable, unit, method, QC,
observedAt, availableAt, issuedAt, validAt, capturedAt/asOf y licencia cuando aplique. Campos desconocidos
se declaran desconocidos. No fusionar observado, satélite, modelo y simulación en una sola serie anónima.

## Operación

Para preparar demo usa capturas identificadas y APIs propias. Verifica acceso y latencia antes del
ensayo. Los metadatos del servidor incluidos sólo prueban existencia/fecha de archivos al 19-10-2026,
no calidad de cada píxel, observación vigente ni autenticación actual de las credenciales.
Corrige conectores sólo con evidencia y pruebas proporcionadas. No alterar modelos, gates o alertas
por un trabajo de prototipo o documentación. Leer estrategia científica del destino para cambios de datos.

Para otro fenómeno crea un contrato específico de objetivo, observables, hipótesis, ámbito y límites.
El dashboard puede reunir evidencia heterogénea; eso no acredita explicar causalmente todo fenómeno.

Índice de código y assets: [references/INDICE.md](references/INDICE.md).
