"""Carga el TXT interno en el entorno de un proceso sin mostrar secretos ni salidas sensibles."""
import json
import os
from pathlib import Path
import subprocess
import sys

ALLOWED = {'COPERNICUSMARINE_SERVICE_USERNAME', 'COPERNICUSMARINE_SERVICE_PASSWORD', 'CDSAPI_URL', 'CDSAPI_KEY'}

def read_credentials(path):
    result = {}
    for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        key, sep, value = line.partition('=')
        if not sep or key.strip() not in ALLOWED:
            raise ValueError('Clave o formato no permitido; no se muestran valores')
        key = key.strip()
        if key in result:
            raise ValueError('Clave duplicada; no se muestran valores')
        parsed = json.loads(value.strip())
        if not isinstance(parsed, str) or not parsed:
            raise ValueError('Valor no válido; no se muestran valores')
        result[key] = parsed
    return result

def main():
    if len(sys.argv) < 4 or sys.argv[2] != '--':
        print('Uso: ejecutar-con-credenciales.py <txt> -- <comando> [argumentos]')
        return 2
    try:
        values = read_credentials(sys.argv[1])
        env = os.environ.copy()
        env.update(values)
        # The caller can execute a reviewed script that saves its intended result separately.
        child = subprocess.run(sys.argv[3:], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print('Proceso terminado. Código:', child.returncode, '· Salidas suprimidas para proteger credenciales.')
        return child.returncode
    except Exception:
        print('No se pudo cargar o ejecutar el proceso; no se muestran valores ni salidas sensibles.')
        return 1

if __name__ == '__main__':
    sys.exit(main())
