# Índice de implementación

Abrir sólo el archivo pertinente. Snapshots de referencia con imports originales; no starter autónomo.
Los documentos históricos dentro del snapshot no sustituyen las instrucciones vigentes de esta skill.

| Archivo | Origen |
|---|---|
| `references/codigo/datasource/registry.ts` | repositorio local inspeccionado 19-10-2026: datasource/registry.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/core/types.ts` | repositorio local inspeccionado 19-10-2026: datasource/core/types.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/core/fetchSource.ts` | repositorio local inspeccionado 19-10-2026: datasource/core/fetchSource.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/core/env.ts` | repositorio local inspeccionado 19-10-2026: datasource/core/env.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/jobs/ingest_copernicus.py` | repositorio local inspeccionado 19-10-2026: datasource/jobs/ingest_copernicus.py; puede incluir cambios sin commit |
| `references/codigo/datasource/jobs/credentials.mjs` | repositorio local inspeccionado 19-10-2026: datasource/jobs/credentials.mjs; puede incluir cambios sin commit |
| `references/codigo/src/lib/currents/chonosCurrents.ts` | repositorio local inspeccionado 19-10-2026: src/lib/currents/chonosCurrents.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/jobs/cycle.mjs` | repositorio local inspeccionado 19-10-2026: datasource/jobs/cycle.mjs; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/acs-sotracs/buoyBinding.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/acs-sotracs/buoyBinding.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/acs-sotracs/centers.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/acs-sotracs/centers.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/acs-sotracs/client.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/acs-sotracs/client.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/acs-sotracs/mooring.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/acs-sotracs/mooring.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/acs-sotracs/types.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/acs-sotracs/types.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/chonos/mosa.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/chonos/mosa.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/chonos-redmet/parser.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/chonos-redmet/parser.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/chonos-redmet/stations.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/chonos-redmet/stations.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/climate-indices/indices.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/climate-indices/indices.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/climate-indices/parsers.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/climate-indices/parsers.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/copernicus/bgc.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/copernicus/bgc.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/copernicus/oceanColour.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/copernicus/oceanColour.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/copernicus/sentinel2.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/copernicus/sentinel2.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/copernicus/types.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/copernicus/types.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/ifop-websig/wfs.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/ifop-websig/wfs.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/noaa-erddap/chla.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/noaa-erddap/chla.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/open-meteo/flood.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/open-meteo/flood.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/open-meteo/index.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/open-meteo/index.ts; puede incluir cambios sin commit |
| `references/codigo/datasource/sources/subpesca/marearoja.ts` | repositorio local inspeccionado 19-10-2026: datasource/sources/subpesca/marearoja.ts; puede incluir cambios sin commit |
| `references/codigo/docs/ESTRATEGIA-CIENTIFICA-RELONCAVI.md` | repositorio local inspeccionado 19-10-2026: docs/ESTRATEGIA-CIENTIFICA-RELONCAVI.md; puede incluir cambios sin commit |
| `references/codigo/docs/CONTRATO-MODELOS-POR-ETAPAS.md` | repositorio local inspeccionado 19-10-2026: docs/CONTRATO-MODELOS-POR-ETAPAS.md; puede incluir cambios sin commit |
| `references/codigo/docs/CORRIENTES-CACHE-REGIONAL-2026-10-11.md` | repositorio local inspeccionado 19-10-2026: docs/CORRIENTES-CACHE-REGIONAL-2026-10-11.md; puede incluir cambios sin commit |
| `references/metadata-servidor.jsonl` | SSH autorizado, sólo metadatos de archivos; 19-10-2026; no demuestra frescura observacional |
