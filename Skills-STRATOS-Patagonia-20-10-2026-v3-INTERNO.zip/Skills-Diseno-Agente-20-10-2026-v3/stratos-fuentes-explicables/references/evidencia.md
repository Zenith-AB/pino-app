# Explicabilidad que puede sostener el sistema

Para cada respuesta: qué se observó/modeló → dónde/cuándo/profundidad → cambio comparable → hipótesis
compatibles → evidencia faltante → acción de verificación. Separar dato, derivación, hipótesis y pronóstico.
No dar una explicación causal sólo porque varias curvas se mueven juntas o porque el judge la acepta.

Una tarjeta de evidencia incluye variable, valor/unidad si existe, fuente, método, naturaleza, sitio,
soporte espacial, profundidad, fechas, QC, cobertura, enlace y limitación principal. Para diferencias,
periodo y baseline deben ser comparables. Si no, se muestra contexto separado en vez de un delta.

Ejemplo de estructura sin cifras inventadas:
«El campo CHONOS indica [dirección/velocidad modeladas] para [celda/fecha]. La boya [id] registró
[variable] a [profundidad/fecha/QC]. Es contexto de [ubicación/distancia], no medición en las jaulas.
Es compatible con [hipótesis], pero faltan [observaciones] para atribuir el cambio.»

El índice GEFS 0–100 es favorabilidad sin calibrar, no probabilidad biológica. No usar un ROC-AUC
regional como porcentaje de acierto local. Floración, abundancia ordinal, células, toxina, cierre y
daño a peces son objetivos diferentes. El gate local de Dinophysis no se habilita por una demo.
Predicción por entidad/variable/profundidad/horizonte exige evidencia propia. Sin soporte, no evaluable.

No imponer ENSO/SAM como requisito universal de FAN, menor caudal como mezcla/estratificación
universal ni una boya cercana como influencia hidrodinámica probada. Dos profundidades no reconstruyen
picnoclina. Una ilustración submarina no es observación. Para otros fenómenos, definir objetivo y
referencias independientes antes de mostrar capacidad explicativa o predictiva.
