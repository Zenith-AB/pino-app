# Inventario técnico inspeccionado · 19-10-2026

Endpoints extraídos del código; comprobar respuesta/esquema/cobertura al utilizarlos. No representan
contratos comerciales permanentes. Las fuentes públicas también tienen condiciones de uso y atribución.

| Capacidad | Origen y ruta | Integración y límite |
|---|---|---|
| Mapa satelital | Esri World Imagery: https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x} | Leaflet, detalle desde z12, nativo hasta z18 según config; atribución Esri/Vantor/Earthstar |
| Mapa oscuro | https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x} | Contexto cartográfico, no medición ambiental |
| Corrientes | https://chonos5.meteodata.cl; mosa_domains_geojson, data_visor, variables, series vía /ds/chonos | CROCO/WRF modelado; interfaz pública frágil/no documentada en cliente; archivo horario regional |
| Boyas y sondas | https://acs.ifop.cl/api/v1; boyas/, sensores/, lecturas/ vía /ds/acs | Unir por sensor y profundidad; validar cada fila contra boya_code y variable_code |
| Meteorología instrumental | https://chonos.ifop.cl/met2/api2 | REDMET: catálogo ≠ observaciones recientes; fecha/QC por variable |
| Biología | https://sig-acuicultura.ifop.cl/geoserver/ows | WFS de muestras; taxón, estación, AR ordinal; no confundir con toxina o conteo celular |
| Eventos reportados | https://geoportal.subpesca.cl/server/rest/services/IDE_PUBLICO/SRMPUB_MAREAROJA/MapServer | Evento/taxón/fecha/geometría; ausencia de registro no es negativo |
| Clorofila satelital adicional | https://coastwatch.noaa.gov/erddap/griddap/noaacwNPPVIIRSSQchlaDaily | VIIRS, máscara/calidad/costa/nubes; no especie |
| Meteorología modelada | https://api.open-meteo.com/v1/forecast; https://ensemble-api.open-meteo.com/v1/ensemble | Modelos/ensemble identificados; índice GEFS sin calibrar no es P(FAN) |
| Caudal | https://flood-api.open-meteo.com/v1/flood | GloFAS modelado, no aforo DGA; ubicación de celda y cuenca importan |
| Contexto marino alternativo | https://marine-api.open-meteo.com/v1/marine | No usar como medición local; no consultar por pan/zoom si existe archivo común |
| Oceanografía global | Copernicus Marine Toolbox | Física/BGC/satélite son productos distintos; credenciales sólo en servidor |
| Reanálisis meteorológico | CDS/ERA5: https://cds.climate.copernicus.eu/api | Token separado de Marine; reconstrucción retrospectiva, no forecast histórico emitido |

## Corrientes y partículas

`chonosCurrents.ts` consume `/datasource/chonos-currents-index.json`, envelopes JSON/bin regionales
y fallback `/datasource/chonos-currents.json` + bin. Archivo compartido, máscaras y fechas por corrida.
CHONOS/MOSA tiene dominios de ~1 km Los Lagos/Aysén y ~3 km Magallanes según código; verificar dominio
y malla antes de atribuir detalle. `chonosCenterDetailSource.ts` busca celda de agua hasta 3 km: es
una regla de muestreo del código, no evidencia de representatividad o conectividad hidrodinámica.
`uvel/vvel` → U/V; `vectorToCourse` calcula velocidad y rumbo hacia. Un campo sólo superficial no prueba
cizalla, retención, residencia ni transporte tridimensional. Distinguir una simulación RK2 de observaciones.

## Boyas

El cliente documenta que sensor_id puede ignorarse y que sensores limita páginas; usar filtros por
boya+variable, comprobar paginación y validar filas. Profundidad sale de sensores/, no de la lectura.
Una boya distante aporta contexto; ni radio visual ni proximidad validan influencia sobre un centro.
ACS1 tiene antecedente de coordenadas -1/-1; el código conserva fondeo verificado con procedencia.
GOOD de proveedor no sustituye controles de plausibilidad/deriva propios.

## Productos configurados de Copernicus

- Física: GLOBAL_ANALYSISFORECAST_PHY_001_024; dataset `cmems_mod_glo_phy_anfc_0.083deg_PT1H-m`:
  thetao, so, uo, vo, zos; malla de contexto ~9 km, no microescala del centro.
- BGC forecast: GLOBAL_ANALYSISFORECAST_BGC_001_028, familias nut/bio/car/pft/optics a 0.25°:
  NO3, PO4, Si, O2, producción primaria, pH, alcalinidad, DIC, clorofila, carbono y atenuación según dataset.
- BGC retrospectivo: GLOBAL_MULTIYEAR_BGC_001_029. Mantener periodo y naturaleza retrospectiva.
- OLCI: OCEANCOLOUR_GLO_BGC_L3_NRT_009_101, CHL y RRS443. En el código, «300 m» nombra el sensor;
  la malla usada se declara ~620 m. KD490/SPM se toman del producto de ~4.64 km, no del de 300 m.
- NH4/NO2 no aparecen en estas variables configuradas: no fabricarlos ni sustituirlos por nitrato.

Esos IDs son el estado del código, no un listado perpetuo de datasets disponibles. Resolver catálogo
vigente antes de descargar y declarar versión, límites, máscara y profundidad. Interpolar a H3 no
aumenta resolución física. Satélite/clorofila/fluorescencia no identifica por sí solo una especie FAN.

Snapshots previstos: acs-buoys, chonos-currents[-index], copernicus-glorys, copernicus-bgc,
copernicus-bgc-hindcast, copernicus-olci-300m, era5, weather-context e ifop-websig en public/datasource.
Generación reciente de un snapshot no demuestra frescura del dato interno. Ver metadata-servidor.jsonl.

## Contraste de esta revisión V3

Lectura SSH autorizada 19-10-2026: denoise-server accesible; HEAD productivo
`1f92816fad33ff4a3160f325ed797169ad373649`; archivo de entorno legible. Coincidencia de las cuatro
variables privadas comprobada sin revelar valores. No se verificó autenticación externa ni frescura
individual de cada API. El inventario anterior sigue siendo evidencia de código, no test de conexión.

La documentación oficial consultada distingue login Marine con usuario/contraseña, catálogo/metadata
mediante `describe` y extracción por variable/área/profundidad/periodo mediante `subset`.
CDS tiene setup y token propios. Comprobar versión instalada y condiciones del producto antes de ejecutar.
No descargar datos grandes localmente ni por cada pan/zoom. El backend archiva la fuente con versiones;
el cliente consume una salida acotada, cacheada y con procedencia.

- [Marine Toolbox](https://help.marine.copernicus.eu/en/articles/7949409-copernicus-marine-toolbox-introduction)
- [Producto físico global](https://data.marine.copernicus.eu/product/GLOBAL_ANALYSISFORECAST_PHY_001_024/description)
- [CDS API setup](https://cds.climate.copernicus.eu/how-to-api)

Explicación de un fenómeno: observación/periodo → comparación comparable → mecanismo propuesto →
alternativas → dato faltante que lo contrastaría. No presentar causalidad por correlación, partículas,
SHAP, proximidad o relato del agente. La clorofila no resuelve taxonomía; una cámara tampoco por existir.
