// Configuración del cliente. Sólo lee variables con prefijo `VITE_`, que son las
// únicas que Vite inyecta en el bundle.
//
// Aquí no hay ni puede haber secretos: las credenciales de Copernicus Marine y
// CDS/ERA5 viven en `.env.local` sin prefijo `VITE_` y las lee exclusivamente
// Node (`datasource/jobs/*`, `datasource/server/serve.mjs`). Si alguna vez
// aparece un `VITE_COPERNICUS_PASSWORD`, está publicado en el navegador.

type RawEnv = Record<string, string | boolean | undefined>;

function env(): RawEnv {
  try {
    return (import.meta as unknown as { env?: RawEnv }).env ?? {};
  } catch {
    return {};
  }
}

function text(key: string, fallback: string): string {
  const value = env()[key];
  return typeof value === 'string' && value.length > 0 ? value : fallback;
}

function flag(key: string, fallback: boolean): boolean {
  const value = env()[key];
  if (value === undefined) return fallback;
  return value === true || value === 'true' || value === '1';
}

function number(key: string, fallback: number): number {
  const value = Number(env()[key]);
  return Number.isFinite(value) ? value : fallback;
}

/** Prefijo de las rutas servidas por el proxy (dev: Vite; prod: serve.mjs). */
export const PROXY_BASE = text('VITE_DATASOURCE_PROXY', '/ds');

/** Carpeta pública donde `jobs/snapshot.mjs` deja los extractos offline. */
export const SNAPSHOT_BASE = text('VITE_DATASOURCE_SNAPSHOTS', '/datasource');

/** Timeout por defecto de una petición a proveedor, en ms. */
export const REQUEST_TIMEOUT_MS = number('VITE_DATASOURCE_TIMEOUT_MS', 12_000);

/** Reintentos por defecto ante error de red o 5xx. */
export const REQUEST_RETRIES = number('VITE_DATASOURCE_RETRIES', 2);

/**
 * Permite el respaldo mockup en el último escalón de la cascada. Ponerlo en
 * `false` fuerza a la interfaz a declarar `missing` en vez de rellenar: es el
 * modo honesto para una demostración operacional.
 */
export const ALLOW_MOCK = flag('VITE_DATASOURCE_ALLOW_MOCK', false);

/** Silencia el log de `datasource` en consola. */
export const VERBOSE = flag('VITE_DATASOURCE_VERBOSE', true);

/** Construye una URL del proxy: `proxyUrl('acs', 'boyas/?limit=20')`. */
export function proxyUrl(sourceId: string, path = ''): string {
  const base = `${PROXY_BASE.replace(/\/$/, '')}/${sourceId}`;
  if (!path) return base;
  return `${base}/${path.replace(/^\//, '')}`;
}

/** Construye la URL de un snapshot publicado. */
export function snapshotUrl(file: string): string {
  return `${SNAPSHOT_BASE.replace(/\/$/, '')}/${file.replace(/^\//, '')}`;
}
