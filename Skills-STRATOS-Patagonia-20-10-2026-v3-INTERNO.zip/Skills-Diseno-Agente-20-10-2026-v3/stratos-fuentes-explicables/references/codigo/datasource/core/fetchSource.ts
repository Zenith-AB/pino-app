// La única puerta de entrada de datos de STRATOS-UXUI.
//
// Implementa la cascada completa, igual para todas las fuentes:
//
//   live  → respuesta del proveedor en este ciclo
//   stale → última respuesta buena de esa misma clave (memoria, luego localStorage)
//   snapshot → extracto offline en public/datasource (Copernicus, ERA5, CR2)
//   mock  → respaldo de forma idéntica, marcado como NO medición
//   missing → no hay nada que decir, y se dice
//
// Ningún escalón inventa un valor y ninguno se salta la etiqueta: el
// `SourceResult` que sale de aquí siempre sabe de dónde viene.

import { readLastGood, writeLastGood } from './cache';
import { REQUEST_RETRIES, REQUEST_TIMEOUT_MS, ALLOW_MOCK, VERBOSE, snapshotUrl } from './env';
import { recordHealth } from './health';
import { createLogger } from '../../src/lib/stratos/logger';
import { degraded, live, missing, type SourceResult } from './types';

const log = createLogger('datasource');

export interface FetchSourceOptions<T> {
  /** Identificador de la fuente en `registry.ts`. */
  sourceId: string;
  /** URL absoluta del proveedor, o ruta `/ds/...` del proxy. */
  url: string;
  /** Etiqueta legible para el log. Por defecto, el `sourceId`. */
  label?: string;
  /** Opciones de `fetch` (método, cuerpo, cabeceras). */
  init?: RequestInit;
  /** `json` decodifica la respuesta; `text` la entrega cruda (índices climáticos, WFS XML). */
  as?: 'json' | 'text';
  timeoutMs?: number;
  retries?: number;
  /**
   * Valida y transforma la carga cruda. Debe lanzar si el proveedor cambió de
   * esquema: un fallo ruidoso es preferible a una serie silenciosamente vacía.
   */
  parse: (raw: unknown) => T;
  /** Clave de caché. Por defecto la URL; explicítala cuando el cuerpo POST distingue. */
  cacheKey?: string;
  /** Archivo dentro de public/datasource que sirve de snapshot. */
  snapshotFile?: string;
  /**
   * La fuente no tiene endpoint propio en el navegador: su dato lo produce un
   * pipeline externo y aquí sólo se lee el snapshot. Se salta el intento de red
   * en vez de provocar un fallo para llegar al mismo sitio.
   */
  snapshotOnly?: boolean;
  /** Respaldo. Se usa sólo si `VITE_DATASOURCE_ALLOW_MOCK` no lo desactiva. */
  mock?: () => T;
}

interface Attempt {
  ok: boolean;
  status?: number;
  raw?: unknown;
  error?: string;
}

async function attempt<T>(options: FetchSourceOptions<T>): Promise<Attempt> {
  const timeout = options.timeoutMs ?? REQUEST_TIMEOUT_MS;
  try {
    const response = await fetch(options.url, {
      ...options.init,
      signal: AbortSignal.timeout(timeout),
    });
    if (!response.ok) {
      return { ok: false, status: response.status, error: `HTTP ${response.status}` };
    }
    const raw = options.as === 'text' ? await response.text() : await response.json();
    return { ok: true, status: response.status, raw };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

/** Reintenta sólo lo que tiene sentido reintentar: red caída y 5xx, nunca un 4xx. */
function worthRetrying(result: Attempt): boolean {
  if (result.status === undefined) return true;
  return result.status >= 500;
}

export async function fetchSource<T>(options: FetchSourceOptions<T>): Promise<SourceResult<T>> {
  const { sourceId, url } = options;
  const label = options.label ?? sourceId;
  const key = options.cacheKey ?? url;
  const retries = options.retries ?? REQUEST_RETRIES;
  const started = performance.now();

  let last: Attempt = { ok: false, error: 'sin intentos' };
  if (options.snapshotOnly) {
    const snapshot = options.snapshotFile ? await loadSnapshot(options) : null;
    if (snapshot) {
      recordHealth({ sourceId, state: 'snapshot', at: Date.now(), durationMs: null });
      return degraded(sourceId, 'snapshot', snapshot.data, snapshot.generatedAt, 'extracto publicado por el servidor');
    }
    return fallback(options, key, 0, 'fuente sin endpoint propio: se lee el recorte del pipeline');
  }
  for (let round = 0; round <= retries; round += 1) {
    last = await attempt(options);
    if (last.ok || !worthRetrying(last)) break;
    if (round < retries) await new Promise((resolve) => setTimeout(resolve, 400 * (round + 1)));
  }

  const durationMs = Math.round(performance.now() - started);

  if (last.ok) {
    try {
      const data = options.parse(last.raw);
      writeLastGood(key, last.raw);
      if (VERBOSE) log.ok(`✓ ${label} (${durationMs}ms)`);
      recordHealth({ sourceId, state: 'live', at: Date.now(), durationMs, httpStatus: last.status });
      return live(sourceId, data);
    } catch (error) {
      // Respondió, pero el esquema no es el esperado. No se cachea una carga que
      // no se entiende: se degrada y se deja constancia del motivo real.
      const note = error instanceof Error ? error.message : String(error);
      log.error(`✗ ${label}: esquema inesperado — ${note}`);
      return fallback(options, key, durationMs, `esquema inesperado: ${note}`);
    }
  }

  if (VERBOSE) log.warn(`✗ ${label}: ${last.error} (${durationMs}ms)`);
  return fallback(options, key, durationMs, last.error ?? 'error desconocido', last.status);
}

async function fallback<T>(
  options: FetchSourceOptions<T>,
  key: string,
  durationMs: number,
  note: string,
  httpStatus?: number,
): Promise<SourceResult<T>> {
  const { sourceId } = options;
  const label = options.label ?? sourceId;

  // 1. Última captura buena de esta misma clave.
  const cached = readLastGood(key);
  if (cached) {
    try {
      const data = options.parse(cached.data);
      const age = Math.round((Date.now() - cached.savedAt) / 60_000);
      if (VERBOSE) log.warn(`⟳ ${label}: última captura, hace ${age} min`);
      recordHealth({ sourceId, state: 'stale', at: Date.now(), durationMs, httpStatus, note });
      return degraded(sourceId, 'stale', data, cached.savedAt, note);
    } catch {
      /* la captura ya no encaja con el parser actual: se sigue bajando la cascada */
    }
  }

  // 2. Snapshot offline publicado por `jobs/snapshot.mjs`.
  if (options.snapshotFile) {
    const snapshot = await loadSnapshot(options);
    if (snapshot) {
      if (VERBOSE) log.warn(`⧉ ${label}: snapshot ${options.snapshotFile}`);
      recordHealth({ sourceId, state: 'snapshot', at: Date.now(), durationMs: null, note });
      return degraded(sourceId, 'snapshot', snapshot.data, snapshot.generatedAt, note);
    }
  }

  // 3. Respaldo mockup, explícitamente marcado como no medición.
  if (options.mock && ALLOW_MOCK) {
    if (VERBOSE) log.warn(`◌ ${label}: respaldo mockup — NO es una medición`);
    recordHealth({ sourceId, state: 'mock', at: Date.now(), durationMs: null, note });
    return degraded(sourceId, 'mock', options.mock(), null, note);
  }

  recordHealth({ sourceId, state: 'missing', at: Date.now(), durationMs, httpStatus, note });
  return missing<T>(sourceId, note);
}

interface SnapshotEnvelope<T> {
  data: T;
  generatedAt: number | null;
}

/**
 * Lee `public/datasource/<archivo>`. El job escribe `{ generatedAt, data }`; se
 * acepta también un documento pelado para poder publicar un extracto a mano.
 */
async function loadSnapshot<T>(options: FetchSourceOptions<T>): Promise<SnapshotEnvelope<T> | null> {
  try {
    const response = await fetch(snapshotUrl(options.snapshotFile as string), {
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
    if (!response.ok) return null;
    const payload = (await response.json()) as { generatedAt?: string; data?: unknown };
    const hasEnvelope = payload && typeof payload === 'object' && 'data' in payload;
    const body = hasEnvelope ? payload.data : payload;
    const generatedAt = hasEnvelope && payload.generatedAt ? Date.parse(payload.generatedAt) : null;
    return {
      data: options.parse(body),
      generatedAt: Number.isFinite(generatedAt) ? (generatedAt as number) : null,
    };
  } catch {
    return null;
  }
}
