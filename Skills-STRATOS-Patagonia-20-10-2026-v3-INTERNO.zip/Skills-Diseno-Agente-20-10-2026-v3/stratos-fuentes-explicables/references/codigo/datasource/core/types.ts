// Contrato único de `datasource/`.
//
// Toda fuente —una boya de IFOP, un pronóstico de CHONOS, un snapshot de
// Copernicus— devuelve la misma forma. El consumidor nunca recibe un `null`
// crudo ni un valor sin etiqueta: recibe un `SourceResult` que dice qué trae y
// de dónde salió.

import type { Provenance } from './provenance';

export interface SourceMeta {
  /** Identificador de la fuente en `registry.ts`. */
  sourceId: string;
  /** ISO-8601 del instante en que se obtuvo el dato que se está devolviendo. */
  fetchedAt: string;
  /** Antigüedad en ms del dato devuelto. `null` cuando no hay dato. */
  ageMs: number | null;
  /** Identificador de corrida del proveedor, cuando lo publica (p. ej. MOSA). */
  runId?: string;
  /** Nota legible: por qué se degradó, qué endpoint respondió, qué falta. */
  note?: string;
}

export interface SourceResult<T> {
  state: Provenance;
  data: T | null;
  meta: SourceMeta;
}

/** Construye un resultado vivo. */
export function live<T>(sourceId: string, data: T, extra: Partial<SourceMeta> = {}): SourceResult<T> {
  return {
    state: 'live',
    data,
    meta: { sourceId, fetchedAt: new Date().toISOString(), ageMs: 0, ...extra },
  };
}

/** Construye un resultado degradado con la antigüedad real del dato que lleva. */
export function degraded<T>(
  sourceId: string,
  state: Provenance,
  data: T | null,
  fetchedAtMs: number | null,
  note?: string,
): SourceResult<T> {
  const at = fetchedAtMs ?? Date.now();
  return {
    state,
    data,
    meta: {
      sourceId,
      fetchedAt: new Date(at).toISOString(),
      ageMs: fetchedAtMs === null ? null : Math.max(0, Date.now() - fetchedAtMs),
      note,
    },
  };
}

/** Resultado sin dato alguno. */
export function missing<T>(sourceId: string, note?: string): SourceResult<T> {
  return {
    state: 'missing',
    data: null,
    meta: { sourceId, fetchedAt: new Date().toISOString(), ageMs: null, note },
  };
}

/** Aplica una transformación conservando estado y procedencia. */
export function mapResult<A, B>(
  result: SourceResult<A>,
  transform: (value: A) => B,
): SourceResult<B> {
  if (result.data === null) return { ...result, data: null };
  return { ...result, data: transform(result.data) };
}
