// NOAA CoastWatch / ERDDAP — clorofila superficial VIIRS, producto diario.
//
// Es la única señal de biomasa fitoplanctónica con cobertura espacial continua
// sobre los fiordos. Las boyas ACS miden fluorescencia en un punto; esto da el
// campo alrededor de ese punto.
//
// Dos cosas medidas el 2026-09-16 que condicionan cómo se lee:
//
//   · El producto va con ~10 días de retraso respecto a hoy. No es una fuente
//     de "ahora": la fecha de la imagen viaja en el resultado y hay que mostrarla.
//   · Sobre los fiordos, buena parte de las celdas vuelven nulas —nubosidad y
//     máscara de tierra—. Un nulo aquí significa "sin observación", nunca cero
//     clorofila, así que se cuentan aparte y no se promedian como si fueran ceros.

import { fetchSource } from '../../core/fetchSource';
import { proxyUrl } from '../../core/env';
import { mapResult, type SourceResult } from '../../core/types';

const SOURCE_ID = 'noaa-erddap-chla';
const DATASET = 'noaacwNPPVIIRSSQchlaDaily';

export interface ChlaCell {
  lat: number;
  lon: number;
  /** mg·m⁻³. `null` significa sin observación (nube o tierra), no ausencia de clorofila. */
  value: number | null;
}

export interface ChlaField {
  /** ISO-8601 UTC de la imagen efectivamente devuelta. */
  time: string;
  cells: ChlaCell[];
  /** Celdas con observación válida. */
  observed: number;
  /** Celdas sin observación. */
  cloudy: number;
  /** Media de las celdas observadas. `null` si no hubo ninguna. */
  mean: number | null;
}

export interface ChlaQuery {
  /** Caja `[norte, sur, oeste, este]`. La latitud del producto es descendente. */
  north: number;
  south: number;
  west: number;
  east: number;
}

interface ErddapTable {
  table?: {
    columnNames?: string[];
    rows?: unknown[][];
  };
}

/**
 * Campo de clorofila más reciente sobre una caja.
 *
 * Usa el índice `[last]` de ERDDAP en vez de una fecha calculada: el producto no
 * publica todos los días y pedir una fecha concreta devuelve un error cuando esa
 * pasada no existe.
 */
export async function fetchLatestChla(query: ChlaQuery): Promise<SourceResult<ChlaField>> {
  // La latitud va de mayor a menor en este producto: el rango debe escribirse
  // norte:sur o ERDDAP devuelve una selección vacía sin quejarse.
  const selection =
    `chlor_a[last][(0.0)][(${query.north}):(${query.south})][(${query.west}):(${query.east})]`;
  const url = proxyUrl('erddap', `griddap/${DATASET}.json?${encodeURIComponent(selection)}`);

  const response = await fetchSource<ErddapTable>({
    sourceId: SOURCE_ID,
    label: 'ERDDAP clorofila VIIRS',
    url,
    timeoutMs: 90_000,
    snapshotFile: 'noaa-chla.json',
    parse: (raw) => {
      const payload = raw as ErddapTable;
      if (!payload.table?.rows) throw new Error('ERDDAP: respuesta sin tabla');
      if (payload.table.rows.length === 0) throw new Error('ERDDAP: la caja no intersecta el producto');
      return payload;
    },
  });

  return mapResult(response, toField);
}

function toField(payload: ErddapTable): ChlaField {
  const names = payload.table?.columnNames ?? [];
  const rows = payload.table?.rows ?? [];

  const at = (row: unknown[], column: string) => row[names.indexOf(column)];

  const cells: ChlaCell[] = rows.map((row) => {
    const value = at(row, 'chlor_a');
    return {
      lat: Number(at(row, 'latitude')),
      lon: Number(at(row, 'longitude')),
      value: value === null || value === undefined ? null : Number(value),
    };
  });

  const observedCells = cells.filter((cell) => cell.value !== null);
  const mean =
    observedCells.length === 0
      ? null
      : observedCells.reduce((sum, cell) => sum + (cell.value as number), 0) / observedCells.length;

  return {
    time: String(at(rows[0] ?? [], 'time') ?? ''),
    cells,
    observed: observedCells.length,
    cloudy: cells.length - observedCells.length,
    mean,
  };
}
