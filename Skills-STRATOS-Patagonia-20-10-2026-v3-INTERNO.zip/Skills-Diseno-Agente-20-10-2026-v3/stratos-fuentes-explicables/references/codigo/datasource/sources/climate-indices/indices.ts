// Índices climáticos: ONI, SOI, PDO y AAO.
//
// Son el contexto interanual del que cuelga cualquier anomalía local. Una
// temperatura de 11,5 °C en Reloncaví significa una cosa en un año Niño fuerte
// (ONI JJA 2026 = +1,80) y otra distinta en un año neutro.
//
// Los cuatro llegan como texto plano por el proxy: NOAA no emite CORS. Los
// formatos son de ancho fijo y de los años ochenta, así que cada uno lleva su
// parser y todos comparten el mismo contrato de salida.

import { fetchSource } from '../../core/fetchSource';
import { proxyUrl } from '../../core/env';
import { worstProvenance } from '../../core/provenance';
import { type SourceResult } from '../../core/types';
import { climateIndex as mockClimateIndex } from '../../mock/index';

import { parseMonthlyMatrix, parseOni, type IndexPoint, parseCpcSoi } from './parsers';

export type { IndexPoint } from './parsers';

const SOURCE_ID = 'climate-indices';

export type IndexCode = 'oni' | 'soi' | 'pdo' | 'aao';

export interface ClimateIndex {
  code: IndexCode;
  name: string;
  description: string;
  points: IndexPoint[];
  latest: IndexPoint | null;
}

const META: Record<IndexCode, { name: string; description: string }> = {
  oni: {
    name: 'ONI',
    description: 'Oceanic Niño Index: anomalía de TSM en Niño 3.4, media trimestral móvil.',
  },
  soi: {
    name: 'SOI',
    description: 'Southern Oscillation Index: gradiente de presión Tahití–Darwin.',
  },
  pdo: {
    name: 'PDO',
    description: 'Pacific Decadal Oscillation: modo decadal del Pacífico norte.',
  },
  aao: {
    name: 'AAO / SAM',
    description:
      'Antarctic Oscillation: el modo anular del sur, el que gobierna los vientos del oeste sobre los fiordos.',
  },
};

// Los parsers viven en `parsers.ts`: son puros y se prueban contra textos reales.

// ── Descarga ─────────────────────────────────────────────────────────────────

interface IndexSpec {
  proxyId: 'noaa-cpc' | 'noaa-psl' | 'noaa-ncei';
  path: string;
  parse: (text: string) => IndexPoint[];
}

const SPECS: Record<IndexCode, IndexSpec> = {
  oni: { proxyId: 'noaa-cpc', path: 'data/indices/oni.ascii.txt', parse: parseOni },
  // 11-10-2026: la PDO del PSL dejó de actualizarse en ago-2025 y su SOI va dos meses atrás.
  soi: { proxyId: 'noaa-cpc', path: 'data/indices/soi', parse: parseCpcSoi },
  pdo: { proxyId: 'noaa-ncei', path: 'pub/data/cmb/ersst/v5/index/ersst.v5.pdo.dat', parse: parseMonthlyMatrix },
  aao: {
    proxyId: 'noaa-cpc',
    path: 'products/precip/CWlink/daily_ao_index/aao/monthly.aao.index.b79.current.ascii.table',
    parse: parseMonthlyMatrix,
  },
};

export function fetchIndex(code: IndexCode): Promise<SourceResult<ClimateIndex>> {
  const spec = SPECS[code];
  return fetchSource<ClimateIndex>({
    sourceId: SOURCE_ID,
    label: `índice ${META[code].name}`,
    url: proxyUrl(spec.proxyId, spec.path),
    as: 'text',
    timeoutMs: 30_000,
    snapshotFile: `climate-index-${code}.json`,
    snapshotOnly: true,
    mock: () => mockClimateIndex(code),
    parse: (raw) => {
      const points = spec.parse(String(raw));
      // Un parser que devuelve cero puntos sobre un archivo que sí llegó es un
      // cambio de formato del proveedor, no una serie vacía: debe fallar alto.
      if (points.length < 12) {
        throw new Error(`${code}: sólo ${points.length} valores; el formato cambió`);
      }
      points.sort((a, b) => a.month.localeCompare(b.month));
      return {
        code,
        name: META[code].name,
        description: META[code].description,
        points,
        latest: points[points.length - 1] ?? null,
      };
    },
  });
}

/** Los cuatro índices en paralelo. El estado del bloque es el peor de los cuatro. */
export async function fetchAllIndices(): Promise<SourceResult<Record<IndexCode, ClimateIndex>>> {
  const codes: IndexCode[] = ['oni', 'soi', 'pdo', 'aao'];
  const results = await Promise.all(codes.map((code) => fetchIndex(code)));

  const data = {} as Record<IndexCode, ClimateIndex>;
  results.forEach((result, position) => {
    if (result.data) data[codes[position]] = result.data;
  });

  const found = Object.keys(data).length;
  return {
    state: found === 0 ? 'missing' : worstProvenance(results.map((result) => result.state)),
    data: found === 0 ? null : data,
    meta: {
      sourceId: SOURCE_ID,
      fetchedAt: new Date().toISOString(),
      ageMs: 0,
      note: `${found} de ${codes.length} índices`,
    },
  };
}
