// Lectura de los textos de índices climáticos de NOAA (CPC y PSL).
//
// Funciones puras, sin red ni dependencias: se separan de `indices.ts` para que
// el runner de pruebas de Node pueda ejercitarlas contra textos reales del
// proveedor. El error que motivó separarlas —los meses faltantes de la PDO
// leídos como valor -9.9— sólo se ve con el texto real delante.

export interface IndexPoint {
  /** `YYYY-MM` del mes al que corresponde el valor. */
  month: string;
  value: number;
}

/**
 * Centinelas de dato ausente. NO hay uno solo: cada serie del PSL declara el
 * suyo en la línea que sigue a la matriz —la SOI usa -99.99 y la PDO -9.90—. Con
 * un único -99.99 los meses faltantes de la PDO entraban como valores, y el
 * «último valor» mostrado era -9.9 (detectado por validation/validate_app.py,
 * regla R4, el 18-09-2026). Se lee el declarado y, además, se descartan los
 * centinelas conocidos por si un archivo no lo declara.
 */
// 99.99 positivo: el centinela de la PDO de NCEI (ERSSTv5), fuente desde el 11-10-2026.
const KNOWN_MISSING = [-99.99, 99.99, -9.9, -999, -999.9, -9999];

/** Centinela que declara el propio archivo tras la última fila de datos, si lo hay. */
function declaredMissing(lines: string[]): number | null {
  let lastRow = -1;
  lines.forEach((line, index) => {
    if (/^\s*(19|20)\d{2}\s/.test(line)) lastRow = index;
  });
  const next = lines[lastRow + 1]?.trim();
  return next && /^-?\d+(\.\d+)?$/.test(next) ? Number(next) : null;
}

export function isMissingValue(value: number, declared: number | null): boolean {
  if (declared !== null && Math.abs(value - declared) < 0.001) return true;
  return KNOWN_MISSING.some((sentinel) => Math.abs(value - sentinel) < 0.001);
}

/**
 * Formato CPC del ONI: `SEAS YR TOTAL ANOM`, una fila por trimestre móvil.
 * La estación se ancla a su mes central —DJF a enero, JFM a febrero— que es la
 * convención del propio CPC.
 */
const SEASON_CENTER: Record<string, number> = {
  DJF: 1, JFM: 2, FMA: 3, MAM: 4, AMJ: 5, MJJ: 6,
  JJA: 7, JAS: 8, ASO: 9, SON: 10, OND: 11, NDJ: 12,
};

export function parseOni(text: string): IndexPoint[] {
  const points: IndexPoint[] = [];
  for (const line of text.split(/\r?\n/).slice(1)) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 4) continue;
    const month = SEASON_CENTER[parts[0]];
    const year = Number(parts[1]);
    const value = Number(parts[3]);
    if (!month || !Number.isFinite(year) || !Number.isFinite(value)) continue;
    points.push({ month: `${year}-${String(month).padStart(2, '0')}`, value });
  }
  return points;
}

/**
 * Formato matricial: una fila por año con doce columnas mensuales.
 *
 * Lo usan tanto las series del PSL (SOI, PDO) como la tabla del CPC (AAO). Las
 * dos primeras variantes abren con una línea de rango de años y cierran con
 * líneas de procedencia en prosa; la del CPC abre con los nombres de los meses.
 * En los tres casos sólo son filas válidas las que empiezan por un año de cuatro
 * dígitos, así que la cabecera y el pie se descartan por construcción.
 */
export function parseMonthlyMatrix(text: string): IndexPoint[] {
  const points: IndexPoint[] = [];
  const lines = text.split(/\r?\n/);
  const declared = declaredMissing(lines);
  for (const line of lines) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 2) continue;
    if (!/^(19|20)\d{2}$/.test(parts[0])) continue;
    /*
     * La cabecera del PSL es «desde hasta» —`1948 2026`— y empieza por un año
     * igual que una fila de datos. Leída como fila metía «enero de 1948 = 2026»
     * en la SOI y la PDO (detectado por la prueba de rangos contra el texto real,
     * 18-09-2026). Una fila de datos nunca tiene un año de cuatro cifras como
     * primer valor mensual.
     */
    if (parts.length === 2 && /^(19|20)\d{2}$/.test(parts[1])) continue;

    const year = Number(parts[0]);
    parts.slice(1, 13).forEach((raw, index) => {
      const value = Number(raw);
      if (!Number.isFinite(value) || isMissingValue(value, declared)) return;
      points.push({ month: `${year}-${String(index + 1).padStart(2, '0')}`, value });
    });
  }
  return points;
}

/**
 * SOI del CPC (`data/indices/soi`). Desde el 11-10-2026 reemplaza a la copia del
 * PSL, que publica con dos meses de atraso (mismos valores donde coinciden).
 *
 * El archivo trae dos tablas, anomalía y estandarizada; se lee sólo la primera,
 * la misma serie que publicaba el PSL. Sus columnas son de ancho fijo (año de 4
 * y meses de 6 caracteres) y un valor negativo puede quedar pegado al centinela
 * (`-3.3-999.9`): por eso se corta por posición, no por espacios.
 */
export function parseCpcSoi(text: string): IndexPoint[] {
  const points: IndexPoint[] = [];
  for (const line of text.split(/\r?\n/)) {
    if (/STANDARDIZED/i.test(line)) break;
    if (!/^(19|20)\d{2}\s/.test(line)) continue;
    const year = Number(line.slice(0, 4));
    for (let month = 0; month < 12; month += 1) {
      const value = Number(line.slice(4 + month * 6, 10 + month * 6));
      if (!Number.isFinite(value) || line.slice(4 + month * 6, 10 + month * 6).trim() === '' || isMissingValue(value, null)) continue;
      points.push({ month: `${year}-${String(month + 1).padStart(2, '0')}`, value });
    }
  }
  return points;
}
