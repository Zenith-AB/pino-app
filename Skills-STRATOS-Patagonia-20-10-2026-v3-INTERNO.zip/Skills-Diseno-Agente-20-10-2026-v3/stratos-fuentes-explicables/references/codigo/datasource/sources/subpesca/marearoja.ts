// SUBPESCA — programa de monitoreo de marea roja, servido como ArcGIS MapServer.
//
// Lo que publica no son áreas de restricción, pese al nombre del servicio: son
// las estaciones de cada crucero con la abundancia relativa por taxón, la misma
// nomenclatura `AR*` que usa IFOP. Comprobado el 2026-09-16 sobre las dos capas
// del servicio.
//
// Es la contraparte de SERNAPESCA/SUBPESCA al registro de IFOP: distinto
// organismo, distinta grilla de estaciones, mismo fenómeno. Tenerlas por
// separado permite contrastarlas en vez de promediarlas.

import { fetchSource } from '../../core/fetchSource';
import { proxyUrl } from '../../core/env';
import { worstProvenance } from '../../core/provenance';
import { type SourceResult } from '../../core/types';

const SOURCE_ID = 'subpesca-marearoja';

const SERVICE = 'server/rest/services/IDE_PUBLICO/SRMPUB_MAREAROJA/MapServer';

/** Campos `AR<taxón>` del proveedor → nombres canónicos. */
const TAXA: Record<string, keyof RedTideStation['taxa']> = {
  ARALEXCATE: 'alexandriumCatenella',
  ARALEXOSTE: 'alexandriumOstenfeldii',
  ARDINOACUM: 'dinophysisAcuminata',
  ARDINOACUT: 'dinophysisAcuta',
  ARPROTRETI: 'protoceratiumReticulatum',
  ARPSEUAUST: 'pseudoNitzschiaAustralis',
  ARPSEUPSEU: 'pseudoNitzschiaPseudodelicatissima',
};

export interface RedTideLayer {
  id: number;
  /** Nombre del crucero tal como lo publica SUBPESCA. */
  name: string;
}

export interface RedTideStation {
  layerId: number;
  layerName: string;
  stationId: string;
  cruise: string;
  program: number;
  regionCode: number;
  /** ISO-8601 del muestreo. El proveedor lo emite como epoch en milisegundos. */
  sampledAt: string;
  lat: number | null;
  lon: number | null;
  taxa: {
    alexandriumCatenella: number | null;
    alexandriumOstenfeldii: number | null;
    dinophysisAcuminata: number | null;
    dinophysisAcuta: number | null;
    protoceratiumReticulatum: number | null;
    pseudoNitzschiaAustralis: number | null;
    pseudoNitzschiaPseudodelicatissima: number | null;
  };
}

function numberOrNull(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/** Catálogo de capas del servicio: un crucero por capa. */
export function fetchLayers(): Promise<SourceResult<RedTideLayer[]>> {
  return fetchSource<RedTideLayer[]>({
    sourceId: SOURCE_ID,
    label: 'SUBPESCA capas',
    url: proxyUrl('subpesca', `${SERVICE}?f=json`),
    timeoutMs: 30_000,
    parse: (raw) => {
      const payload = raw as { layers?: { id: number; name: string }[] };
      if (!Array.isArray(payload.layers)) throw new Error('el MapServer no declaró capas');
      return payload.layers.map((layer) => ({ id: layer.id, name: layer.name }));
    },
  });
}

export interface StationQuery {
  layerId: number;
  layerName?: string;
  /** Máximo de estaciones. ArcGIS lo acota además por su propio tope de servicio. */
  count?: number;
  /** Ordena del muestreo más reciente hacia atrás. */
  newestFirst?: boolean;
}

export function fetchStations(query: StationQuery): Promise<SourceResult<RedTideStation[]>> {
  const params = new URLSearchParams({
    where: '1=1',
    outFields: '*',
    f: 'json',
    returnGeometry: 'true',
    outSR: '4326',
    resultRecordCount: String(Math.min(query.count ?? 500, 2000)),
  });
  if (query.newestFirst) params.set('orderByFields', 'F_MUESTREO DESC');

  return fetchSource<RedTideStation[]>({
    sourceId: SOURCE_ID,
    label: `SUBPESCA capa ${query.layerId}`,
    url: proxyUrl('subpesca', `${SERVICE}/${query.layerId}/query?${params}`),
    timeoutMs: 60_000,
    parse: (raw) => {
      const payload = raw as {
        error?: { message?: string };
        features?: { attributes?: Record<string, unknown>; geometry?: { x?: number; y?: number } }[];
      };
      // ArcGIS informa de sus errores dentro de un HTTP 200; sin esto, un fallo
      // del servicio se leería como "este crucero no tiene estaciones".
      if (payload.error) throw new Error(`ArcGIS: ${payload.error.message ?? 'error sin mensaje'}`);
      if (!Array.isArray(payload.features)) throw new Error('respuesta sin arreglo "features"');

      return payload.features.map((feature) => {
        const attributes = feature.attributes ?? {};
        const taxa = {} as RedTideStation['taxa'];
        for (const [provider, canonical] of Object.entries(TAXA)) {
          taxa[canonical] = numberOrNull(attributes[provider]);
        }
        const epoch = numberOrNull(attributes.F_MUESTREO);
        return {
          layerId: query.layerId,
          layerName: query.layerName ?? '',
          stationId: String(attributes.ESTACIONID ?? ''),
          cruise: String(attributes.CRUCERO ?? ''),
          program: Number(attributes.PROGRAMA ?? 0),
          regionCode: Number(attributes.C_REGION ?? 0),
          sampledAt: epoch === null ? '' : new Date(epoch).toISOString(),
          lat: feature.geometry?.y ?? null,
          lon: feature.geometry?.x ?? null,
          taxa,
        };
      });
    },
  });
}

/** Todas las capas del servicio con sus estaciones más recientes. */
export async function fetchAllStations(countPerLayer = 500): Promise<SourceResult<RedTideStation[]>> {
  const layers = await fetchLayers();
  if (!layers.data) return { ...layers, data: null } as SourceResult<RedTideStation[]>;

  const results = await Promise.all(
    layers.data.map((layer) =>
      fetchStations({
        layerId: layer.id,
        layerName: layer.name,
        count: countPerLayer,
        newestFirst: true,
      }),
    ),
  );

  const stations = results.flatMap((result) => result.data ?? []);
  return {
    state: stations.length === 0 ? 'missing' : worstProvenance(results.map((r) => r.state)),
    data: stations.length === 0 ? null : stations,
    meta: {
      sourceId: SOURCE_ID,
      fetchedAt: new Date().toISOString(),
      ageMs: 0,
      note: `${stations.length} estaciones en ${layers.data.length} cruceros`,
    },
  };
}
