// IFOP WebSIG — serie histórica de abundancia relativa de especies FAN en los
// fiordos, con el contexto ambiental de la misma estación y muestreo.
//
// Es la única de las fuentes principales que el navegador alcanza directamente:
// el GeoServer emite `Access-Control-Allow-Origin: *` (comprobado el 2026-09-16).
// Aun así el proxy la tiene declarada como respaldo.
//
// Alcance real de la capa, medido: 21.102 registros geolocalizados cuya última
// muestra es del 28-06-2022. **No es una fuente en vivo**: es el registro
// histórico contra el que se contrastan las observaciones de hoy. Confundir una
// cosa con otra haría que el panel pareciera actualizado cuando no lo está.

import { fetchSource } from '../../core/fetchSource';
import { type SourceResult } from '../../core/types';

const SOURCE_ID = 'ifop-websig';

const ENDPOINT = 'https://sig-acuicultura.ifop.cl/geoserver/ows';
export const LAYER = 'MRF_2024:AR_FIORDOS_HISTO_TEST';

/**
 * Tope de features por petición. Si la respuesta lo alcanza, la capa viene
 * truncada y eso se trata como error: una serie cortada en silencio es peor que
 * ninguna serie.
 */
const MAX_FEATURES = 10_000;

/** Nombres del proveedor → nombres canónicos de STRATOS. */
const RENAMES: Record<string, keyof IfopObservation['values']> = {
  PROFUNDIDAD_5: 'depthM',
  TEMPERATURA_5: 'temperature5mC',
  CLOROFILA_5: 'chlorophyll5m',
  SALINIDAD_5: 'salinity5mPsu',
  OXIGENO_5: 'oxygen5mMlL',
};

/** Abundancia relativa por taxón. `AR` en la nomenclatura de IFOP. */
const TAXA: Record<string, keyof IfopObservation['taxa']> = {
  ACATENELLA: 'alexandriumCatenella',
  AOSTENFELDII: 'alexandriumOstenfeldii',
  DACUMINATA: 'dinophysisAcuminata',
  DACUTA: 'dinophysisAcuta',
  PRETICULATUM: 'protoceratiumReticulatum',
  GPSERIATA: 'pseudoNitzschiaSeriata',
  GPDELICATISSIMA: 'pseudoNitzschiaDelicatissima',
};

export interface IfopObservation {
  stationCode: string;
  stationName: string;
  sector: string;
  region: string;
  subprogram: string;
  /** ISO-8601 de la fecha de muestreo. */
  sampledAt: string;
  lat: number;
  lon: number;
  values: {
    depthM: number | null;
    temperature5mC: number | null;
    chlorophyll5m: number | null;
    salinity5mPsu: number | null;
    oxygen5mMlL: number | null;
  };
  taxa: {
    alexandriumCatenella: number | null;
    alexandriumOstenfeldii: number | null;
    dinophysisAcuminata: number | null;
    dinophysisAcuta: number | null;
    protoceratiumReticulatum: number | null;
    pseudoNitzschiaSeriata: number | null;
    pseudoNitzschiaDelicatissima: number | null;
  };
}

export interface IfopQuery {
  /** Máximo de registros a traer. */
  count?: number;
  /** Caja geográfica `[oeste, sur, este, norte]` en grados. */
  bbox?: [number, number, number, number];
  /** Filtra por año de muestreo. */
  year?: number;
  /** `true` para leer del final de la serie hacia atrás. */
  newestFirst?: boolean;
}

function numberOrNull(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/** `28-06-2022` → `2022-06-28`. El proveedor escribe la fecha en formato chileno. */
function toIsoDate(value: unknown): string {
  const text = String(value ?? '');
  const match = /^(\d{1,2})-(\d{1,2})-(\d{4})$/.exec(text);
  if (!match) return text;
  const [, day, month, year] = match;
  return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
}

export function fetchObservations(query: IfopQuery = {}): Promise<SourceResult<IfopObservation[]>> {
  const count = Math.min(query.count ?? 500, MAX_FEATURES);
  const params = new URLSearchParams({
    service: 'WFS',
    version: '2.0.0',
    request: 'GetFeature',
    typeNames: LAYER,
    outputFormat: 'application/json',
    count: String(count),
    srsName: 'EPSG:4326',
  });
  if (query.bbox) params.set('bbox', `${query.bbox.join(',')},EPSG:4326`);
  if (query.year) params.set('cql_filter', `ANNO=${query.year}`);
  if (query.newestFirst) params.set('sortBy', 'ANNO+D');

  return fetchSource<IfopObservation[]>({
    sourceId: SOURCE_ID,
    label: 'IFOP WebSIG',
    url: `${ENDPOINT}?${params}`,
    timeoutMs: 60_000,
    snapshotFile: 'ifop-websig.json',
    parse: (raw) => {
      const geo = raw as {
        features?: {
          geometry?: { coordinates?: [number, number] };
          properties?: Record<string, unknown>;
        }[];
      };
      if (!Array.isArray(geo.features)) throw new Error('WFS: respuesta sin arreglo "features"');
      // Devolver exactamente `count` filas es paginación normal, no un problema.
      // Lo que sí lo es: haber chocado con el tope duro de esta capa, porque a
      // partir de ahí el recorte deja de ser el que se pidió y pasa a ser el que
      // el cliente aguanta, sin que nada lo diga.
      if (geo.features.length >= MAX_FEATURES) {
        throw new Error(
          `WFS: se alcanzó el tope duro de ${MAX_FEATURES} features; el recorte sería arbitrario`,
        );
      }

      return geo.features.map((feature) => {
        const properties = feature.properties ?? {};
        const [lon, lat] = feature.geometry?.coordinates ?? [NaN, NaN];

        const values = {} as IfopObservation['values'];
        for (const [provider, canonical] of Object.entries(RENAMES)) {
          values[canonical] = numberOrNull(properties[provider]);
        }

        const taxa = {} as IfopObservation['taxa'];
        for (const [provider, canonical] of Object.entries(TAXA)) {
          taxa[canonical] = numberOrNull(properties[provider]);
        }

        return {
          stationCode: String(properties.COD_ESTACION ?? ''),
          stationName: String(properties.NOMESTACION ?? ''),
          sector: String(properties.NOMSECTOR ?? ''),
          region: String(properties.NOMREGION ?? ''),
          subprogram: String(properties.NOMSUBPROGRAMA ?? ''),
          sampledAt: toIsoDate(properties.FECHA_MUESTREO),
          lat,
          lon,
          values,
          taxa,
        };
      });
    },
  });
}
