// CHONOS5 / MOSA — pronóstico acoplado CROCO (océano) + WRF (atmósfera) de IFOP
// para los fiordos, vía el proxy `/ds/chonos` porque el handshake TLS falla
// contra el almacén de certificados local.
//
// La API es pública pero no está documentada. El recorrido, verificado el
// 2026-09-16, son cuatro pasos encadenados:
//
//   1. GET mosa_domains_geojson        → dominios disponibles (`mosa_chiloe_1km_20260914`)
//   2. GET data_visor/<dominio>        → HTML del visor; de ahí se extraen los
//                                        códigos de dataset marcados `t0:"_latest"`
//   3. GET variables?options={...}     → qué variables trae cada dataset
//   4. GET series?options={...}        → la serie en un punto: [[epochMs, valor], …]
//
// MOSA no es histórico y no debe tratarse como tal: cada fila es un pronóstico
// con hora de emisión (la fecha del código del dataset) y un lead. Eso viaja en
// el resultado, no se pierde por el camino.

import { fetchSource } from '../../core/fetchSource';
import { proxyUrl } from '../../core/env';
import { type SourceResult } from '../../core/types';

const SOURCE_ID = 'chonos-mosa';

/** Nombres canónicos STRATOS de las variables de cada modelo. */
export const CHONOS_VARIABLES = {
  croco: {
    temp: 'waterTempC',
    salt: 'salinityPsu',
    uvel: 'currentUMs',
    vvel: 'currentVMs',
    zeta: 'seaLevelM',
  },
  wrf: {
    t2: 'airTemp2mC',
    uvel10: 'windU10mMs',
    vvel10: 'windV10mMs',
    precip: 'precipAccum',
    prate: 'precipRate',
    SWDOWN: 'shortwaveDown',
  },
} as const;

type Model = keyof typeof CHONOS_VARIABLES;
export type MosaField =
  | (typeof CHONOS_VARIABLES.croco)[keyof typeof CHONOS_VARIABLES.croco]
  | (typeof CHONOS_VARIABLES.wrf)[keyof typeof CHONOS_VARIABLES.wrf];

export interface MosaPoint {
  zoneId: string;
  lat: number;
  lon: number;
}

export interface MosaStep {
  /** ISO-8601 UTC del instante pronosticado. */
  validTime: string;
  /** Horas desde la emisión de la corrida. */
  leadHours: number;
  values: Partial<Record<MosaField, number | null>>;
}

export interface MosaForecast {
  zoneId: string;
  lat: number;
  lon: number;
  /** Dominio del que salió, con su fecha de corrida (`mosa_chiloe_1km_20260914`). */
  domain: string;
  /** ISO-8601 UTC de emisión de la corrida, leída del código del dataset. */
  issuedAt: string;
  datasets: string[];
  steps: MosaStep[];
}

/** El código del dataset termina en la fecha de la corrida: `..._20260914`. */
function issueTimeOf(datasetCode: string): string {
  const match = /(20\d{6})$/.exec(datasetCode);
  if (!match) throw new Error(`dataset CHONOS sin identificador de corrida: ${datasetCode}`);
  const stamp = match[1];
  return `${stamp.slice(0, 4)}-${stamp.slice(4, 6)}-${stamp.slice(6, 8)}T00:00:00.000Z`;
}

function optionsUrl(path: string, options: unknown): string {
  return proxyUrl('chonos', `${path}?options=${encodeURIComponent(JSON.stringify(options))}`);
}

// ── Paso 1: dominios ─────────────────────────────────────────────────────────

/** Dominios MOSA publicados. El nombre lleva la resolución y la fecha de corrida. */
export function fetchDomains(): Promise<SourceResult<string[]>> {
  return fetchSource<string[]>({
    sourceId: SOURCE_ID,
    label: 'CHONOS dominios',
    url: proxyUrl('chonos', 'mosa_domains_geojson'),
    timeoutMs: 45_000,
    parse: (raw) => {
      const geo = raw as { features?: { properties?: { id?: string } }[] };
      const ids = (geo.features ?? [])
        .map((feature) => feature.properties?.id)
        .filter((id): id is string => typeof id === 'string');
      if (ids.length === 0) throw new Error('mosa_domains_geojson sin dominios');
      return ids;
    },
  });
}

// ── Paso 2: datasets de la corrida más reciente ──────────────────────────────

/**
 * Códigos de dataset de la última corrida del dominio.
 *
 * Salen del HTML del visor porque la API no publica un índice: es frágil por
 * construcción, así que un HTML sin coincidencias se trata como error y la
 * cascada degrada, en vez de devolver una lista vacía que parecería "sin datos".
 */
export function fetchLatestDatasets(domain: string): Promise<SourceResult<string[]>> {
  return fetchSource<string[]>({
    sourceId: SOURCE_ID,
    label: `CHONOS datasets ${domain}`,
    url: proxyUrl('chonos', `data_visor/${domain}`),
    as: 'text',
    timeoutMs: 45_000,
    parse: (raw) => {
      const html = String(raw);
      const codes = [...html.matchAll(/\{code:"([^"]+)",\s*t0:"_latest"\}/g)].map((m) => m[1]);
      if (codes.length === 0) {
        throw new Error(`el visor de ${domain} no declara datasets _latest`);
      }
      return codes;
    },
  });
}

// ── Paso 3: variables disponibles por dataset ────────────────────────────────

export type DatasetVariables = Record<string, string[]>;

export function fetchDatasetVariables(datasets: string[]): Promise<SourceResult<DatasetVariables>> {
  const options = { datasets: datasets.map((code) => ({ code, t0: '_latest' })) };
  return fetchSource<DatasetVariables>({
    sourceId: SOURCE_ID,
    label: 'CHONOS variables',
    url: optionsUrl('variables', options),
    timeoutMs: 45_000,
    parse: (raw) => {
      const payload = raw as { variables?: Record<string, { code: string }[]> };
      if (!payload.variables) throw new Error('respuesta de variables sin campo "variables"');
      const out: DatasetVariables = {};
      for (const [dataset, list] of Object.entries(payload.variables)) {
        out[dataset] = list.map((item) => item.code);
      }
      return out;
    },
  });
}

// ── Paso 4: serie en un punto ────────────────────────────────────────────────

interface SeriesResponse {
  series?: { variable: string; data: [number, number][] }[];
}

function fetchSeries(
  dataset: string,
  variables: string[],
  point: MosaPoint,
  model: Model,
): Promise<SourceResult<SeriesResponse>> {
  const options = {
    variables: variables.map((variable) => `${dataset}:${variable}`),
    depth: -1,
    // WRF entrega a 2 m sobre el suelo; CROCO usa -1 para la capa superficial.
    height: model === 'wrf' ? 2 : -1,
    lon: point.lon,
    lat: point.lat,
  };
  return fetchSource<SeriesResponse>({
    sourceId: SOURCE_ID,
    label: `CHONOS series ${point.zoneId}/${model}`,
    url: optionsUrl('series', options),
    timeoutMs: 90_000,
    parse: (raw) => {
      const payload = raw as SeriesResponse;
      if (!Array.isArray(payload.series)) throw new Error('respuesta de series sin arreglo "series"');
      return payload;
    },
  });
}

/**
 * Pronóstico MOSA completo en un punto: CROCO y WRF unidos por instante válido.
 *
 * `domainPattern` selecciona la malla (`mosa_chiloe`, `mosa_magallanes`). Si no
 * hay dominio que case, es un error explícito y no un pronóstico vacío.
 */
export async function fetchPointForecast(
  point: MosaPoint,
  domainPattern = 'mosa_chiloe',
): Promise<SourceResult<MosaForecast>> {
  const domains = await fetchDomains();
  const domain = (domains.data ?? []).find((id) => id.includes(domainPattern));
  if (!domain) {
    return {
      state: 'missing',
      data: null,
      meta: {
        sourceId: SOURCE_ID,
        fetchedAt: new Date().toISOString(),
        ageMs: null,
        note: `ningún dominio MOSA coincide con "${domainPattern}"`,
      },
    };
  }

  const datasets = await fetchLatestDatasets(domain);
  const codes = datasets.data ?? [];
  const available = await fetchDatasetVariables(codes);

  const steps = new Map<number, MosaStep>();
  const used: string[] = [];

  for (const model of Object.keys(CHONOS_VARIABLES) as Model[]) {
    const dataset = codes.find((code) => code.startsWith(`${model}_`));
    if (!dataset) continue;

    const mapping = CHONOS_VARIABLES[model] as Record<string, MosaField>;
    const present = available.data?.[dataset] ?? Object.keys(mapping);
    const wanted = Object.keys(mapping).filter((code) => present.includes(code));
    if (wanted.length === 0) continue;

    const series = await fetchSeries(dataset, wanted, point, model);
    if (!series.data) continue;
    used.push(dataset);

    const issuedAtMs = Date.parse(issueTimeOf(dataset));
    for (const entry of series.data.series ?? []) {
      const field = mapping[entry.variable];
      if (!field) continue;
      for (const [epochMs, value] of entry.data) {
        const step = steps.get(epochMs) ?? {
          validTime: new Date(epochMs).toISOString(),
          leadHours: Math.round((epochMs - issuedAtMs) / 3_600_000),
          values: {},
        };
        step.values[field] = Number.isFinite(value) ? value : null;
        steps.set(epochMs, step);
      }
    }
  }

  if (steps.size === 0 || used.length === 0) {
    return {
      state: 'missing',
      data: null,
      meta: {
        sourceId: SOURCE_ID,
        fetchedAt: new Date().toISOString(),
        ageMs: null,
        note: `MOSA no devolvió series para ${point.zoneId}`,
      },
    };
  }

  const ordered = [...steps.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([, step]) => maskLandCells(step));

  return {
    state: datasets.state === 'live' && domains.state === 'live' ? 'live' : datasets.state,
    data: {
      zoneId: point.zoneId,
      lat: point.lat,
      lon: point.lon,
      domain,
      issuedAt: issueTimeOf(used[0]),
      datasets: used,
      steps: ordered,
    },
    meta: {
      sourceId: SOURCE_ID,
      fetchedAt: new Date().toISOString(),
      ageMs: 0,
      runId: used.join('+'),
      note: `${ordered.length} pasos · dominio ${domain}`,
    },
  };
}

/**
 * CROCO rellena las celdas de tierra con valores cercanos a cero. Sin esta
 * máscara, una interpolación sobre tierra entra al panel disfrazada de agua fría
 * y dulce —justo la firma que STRATOS busca— y contamina la señal.
 *
 * La fila de WRF se conserva: el viento y la radiación sobre esa celda sí valen.
 */
function maskLandCells(step: MosaStep): MosaStep {
  const salinity = step.values.salinityPsu;
  if (salinity === null || salinity === undefined || salinity > 1) return step;

  const ocean = Object.values(CHONOS_VARIABLES.croco) as MosaField[];
  const values = { ...step.values };
  for (const field of ocean) values[field] = null;
  return { ...step, values };
}
