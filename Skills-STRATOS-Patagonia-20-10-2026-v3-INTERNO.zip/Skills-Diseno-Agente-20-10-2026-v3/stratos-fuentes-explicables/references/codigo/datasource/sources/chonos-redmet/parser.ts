export interface RedmetReading {
  code: string;
  name: string;
  unit: string;
  value: number;
  observedAt: string;
  availableAt: string;
  qc: 'not_provided';
  points: { time: number; value: number }[];
}

export interface RedmetStation {
  id: number;
  name: string;
  opcode: string;
  lat: number;
  lon: number;
  start: string | null;
  end: string | null;
  variables: string[];
  variableCoverage?: { code: string; end: string | null }[];
  readings?: RedmetReading[];
  capturedAt?: string;
  versionId?: string;
}

/** Only dated numeric observations establish freshness; catalog coverage never does. */
export function recentRedmetReadings(station: RedmetStation, now = Date.now()): RedmetReading[] {
  return (station.readings ?? []).filter(reading => {
    const age = now - Date.parse(reading.observedAt);
    return Number.isFinite(age) && age >= 0 && age <= 48 * 3_600_000 && Number.isFinite(reading.value);
  });
}

export function parseRedmetSnapshot(raw: unknown): RedmetStation[] {
  const payload = raw as { version?: number; capturedAt?: string; versionId?: string; stations?: unknown[]; readings?: Record<string, RedmetReading[]> };
  if (payload?.version !== 1 || !Array.isArray(payload.stations) || !payload.readings || !Number.isFinite(Date.parse(payload.capturedAt ?? ''))) {
    throw new Error('Captura meteorológica inválida');
  }
  return parseRedmetStations([payload.stations]).map(station => ({ ...station,
    readings: (payload.readings?.[String(station.id)] ?? []).filter(reading =>
      typeof reading.value === 'number' && Number.isFinite(reading.value) &&
      Number.isFinite(Date.parse(reading.observedAt)) && Array.isArray(reading.points)),
    capturedAt: payload.capturedAt, versionId: payload.versionId,
  }));
}

/** Parser público para fijar el contrato de la API POST de REDMET. */
export function parseRedmetStations(raw: unknown): RedmetStation[] {
  const envelope = raw as unknown[];
  const rows = Array.isArray(envelope?.[0]) ? envelope[0] as Record<string, unknown>[] : [];
  return rows
    .map((row) => ({
      id: Number(row.id),
      name: String(row.name ?? row.opcode ?? ''),
      opcode: String(row.opcode ?? ''),
      lat: Number(row.lat),
      lon: Number(row.lon),
      start: row.start ? String(row.start) : null,
      end: row.end ? String(row.end) : null,
      variables: Array.isArray(row.vars) ? row.vars.map(String) : [],
      variableCoverage: Array.isArray(row.vtable) ? row.vtable.map((item: Record<string, unknown>) =>
        ({ code: String(item.code), end: item.end ? String(item.end) : null })) : [],
    }))
    // La API conserva una estación de prueba en 0,0: no tiene ubicación utilizable.
    .filter((station) =>
      Number.isFinite(station.id) &&
      station.name.length > 0 &&
      Number.isFinite(station.lat) &&
      Number.isFinite(station.lon) &&
      (station.lat !== 0 || station.lon !== 0),
    );
}
