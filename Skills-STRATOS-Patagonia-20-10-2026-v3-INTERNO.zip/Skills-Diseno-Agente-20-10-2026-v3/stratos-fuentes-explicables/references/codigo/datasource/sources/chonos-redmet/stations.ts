import { fetchSource } from '../../core/fetchSource.ts';
import type { SourceResult } from '../../core/types.ts';
import { parseRedmetSnapshot, type RedmetStation } from './parser.ts';

export { parseRedmetStations, recentRedmetReadings } from './parser.ts';
export type { RedmetStation, RedmetReading } from './parser.ts';

const SOURCE_ID = 'chonos-redmet';

export function fetchStations(): Promise<SourceResult<RedmetStation[]>> {
  return fetchSource({
    sourceId: SOURCE_ID,
    label: 'CHONOS REDMET observaciones',
    url: '', snapshotOnly: true, snapshotFile: 'redmet-live.json',
    cacheKey: 'chonos-redmet:observations-v1',
    parse: parseRedmetSnapshot,
  });
}
