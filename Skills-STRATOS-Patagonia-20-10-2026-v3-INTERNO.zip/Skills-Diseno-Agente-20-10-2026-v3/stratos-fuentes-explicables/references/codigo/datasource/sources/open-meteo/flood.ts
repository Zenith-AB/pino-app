// Caudal de ríos — Open-Meteo Flood API sobre GloFAS v4 (Copernicus EMS).
//
// Por qué no la DGA: su portal es público pero no expone una API JSON estable
// (verificado en la auditoría de STRATOS-Architecture), y el producto de CR2 con
// caudales diarios es un ZIP nacional cuya serie termina en 2018. Ninguno de los
// dos sirve para decir cuál es el caudal de esta semana.
//
// GloFAS sí: caudal diario modelado, con 31 días de historia y 7 de pronóstico,
// sin credenciales y con `Access-Control-Allow-Origin: *`, así que el navegador
// llega directo. Es un modelo global, no un aforo: la cifra es una estimación de
// descarga y la tarjeta lo declara como tal.
//
// El caudal importa aquí porque gobierna la entrada de agua dulce al estuario, y
// con ella la estratificación que retiene el fitoplancton en superficie. Un
// caudal en descenso sostenido es una de las condiciones que preceden a una
// floración en el mar interior.

import { fetchSource } from '../../core/fetchSource';
import { mapResult, type SourceResult } from '../../core/types';

const SOURCE_ID = 'open-meteo-flood';
const ENDPOINT = 'https://flood-api.open-meteo.com/v1/flood';

export interface RiverPoint {
  /** Fecha ISO del día. */
  date: string;
  /** Descarga en m³/s. `null` cuando el modelo no resolvió ese día. */
  value: number | null;
  /** `true` si el día es posterior a hoy: pronóstico, no historia. */
  forecast: boolean;
}

export interface RiverDischarge {
  riverName: string;
  lat: number;
  lon: number;
  unit: string;
  /** Historia y pronóstico en una sola serie, cada punto etiquetado. */
  points: RiverPoint[];
  /** Último día observado (no pronóstico) con valor. */
  latest: RiverPoint | null;
  /** Variación porcentual frente a hace siete días. `null` si falta alguno. */
  weeklyChangePct: number | null;
}

export interface RiverQuery {
  riverName: string;
  lat: number;
  lon: number;
  /** Días de historia. */
  pastDays?: number;
  /** Días de pronóstico. */
  forecastDays?: number;
}

/**
 * Punto GloFAS del cauce principal del Río Puelo.
 *
 * Elegido barriendo la malla del modelo alrededor de la desembocadura: las
 * celdas cercanas a la boca dan ~14 m³/s y la del cauce principal ~218 m³/s. La
 * diferencia es de un orden de magnitud, así que tomar "el punto más cercano a
 * la desembocadura" habría medido un tributario y lo habría llamado Puelo.
 */
export const RIO_PUELO: RiverQuery = {
  riverName: 'Río Puelo',
  lat: -41.675,
  lon: -72.175,
};

/**
 * Punto GloFAS del cauce del Río Petrohué, el segundo aporte de agua dulce del
 * sistema Reloncaví. Elegido con el mismo barrido que el Puelo (malla de 0,05°
 * alrededor del valle, 17-09-2026): la celda del cauce da ~167 m³/s y las
 * vecinas de ladera caen a menos de 10. Está entre el lago Todos los Santos y
 * Ralún, bien separada del sistema del Puelo.
 */
export const RIO_PETROHUE: RiverQuery = {
  riverName: 'Río Petrohué',
  lat: -41.3,
  lon: -72.42,
};

/*
 * Por qué NO hay una entrada para el Río Cochamó.
 *
 * Se barrió su entorno con el mismo método (25 celdas alrededor del poblado,
 * -41,49 / -72,31). Todas devuelven entre 1 y 22 m³/s, dispersas y sin un cauce
 * continuo: a ~5 km de celda, GloFAS v4 no resuelve un río de ese tamaño. Los
 * únicos valores altos del entorno (169–171 m³/s) pertenecen al Petrohué, no al
 * Cochamó. Asignarle una celda sería ponerle el nombre de un río a la descarga
 * de otro, que es justo el error que el punto del Puelo evita. Si el Cochamó
 * llega a hacer falta, tiene que venir de un aforo, no de este modelo.
 */

export function fetchRiverDischarge(query: RiverQuery): Promise<SourceResult<RiverDischarge>> {
  const params = new URLSearchParams({
    latitude: String(query.lat),
    longitude: String(query.lon),
    daily: 'river_discharge',
    past_days: String(query.pastDays ?? 31),
    forecast_days: String(query.forecastDays ?? 7),
  });

  return fetchSource<RiverDischarge>({
    sourceId: SOURCE_ID,
    label: `caudal ${query.riverName}`,
    url: `${ENDPOINT}?${params}`,
    timeoutMs: 30_000,
    snapshotFile: 'river-discharge.json',
    parse: (raw) => {
      const payload = raw as {
        daily?: { time?: string[]; river_discharge?: (number | null)[] };
        daily_units?: { river_discharge?: string };
      };
      const time = payload.daily?.time;
      const discharge = payload.daily?.river_discharge;
      if (!Array.isArray(time) || !Array.isArray(discharge)) {
        throw new Error('flood: respuesta sin serie diaria de caudal');
      }

      const today = new Date().toISOString().slice(0, 10);
      const points: RiverPoint[] = time.map((date, index) => ({
        date,
        value: discharge[index] ?? null,
        forecast: date > today,
      }));

      const observed = points.filter((point) => !point.forecast && point.value !== null);
      const latest = observed[observed.length - 1] ?? null;
      const weekAgo = observed[observed.length - 8] ?? null;
      const weeklyChangePct =
        latest?.value && weekAgo?.value
          ? Math.round(((latest.value - weekAgo.value) / weekAgo.value) * 100)
          : null;

      return {
        riverName: query.riverName,
        lat: query.lat,
        lon: query.lon,
        unit: payload.daily_units?.river_discharge ?? 'm³/s',
        points,
        latest,
        weeklyChangePct,
      };
    },
  });
}

/** El caudal del Puelo, que es el que manda sobre el estuario de Reloncaví. */
export function fetchPueloDischarge(): Promise<SourceResult<RiverDischarge>> {
  return fetchRiverDischarge(RIO_PUELO);
}

/** El caudal del Petrohué, el otro aporte grande de agua dulce al estuario. */
export function fetchPetrohueDischarge(): Promise<SourceResult<RiverDischarge>> {
  return fetchRiverDischarge(RIO_PETROHUE);
}

/** Los aportes fluviales que GloFAS resuelve para el sistema Reloncaví. */
export const RELONCAVI_RIVERS: RiverQuery[] = [RIO_PUELO, RIO_PETROHUE];

/** Últimos `days` días observados, para el gráfico de barras de la tarjeta. */
export function recentBars(result: SourceResult<RiverDischarge>, days = 16): number[] {
  return mapResult(result, (river) =>
    river.points
      .filter((point) => !point.forecast && point.value !== null)
      .slice(-days)
      .map((point) => point.value as number),
  ).data ?? [];
}
