// Open-Meteo bajo el contrato de `datasource`.
//
// Esta fuente ya funcionaba en `src/lib/stratos/api/*` y su lógica de dominio
// —índice de riesgo, fan de 30 días, horizontes tácticos— es correcta y está
// probada. Aquí no se reescribe nada de eso: sólo se envuelve, para que un
// consumidor pueda pedir Open-Meteo y ACS con la misma forma y comparar su
// procedencia en la misma escala.
//
// El estado se deriva de la telemetría que el propio cliente de Open-Meteo ya
// llevaba (`fetchHealthSince`): si todas sus peticiones fueron en vivo el
// resultado es `live`; si alguna se resolvió con la última captura, `stale`.

import { fetchHealthSince } from '../../../src/lib/stratos/api/client';
import { fetchAllStations } from '../../../src/lib/stratos/api/stations';
import { fetchTimeSeries } from '../../../src/lib/stratos/api/timeseries';
import { fetchEnsemble } from '../../../src/lib/stratos/api/ensemble';
import { fetchRecentDaily } from '../../../src/lib/stratos/api/recent';
import type { Provenance } from '../../core/provenance';
import { recordHealth } from '../../core/health';
import type { SourceResult } from '../../core/types';

/**
 * Traduce el recuento de peticiones de Open-Meteo a un estado de procedencia.
 * Basta una petición sin resolver para que el bloque deje de ser "en vivo": el
 * peor escalón manda, igual que en el resto de la capa.
 */
function provenanceOf(startedAt: number, hasData: boolean): Provenance {
  const health = fetchHealthSince(startedAt);
  if (!hasData) return 'missing';
  if (health.missing > 0) return health.live + health.stale > 0 ? 'stale' : 'missing';
  if (health.stale > 0) return 'stale';
  if (health.live > 0) return 'live';
  return hasData ? 'stale' : 'missing';
}

async function wrap<T>(
  sourceId: string,
  call: () => Promise<T>,
  hasData: (value: T) => boolean,
): Promise<SourceResult<T>> {
  const startedAt = Date.now();
  const started = performance.now();
  const data = await call();
  const durationMs = Math.round(performance.now() - started);
  const state = provenanceOf(startedAt, hasData(data));

  recordHealth({ sourceId, state, at: Date.now(), durationMs });

  return {
    state,
    data: state === 'missing' ? null : data,
    meta: { sourceId, fetchedAt: new Date().toISOString(), ageMs: 0 },
  };
}

/** Condiciones marinas actuales de todos los centros configurados. */
export function fetchStations() {
  return wrap('open-meteo-marine', fetchAllStations, (rows) => rows.length > 0);
}

/** Serie multivariable de la estación de referencia: 72 h atrás + 168 h adelante. */
export function fetchSeries() {
  return wrap('open-meteo-marine', fetchTimeSeries, (raw) => Object.keys(raw ?? {}).length > 0);
}

/** Ensemble de 32 días que sostiene el fan de 30 y sus recortes de 14 y 7. */
export function fetchForecastEnsemble() {
  return wrap('open-meteo-forecast', fetchEnsemble, (raw) => Object.keys(raw ?? {}).length > 0);
}

/** Últimos días diarios, para contrastar el pronóstico con lo ya ocurrido. */
export function fetchRecent() {
  return wrap('open-meteo-forecast', fetchRecentDaily, (raw) => Object.keys(raw ?? {}).length > 0);
}
