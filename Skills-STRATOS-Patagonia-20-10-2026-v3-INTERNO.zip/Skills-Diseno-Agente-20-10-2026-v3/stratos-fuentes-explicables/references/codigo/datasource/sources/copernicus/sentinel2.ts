// Sentinel-2 MSI — descubrimiento de escenas por el Copernicus Data Space.
//
// El escalón fino de la jerarquía espacial de STRATOS:
//
//   Copernicus BGC (25 km) → OLCI 300 m → Sentinel-2 (10 m)
//
// Se usa donde 300 m no alcanza —estuario de Reloncaví, desembocaduras del Puelo
// y el Petrohué, canales estrechos, el entorno inmediato de los centros—, como
// complemento de OLCI y nunca como reemplazo general: su revisita es de ~5 días
// y la nubosidad del mar interior se come buena parte de las pasadas.
//
// Lo que se consulta aquí es el CATÁLOGO: qué escena existe, de cuándo y con
// cuánta nube. Los píxeles no pasan por el navegador; extraerlos es trabajo del
// pipeline, igual que el resto de lo gridded.
//
// Nota sobre la API (verificado el 17-09-2026): el endpoint STAC del Data Space
// NO publica una colección `SENTINEL-2` —devuelve 404—, así que la búsqueda va
// por OData, que sí responde sin credenciales y admite filtro por geometría,
// tipo de producto y nubosidad.

import { fetchSource } from '../../core/fetchSource';
import { proxyUrl } from '../../core/env';
import { type SourceResult } from '../../core/types';

const SOURCE_ID = 'sentinel2-cdse';
const COLLECTION = 'SENTINEL-2';
/** L2A: reflectancia de fondo de atmósfera. L1C sería techo de atmósfera. */
const PRODUCT_TYPE = 'S2MSI2A';

export interface Sentinel2Scene {
  id: string;
  /** Nombre SAFE completo, que es lo que el pipeline necesita para descargarla. */
  name: string;
  /** ISO-8601 UTC de la toma. */
  sensedAt: string;
  /** Porcentaje de nube de la escena completa. `null` si el catálogo no lo declaró. */
  cloudCoverPct: number | null;
  /** Tesela MGRS (`T18GYV`). Reloncaví cae entre 18G y 19G. */
  tile: string | null;
  /** `false` si está en almacenamiento frío: pedirla implica una espera. */
  online: boolean;
}

export interface Sentinel2Query {
  /** Punto de interés. El catálogo devuelve las escenas que lo contienen. */
  lat: number;
  lon: number;
  /** Nubosidad máxima aceptada, en porcentaje. */
  maxCloudPct?: number;
  /** Ventana hacia atrás, en días. */
  sinceDays?: number;
  limit?: number;
}

/**
 * Zonas del sistema Reloncaví donde Sentinel-2 aporta algo que OLCI no puede.
 * Son puntos de consulta del catálogo, no recortes: el recorte lo decide quien
 * procese la escena.
 */
export const SENTINEL2_FOCUS = {
  estuarioReloncavi: { lat: -41.55, lon: -72.33, label: 'Estuario de Reloncaví' },
  desembocaduraPuelo: { lat: -41.66, lon: -72.31, label: 'Desembocadura del Puelo' },
  desembocaduraPetrohue: { lat: -41.4, lon: -72.33, label: 'Desembocadura del Petrohué' },
  senoReloncavi: { lat: -41.72, lon: -72.75, label: 'Seno de Reloncaví' },
} as const;

/**
 * Advertencia que debe acompañar a cualquier producto derivado de estas escenas
 * sobre agua costera. Sen2Cor corrige la atmósfera, pero NO el efecto de
 * adyacencia: a pocos cientos de metros de la costa el brillo de la tierra
 * contamina la señal del agua, y en un fiordo casi todo el píxel útil está en
 * esa franja. Derivar clorofila de aquí sin una cadena tipo ACOLITE o T-Mart no
 * está justificado; la reflectancia sí sirve para ver estructura —plumas,
 * frentes, sedimento— que a 300 m no se distingue.
 */
export const ADJACENCY_WARNING =
  'Sentinel-2 L2A no lleva corrección del efecto de adyacencia: sobre agua próxima a la costa ' +
  'la reflectancia está contaminada por el brillo de tierra. Sirve para estructura, no para ' +
  'concentraciones, mientras no haya una cadena de corrección para aguas costeras.';

function odataFilter(query: Sentinel2Query): string {
  const since = new Date(Date.now() - (query.sinceDays ?? 30) * 86_400_000).toISOString();
  const cloud = query.maxCloudPct ?? 60;
  return [
    `Collection/Name eq '${COLLECTION}'`,
    `Attributes/OData.CSC.StringAttribute/any(a:a/Name eq 'productType' and a/OData.CSC.StringAttribute/Value eq '${PRODUCT_TYPE}')`,
    `Attributes/OData.CSC.DoubleAttribute/any(a:a/Name eq 'cloudCover' and a/OData.CSC.DoubleAttribute/Value lt ${cloud})`,
    `OData.CSC.Intersects(area=geography'SRID=4326;POINT(${query.lon} ${query.lat})')`,
    `ContentDate/Start gt ${since}`,
  ].join(' and ');
}

/** Escenas L2A recientes que cubren el punto, de la más nueva a la más vieja. */
export function fetchSentinel2Scenes(query: Sentinel2Query): Promise<SourceResult<Sentinel2Scene[]>> {
  const params = new URLSearchParams({
    $filter: odataFilter(query),
    $expand: 'Attributes',
    $orderby: 'ContentDate/Start desc',
    $top: String(query.limit ?? 10),
  });

  return fetchSource<Sentinel2Scene[]>({
    sourceId: SOURCE_ID,
    label: `Sentinel-2 (${query.lat.toFixed(2)}, ${query.lon.toFixed(2)})`,
    url: proxyUrl('cdse', `/odata/v1/Products?${params}`),
    timeoutMs: 45_000,
    parse: (raw) => {
      const payload = raw as { value?: unknown[] };
      if (!Array.isArray(payload?.value)) throw new Error('CDSE: respuesta sin `value`');
      return payload.value.map((item) => {
        const product = item as {
          Id?: string;
          Name?: string;
          Online?: boolean;
          ContentDate?: { Start?: string };
          Attributes?: { Name?: string; Value?: unknown }[];
        };
        const attributes = new Map(
          (product.Attributes ?? []).map((attribute) => [attribute.Name, attribute.Value]),
        );
        const cloud = attributes.get('cloudCover');
        const name = product.Name ?? '';
        return {
          id: product.Id ?? name,
          name,
          sensedAt: product.ContentDate?.Start ?? '',
          cloudCoverPct: typeof cloud === 'number' ? cloud : null,
          tile: /_(T\d{2}[A-Z]{3})_/.exec(name)?.[1] ?? null,
          online: product.Online !== false,
        };
      });
    },
  });
}

/** La escena utilizable más reciente sobre un foco del sistema Reloncaví. */
export function fetchLatestScene(
  focus: keyof typeof SENTINEL2_FOCUS,
  options: { maxCloudPct?: number; sinceDays?: number } = {},
): Promise<SourceResult<Sentinel2Scene[]>> {
  const spot = SENTINEL2_FOCUS[focus];
  return fetchSentinel2Scenes({ lat: spot.lat, lon: spot.lon, limit: 5, ...options });
}
