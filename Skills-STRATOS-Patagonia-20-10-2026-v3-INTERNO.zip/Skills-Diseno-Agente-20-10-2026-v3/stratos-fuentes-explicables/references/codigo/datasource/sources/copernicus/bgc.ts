// Copernicus Marine — biogeoquímica global (análisis/pronóstico e hindcast).
//
// Es la única fuente de nutrientes que tiene STRATOS: nitrato, fosfato y
// silicato no los entrega ninguna otra integración, ni CHONOS ni las boyas ACS.
// También es la única con pH de columna, alcalinidad y carbono inorgánico.
//
// Y es, a la vez, la más gruesa de todas: 0,25° ≈ 25 km. Una sola celda cubre el
// Seno de Reloncaví entero. Eso la hace CONTEXTO REGIONAL y de columna de agua,
// nunca microescala costera: no se interpola para aparentar detalle, y cuando se
// muestre junto a un dato de 300 m o de una boya hay que decir cuál es cuál.
//
// Reparto de variables por dataset (verificado contra el STAC de CMEMS el
// 17-09-2026 — el agrupamiento no es obvio y equivocarse cuesta una descarga):
//
//   -nut       → no3, po4, si, fe
//   -bio       → o2, nppv
//   -car       → dissic, ph, talk
//   -pft       → chl, phyc
//   -plankton  → zooc          (ojo: aquí NO está la clorofila)

import { fetchSource } from '../../core/fetchSource';
import { mapResult, type SourceResult } from '../../core/types';
import type { VariableId } from '../../core/variables';
import {
  findVariable,
  parseCopernicusSnapshot,
  type CopernicusGrid,
  type CopernicusSnapshot,
  type GridVariable,
} from './types';

const OPERATIONAL_ID = 'copernicus-bgc';
const HINDCAST_ID = 'copernicus-bgc-hindcast';

/** Datasets diarios del análisis y pronóstico operacional. */
export const BGC_DATASETS = {
  nutrients: 'cmems_mod_glo_bgc-nut_anfc_0.25deg_P1D-m',
  biology: 'cmems_mod_glo_bgc-bio_anfc_0.25deg_P1D-m',
  carbon: 'cmems_mod_glo_bgc-car_anfc_0.25deg_P1D-m',
  plankton: 'cmems_mod_glo_bgc-pft_anfc_0.25deg_P1D-m',
} as const;

/**
 * Hindcast multianual. Cubre 1993-01-01 → 2026-05-31 (extensión declarada por el
 * propio catálogo), que es la base para climatologías y anomalías.
 *
 * Diferencia que importa: el hindcast NO trae pH, alcalinidad ni carbono
 * inorgánico. Sólo clorofila, nitrato, fosfato, silicato, oxígeno y producción
 * primaria. Pedirle carbonatos devuelve nada, no ceros.
 */
export const BGC_HINDCAST_DATASETS = {
  daily: 'cmems_mod_glo_bgc_my_0.25deg_P1D-m',
  monthly: 'cmems_mod_glo_bgc_my_0.25deg_P1M-m',
} as const;

export const BGC_HINDCAST_COVERAGE = { from: '1993-01-01', to: '2026-05-31' } as const;

/** Variables que el operacional entrega y el hindcast no. */
export const HINDCAST_MISSING: VariableId[] = ['ph', 'alkalinity', 'dissolvedInorganicCarbon'];

export interface BgcField {
  grid: CopernicusGrid;
  /** Profundidad del nivel leído, en metros. */
  depthM: number | null;
}

function readSnapshot(sourceId: string, file: string, label: string) {
  return fetchSource<CopernicusSnapshot>({
    sourceId,
    label,
    url: '',
    snapshotOnly: true,
    snapshotFile: file,
    parse: parseCopernicusSnapshot,
  });
}

/**
 * Campo BGC operacional que contiene una variable dada, al nivel más somero
 * disponible salvo que se pida otro. `depthM` viaja con el resultado: una
 * concentración de nitrato a 50 m no dice lo mismo que en superficie.
 */
export function fetchBgcField(
  variable: VariableId,
  { depthM = 0 }: { depthM?: number } = {},
): Promise<SourceResult<BgcField>> {
  return readSnapshot(OPERATIONAL_ID, 'copernicus-bgc.json', `BGC ${variable}`).then((snapshot) =>
    mapResult(snapshot, (payload) => {
      const grid = pickGrid(payload, variable, depthM);
      if (!grid) {
        throw new Error(`${OPERATIONAL_ID}: el recorte no trae ${variable} a ${depthM} m`);
      }
      return { grid, depthM: grid.depthM };
    }),
  );
}

/** Lo mismo sobre la serie multianual, para climatologías y anomalías. */
export function fetchBgcHindcast(variable: VariableId): Promise<SourceResult<BgcField>> {
  if (HINDCAST_MISSING.includes(variable)) {
    return Promise.reject(
      new Error(
        `${HINDCAST_ID}: ${variable} no existe en el hindcast multianual; sólo en el operacional`,
      ),
    );
  }
  return readSnapshot(HINDCAST_ID, 'copernicus-bgc-hindcast.json', `BGC histórico ${variable}`).then(
    (snapshot) =>
      mapResult(snapshot, (payload) => {
        const grid = pickGrid(payload, variable, 0);
        if (!grid) throw new Error(`${HINDCAST_ID}: el recorte no trae ${variable}`);
        return { grid, depthM: grid.depthM };
      }),
  );
}

function pickGrid(payload: CopernicusSnapshot, variable: VariableId, depthM: number) {
  const candidates = payload.grids.filter((grid) => findVariable(grid, variable) !== null);
  if (candidates.length === 0) return null;
  // El nivel más cercano al pedido; nunca se promedian profundidades distintas.
  return candidates.reduce((best, grid) =>
    Math.abs((grid.depthM ?? 0) - depthM) < Math.abs((best.depthM ?? 0) - depthM) ? grid : best,
  );
}

/**
 * Valor de la celda que contiene el punto, sin interpolar. A 25 km interpolar
 * sería inventar un gradiente que el modelo no resuelve.
 */
export function sampleBgcCell(field: BgcField, variable: VariableId, longitude: number, latitude: number) {
  const { grid } = field;
  const entry: GridVariable | null = findVariable(grid, variable);
  if (!entry) return null;
  const { west, east, north, south } = grid.bounds;
  if (longitude < west || longitude > east || latitude < south || latitude > north) return null;

  const column = Math.min(grid.width - 1, Math.floor(((longitude - west) / (east - west)) * grid.width));
  const row = Math.min(grid.height - 1, Math.floor(((north - latitude) / (north - south)) * grid.height));
  const value = entry.values[row * grid.width + column];
  if (value === null || value === undefined) return null;

  return {
    value,
    unit: entry.unit,
    time: grid.time,
    depthM: grid.depthM,
    resolutionM: grid.resolutionM,
  };
}
