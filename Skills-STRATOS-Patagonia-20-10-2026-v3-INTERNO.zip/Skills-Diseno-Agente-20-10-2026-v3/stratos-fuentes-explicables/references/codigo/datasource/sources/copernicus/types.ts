// Forma común de los campos gridded de Copernicus que STRATOS lee.
//
// La descarga NO ocurre aquí: el subset por zona lo produce el pipeline de
// STRATOS-Architecture y lo deja en public/datasource. Este módulo define qué
// espera encontrar STRATOS y valida que lo encontrado sea eso. Si el pipeline
// cambia de forma, el parseo falla alto en vez de dibujar un campo vacío.

import type { VariableId } from '../../core/variables';

/** Caja geográfica del recorte, en grados. */
export interface GeoBounds {
  west: number;
  south: number;
  east: number;
  north: number;
}

/**
 * Una variable dentro de un campo, con su malla y —cuando el proveedor las
 * publica— su incertidumbre y sus banderas de calidad. Las tres viajan juntas a
 * propósito: un píxel de color del océano sin su `flags` no es interpretable
 * cerca de la costa, que es justo donde STRATOS necesita mirar.
 */
export interface GridVariable {
  /** Nombre canónico STRATOS. */
  id: VariableId;
  /** Nombre nativo en el producto (`CHL`, `no3`, `RRS443`…). */
  nativeName: string;
  unit: string;
  /** Valores en orden fila-mayor desde el norte. `null` = sin dato, nunca cero. */
  values: (number | null)[];
  /** Incertidumbre por celda en %, si el producto la publica. */
  uncertainty?: (number | null)[];
  /** Banderas de calidad del proveedor por celda, sin reinterpretar. */
  flags?: (number | null)[];
  /**
   * Sólo en compuestos: edad de cada píxel en días respecto de `time` de la
   * malla (0 = el día más reciente). Un compuesto no promedia días: cada celda
   * es la última observación válida, y esto dice de qué día es.
   */
  ageDays?: (number | null)[];
}

export interface CopernicusGrid {
  /** Identificador del dataset en el catálogo CMEMS, tal cual. */
  datasetId: string;
  bounds: GeoBounds;
  width: number;
  height: number;
  /** Metros por celda, declarado por el producto. Nunca se interpola a más fino. */
  resolutionM: number;
  /** ISO-8601 UTC del instante que representa el campo. */
  time: string;
  /** Profundidad en metros. `0` superficie; `null` si el producto es 2D. */
  depthM: number | null;
  variables: GridVariable[];
  /** Ventana del compuesto en días, si la malla es un compuesto por píxel. */
  compositeDays?: number;
}

/** Lo que el pipeline deja en un archivo de snapshot. */
export interface CopernicusSnapshot {
  generatedAt: string;
  /** Producto CMEMS del que salió. */
  productId: string;
  grids: CopernicusGrid[];
}

const isNumberOrNull = (value: unknown) => value === null || typeof value === 'number';

/**
 * Valida la carga del pipeline. Es deliberadamente estricta: prefiere lanzar a
 * dejar pasar una malla cuyo tamaño no cuadra con sus valores, que más adelante
 * se leería como un campo desplazado sobre el mapa.
 */
export function parseCopernicusSnapshot(raw: unknown): CopernicusSnapshot {
  const payload = raw as Partial<CopernicusSnapshot>;
  if (!payload || typeof payload !== 'object') throw new Error('copernicus: carga vacía');
  if (!Array.isArray(payload.grids)) throw new Error('copernicus: falta `grids`');

  for (const grid of payload.grids) {
    const cells = grid.width * grid.height;
    if (!Number.isFinite(cells) || cells <= 0) {
      throw new Error(`copernicus ${grid.datasetId}: malla sin dimensiones`);
    }
    if (!Array.isArray(grid.variables) || grid.variables.length === 0) {
      throw new Error(`copernicus ${grid.datasetId}: malla sin variables`);
    }
    for (const variable of grid.variables) {
      if (variable.values.length !== cells) {
        throw new Error(
          `copernicus ${grid.datasetId}/${variable.nativeName}: ${variable.values.length} valores para ${cells} celdas`,
        );
      }
      if (!variable.values.every(isNumberOrNull)) {
        throw new Error(`copernicus ${grid.datasetId}/${variable.nativeName}: valores no numéricos`);
      }
      for (const companion of ['uncertainty', 'flags', 'ageDays'] as const) {
        const series = variable[companion];
        if (series && series.length !== cells) {
          throw new Error(
            `copernicus ${grid.datasetId}/${variable.nativeName}: ${companion} no cuadra con la malla`,
          );
        }
      }
    }
  }
  return payload as CopernicusSnapshot;
}

/** Busca una variable canónica dentro de un campo. `null` si el producto no la trae. */
export function findVariable(grid: CopernicusGrid, id: VariableId): GridVariable | null {
  return grid.variables.find((variable) => variable.id === id) ?? null;
}
