// Copernicus Marine — Ocean Colour OLCI 300 m (Sentinel-3).
//
// Capa principal de color del océano para el Seno de Reloncaví y el Mar Interior
// de Chiloé. Sustituye a VIIRS (750 m, ~10 días de latencia) como observación
// superficial de referencia, sin retirarlo: VIIRS cubre lo que OLCI no alcanza.
//
// Lo que el catálogo publica realmente a 300 m (verificado contra el STAC de
// CMEMS el 17-09-2026) son DOS datasets, y conviene tenerlo presente:
//
//   · plankton    → CHL + CHL_uncertainty + flags
//   · reflectance → RRS de 11 bandas (400…709 nm), cada una con incertidumbre
//
// Kd490, disco de Secchi, turbidez, TSM y las propiedades ópticas inherentes NO
// existen a 300 m: sólo a 4 km. Los grupos funcionales de fitoplancton tampoco.
// Cuando haga falta alguna de esas variables hay que declarar que se está
// bajando de resolución, nunca presentar el producto de 4 km como si fuera éste.
//
// La descarga gridded no vive en este repositorio (ver `types.ts`).

import { fetchSource } from '../../core/fetchSource';
import { mapResult, type SourceResult } from '../../core/types';
import {
  findVariable,
  parseCopernicusSnapshot,
  type CopernicusGrid,
  type CopernicusSnapshot,
} from './types';

const SOURCE_ID = 'copernicus-olci-300m';

/** Datasets de 300 m del producto NRT. Son los que el pipeline debe pedir. */
export const OLCI_300M_DATASETS = {
  chlorophyll: 'cmems_obs-oc_glo_bgc-plankton_nrt_l3-olci-300m_P1D',
  reflectance: 'cmems_obs-oc_glo_bgc-reflectance_nrt_l3-olci-300m_P1D',
} as const;

/** Los mismos, en la colección multianual, para series largas. */
export const OLCI_300M_DATASETS_MY = {
  chlorophyll: 'cmems_obs-oc_glo_bgc-plankton_my_l3-olci-300m_P1D',
  reflectance: 'cmems_obs-oc_glo_bgc-reflectance_my_l3-olci-300m_P1D',
} as const;

/**
 * Variables que STRATOS NO puede pedir a 300 m, con el motivo. Existe para que
 * un módulo que las necesite lo consulte y decida explícitamente, en vez de
 * caer sin querer en el producto de 4 km.
 */
export const NOT_AVAILABLE_AT_300M: Record<string, string> = {
  diffuseAttenuation: 'Kd490 sólo se publica a 4 km (dataset `transp`).',
  turbidity: 'La turbidez óptica sólo se publica a 4 km (dataset `transp`).',
  suspendedMatter: 'El TSM sólo se publica a 4 km (dataset `transp`).',
  phytoplanktonGroups: 'Los grupos funcionales (PFT) sólo existen a 4 km.',
};

export interface OceanColourField {
  grid: CopernicusGrid;
  /** Celdas con observación válida. */
  observed: number;
  /** Celdas sin observación: nube, tierra o descarte por calidad. */
  blank: number;
}

/**
 * Campo de clorofila OLCI a 300 m del último recorte disponible.
 *
 * Un `null` significa «sin observación» —nube, tierra o píxel descartado—, jamás
 * cero clorofila: no se promedian como ceros ni se rellenan por interpolación.
 */
export function fetchOlciChlorophyll(): Promise<SourceResult<OceanColourField>> {
  return fetchSnapshotGrid(OLCI_300M_DATASETS.chlorophyll, 'clorofila OLCI 300 m');
}

/** Campo de reflectancia OLCI a 300 m. Es radiometría: no es una concentración. */
export function fetchOlciReflectance(): Promise<SourceResult<OceanColourField>> {
  return fetchSnapshotGrid(OLCI_300M_DATASETS.reflectance, 'reflectancia OLCI 300 m');
}

function fetchSnapshotGrid(datasetId: string, label: string): Promise<SourceResult<OceanColourField>> {
  const result = fetchSource<CopernicusSnapshot>({
    sourceId: SOURCE_ID,
    label,
    // Sin descarga propia: se lee el recorte que dejó el pipeline.
    url: '',
    snapshotOnly: true,
    snapshotFile: 'copernicus-olci-300m.json',
    parse: parseCopernicusSnapshot,
  });

  return result.then((snapshot) =>
    mapResult(snapshot, (payload) => {
      const grid = payload.grids.find((candidate) => candidate.datasetId.startsWith(datasetId));
      if (!grid) throw new Error(`${SOURCE_ID}: el snapshot no trae ${datasetId}`);
      const primary = grid.variables[0];
      const observed = primary.values.filter((value) => value !== null).length;
      return { grid, observed, blank: primary.values.length - observed };
    }),
  );
}

/**
 * Clorofila en un punto, sin interpolar entre celdas: se devuelve el valor de la
 * celda que lo contiene. A 300 m una celda ya es más fina que cualquier decisión
 * operativa, y suavizarla sólo inventaría precisión.
 *
 * `null` si el punto cae fuera del recorte o si la celda no tiene observación.
 */
export function sampleCell(field: OceanColourField, longitude: number, latitude: number) {
  const { grid } = field;
  const chl = findVariable(grid, 'chlorophyll');
  if (!chl) return null;
  const { west, east, north, south } = grid.bounds;
  if (longitude < west || longitude > east || latitude < south || latitude > north) return null;

  const column = Math.min(grid.width - 1, Math.floor(((longitude - west) / (east - west)) * grid.width));
  const row = Math.min(grid.height - 1, Math.floor(((north - latitude) / (north - south)) * grid.height));
  const index = row * grid.width + column;
  const value = chl.values[index];
  if (value === null || value === undefined) return null;

  return {
    value,
    unit: chl.unit,
    uncertaintyPct: chl.uncertainty?.[index] ?? null,
    /** Bandera cruda del proveedor. Se entrega sin reinterpretar. */
    flag: chl.flags?.[index] ?? null,
    time: grid.time,
    resolutionM: grid.resolutionM,
  };
}
