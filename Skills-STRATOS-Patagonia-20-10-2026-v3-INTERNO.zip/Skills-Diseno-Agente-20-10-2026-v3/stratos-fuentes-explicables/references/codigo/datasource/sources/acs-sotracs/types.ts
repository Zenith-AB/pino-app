// Formas de la red ACS / SOTRACS de IFOP, verificadas contra la API el 2026-09-16.
//
// SOTRACS es la única fuente observada in situ y de alta frecuencia de los
// fiordos: 15 boyas con sonda de superficie, sonda de profundidad, meteorología,
// GPS y un ADCP de ~121 celdas entre 0 y 120 m. Todo lo demás que alimenta la
// cascada por debajo de la superficie es reanálisis, no medición.

/** Variables de columna de agua: lo que alimenta estratificación y nutrientes. */
import type { MooringPosition } from './mooring.ts';

export const WATER_COLUMN_VARIABLES = [
  'water_temperature',
  'salinity',
  'oxygen_conc',
  'oxygen_sat',
  'fluorescence',
  'turbidity',
  'density',
  'ph',
  'conductivity',
] as const;

/** Variables meteorológicas de la boya. */
export const METEO_VARIABLES = [
  'air_temperature',
  'air_pressure',
  'wind_speed',
  'wind_direction',
  'gust_speed',
  'radiation',
  'precipitation',
  'relative_humidity',
] as const;

/**
 * Variables del ADCP. Se listan aparte a propósito: 13 variables por ~121 celdas
 * son dos órdenes de magnitud más datos que el resto y merecen una decisión de
 * alcance propia, no colarse en una carga de panel.
 */
export const ADCP_VARIABLES = [
  'component_u',
  'component_v',
  'component_w',
  'velocity',
  'direction',
  'amplitude',
  'correlation',
  'error',
] as const;

export type AcsVariableCode =
  | (typeof WATER_COLUMN_VARIABLES)[number]
  | (typeof METEO_VARIABLES)[number]
  | (typeof ADCP_VARIABLES)[number]
  | (string & {});

export interface AcsInstrument {
  code: string;
  active: boolean;
}

export interface AcsBuoy {
  /** Clave estable de la boya (`acs1`, `acs18b`…). Es la que STRATOS debe usar. */
  code: string;
  name: string;
  lat: number;
  lon: number;
  region: string;
  operator: string;
  /** Empresa titular de la concesión donde está fondeada. */
  titular: string;
  active: boolean;
  estatus: string;
  instruments: AcsInstrument[];
  /**
   * De dónde sale `lat`/`lon`. Ausente o `catalogue`: lo que publica IFOP hoy.
   * `last-known`: el catálogo publicó una posición imposible y se usa el último
   * fondeo verificado; la interfaz debe declararlo (ver `mooring.ts`).
   */
  position?: MooringPosition;
}

export interface AcsSensor {
  id: number;
  buoyCode: string;
  variableCode: AcsVariableCode;
  unit: string;
  /** `sonda_sup`, `sonda_prof`, `meteo`, `adcp`, `gps`. */
  instrumentCode: string;
  /**
   * Profundidad del sensor en metros. Es el dato que NO viaja en la lectura: sin
   * él las series de 5 m y de 60 m se mezclan sin manera de separarlas.
   */
  depthM: number | null;
  /** Índice de celda dentro del instrumento (0 salvo en el ADCP). */
  number: number;
  active: boolean;
}

/** Control de calidad que publica IFOP junto a cada lectura. */
export interface AcsFlag {
  code: number;
  symbol: string;
  description: string;
}

export interface AcsReading {
  /** ISO-8601 con desfase de Chile continental, tal como lo emite la API. */
  time: string;
  sensorId: number;
  buoyCode: string;
  variableCode: AcsVariableCode;
  value: number;
  flag: AcsFlag;
  /** Profundidad unida por `sensorId` contra el registro de sensores. */
  depthM: number | null;
}

/** Una serie de una variable en una boya, separada por profundidad. */
export interface AcsSeries {
  buoyCode: string;
  variableCode: AcsVariableCode;
  unit: string;
  /** Total de lecturas que la API declara para esta combinación. */
  totalAvailable: number;
  /** Una entrada por sensor, es decir por profundidad. */
  levels: AcsLevel[];
}

export interface AcsLevel {
  sensorId: number;
  instrumentCode: string;
  depthM: number | null;
  points: AcsPoint[];
}

export interface AcsPoint {
  time: string;
  value: number;
  flag: AcsFlag;
}

/** Última medición válida de una variable a una profundidad. */
export interface AcsLatestValue {
  variableCode: AcsVariableCode;
  unit: string;
  depthM: number | null;
  instrumentCode: string;
  value: number;
  time: string;
  flag: AcsFlag;
}
