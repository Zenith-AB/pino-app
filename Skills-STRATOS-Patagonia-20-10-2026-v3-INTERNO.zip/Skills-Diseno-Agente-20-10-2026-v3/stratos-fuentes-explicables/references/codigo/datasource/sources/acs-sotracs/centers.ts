// Centros de cultivo monitoreados por la red ACS / SOTRACS.
//
// Un centro es un sitio: las jaulas, ancladas donde están. Una boya es el
// instrumento que lo mide, y cuál sea no es una propiedad del centro — depende de
// qué haya fondeado y reportando hoy. Por eso aquí el centro declara su posición
// y la boya se resuelve contra el catálogo vivo de la red: la más cercana de las
// que tienen las dos sondas de columna activas.
//
// Esa separación es lo que permite decir a qué distancia está la medición de la
// jaula, que es la pregunta que decide si el número describe este centro o el
// cuerpo de agua de al lado. Antes el código de boya estaba escrito a mano junto
// al centro y esa distancia no existía en ninguna parte.
//
// El titular y la concesión vienen del registro auditado de STRATOS-Architecture
// (`conf/base/acs_stations.yml`).

import { worstProvenance } from '../../core/provenance';
import { degraded, missing, type SourceResult } from '../../core/types';
import { getMonitoredCenter, MAX_CENTER_SENSOR_DISTANCE_KM, nearestAvailableBuoy, resolveBuoyForCenter } from './buoyBinding.ts';
import type { MonitoredCenter, ResolvedBuoy } from './buoyBinding.ts';
import { fetchBuoys, fetchLatest, fetchSeries } from './client';
import type { AcsBuoy, AcsLatestValue, AcsPoint, AcsVariableCode } from './types';

const SOURCE_ID = 'acs-sotracs';

/** Profundidad de la sonda de superficie en la red. */
export const SURFACE_M = 5;
/** Profundidad de la sonda profunda. */
export const DEEP_M = 60;

export type { MonitoredCenter, ResolvedBuoy } from './buoyBinding.ts';
export {
  MONITORED_CENTERS,
  distanceKm,
  getMonitoredCenter,
  isBuoyAvailable,
  nearestAvailableBuoy,
  resolveBuoyForCenter,
} from './buoyBinding.ts';

/**
 * El catálogo se pide una vez por sesión y se comparte: son quince filas que no
 * cambian entre recargas de sonda, y resolverlo por centro y por ventana serían
 * seis peticiones idénticas en cada arranque.
 */
let catalogue: Promise<AcsBuoy[] | null> | null = null;

/** Para las pruebas y para forzar una relectura del catálogo. */
export function resetBuoyCatalogue(): void {
  catalogue = null;
}

function loadCatalogue(): Promise<AcsBuoy[] | null> {
  catalogue ??= fetchBuoys()
    .then((result) => result.data)
    .catch(() => null);
  return catalogue;
}

/**
 * Boya asignada a un centro. Sin catálogo o sin una estación dentro del radio,
 * no existe asignación: una conexión no comprobada no se dibuja ni entrega KPIs.
 */
export async function resolveCenterBuoy(center: MonitoredCenter): Promise<ResolvedBuoy | null> {
  const buoys = await loadCatalogue();
  if (!buoys) return null;
  return resolveBuoyForCenter(buoys, center, MAX_CENTER_SENSOR_DISTANCE_KM);
}

// ── Lectura de columna de agua ───────────────────────────────────────────────

/** Variables de sonda que sostienen la tarjeta de un centro. */
export const CENTER_VARIABLES: AcsVariableCode[] = [
  'fluorescence',
  'water_temperature',
  'salinity',
  'oxygen_conc',
];

export interface CenterReading {
  variableCode: AcsVariableCode;
  unit: string;
  /** Valor de la sonda de superficie (5 m). */
  surface: number | null;
  /** Valor de la sonda profunda (60 m). */
  deep: number | null;
  /**
   * Control de calidad de IFOP para la lectura de superficie: `GOOD`, `SUSPECT`…
   * Un valor con flag distinto de `GOOD` existe pero el proveedor no lo certifica,
   * y la interfaz debe tratarlo distinto de un sensor que no reporta.
   */
  surfaceFlag: string | null;
  /** Hora de la lectura de superficie. */
  time: string | null;
}

export interface CenterStratification {
  /** T(5 m) − T(60 m) en °C. Medición, no modelo. */
  deltaTempC: number | null;
  surfaceTempC: number | null;
  deepTempC: number | null;
  /** Serie de ΔT en la ventana pedida, para el gráfico. */
  trend: number[];
  /** Lectura cualitativa del gradiente. */
  label: 'Fuerte' | 'Moderada' | 'Débil' | 'Sin dato';
}

export interface CenterSnapshot {
  center: MonitoredCenter;
  /** Instrumento que midió este centro, con su distancia a las jaulas. */
  buoy: ResolvedBuoy;
  readings: Record<string, CenterReading>;
  /** Serie de fluorescencia a 5 m — la señal de biomasa del centro. */
  chlorophyllTrend: number[];
  /** Instante (epoch ms) de cada valor de `chlorophyllTrend`, mismo orden. */
  chlorophyllTimes: number[];
  stratification: CenterStratification;
  /** Hora de la lectura más reciente del conjunto. */
  updatedAt: string | null;
}

/** Elige el nivel más próximo a una profundidad objetivo. */
function pickDepth<T extends { depthM: number | null }>(items: T[], target: number): T | undefined {
  const withDepth = items.filter((item) => item.depthM !== null);
  if (withDepth.length === 0) return undefined;
  return withDepth.reduce((best, item) =>
    Math.abs((item.depthM as number) - target) < Math.abs((best.depthM as number) - target)
      ? item
      : best,
  );
}

/** Sólo las lecturas con control de calidad bueno entran en una cifra de panel. */
const isGood = (point: AcsPoint) => point.flag.symbol === 'GOOD';

/**
 * Estado actual de la columna de agua de un centro.
 *
 * `hours` fija la ventana de las series. La API entrega una lectura por hora y
 * por sensor, y cada variable tiene dos sensores, así que se pide el doble.
 */
export async function fetchCenterSnapshot(
  centerId: string,
  hours = 72,
): Promise<SourceResult<CenterSnapshot>> {
  const center = getMonitoredCenter(centerId);
  if (!center) {
    return degraded<CenterSnapshot>(
      SOURCE_ID,
      'missing',
      null,
      null,
      `centro desconocido: ${centerId}`,
    );
  }

  const buoy = await resolveCenterBuoy(center);
  if (!buoy) {
    return missing<CenterSnapshot>(
      SOURCE_ID,
      `${center.name}: sin boya disponible a ${MAX_CENTER_SENSOR_DISTANCE_KM} km o menos`,
    );
  }
  const [latest, chlorophyll, temperature] = await Promise.all([
    fetchLatest(buoy.code, CENTER_VARIABLES),
    fetchSeries({ buoyCode: buoy.code, variableCode: 'fluorescence', limit: hours * 2 }),
    fetchSeries({ buoyCode: buoy.code, variableCode: 'water_temperature', limit: hours * 2 }),
  ]);

  return {
    state: worstProvenance([latest.state, chlorophyll.state, temperature.state]),
    data: assembleSnapshot(center, buoy, latest.data ?? [], chlorophyll.data?.levels ?? [], temperature.data?.levels ?? []),
    meta: {
      sourceId: SOURCE_ID,
      fetchedAt: new Date().toISOString(),
      ageMs: 0,
      note: buoyNote(center, buoy),
    },
  };
}

/** "Centro Reloncaví · boya acs1 a 28 km · concesión 103704". */
function buoyNote(center: MonitoredCenter, buoy: ResolvedBuoy): string {
  const where = buoy.assumed ? 'sin catálogo' : `a ${buoy.distanceKm} km`;
  return `${center.name} · boya ${buoy.code} ${where} · concesión ${center.concessionId}`;
}

/**
 * Estratificación medida: la diferencia entre las dos sondas de la misma boya.
 *
 * Es una resta entre dos termómetros reales a 5 y 60 m, no la salida de un modelo.
 * Los umbrales siguen la práctica del mar interior: por debajo de ~1 °C en 55 m de
 * columna la mezcla domina y la retención superficial que favorece una floración
 * deja de sostenerse.
 */
function buildStratification(
  levels: { depthM: number | null; points: AcsPoint[] }[],
): CenterStratification {
  const surface = pickDepth(levels, SURFACE_M);
  const deep = pickDepth(levels, DEEP_M);

  if (!surface || !deep || surface.depthM === deep.depthM) {
    return { deltaTempC: null, surfaceTempC: null, deepTempC: null, trend: [], label: 'Sin dato' };
  }

  // Las dos sondas comparten el reloj de la boya: se emparejan por hora para no
  // restar un instante contra otro cuando a una le falta una muestra.
  const deepByTime = new Map(deep.points.filter(isGood).map((point) => [point.time, point.value]));
  const trend: number[] = [];
  let lastSurface: number | null = null;
  let lastDeep: number | null = null;

  for (const point of surface.points.filter(isGood)) {
    const deepValue = deepByTime.get(point.time);
    if (deepValue === undefined) continue;
    trend.push(Number((point.value - deepValue).toFixed(2)));
    lastSurface = point.value;
    lastDeep = deepValue;
  }

  const deltaTempC = trend.length > 0 ? trend[trend.length - 1] : null;
  const label =
    deltaTempC === null
      ? 'Sin dato'
      : Math.abs(deltaTempC) >= 2
        ? 'Fuerte'
        : Math.abs(deltaTempC) >= 1
          ? 'Moderada'
          : 'Débil';

  return { deltaTempC, surfaceTempC: lastSurface, deepTempC: lastDeep, trend, label };
}


/**
 * Arma el estado de un centro a partir de sus lecturas. Lo comparten la carga propia
 * (`fetchCenterSnapshot`) y la derivada de la red de sensores
 * (`centerSnapshotFromSensors`): el panel lee lo mismo venga de donde venga.
 */
function assembleSnapshot(
  center: MonitoredCenter,
  buoy: ResolvedBuoy,
  latestValues: AcsLatestValue[],
  chlorophyllLevels: { depthM: number | null; points: AcsPoint[] }[],
  temperatureLevels: { depthM: number | null; points: AcsPoint[] }[],
): CenterSnapshot {
  const readings: Record<string, CenterReading> = {};
  for (const variableCode of CENTER_VARIABLES) {
    const forVariable = latestValues.filter((value) => value.variableCode === variableCode);
    const surface = pickDepth(forVariable, SURFACE_M);
    const deep = pickDepth(forVariable, DEEP_M);
    readings[variableCode] = {
      variableCode,
      unit: surface?.unit ?? deep?.unit ?? '',
      surface: surface?.value ?? null,
      deep: deep?.value ?? null,
      surfaceFlag: surface?.flag.symbol ?? null,
      time: surface?.time ?? deep?.time ?? null,
    };
  }

  const chlorophyllLevel = pickDepth(chlorophyllLevels, SURFACE_M);
  const chlorophyllPoints = (chlorophyllLevel?.points ?? []).filter(isGood);

  return {
    center,
    buoy,
    readings,
    chlorophyllTrend: chlorophyllPoints.map((p) => p.value),
    // El instante viaja con el valor: sin él, una serie de 72 h no se distingue de una de 72 días.
    chlorophyllTimes: chlorophyllPoints.map((p) => Date.parse(p.time)),
    stratification: buildStratification(temperatureLevels),
    updatedAt: readings.water_temperature?.time ?? null,
  };
}

/**
 * Lecturas que mira `fetchLatest` por sonda: pide 12 filas por variable, repartidas
 * entre dos sondas, es decir las últimas ~6 horas de cada una.
 */
const LATEST_LOOKBACK_POINTS = 6;

/**
 * El estado de un centro sin pedir nada: se deriva de su red de sensores, que ya trae
 * todas las sondas de la ventana. Mismas reglas que la carga propia —última lectura
 * buena de las recientes, o la más reciente con su flag; tendencia de clorofila con
 * lecturas buenas; estratificación emparejada por hora—, misma procedencia.
 */
export function centerSnapshotFromSensors(result: SourceResult<CenterSensors>): SourceResult<CenterSnapshot> {
  const sensors = result.data;
  // La boya es parte del dato: sin ella la red no se puede atribuir a nada y se
  // trata como si no hubiera llegado, en vez de romper a quien la lea.
  if (!sensors?.buoy) return { ...result, data: null };
  const latestValues: AcsLatestValue[] = sensors.channels.flatMap((channel) => {
    if (!CENTER_VARIABLES.includes(channel.variableCode)) return [];
    const recent = channel.points.slice(-LATEST_LOOKBACK_POINTS).reverse();
    const point = recent.find(isGood) ?? recent[0];
    if (!point) return [];
    return [{
      variableCode: channel.variableCode,
      unit: channel.unit,
      depthM: channel.depthM,
      instrumentCode: channel.instrumentCode,
      value: point.value,
      time: point.time,
      flag: point.flag,
    }];
  });
  const levelsOf = (variableCode: string) => sensors.channels.filter((channel) => channel.variableCode === variableCode);
  return {
    state: result.state,
    data: assembleSnapshot(sensors.center, sensors.buoy, latestValues, levelsOf('fluorescence'), levelsOf('water_temperature')),
    meta: { ...result.meta, note: buoyNote(sensors.center, sensors.buoy) },
  };
}

// ── Red de sondas de un centro ───────────────────────────────────────────────

/**
 * Variables que publican las dos sondas CTD de cada boya (5 m y 60 m). Verificado
 * el 2026-09-17 en acs1 y acs17a: las nueve reportan a la hora en ambas sondas.
 * El orden es el de lectura en pantalla: biomasa, columna física, oxígeno, resto.
 */
export const SENSOR_NETWORK_VARIABLES: AcsVariableCode[] = [
  'fluorescence',
  'water_temperature',
  'salinity',
  'density',
  'conductivity',
  'oxygen_conc',
  'oxygen_sat',
  'turbidity',
  'ph',
];

/** Instrumentos que son sondas de columna. El ADCP y la meteorología quedan fuera. */
const PROBE_INSTRUMENTS = new Set(['sonda_sup', 'sonda_prof']);

/** Un sensor físico: una variable a una profundidad, con su serie en la ventana. */
export interface SensorChannel {
  /** `boya:variable:sensor`, estable entre cargas. */
  id: string;
  sensorId: number;
  variableCode: AcsVariableCode;
  unit: string;
  depthM: number | null;
  /** `sonda_sup` o `sonda_prof`. */
  instrumentCode: string;
  /**
   * Lecturas de la ventana en orden cronológico, todas con su flag de IFOP. No se
   * filtran aquí: la vista decide qué dibuja y cómo declara lo que no es `GOOD`.
   */
  points: AcsPoint[];
}

export interface CenterSensors {
  center: MonitoredCenter;
  /** Instrumento que quedó midiendo este centro, con su distancia a las jaulas. */
  buoy: ResolvedBuoy;
  windowHours: number;
  channels: SensorChannel[];
}

/**
 * Todas las sondas de columna de un centro en una ventana. Cada variable se pide
 * por separado —la API sólo filtra por boya + variable— y una que falle no borra
 * las demás: el estado del conjunto es el peor de los que respondieron.
 */
export async function fetchCenterSensors(
  centerId: string,
  hours = 72,
): Promise<SourceResult<CenterSensors>> {
  const center = getMonitoredCenter(centerId);
  if (!center) return missing<CenterSensors>(SOURCE_ID, `centro desconocido: ${centerId}`);

  // La API no filtra por fecha: se piden lecturas desde la más reciente, una por hora
  // y por sensor. Temperatura suma el ADCP a las dos sondas: tres por hora; el resto,
  // dos. Verificado el 2026-09-17 contra pedir tres en todas: las 36 series son
  // idénticas lectura por lectura (72 h y 7 d), con un tercio menos de filas.
  const buoy = await resolveCenterBuoy(center);
  if (!buoy) {
    return missing<CenterSensors>(
      SOURCE_ID,
      `${center.name}: sin boya disponible a ${MAX_CENTER_SENSOR_DISTANCE_KM} km o menos`,
    );
  }
  const results = await Promise.all(
    SENSOR_NETWORK_VARIABLES.map((variableCode) =>
      fetchSeries({ buoyCode: buoy.code, variableCode, limit: hours * (variableCode === 'water_temperature' ? 3 : 2) }),
    ),
  );

  const channels: SensorChannel[] = [];
  for (const result of results) {
    const series = result.data;
    if (!series) continue;
    for (const level of series.levels) {
      if (!PROBE_INSTRUMENTS.has(level.instrumentCode) || level.points.length === 0) continue;
      // La ventana se corta por tiempo, no por cantidad: una sonda que perdió horas
      // no debe completar su ventana con lecturas más viejas.
      const newest = Date.parse(level.points[level.points.length - 1].time);
      const from = newest - hours * 3_600_000;
      channels.push({
        id: `${buoy.code}:${series.variableCode}:${level.sensorId}`,
        sensorId: level.sensorId,
        variableCode: series.variableCode,
        unit: series.unit,
        depthM: level.depthM,
        instrumentCode: level.instrumentCode,
        points: level.points.filter((point) => Date.parse(point.time) > from),
      });
    }
  }

  if (channels.length === 0) {
    return missing<CenterSensors>(SOURCE_ID, `${buoy.code}: ninguna sonda respondió`);
  }

  return {
    state: worstProvenance(results.map((result) => result.state)),
    data: { center, buoy, windowHours: hours, channels },
    meta: {
      sourceId: SOURCE_ID,
      fetchedAt: new Date().toISOString(),
      ageMs: 0,
      note: `${channels.length} sondas en ${buoy.code}${buoy.assumed ? '' : ` · a ${buoy.distanceKm} km`}`,
    },
  };
}
