// Cliente de la red ACS / SOTRACS de IFOP (acs.ifop.cl/api/v1), vía el proxy
// `/ds/acs` porque la API responde 200 pero sin cabecera CORS.
//
// Tres restricciones de la API, medidas el 2026-09-16 y no heredadas de nadie:
//
// 1. **`sensor_id` se ignora en silencio.** `/lecturas/?sensor_id=249` devuelve
//    las 60,5 millones de filas sin filtrar y con `count` intacto: el servidor no
//    protesta, simplemente no aplica el filtro. Lo que sí filtra es la pareja
//    `boya_code` + `variable_code`. Por eso cada respuesta se valida fila a fila
//    contra lo que se pidió: un filtro que no se aplica es peor que un error.
// 2. **No hay filtro por fecha.** La ventana se obtiene con `ordering=-time` y un
//    `limit`, leyendo desde la lectura más reciente hacia atrás.
// 3. **La profundidad no viaja en la lectura.** Hay que unirla por `sensor_id`
//    contra `/sensores/`, que sí acepta `boya_code` y `variable_code` y evita
//    paginar los 15.039 sensores.

import { fetchSource } from '../../core/fetchSource';
import { ALLOW_MOCK, proxyUrl } from '../../core/env';
import { worstProvenance } from '../../core/provenance';
import { degraded, mapResult, missing, type SourceResult } from '../../core/types';
import { buoys as mockBuoys, latest as mockLatest } from '../../mock/index';
import { resolveMooring } from './mooring';
import type {
  AcsBuoy,
  AcsFlag,
  AcsLatestValue,
  AcsLevel,
  AcsPoint,
  AcsReading,
  AcsSensor,
  AcsSeries,
  AcsVariableCode,
} from './types';

const SOURCE_ID = 'acs-sotracs';

/** Tope por petición. La API acepta `limit` alto en `lecturas`; se acota igual. */
const MAX_LIMIT = 5000;

interface Paged<T> {
  count: number;
  next: string | null;
  results: T[];
}

function asPaged<T>(raw: unknown, what: string): Paged<T> {
  const payload = raw as Partial<Paged<T>>;
  if (!payload || !Array.isArray(payload.results)) {
    throw new Error(`${what}: la respuesta no trae un arreglo "results"`);
  }
  return {
    count: typeof payload.count === 'number' ? payload.count : payload.results.length,
    next: payload.next ?? null,
    results: payload.results,
  };
}

function toFlag(row: Record<string, unknown>): AcsFlag {
  return {
    code: Number(row.flag ?? -1),
    symbol: String(row.flag_symbol ?? 'UNKNOWN'),
    description: String(row.legacy_flag_description ?? ''),
  };
}

// ── Boyas ────────────────────────────────────────────────────────────────────

/** Las 15 estaciones de la red, con su fondeo real (no el centro de la concesión). */
export function fetchBuoys(): Promise<SourceResult<AcsBuoy[]>> {
  return fetchSource<AcsBuoy[]>({
    sourceId: SOURCE_ID,
    label: 'ACS boyas',
    url: proxyUrl('acs', 'boyas/?limit=100'),
    snapshotFile: 'acs-buoys.json',
    mock: mockBuoys,
    parse: (raw) => {
      const paged = asPaged<Record<string, unknown>>(raw, 'boyas');
      if (paged.results.length === 0) throw new Error('boyas: red vacía');
      return paged.results.flatMap((row) => {
        const code = String(row.code);
        // IFOP ha publicado posiciones de relleno (ACS1 en -1, -1). Ver `mooring.ts`.
        const mooring = resolveMooring(code, Number(row.lat), Number(row.lon));
        if (!mooring) return [];
        return [{
          code,
          name: String(row.name ?? row.code),
          lat: mooring.lat,
          lon: mooring.lon,
          position: mooring.position,
          region: String(row.region ?? ''),
          operator: String(row.operator_name ?? ''),
          titular: String(row.titular_name ?? ''),
          active: Boolean(row.active),
          estatus: String(row.estatus ?? ''),
          instruments: Array.isArray(row.instruments)
            ? (row.instruments as Record<string, unknown>[]).map((item) => ({
                code: String(item.code),
                active: Boolean(item.active),
              }))
            : [],
        }];
      });
    },
  });
}

// ── Sensores (registro de profundidades) ─────────────────────────────────────

export interface SensorQuery {
  buoyCode: string;
  /**
   * Obligatorio, y no por comodidad de la API.
   *
   * `sensores` ignora `limit` —tope duro de 100 por página, paginación por `page`—
   * y una boya declara ~1.003 sensores, de los que unos 1.000 son celdas del ADCP.
   * Pedir sólo `boya_code` devuelve 100 filas, todas de ADCP, con `count: 1003` y
   * sin error: las sondas de 5 m y 60 m simplemente no aparecen. Con
   * `variable_code` el conjunto cae a tres filas y entra entero en una página.
   */
  variableCode: AcsVariableCode;
}

/**
 * El registro de profundidades es casi inmutable —cambia cuando se reinstala una
 * sonda— y cada serie lo necesita: sin caché, la mitad de las peticiones de un
 * ciclo de refresco eran este mismo registro. Se reutiliza unas horas; sólo se
 * guarda una respuesta viva, así un fallo se reintenta en la siguiente carga.
 */
const SENSOR_REGISTRY_TTL_MS = 6 * 60 * 60 * 1000;
const sensorRegistry = new Map<string, { at: number; result: Promise<SourceResult<AcsSensor[]>> }>();

/**
 * Registro de sensores de una boya para una variable. Comprobado el 2026-09-16:
 * acs1 + `water_temperature` devuelve 3 sensores, a 5 m (sonda_sup), 10 m (ADCP)
 * y 60 m (sonda_prof).
 */
export function fetchSensors(query: SensorQuery): Promise<SourceResult<AcsSensor[]>> {
  const key = `${query.buoyCode}:${query.variableCode}`;
  const cached = sensorRegistry.get(key);
  if (cached && Date.now() - cached.at < SENSOR_REGISTRY_TTL_MS) return cached.result;
  // Llamadas simultáneas (las nueve variables de una boya) comparten la misma petición.
  const result = requestSensors(query);
  sensorRegistry.set(key, { at: Date.now(), result });
  void result.then(
    (value) => {
      if (value.state !== 'live' || value.data === null) sensorRegistry.delete(key);
    },
    () => sensorRegistry.delete(key),
  );
  return result;
}

function requestSensors(query: SensorQuery): Promise<SourceResult<AcsSensor[]>> {
  const params = new URLSearchParams({
    boya_code: query.buoyCode,
    variable_code: query.variableCode,
  });

  return fetchSource<AcsSensor[]>({
    sourceId: SOURCE_ID,
    label: `ACS sensores ${query.buoyCode}`,
    url: proxyUrl('acs', `sensores/?${params}`),
    parse: (raw) => {
      const paged = asPaged<Record<string, unknown>>(raw, 'sensores');
      // Si el conjunto filtrado no cabe en una página, esta lectura es parcial y
      // el cruce de profundidad quedaría incompleto sin que nada fallara.
      if (paged.next !== null) {
        throw new Error(
          `sensores: ${query.buoyCode}/${query.variableCode} declara ${paged.count} sensores ` +
            'y no caben en una página; el cruce de profundidad sería parcial',
        );
      }
      const sensors = paged.results.map((row) => ({
        id: Number(row.id),
        buoyCode: String(row.boya_code),
        variableCode: String(row.variable_code),
        unit: String(row.variable_unit ?? ''),
        instrumentCode: String(row.instrument_code ?? ''),
        depthM: row.z === null || row.z === undefined ? null : Number(row.z),
        number: Number(row.number ?? 0),
        active: Boolean(row.active),
      }));
      return guardFilter(sensors, query, 'sensores');
    },
  });
}

/**
 * Descarta las filas que no corresponden a lo pedido y lo hace notar.
 *
 * Existe por el punto 1 de la cabecera: la API acepta parámetros que no aplica.
 * Si el filtro se cayó, la alternativa a esto es una serie que mezcla boyas sin
 * que nada falle.
 */
function guardFilter<T extends { buoyCode: string; variableCode: string }>(
  rows: T[],
  query: { buoyCode: string; variableCode?: string },
  what: string,
): T[] {
  const kept = rows.filter(
    (row) =>
      row.buoyCode === query.buoyCode &&
      (!query.variableCode || row.variableCode === query.variableCode),
  );
  if (kept.length === 0 && rows.length > 0) {
    throw new Error(
      `${what}: el proveedor ignoró el filtro (${rows.length} filas, ninguna de ` +
        `${query.buoyCode}${query.variableCode ? '/' + query.variableCode : ''})`,
    );
  }
  return kept;
}

// ── Lecturas ─────────────────────────────────────────────────────────────────

export interface SeriesQuery {
  buoyCode: string;
  variableCode: AcsVariableCode;
  /** Lecturas a traer, contadas desde la más reciente. Se reparten entre profundidades. */
  limit?: number;
}

/**
 * Serie reciente de una variable en una boya, ya separada por profundidad.
 *
 * Trae primero el registro de sensores porque la profundidad no viene en la
 * lectura: sin ese cruce, las series de 5 m y de 60 m llegan indistinguibles.
 */
export async function fetchSeries(query: SeriesQuery): Promise<SourceResult<AcsSeries>> {
  const sensors = await fetchSensors({
    buoyCode: query.buoyCode,
    variableCode: query.variableCode,
  });
  const depthBySensor = new Map<number, AcsSensor>(
    (sensors.data ?? []).map((sensor) => [sensor.id, sensor]),
  );

  const readings = await fetchReadings(query);

  return mapResult(readings, (rows) => {
    const levels = new Map<number, AcsLevel>();
    for (const row of rows) {
      const sensor = depthBySensor.get(row.sensorId);
      if (!levels.has(row.sensorId)) {
        levels.set(row.sensorId, {
          sensorId: row.sensorId,
          instrumentCode: sensor?.instrumentCode ?? 'desconocido',
          depthM: sensor?.depthM ?? null,
          points: [],
        });
      }
      const point: AcsPoint = { time: row.time, value: row.value, flag: row.flag };
      (levels.get(row.sensorId) as AcsLevel).points.push(point);
    }

    // La API entrega de la más reciente a la más antigua; una serie se lee al revés.
    for (const level of levels.values()) {
      level.points.reverse();
    }

    return {
      buoyCode: query.buoyCode,
      variableCode: query.variableCode,
      unit: sensors.data?.[0]?.unit ?? '',
      totalAvailable: rows.length,
      levels: [...levels.values()].sort(
        (a, b) => (a.depthM ?? Infinity) - (b.depthM ?? Infinity),
      ),
    };
  });
}

/** Lecturas crudas, de la más reciente hacia atrás. Sin unir profundidad. */
export function fetchReadings(query: SeriesQuery): Promise<SourceResult<AcsReading[]>> {
  const limit = Math.min(query.limit ?? 500, MAX_LIMIT);
  const params = new URLSearchParams({
    boya_code: query.buoyCode,
    variable_code: query.variableCode,
    ordering: '-time',
    limit: String(limit),
  });

  return fetchSource<AcsReading[]>({
    sourceId: SOURCE_ID,
    label: `ACS ${query.buoyCode}/${query.variableCode}`,
    url: proxyUrl('acs', `lecturas/?${params}`),
    parse: (raw) => {
      const paged = asPaged<Record<string, unknown>>(raw, 'lecturas');
      const rows: AcsReading[] = paged.results.map((row) => ({
        time: String(row.time),
        sensorId: Number(row.sensor_id ?? row.sensor),
        buoyCode: String(row.boya_code),
        variableCode: String(row.variable_code),
        value: Number(row.value),
        flag: toFlag(row),
        depthM: null,
      }));
      return guardFilter(rows, query as { buoyCode: string; variableCode: string }, 'lecturas').filter(
        (row) => Number.isFinite(row.value),
      );
    },
  });
}

// ── Estado actual de una boya ────────────────────────────────────────────────

/**
 * Última medición de cada variable pedida, por profundidad. Es la lectura que
 * alimenta una tarjeta de estado: un valor por sensor, con su hora y su flag.
 *
 * Las variables se piden en paralelo porque son consultas independientes; si una
 * cae, las demás siguen y el estado del bloque es el peor de los estados.
 */
export async function fetchLatest(
  buoyCode: string,
  variables: readonly AcsVariableCode[],
): Promise<SourceResult<AcsLatestValue[]>> {
  const results = await Promise.all(
    variables.map((variableCode) => fetchSeries({ buoyCode, variableCode, limit: 12 })),
  );

  const values: AcsLatestValue[] = [];
  for (const result of results) {
    const series = result.data;
    if (!series) continue;
    for (const level of series.levels) {
      // Se prefiere la última lectura que IFOP marca como buena. Si no hay
      // ninguna, se devuelve la más reciente con su flag real en vez de nada: el
      // consumidor necesita poder distinguir "este sensor no reporta" de "reporta
      // y el control de calidad del proveedor desconfía del valor". acs17a, por
      // ejemplo, lleva la salinidad entera en SUSPECT —36,7 PSU en superficie de
      // fiordo—, y eso es una avería que hay que poder ver, no un hueco.
      const ordered = [...level.points].reverse();
      const point = ordered.find((item) => item.flag.symbol === 'GOOD') ?? ordered[0];
      if (!point) continue;
      values.push({
        variableCode: series.variableCode,
        unit: series.unit,
        depthM: level.depthM,
        instrumentCode: level.instrumentCode,
        value: point.value,
        time: point.time,
        flag: point.flag,
      });
    }
  }

  // Ninguna variable dejó un valor con flag bueno: la boya no está diciendo nada
  // ahora mismo. Se baja al último escalón de la cascada, marcado como respaldo.
  if (values.length === 0) {
    if (!ALLOW_MOCK) {
      return missing<AcsLatestValue[]>(SOURCE_ID, `sin lecturas válidas en ${buoyCode}`);
    }
    return degraded(
      SOURCE_ID,
      'mock',
      mockLatest(buoyCode, variables as readonly string[]),
      null,
      `sin lecturas válidas en ${buoyCode}`,
    );
  }

  return {
    state: worstProvenance(results.map((result) => result.state)),
    data: values,
    meta: {
      sourceId: SOURCE_ID,
      fetchedAt: new Date().toISOString(),
      ageMs: 0,
      note: `${values.length} valores de ${variables.length} variables en ${buoyCode}`,
    },
  };
}
