// Posición de fondeo de una boya cuando el catálogo publica una imposible.
//
// El 30-09-2026 el catálogo de IFOP (`/boyas/`) publicó ACS1 en `-1, -1` —golfo
// de Guinea— mientras la boya seguía `operativa` y transmitiendo cada hora desde
// el Estuario de Reloncaví. Tomada al pie de la letra, esa coordenada movía la
// boya del mapa al ecuador y dejaba el Centro Reloncaví «a 8.700 km» de su boya
// de contexto. Las lecturas eran reales; sólo la posición estaba mal.
//
// Regla: una posición fuera del dominio de la red no es un fondeo, es un valor de
// relleno. Se reemplaza por el último fondeo verificado publicado por IFOP y el
// reemplazo viaja con la boya (`position`), para que la interfaz lo declare en
// vez de presentarlo como la posición informada hoy.
//
// Módulo puro, sólo tipos: la regla se prueba sin red.

/**
 * Dominio de la red ACS/SOTRACS: costa y fiordos de Chile, de Los Lagos a
 * Magallanes, con margen. Una boya fondeada no puede estar fuera de él.
 */
export const NETWORK_BOUNDS = { south: -57, north: -17, west: -80, east: -66 } as const;

/**
 * Último fondeo verificado de cada boya, tal como lo publicó IFOP en el catálogo
 * capturado el 2026-09-23T03:01Z (`public/datasource/acs-buoys.json`), antes del
 * cambio a `-1, -1`. Si una boya se re-fondea, el catálogo manda: esto sólo
 * entra cuando lo publicado no puede ser una posición.
 */
export const LAST_KNOWN_MOORING: Record<string, { lat: number; lon: number }> = {
  acs1: { lat: -41.6035, lon: -72.3264 },
  acs10a: { lat: -42.6457, lon: -73.5394 },
  acs11: { lat: -42.9221, lon: -73.588 },
  acs16: { lat: -42.3557, lon: -72.7814 },
  acs17a: { lat: -42.2872, lon: -72.4633 },
  acs18b: { lat: -44.152, lon: -73.543 },
  acs27: { lat: -45.6966, lon: -73.3652 },
  acs28b: { lat: -45.2949, lon: -73.2192 },
  acs32: { lat: -44.941, lon: -73.159 },
  acs34: { lat: -44.0531, lon: -73.1878 },
  acs43a: { lat: -51.8964, lon: -73.5117 },
  acs46: { lat: -51.9467, lon: -72.7758 },
  acs48: { lat: -52.1529, lon: -73.0293 },
  acs50b: { lat: -52.7722, lon: -72.4026 },
  acs51: { lat: -52.7982, lon: -73.3713 },
};
export const LAST_KNOWN_MOORING_AT = '2026-09-23';

export type MooringPosition =
  | { kind: 'catalogue' }
  /** El catálogo publicó una posición imposible; se usa el último fondeo verificado. */
  | { kind: 'last-known'; reportedLat: number; reportedLon: number; since: string };

export function isPlausibleMooring(lat: number, lon: number): boolean {
  return (
    Number.isFinite(lat) &&
    Number.isFinite(lon) &&
    lat >= NETWORK_BOUNDS.south &&
    lat <= NETWORK_BOUNDS.north &&
    lon >= NETWORK_BOUNDS.west &&
    lon <= NETWORK_BOUNDS.east
  );
}

/**
 * Posición con la que STRATOS ubica una boya. `null` si la publicada es imposible
 * y no hay fondeo verificado al que volver: una boya sin posición no se dibuja
 * ni se vincula, en lugar de ubicarse en un punto inventado.
 */
export function resolveMooring(
  code: string,
  lat: number,
  lon: number,
): { lat: number; lon: number; position: MooringPosition } | null {
  if (isPlausibleMooring(lat, lon)) return { lat, lon, position: { kind: 'catalogue' } };
  const known = LAST_KNOWN_MOORING[code];
  if (!known) return null;
  return {
    lat: known.lat,
    lon: known.lon,
    position: { kind: 'last-known', reportedLat: lat, reportedLon: lon, since: LAST_KNOWN_MOORING_AT },
  };
}
