// Qué boya mide cada centro de cultivo.
//
// Un centro es un sitio: las jaulas, ancladas donde están. Una boya es el
// instrumento que lo mide, y cuál sea no es una propiedad del centro — depende de
// qué haya fondeado y reportando hoy. Por eso el centro declara su posición y la
// boya se elige contra el catálogo vivo de la red.
//
// Esa separación es lo que permite decir a qué distancia está la medición de la
// jaula, que es la pregunta que decide si el número describe este centro o el
// cuerpo de agua de al lado. Antes el código de boya estaba escrito a mano junto
// al centro y esa distancia no existía en ninguna parte.
//
// El módulo es puro a propósito —sólo tipos importados— para que la regla de
// asignación se pueda probar sin red: es la decisión de la que cuelga todo lo
// que la interfaz muestra bajo el nombre de un centro.

import type { AcsBuoy } from './types.ts';

export interface MonitoredCenter {
  /** Identificador dentro de STRATOS. */
  id: string;
  /** Nombre del centro para pantalla. */
  name: string;
  /** Código de la concesión. */
  concessionId: number;
  titular: string;
  operator: string;
  region: string;
  /**
   * Dónde están las jaulas. Es el ancla de la búsqueda de boya y debe coincidir
   * con la posición del centro en el mapa (`CULTIVATION_CENTERS`); hay una prueba
   * que lo comprueba, porque son dos listas y con el tiempo se separan.
   */
  site: { lat: number; lon: number };
  /** Cuerpo de agua al que pertenece, para orientar en el mapa. */
  water: string;
  /**
   * Boya de contexto, declarada a mano, para un centro que no tiene ningún
   * instrumento dentro del radio operacional.
   *
   * No convierte la lectura en medición del sitio: se elige explícitamente, su
   * distancia real viaja hasta la interfaz y `context` dice por qué está. Es la
   * diferencia entre «no hay dato» y «hay dato del cuerpo de agua, a esta
   * distancia» — dos cosas distintas que antes se veían igual, porque sin boya
   * dentro del radio el centro quedaba mudo.
   *
   * El texto debe coincidir con `centro_ubicacion_modelo.relacion` en la base:
   * son dos listas y con el tiempo se separan.
   */
  contextBuoy?: { code: string; reason: string };
}

/** La boya que quedó asignada a un centro, con lo que hace falta para juzgarla. */
export interface ResolvedBuoy {
  code: string;
  name: string;
  /** Fondeo real que publica la API, no el centroide de la concesión. */
  lat: number;
  lon: number;
  /** Del fondeo a las jaulas. Es lo que separa la medición del sitio que describe. */
  distanceKm: number;
  /** `operativa`, `parcialmente_operativa`… tal como lo publica IFOP. */
  estatus: string;
  /** Compatibilidad con capturas antiguas; una asignación operacional siempre es `false`. */
  assumed: boolean;
  /**
   * Por qué se atribuyó una boya fuera del radio. Ausente en una asignación
   * operacional normal. Si viene, la interfaz **debe** declararlo: la lectura
   * describe el cuerpo de agua, no las jaulas.
   */
  context?: string;
}

/**
 * Límite operacional para atribuir una boya a un centro.
 *
 * Es un guardarraíl de representatividad espacial, no una equivalencia
 * oceanográfica: por encima de 15 km la interfaz deja el centro sin sensor en
 * vez de presentar una lectura regional como si proviniera de sus jaulas.
 */
export const MAX_CENTER_SENSOR_DISTANCE_KM = 15;

/** Los centros de cultivo con seguimiento en STRATOS, en el orden de la interfaz. */
export const MONITORED_CENTERS: MonitoredCenter[] = [
  {
    id: 'reloncavi',
    name: 'Centro Reloncaví',
    // Intersección espacial con polígono oficial SUBPESCA, OBJECTID 3818.
    // Concesión otorgada no demuestra operación actual; titular y arrendatario
    // son personas jurídicas distintas (Res. SUBPESCA 2021).
    concessionId: 101936,
    titular: 'SEA SALMON LTDA.',
    operator: 'Salmones Aysén S.A. (arrendatario 2021; vigencia por verificar)',
    region: 'Los Lagos',
    site: { lat: -41.7022, lon: -72.6374 },
    water: 'Estuario de Reloncaví',
    // La boya apta más cercana es ACS1, a 28,1 km: casi el doble del radio, así
    // que el centro queda sin sonda local. Esta boya es sólo contexto del
    // estuario: no pertenece al titular de esta concesión ni mide sus jaulas.
    contextBuoy: {
      code: 'acs1',
      reason: 'boya de contexto del estuario; no medición dentro del centro',
    },
  },
  {
    id: 'comau',
    // Corto a propósito: la cabecera de la tarjeta trunca por encima de ~18
    // caracteres, y "Centro Seno de Co…" no identifica nada.
    name: 'Centro Comau',
    concessionId: 102077,
    titular: 'Ventisqueros S.A.',
    operator: 'TEKFISH',
    region: 'Los Lagos',
    site: { lat: -42.2872, lon: -72.4633 },
    water: 'Seno de Comau',
  },
];

export function getMonitoredCenter(id: string): MonitoredCenter | null {
  return MONITORED_CENTERS.find((center) => center.id === id) ?? null;
}

/** Sondas de columna que hacen falta: sin las dos no hay perfil que leer. */
const COLUMN_PROBES = ['sonda_sup', 'sonda_prof'];

/**
 * Aproximación plana. A esta latitud y con distancias de decenas de kilómetros el
 * error frente a una gran-círculo es de metros: irrelevante para ordenar boyas.
 */
export function distanceKm(a: { lat: number; lon: number }, b: { lat: number; lon: number }): number {
  const meanLat = ((a.lat + b.lat) / 2) * (Math.PI / 180);
  return Math.hypot((a.lat - b.lat) * 111.32, (a.lon - b.lon) * 111.32 * Math.cos(meanLat));
}

/**
 * Una boya sirve si está activa y monta las dos sondas de columna.
 *
 * `estatus` NO entra en el filtro, a propósito. ACS17A está
 * `parcialmente_operativa` y es la que está fondeada en el Seno de Comau, a cero
 * kilómetros de las jaulas; descartarla mandaría ese centro a una boya sana a
 * 27 km, que es peor medición. El estatus viaja hasta la interfaz, que es donde
 * hay que declararlo.
 */
export function isBuoyAvailable(buoy: AcsBuoy): boolean {
  if (!buoy.active) return false;
  const active = new Set(buoy.instruments.filter((instrument) => instrument.active).map((instrument) => instrument.code));
  return COLUMN_PROBES.every((code) => active.has(code));
}

/**
 * La boya de un centro: la más cercana dentro del radio y, si no hay ninguna,
 * la de contexto que el centro declare.
 *
 * `nearestAvailableBuoy` se deja intacta a propósito. Es la regla de
 * representatividad espacial y sigue devolviendo `null` por encima del radio;
 * lo que cambia aquí es que un centro pueda declarar, a mano y con su motivo,
 * de qué agua quiere leer cuando no tiene instrumento propio. La distancia real
 * viaja igual, así que la interfaz nunca puede presentarla como medición del
 * sitio.
 */
export function resolveBuoyForCenter(
  buoys: AcsBuoy[],
  center: MonitoredCenter,
  maxDistanceKm = MAX_CENTER_SENSOR_DISTANCE_KM,
): ResolvedBuoy | null {
  const dentroDelRadio = nearestAvailableBuoy(buoys, center.site, maxDistanceKm);
  if (dentroDelRadio) return dentroDelRadio;
  if (!center.contextBuoy) return null;

  const declarada = buoys.find((buoy) => buoy.code === center.contextBuoy?.code);
  // Declarada pero ausente del catálogo, apagada o sin las sondas de columna:
  // no se inventa. Un centro mudo es mejor que uno que cita un instrumento que
  // hoy no mide.
  if (!declarada || !isBuoyAvailable(declarada)) return null;

  return {
    code: declarada.code,
    name: declarada.name,
    lat: declarada.lat,
    lon: declarada.lon,
    distanceKm: Number(distanceKm(center.site, { lat: declarada.lat, lon: declarada.lon }).toFixed(1)),
    estatus: declarada.estatus,
    assumed: false,
    context: center.contextBuoy.reason,
  };
}

/** La boya disponible más cercana a un punto, con su distancia. `null` si no hay ninguna. */
export function nearestAvailableBuoy(
  buoys: AcsBuoy[],
  site: { lat: number; lon: number },
  maxDistanceKm = Number.POSITIVE_INFINITY,
): ResolvedBuoy | null {
  let best: ResolvedBuoy | null = null;
  for (const buoy of buoys) {
    if (!isBuoyAvailable(buoy)) continue;
    const km = distanceKm(site, { lat: buoy.lat, lon: buoy.lon });
    if (km > maxDistanceKm) continue;
    if (best && km >= best.distanceKm) continue;
    best = {
      code: buoy.code,
      name: buoy.name,
      lat: buoy.lat,
      lon: buoy.lon,
      distanceKm: Number(km.toFixed(1)),
      estatus: buoy.estatus,
      assumed: false,
    };
  }
  return best;
}
