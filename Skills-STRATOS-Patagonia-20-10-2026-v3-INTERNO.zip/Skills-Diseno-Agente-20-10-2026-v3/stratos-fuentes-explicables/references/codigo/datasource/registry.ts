// Catálogo único de fuentes de STRATOS.
//
// Es el inventario que la interfaz puede mostrar y el que documenta, por fuente,
// cómo se llega a ella y qué se sabe de su comportamiento real. Los estados no
// son aspiracionales: salen de probar cada proveedor (`npm run ds:probe`).
//
// No importa nada de `server/`: ese módulo usa `node:http` y sólo corre en Node.
// La correspondencia entre `proxyId` aquí y las claves de `server/routes.mjs` la
// verifica `registry.test.ts`.

import type { DataKind, VariableId } from './core/variables';
import { applyHealth, type ComputedStatus } from './core/statusRules.ts';
// Generado por `npm run ds:health` a partir de datasource/health/history.jsonl.
import { SOURCE_HEALTH } from './health/sourceHealth.generated.ts';

export type Transport = 'direct' | 'proxy' | 'snapshot';

/**
 * Familia de la fuente: cómo la agrupa la vista técnica. No es lo mismo que
 * `kind` —observado, modelo, satelital—: una estación meteorológica y una boya son
 * ambas observación, pero pertenecen a mundos distintos y se buscan por separado.
 */
export type SourceFamily =
  | 'observation_ocean'
  | 'observation_atmosphere'
  | 'observation_hydrology'
  | 'ocean_model'
  | 'atmospheric_model'
  | 'hydrological_model'
  | 'satellite'
  | 'climate_index';
export type SourceStatus = 'verified' | 'unstable' | 'credentialed' | 'untested';

export interface SourceDefinition {
  /** Acquired research archive; never eligible for the operational resolver. */
  integrationScope?: 'laboratory';
  /** Identificador estable. Es el que viaja en `SourceResult.meta.sourceId`. */
  id: string;
  name: string;
  /** Organismo responsable del dato. */
  provider: string;
  transport: Transport;
  /** Clave en `server/routes.mjs` cuando `transport === 'proxy'`. */
  proxyId?: string;
  auth: 'none' | 'credentials';
  /** Base pública del proveedor, para trazabilidad y para el panel de estado. */
  upstream: string;
  /** Cada cuánto tiene sentido volver a preguntar, en segundos. */
  cadenceSec: number;
  /** Códigos nativos del proveedor. Se conservan tal cual los publica. */
  variables: string[];
  /**
   * Las mismas variables en el vocabulario canónico de STRATOS (`core/variables`).
   * Es lo que permite preguntar «quién me da nitrato» sin mirar nombres de API, y
   * lo que impide tratar como equivalentes cosas que no lo son.
   */
  provides: VariableId[];
  /** Observado, satelital, modelo o derivado. Condiciona cómo se puede leer el número. */
  kind: DataKind;
  family: SourceFamily;
  /**
   * Matiz de `kind` cuando importa para leer el dato: un reanálisis y un hindcast
   * son modelo, pero reconstruyen el pasado. ERA5 puede tener un conector
   * operativo y aun así su dato es reanálisis, no observación ni pronóstico.
   */
  dataNature?: 'reanalysis' | 'hindcast';
  /**
   * Tamaño de celda en metros. `null` cuando el dato es puntual (una boya, una
   * estación): un punto no tiene resolución espacial, y fingir una invita a
   * interpolarlo como si fuera un campo.
   */
  spatialResolutionM: number | null;
  /**
   * Resolución de variables concretas cuando NO es la de la fuente. Una fuente
   * declara la celda de su producto más fino, pero no todas sus variables llegan
   * a esa finura: en Ocean Colour la clorofila es de 620 m y el Kd490 y el SPM de
   * 4,6 km. Sin esto el catálogo afirmaba «SPM a 300 m», que es falso.
   */
  variableResolutionM?: Partial<Record<VariableId, number>>;
  /** Paso temporal nativo, legible: `horaria`, `diaria`, `mensual`, `por campaña`. */
  temporalResolution: string;
  /** Rango cubierto, cuando la fuente es histórica o tiene inicio conocido. */
  temporalCoverage?: { from: string; to: string };
  /**
   * Estado vigente. Se declara aquí como punto de partida y lo reemplaza el
   * calculado desde sondas (`health`) en cuanto hay evidencia suficiente.
   */
  status: SourceStatus;
  /** Lo que estaba escrito en el registro, cuando el estado vigente es calculado. */
  declaredStatus?: SourceStatus;
  /** Salud medida por el loop de sondas: disponibilidad, muestra y último dato. */
  health?: ComputedStatus;
  /** Lo que se midió al probarla, incluido lo que falla. */
  note: string;
  /** Archivo en public/datasource que la respalda, si lo hay. */
  snapshotFile?: string;
}

const HOUR = 3600;
const DAY = 24 * HOUR;

const DECLARED_SOURCES: SourceDefinition[] = [
  {
    id: 'era5-puelo-basin-archive', name: 'ERA5 · cuenca completa del Puelo', provider: 'ECMWF · Open-Meteo',
    integrationScope: 'laboratory', transport: 'snapshot', auth: 'none',
    upstream: 'https://open-meteo.com/en/docs/historical-weather-api', cadenceSec: 365 * DAY,
    variables: ['precipitation_sum', 'temperature_2m_mean', 'et0_fao_evapotranspiration'],
    provides: ['precipitation', 'airTemperature', 'referenceEvapotranspiration'], kind: 'model',
    dataNature: 'reanalysis', family: 'atmospheric_model', spatialResolutionM: 27780,
    temporalResolution: 'diaria · promedio de 27 celdas',
    temporalCoverage: { from: '2021-01-01', to: '2026-10-04' }, status: 'verified',
    snapshotFile: 'era5-puelo-areal-2021-2026.json',
    note: 'Archivo adquirido el 12 oct 2026, con models=era5. Promedio de las 27 celdas que ' +
      'intersectan el polígono CAMELS del Puelo, ponderadas por área; cada celda se conserva. ' +
      'ET0 FAO56 separada de PET Hargreaves. Captura de laboratorio: no es pronóstico histórico emitido ni conector vivo.',
  },
  {
    id: 'camels-cl-puelo-flow', name: 'CAMELS-CL · caudal Puelo', provider: 'CR2 · DGA',
    integrationScope: 'laboratory', transport: 'snapshot', auth: 'none',
    upstream: 'https://www.cr2.cl/camels-cl/', cadenceSec: 365 * DAY,
    variables: ['q_m3s_day'], provides: ['riverDischarge'], kind: 'observed',
    family: 'observation_hydrology', spatialResolutionM: null, temporalResolution: 'diaria',
    temporalCoverage: { from: '2003-03-02', to: '2020-06-06' }, status: 'verified',
    snapshotFile: 'camels-puelo.json',
    note: 'Archivo CAMELS-CL v202201 adquirido y congelado el 12 oct 2026. Aforo 10523002: ' +
      '6.039 días válidos. Se utiliza para investigación y contraste; no entrega caudal en vivo.',
  },
  {
    id: 'camels-cl-puelo-basin', name: 'CR2MET · cuenca del Puelo', provider: 'CR2 · CAMELS-CL',
    integrationScope: 'laboratory', transport: 'snapshot', auth: 'none',
    upstream: 'https://www.cr2.cl/camels-cl/', cadenceSec: 365 * DAY,
    variables: ['precip_cr2met_mm_day', 'tmean_cr2met_C_day', 'pet_hargreaves_mm_day'],
    provides: ['precipitation', 'airTemperature', 'potentialEvapotranspiration'], kind: 'model',
    dataNature: 'reanalysis', family: 'atmospheric_model', spatialResolutionM: null,
    temporalResolution: 'diaria · promedio de cuenca',
    temporalCoverage: { from: '1979-01-01', to: '2020-04-30' }, status: 'verified',
    snapshotFile: 'camels-puelo.json',
    note: '15.096 días de precipitación, temperatura y PET areales. Cuenca publicada de ' +
      '8.856,36 km² y polígono adquirido; no es una estación puntual. PET Hargreaves no es ET0 FAO56. ' +
      'El archivo descargado no contiene SWE: la nieve del experimento es un estado modelado.',
  },
  {
    id: 'mprwq-puelo', name: 'Nutrientes fluviales · Puelo', provider: 'CIEP · MPRWQ',
    integrationScope: 'laboratory', transport: 'snapshot', auth: 'none',
    upstream: 'https://zenodo.org/records/16422064', cadenceSec: 365 * DAY,
    variables: ['N-NH4+', 'N-NOx', 'dSi', 'Temp'],
    provides: ['ammonium', 'oxidizedNitrogen', 'silicate', 'waterTemperature'], kind: 'observed',
    family: 'observation_hydrology', spatialResolutionM: null, temporalResolution: 'por muestreo',
    temporalCoverage: { from: '2022-03-20', to: '2024-08-08' }, status: 'verified',
    snapshotFile: 'river-chemistry-puelo.json',
    note: 'Archivo público adquirido con unidades y límites de detección. N-NOx suma nitrato ' +
      'y nitrito: no es nitrato separado. N-NH4 está expresado como N; dSi como ácido ortosilícico. ' +
      'Excluir intrusión marina y conservar censura analítica. El README describe 2022–2023, ' +
      'pero la hoja contiene fechas de 2024: se conservan con una marca de discrepancia. No representa química fluvial actual.',
  },
  {
    id: 'marine-physics-scm-archive', name: 'Frontera oceánica · archivo físico', provider: 'Copernicus Marine · GLORYS',
    integrationScope: 'laboratory', transport: 'snapshot', auth: 'credentials',
    upstream: 'https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_PHY_001_030', cadenceSec: 365 * DAY,
    variables: ['so', 'thetao'], provides: ['salinity', 'waterTemperature'], kind: 'model',
    dataNature: 'reanalysis', family: 'ocean_model', spatialResolutionM: 9260, temporalResolution: 'diaria',
    temporalCoverage: { from: '2003-01-01', to: '2025-12-31' }, status: 'verified',
    snapshotFile: 'marine-physics.nc',
    note: '8.401 días adquiridos para el laboratorio, con 21 niveles hasta 80 m. Promedio regional ' +
      'para una frontera modelada; no mide el interior del fiordo ni sustituye perfiles CTD locales.',
  },
  {
    id: 'marine-bgc-scm-archive', name: 'Frontera oceánica · nutrientes', provider: 'Copernicus Marine · BGC',
    integrationScope: 'laboratory', transport: 'snapshot', auth: 'credentials',
    upstream: 'https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_BGC_001_029', cadenceSec: 365 * DAY,
    variables: ['no3', 'si', 'chl'], provides: ['nitrate', 'silicate', 'chlorophyll'], kind: 'model',
    dataNature: 'reanalysis', family: 'ocean_model', spatialResolutionM: 27780, temporalResolution: 'diaria',
    temporalCoverage: { from: '2003-01-01', to: '2025-12-31' }, status: 'verified',
    snapshotFile: 'marine-nutrients.nc',
    note: '8.401 días adquiridos con 22 niveles. Nitrato y silicato modelados en mmol/m³, ' +
      'clorofila en mg/m³. Frontera regional de laboratorio; no identifica especies ni valida biomasa local.',
  },
  {
    id: 'acs-sotracs',
    name: 'Red ACS / SOTRACS',
    provider: 'IFOP',
    transport: 'proxy',
    proxyId: 'acs',
    auth: 'none',
    upstream: 'https://acs.ifop.cl/api/v1',
    cadenceSec: 15 * 60,
    variables: [
      'water_temperature',
      'salinity',
      'oxygen_conc',
      'oxygen_sat',
      'fluorescence',
      'turbidity',
      'density',
      'ph',
      'conductivity',
    ],
    provides: [
      'waterTemperature', 'salinity', 'dissolvedOxygen', 'oxygenSaturation',
      'fluorescence', 'turbidity', 'density', 'ph', 'conductivity',
    ],
    kind: 'observed',
    family: 'observation_ocean',
    // Boyas fondeadas: el dato es del punto, no de un área.
    spatialResolutionM: null,
    temporalResolution: 'cada 15 min',
    status: 'verified',
    note:
      'La única fuente observada in situ y de alta frecuencia de los fiordos: 15 boyas, ' +
      '15.039 sensores, 59,7M de lecturas. Responde 200 sin cabecera CORS, de ahí el proxy. ' +
      'La API no admite filtro por fecha: sólo ordering=time + offset.',
    snapshotFile: 'acs-sotracs.json',
  },
  {
    id: 'chonos-mosa',
    name: 'CHONOS5 / MOSA',
    provider: 'IFOP · Meteodata',
    transport: 'proxy',
    proxyId: 'chonos',
    auth: 'none',
    upstream: 'https://chonos5.meteodata.cl',
    cadenceSec: 6 * HOUR,
    variables: [
      'chonos_water_temp_c',
      'chonos_salinity_psu',
      'chonos_current_u_ms',
      'chonos_current_v_ms',
      'chonos_sea_level_m',
      'chonos_wind_u_10m_ms',
      'chonos_wind_v_10m_ms',
      'chonos_precip_rate',
    ],
    provides: ['waterTemperature', 'salinity', 'currentU', 'currentV', 'seaLevel', 'windU', 'windV', 'precipitation'],
    kind: 'model',
    family: 'ocean_model',
    // CROCO ~1 km en Chiloé y ~3 km en Magallanes; se declara el caso fino.
    spatialResolutionM: 1000,
    temporalResolution: 'horaria, 72 h de pronóstico',
    // Verificada el 18-09-2026 (validation/evidence/02-fuentes.json, probe-now.json):
    // 5/5 lecturas de T y S vigentes; la sonda marcaba PARTIAL sólo por el TLS.
    status: 'verified',
    note:
      'Pronóstico acoplado CROCO + WRF. El handshake TLS falla contra el almacén local, ' +
      'así que el proxy reintenta sin verificar la cadena y lo declara en la cabecera: ' +
      'es una salvedad del certificado, no una caída del servicio. ' +
      'MOSA nunca es histórico: cada fila lleva hora de emisión y lead.',
  },
  {
    id: 'chonos-redmet',
    name: 'CHONOS REDMET',
    provider: 'IFOP',
    transport: 'snapshot',
    snapshotFile: 'redmet-live.json',
    proxyId: 'chonos-redmet',
    auth: 'none',
    upstream: 'https://chonos.ifop.cl/met2/api2',
    cadenceSec: HOUR,
    variables: ['Temperature', 'WindSpeed', 'WindDirection', 'GustSpeed', 'Rain', 'SolarRadiation', 'RH', 'Pressure'],
    provides: ['airTemperature', 'windU', 'windV', 'precipitation'],
    kind: 'observed',
    family: 'observation_atmosphere',
    spatialResolutionM: null,
    temporalResolution: 'registros originales de 10 minutos; captura horaria',
    status: 'unstable',
    note:
      'Observaciones IFOP descargadas y archivadas por el servidor cada hora. ' +
      'Vigencia por variable; no informa QC. El catálogo histórico no equivale a una lectura actual.',
  },
  {
    id: 'ifop-websig',
    name: 'IFOP WebSIG — AR fiordos',
    provider: 'IFOP',
    transport: 'direct',
    auth: 'none',
    upstream: 'https://sig-acuicultura.ifop.cl/geoserver/ows',
    cadenceSec: DAY,
    variables: [
      'alexandrium_ar',
      'dinophysis_acuminata_ar',
      'dinophysis_acuta_ar',
      'pseudo_nitzschia_seriata_ar',
      'ifop_temperature_5m_c',
      'ifop_salinity_5m_psu',
      'ifop_chlorophyll_5m',
      'ifop_oxygen_5m_ml_l',
    ],
    provides: ['speciesAbundance', 'waterTemperature', 'salinity', 'chlorophyll', 'dissolvedOxygen'],
    kind: 'observed',
    family: 'observation_ocean',
    spatialResolutionM: null,
    temporalResolution: 'por campaña de muestreo',
    // Medido sobre los 21.102 registros (validation/evidence/08-websig-fechas.json).
    // El fin lo mantiene al día la sonda: `latestDataAt` de datasource/health.
    temporalCoverage: { from: '2000-09-05', to: '2026-08-12' },
    status: 'verified',
    note:
      'GeoServer WFS con 21.102 registros geolocalizados de abundancia relativa por estación. ' +
      'Emite `Access-Control-Allow-Origin: *`, así que el navegador llega directo. ' +
      'Se sigue publicando: la muestra más reciente es del 12-08-2026 (1.696 registros en ' +
      '2026). Antes se la dio por histórica con fin en 2022 porque FECHA_MUESTREO es texto ' +
      'dd-mm-aaaa y se tomó un registro cualquiera como «último». Es muestreo por campaña: ' +
      'cada dato lleva su fecha y la interfaz la muestra; no es una lectura de hoy. ' +
      'Antes de 2018 hay sólo 7 registros sueltos.',
  },
  {
    id: 'subpesca-marearoja',
    name: 'Monitoreo de marea roja — cruceros',
    provider: 'SUBPESCA',
    transport: 'proxy',
    proxyId: 'subpesca',
    auth: 'none',
    upstream:
      'https://geoportal.subpesca.cl/server/rest/services/IDE_PUBLICO/SRMPUB_MAREAROJA/MapServer',
    cadenceSec: 6 * HOUR,
    variables: [
      'ARALEXCATE',
      'ARALEXOSTE',
      'ARDINOACUM',
      'ARDINOACUT',
      'ARPROTRETI',
      'ARPSEUAUST',
      'ARPSEUPSEU',
    ],
    provides: ['speciesAbundance'],
    kind: 'observed',
    family: 'observation_ocean',
    spatialResolutionM: null,
    temporalResolution: 'por crucero',
    status: 'verified',
    note:
      'Pese al nombre del servicio, no publica áreas de restricción: publica las estaciones ' +
      'de cada crucero con abundancia relativa por taxón. Es la contraparte de SUBPESCA al ' +
      'registro de IFOP —otra grilla, otro organismo, el mismo fenómeno— y por eso se ' +
      'mantienen separadas en vez de promediarse.',
  },
  {
    id: 'open-meteo-marine',
    name: 'Open-Meteo Marine',
    provider: 'Open-Meteo',
    transport: 'direct',
    auth: 'none',
    upstream: 'https://marine-api.open-meteo.com/v1/marine',
    cadenceSec: HOUR,
    variables: [
      'sea_surface_temperature',
      'wave_height',
      'wave_period',
      'ocean_current_velocity',
      'sea_level_height_msl',
    ],
    provides: ['waterTemperature', 'currentU', 'currentV', 'seaLevel'],
    kind: 'model',
    family: 'ocean_model',
    spatialResolutionM: 9000,
    temporalResolution: 'horaria',
    status: 'verified',
    note:
      'Ya en uso por src/lib/stratos. Cuota horaria ajustada: el refresco se mantiene ' +
      'en una hora a propósito.',
  },
  {
    id: 'open-meteo-forecast',
    name: 'Open-Meteo Forecast y Ensemble',
    provider: 'Open-Meteo',
    transport: 'direct',
    auth: 'none',
    upstream: 'https://api.open-meteo.com/v1/forecast',
    cadenceSec: HOUR,
    variables: ['temperature_2m', 'precipitation', 'wind_speed_10m', 'shortwave_radiation'],
    provides: ['airTemperature', 'precipitation', 'windU', 'windV', 'shortwaveRadiation'],
    kind: 'model',
    family: 'atmospheric_model',
    spatialResolutionM: 11000,
    temporalResolution: 'horaria',
    status: 'verified',
    note: 'Sostiene el fan de 30 días y los horizontes tácticos de 14 y 7.',
  },
  {
    // El ensemble GEFS es su propio contrato, no una variante de `forecast`:
    // otra URL base, otra cadencia y —lo que importa— miembros, no un valor
    // único. El índice FAN se puntúa POR MIEMBRO y sólo después se agrega
    // (src/lib/stratos/domain/forecast.ts), así que confundirlos colapsaría la
    // incertidumbre justo donde se necesita.
    id: 'open-meteo-ensemble',
    name: 'GEFS vía Open-Meteo (ensemble)',
    provider: 'Open-Meteo',
    transport: 'direct',
    auth: 'none',
    upstream: 'https://ensemble-api.open-meteo.com/v1/ensemble',
    cadenceSec: 6 * HOUR,
    variables: [
      'temperature_2m_max',
      'wind_speed_10m_max',
      'shortwave_radiation_sum',
      'precipitation_sum',
    ],
    provides: ['airTemperature', 'windU', 'shortwaveRadiation', 'precipitation'],
    kind: 'model',
    family: 'atmospheric_model',
    spatialResolutionM: 55000,
    temporalResolution: 'diaria',
    status: 'verified',
    note:
      'Temperatura del AIRE, no del agua: es la entrada meteorológica del índice ' +
      'FAN, no una medición del mar. Modelo gfs05, 31 miembros, hasta 35 días.',
  },
  {
    id: 'noaa-erddap-chla',
    name: 'Clorofila VIIRS diaria',
    provider: 'NOAA CoastWatch',
    transport: 'proxy',
    proxyId: 'erddap',
    auth: 'none',
    upstream: 'https://coastwatch.noaa.gov/erddap/griddap/noaacwNPPVIIRSSQchlaDaily',
    cadenceSec: DAY,
    variables: ['chlor_a'],
    provides: ['chlorophyll'],
    kind: 'satellite',
    family: 'satellite',
    spatialResolutionM: 750,
    temporalResolution: 'diaria, con ~10 días de latencia',
    status: 'verified',
    note: 'ERDDAP sirve .json con subconjunto por caja y fecha. Proxy por prudencia con CORS.',
  },
  {
    id: 'climate-indices',
    name: 'Índices climáticos ONI · SOI · PDO · AAO',
    provider: 'NOAA CPC / NCEI',
    transport: 'proxy',
    proxyId: 'noaa-cpc',
    auth: 'none',
    upstream: 'https://www.cpc.ncep.noaa.gov/data/indices/oni.ascii.txt',
    cadenceSec: DAY,
    variables: ['oni', 'soi', 'pdo', 'aao'],
    provides: [],
    kind: 'derived',
    family: 'climate_index',
    // Índices globales: no tienen celda, son una serie escalar por mes.
    spatialResolutionM: null,
    temporalResolution: 'mensual',
    status: 'verified',
    note: 'Texto plano de ancho fijo. ONI, SOI y AAO del CPC; PDO ERSSTv5 de NCEI (desde el 11-10-2026: la del PSL dejó de actualizarse en ago-2025). Es el contexto interanual del que cuelga la anomalía local.',
  },
  {
    id: 'shoa-cendhoc',
    name: 'CENDHOC — corrientes, CTD y nivel del mar',
    provider: 'SHOA',
    transport: 'proxy',
    proxyId: 'shoa',
    auth: 'none',
    upstream: 'https://cendhoc.shoa.cl',
    cadenceSec: 12 * HOUR,
    variables: ['corrientes', 'ctd', 'nivel_del_mar'],
    provides: ['currentU', 'currentV', 'waterTemperature', 'salinity', 'seaLevel'],
    kind: 'observed',
    family: 'observation_ocean',
    spatialResolutionM: null,
    temporalResolution: 'por campaña',
    status: 'untested',
    note: 'Catálogo hidrográfico. Sin CORS; el alcance real de la API se fija al probarla.',
  },
  {
    id: 'copernicus-marine',
    name: 'Copernicus Marine · física global',
    provider: 'CMEMS',
    transport: 'snapshot',
    auth: 'credentials',
    upstream: 'https://data.marine.copernicus.eu',
    cadenceSec: DAY,
    // Sólo física: la biogeoquímica es otra fuente (`copernicus-bgc`) con otro producto.
    variables: ['thetao', 'so', 'uo', 'vo', 'zos'],
    provides: ['waterTemperature', 'salinity', 'currentU', 'currentV', 'seaLevel'],
    kind: 'model',
    family: 'ocean_model',
    // 1/12° ≈ 9 km. Física de columna de agua como contexto regional.
    spatialResolutionM: 9000,
    temporalResolution: 'horaria',
    status: 'verified',
    note:
      'Física global del análisis y pronóstico (GLOBAL_ANALYSISFORECAST_PHY_001_024). Se ingesta ' +
      'con el toolbox `copernicusmarine` desde `jobs/ingest_copernicus.py`, recortado al dominio ' +
      'de Patagonia norte; las credenciales viven en el servidor. ' +
      'OJO con el dataset: el DIARIO `cmems_mod_glo_phy_anfc_0.083deg_P1D-m` NO trae temperatura, ' +
      'salinidad ni corrientes —sólo nivel del mar, hielo y variables de fondo—. Las cinco ' +
      'variables de estado salen del HORARIO `..._PT1H-m`, verificado el 17-09-2026.',
    snapshotFile: 'copernicus-glorys.json',
  },
  {
    id: 'era5-cds',
    name: 'ERA5 — reanálisis atmosférico',
    provider: 'Copernicus CDS',
    transport: 'snapshot',
    auth: 'credentials',
    upstream: 'https://cds.climate.copernicus.eu/api',
    cadenceSec: DAY,
    variables: ['t2m', 'u10', 'v10', 'ssr', 'tp', 'msl'],
    provides: ['airTemperature', 'windU', 'windV', 'shortwaveRadiation', 'precipitation'],
    kind: 'model',
    family: 'atmospheric_model',
    dataNature: 'reanalysis',
    spatialResolutionM: 31000,
    temporalResolution: 'horaria',
    status: 'verified',
    note:
      'ERA5 horario en niveles simples, 1940 al presente, 0,25°. Se ingesta server-side con la ' +
      'API del Climate Data Store desde `jobs/ingest_copernicus.py`: el navegador nunca habla ' +
      'con el CDS. Publica con ~5 días de latencia, así que el conector pide una fecha ya ' +
      'disponible. Es REANÁLISIS, no observación: el conector puede ser operativo porque el ' +
      'dataset se actualiza a diario, pero la naturaleza del dato sigue siendo reanálisis.',
    snapshotFile: 'era5.json',
  },
  {
    id: 'open-meteo-flood',
    name: 'Caudal de ríos — GloFAS',
    provider: 'Copernicus EMS · Open-Meteo',
    transport: 'direct',
    auth: 'none',
    upstream: 'https://flood-api.open-meteo.com/v1/flood',
    cadenceSec: DAY,
    variables: ['river_discharge'],
    provides: ['riverDischarge'],
    kind: 'model',
    family: 'hydrological_model',
    spatialResolutionM: 5000,
    temporalResolution: 'diaria',
    status: 'verified',
    note:
      'Caudal diario modelado por GloFAS v4, con 31 días de historia y 7 de pronóstico. ' +
      'Emite CORS `*` y no pide credenciales. Es un modelo global, no un aforo: la cifra es ' +
      'una estimación de descarga y la interfaz debe decirlo. Sustituye a la DGA como fuente ' +
      'viva porque la DGA no publica una API estable y el ZIP de CR2 termina en 2018.',
    snapshotFile: 'river-discharge.json',
  },
  {
    id: 'cr2-dga',
    name: 'Caudales diarios DGA — histórico',
    provider: 'CR2 · DGA',
    transport: 'snapshot',
    auth: 'none',
    upstream: 'https://www.cr2.cl/datos-de-caudales/',
    cadenceSec: 7 * DAY,
    variables: ['caudal_diario_m3s'],
    provides: ['riverDischarge'],
    kind: 'observed',
    family: 'observation_hydrology',
    spatialResolutionM: null,
    temporalResolution: 'diaria',
    temporalCoverage: { from: '1900-01-01', to: '2018-12-31' },
    status: 'verified',
    note:
      'ZIP nacional de decenas de MB cuya serie termina en 2018: sirve para contrastar el ' +
      'histórico aforado, nunca para decir el caudal de esta semana. Para eso está ' +
      '`open-meteo-flood`.',
    snapshotFile: 'cr2-flows.json',
  },

  // ── Copernicus: observación satelital y biogeoquímica ─────────────────────
  //
  // Las tres entradas siguientes llegan por snapshot y con credenciales. La
  // descarga gridded NO vive en este repositorio: la hace el pipeline de
  // STRATOS-Architecture y aqui solo se lee su recorte. Los identificadores de
  // producto y dataset se verificaron contra el catalogo STAC publico de CMEMS
  // el 17-09-2026; son los que ese pipeline debe pedir.
  {
    id: 'copernicus-olci-300m',
    // El id conserva el nombre del dataset CMEMS («olci-300m»); la malla real no es de 300 m.
    name: 'Ocean Colour OLCI · Sentinel-3',
    provider: 'CMEMS · Copernicus-GlobColour',
    transport: 'snapshot',
    auth: 'credentials',
    upstream: 'https://data.marine.copernicus.eu/product/OCEANCOLOUR_GLO_BGC_L3_NRT_009_101',
    cadenceSec: DAY,
    variables: [
      // cmems_obs-oc_glo_bgc-plankton_nrt_l3-olci-300m_P1D
      'CHL', 'CHL_uncertainty', 'flags',
      // cmems_obs-oc_glo_bgc-reflectance_nrt_l3-olci-300m_P1D
      'RRS400', 'RRS412', 'RRS443', 'RRS490', 'RRS510', 'RRS560',
      'RRS620', 'RRS665', 'RRS674', 'RRS681', 'RRS709',
    ],
    provides: ['chlorophyll', 'remoteSensingReflectance', 'diffuseAttenuation', 'suspendedMatter'],
    // Atributo `grid_resolution` del dataset `transp_nrt_l3-multi-4km`: 4,638 km (1/24°).
    variableResolutionM: { diffuseAttenuation: 4640, suspendedMatter: 4640 },
    kind: 'satellite',
    family: 'satellite',
    // Medido el 18-09-2026 en el atributo `grid_resolution` del propio dataset:
    // 0,618 km, malla de 1/180° (618 m N-S × 463 m E-O en Reloncaví). «300 m» es
    // la resolución del sensor OLCI; el L3 NRT que publica CMEMS está binneado a
    // 1/180°. Declarar 300 m prometía un detalle que el producto no tiene.
    spatialResolutionM: 620,
    temporalResolution: 'diaria (L3)',
    status: 'verified',
    note:
      'Capa principal de color del oceano para el Seno de Reloncavi y el Mar Interior. ' +
      'Los datasets «olci-300m» del catalogo NRT son DOS: `plankton` (CHL) y `reflectance` ' +
      '(11 bandas Rrs), y su malla real es de 1/180° (~620 m; el 300 m es el del sensor). ' +
      'Kd490, profundidad de Secchi, turbidez y las IOP existen unicamente a 4,6 km, asi ' +
      'que para esas variables NO hay producto fino que usar: hay que declararlo, no ' +
      'sustituirlo. Tampoco hay grupos funcionales en la malla fina. ' +
      'Se ingesta como compuesto de 5 dias por pixel: cada celda es la ultima observacion ' +
      'valida y lleva su edad; no se promedian dias. ' +
      'Cada variable trae su `_uncertainty` y un campo `flags` que es el QA/QC del ' +
      'proveedor: se conservan, porque sin ellos un pixel costero no es interpretable.',
    snapshotFile: 'copernicus-olci-300m.json',
  },
  {
    id: 'copernicus-bgc',
    name: 'Biogeoquímica global · análisis y pronóstico',
    provider: 'CMEMS',
    transport: 'snapshot',
    auth: 'credentials',
    upstream: 'https://data.marine.copernicus.eu/product/GLOBAL_ANALYSISFORECAST_BGC_001_028',
    cadenceSec: DAY,
    variables: [
      'no3', 'po4', 'si', 'fe',
      'o2', 'nppv',
      'ph', 'dissic', 'talk',
      'chl', 'phyc',
      'zooc',
    ],
    provides: [
      'nitrate', 'phosphate', 'silicate', 'dissolvedOxygen', 'primaryProduction',
      'ph', 'alkalinity', 'dissolvedInorganicCarbon', 'chlorophyll', 'phytoplanktonCarbon',
      'diffuseAttenuation',
    ],
    kind: 'model',
    family: 'ocean_model',
    // 0.25 grados es ~25 km. Unica fuente de nutrientes, y tambien la mas gruesa.
    spatialResolutionM: 25000,
    temporalResolution: 'diaria y mensual',
    status: 'verified',
    note:
      'Unica fuente de nitrato, fosfato, silicato, pH, alcalinidad y carbono inorganico ' +
      'del sistema: ninguna otra integracion los entrega. A 0,25 grados una celda cubre el ' +
      'Seno de Reloncavi entero, asi que es CONTEXTO REGIONAL y de columna de agua, nunca ' +
      'microescala costera, y no debe interpolarse para aparentar detalle. Es un modelo, ' +
      'no una medicion: los nutrientes son estimados, no aforados.',
    snapshotFile: 'copernicus-bgc.json',
  },
  {
    id: 'copernicus-bgc-hindcast',
    name: 'Biogeoquímica global · hindcast multianual',
    provider: 'CMEMS',
    transport: 'snapshot',
    auth: 'credentials',
    upstream: 'https://data.marine.copernicus.eu/product/GLOBAL_MULTIYEAR_BGC_001_029',
    cadenceSec: 7 * DAY,
    variables: ['chl', 'no3', 'po4', 'si', 'o2', 'nppv'],
    provides: [
      'chlorophyll', 'nitrate', 'phosphate', 'silicate', 'dissolvedOxygen', 'primaryProduction',
    ],
    kind: 'model',
    family: 'ocean_model',
    dataNature: 'hindcast',
    spatialResolutionM: 25000,
    temporalResolution: 'diaria y mensual',
    // Verificado en el STAC: cube:dimensions.time.extent.
    temporalCoverage: { from: '1993-01-01', to: '2026-05-31' },
    // Verificado, pero NUNCA operativo: su serie termina meses atrás y por eso la
    // disponibilidad lo clasifica como histórico a partir de la cobertura.
    status: 'verified',
    note:
      'Serie de 33 anos: es la base para climatologias y anomalias, y el banco de pruebas ' +
      'de los modelos temporales que vengan despues. Aqui solo se deja disponible la fuente ' +
      'y su estructura temporal; no se entrena nada. Ojo con la variable: el hindcast diario ' +
      'NO trae pH, alcalinidad ni carbono inorgánico, que sí están en el análisis operacional.',
    snapshotFile: 'copernicus-bgc-hindcast.json',
  },
  {
    id: 'sentinel2-cdse',
    name: 'Sentinel-2 MSI L2A · microescala costera',
    provider: 'Copernicus Data Space Ecosystem',
    transport: 'proxy',
    proxyId: 'cdse',
    auth: 'none',
    upstream: 'https://catalogue.dataspace.copernicus.eu/odata/v1',
    cadenceSec: 6 * HOUR,
    variables: ['B02', 'B03', 'B04', 'B05', 'B06', 'B07', 'B08', 'B8A', 'B11', 'B12', 'SCL'],
    provides: ['remoteSensingReflectance'],
    kind: 'satellite',
    family: 'satellite',
    spatialResolutionM: 10,
    temporalResolution: 'revisita ~5 dias, sujeta a nubosidad',
    status: 'untested',
    note:
      'El escalon fino de la jerarquia espacial: donde 620 m no alcanza -estuario de ' +
      'Reloncavi, desembocaduras del Puelo y el Petrohue, canales estrechos y el entorno ' +
      'inmediato de los centros-. Complementa a OLCI, no lo reemplaza. Lo que se consulta ' +
      'aqui es el CATALOGO: que escena hay, cuando y con cuanta nube. Va por OData y no por ' +
      'STAC porque el STAC del Data Space no publica la coleccion SENTINEL-2 (404, verificado ' +
      'el 17-09-2026); OData responde sin credenciales. La extraccion de ' +
      'pixeles queda en el pipeline, como el resto de lo gridded. L2A trae reflectancia de ' +
      'fondo de atmosfera, pero Sen2Cor NO corrige el efecto de adyacencia: sobre agua ' +
      'junto a tierra sus valores estan contaminados por el brillo de la costa, y derivar ' +
      'clorofila de ahi sin una cadena tipo ACOLITE/T-Mart no esta justificado.',
  },
];

/**
 * El catálogo que usa todo el sistema: lo declarado, corregido por la salud
 * medida. Nadie lee `DECLARED_SOURCES` directamente.
 */
export const SOURCES: SourceDefinition[] = applyHealth(DECLARED_SOURCES, SOURCE_HEALTH);

const BY_ID = new Map(SOURCES.map((source) => [source.id, source]));

export function getSource(id: string): SourceDefinition {
  const source = BY_ID.get(id);
  if (!source) throw new Error(`fuente desconocida en el registro: ${id}`);
  return source;
}

export function sourcesByTransport(transport: Transport): SourceDefinition[] {
  return SOURCES.filter((source) => source.integrationScope !== 'laboratory' && source.transport === transport);
}

/** Fuentes que no necesitan credenciales: el sistema vivo mínimo. */
export const PUBLIC_SOURCES = SOURCES.filter((source) => source.integrationScope !== 'laboratory' && source.auth === 'none');

/**
 * Qué fuentes entregan una variable, de la más fina a la más gruesa. Los datos
 * puntuales (`spatialResolutionM === null`) van primero: una boya no tiene
 * resolución, tiene el valor exacto de su punto.
 *
 * Es la consulta que ordena la jerarquía espacial de STRATOS. Para clorofila en
 * Reloncaví devuelve, en orden: OLCI 620 m, VIIRS 750 m y el BGC de 25 km — y
 * deja a la vista que son tres cosas distintas, no tres copias del mismo número.
 */
export function sourcesFor(variable: VariableId): SourceDefinition[] {
  return SOURCES.filter((source) => source.integrationScope !== 'laboratory' && source.provides.includes(variable)).sort((a, b) => {
    const ra = resolutionFor(a, variable);
    const rb = resolutionFor(b, variable);
    if (ra === rb) return 0;
    if (ra === null) return -1;
    if (rb === null) return 1;
    return ra - rb;
  });
}

/**
 * Resolución real con que una fuente entrega UNA variable. Es la que hay que usar
 * al hablar de una variable; `spatialResolutionM` describe la fuente entera.
 */
export function resolutionFor(source: SourceDefinition, variable: VariableId): number | null {
  return source.variableResolutionM?.[variable] ?? source.spatialResolutionM;
}

/** La fuente más fina que entrega la variable, o `null` si no la tiene nadie. */
export function bestSourceFor(variable: VariableId): SourceDefinition | null {
  return sourcesFor(variable)[0] ?? null;
}

/**
 * Variables del catálogo que ninguna fuente entrega hoy. Se consulta para no
 * prometer en la interfaz algo que el sistema no puede medir: hoy incluye
 * amonio y nitrito, que no están en ninguna integración.
 */
export function unsourcedVariables(all: readonly VariableId[]): VariableId[] {
  return all.filter((variable) => sourcesFor(variable).length === 0);
}
