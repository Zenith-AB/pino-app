// Ciclo programado: lo que corre solo, sin que nadie cambie estados a mano.
//
//   node datasource/jobs/cycle.mjs            (lo que programa `npm run dev`, cada hora)
//   node datasource/jobs/cycle.mjs --force    ingesta aunque no toque
//
// 1. Ingesta Copernicus/ERA5 si la última tiene más de INGEST_EVERY_H horas.
//    La cadencia la fija el producto más rápido (GLORYS horario publicado en
//    corridas); ingestar más seguido sólo repite el mismo dato. Una ingesta
//    completa tarda ~190 s (validation/evidence/07-operacion.json).
// 2. Archivo de series en los puntos SOTRACS (archive_points.py), tras cada
//    ingesta: lecturas ACS + modelo y satélite en el mismo punto (D3).
// 3. Loop de salud: sondas + estado calculado (healthLoop.ts).
// 4. Evaluación operacional de TimesFM (services/timesfm): empareja los
//    pronósticos cuyo valid_time ya pasó con la observación que llegó. No carga
//    el modelo ni emite pronósticos; sólo escribe pares. Se omite si el servicio
//    no tiene su entorno instalado.
//
// Cada paso deja una línea en datasource/health/cycle.log. Un paso que falla no
// impide el siguiente: si la ingesta cae, el loop de salud lo registra.

import { spawnSync } from 'node:child_process';
import { appendFileSync, existsSync, mkdirSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { findPython, findPythonWith } from './python.mjs';
import { servicePython } from '../../services/timesfm/run.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..');
const LOG = resolve(ROOT, 'datasource', 'health', 'cycle.log');
const REPORT = resolve(ROOT, 'public', 'datasource', 'ingest-report.json');
const INGEST_EVERY_H = 6;

function log(line) {
  mkdirSync(dirname(LOG), { recursive: true });
  appendFileSync(LOG, `${new Date().toISOString()} ${line}\n`, 'utf8');
}

function step(name, args, timeoutMs, command = process.execPath, cwd = ROOT) {
  const started = Date.now();
  const run = spawnSync(command, args, { cwd, encoding: 'utf8', timeout: timeoutMs });
  const seconds = ((Date.now() - started) / 1000).toFixed(0);
  const tail = `${run.stdout ?? ''}${run.stderr ?? ''}`.trim().split('\n').slice(-2).join(' | ');
  log(`${name} salida=${run.status ?? run.signal} ${seconds}s ${tail.slice(0, 300)}`);
  return run.status === 0;
}

function ingestDue() {
  if (process.argv.includes('--force') || !existsSync(REPORT)) return true;
  const { generatedAt } = JSON.parse(readFileSync(REPORT, 'utf8'));
  return Date.now() - Date.parse(generatedAt) > INGEST_EVERY_H * 3_600_000;
}

// Corrientes e indices climaticos van en cada vuelta, no cada 6 h: el campo
// CROCO cambia cada hora y su descarga son ~4 s. Antes los indices no entraban
// en ninguna tarea programada -solo Copernicus- y el snapshot de AAO/SAM
// llevaba dos dias parado mientras la vista lo daba por vigente.
step('corrientes', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'currents'], 5 * 60_000);
step('indices', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'indices'], 5 * 60_000);
// Check published MUR dates and archive images/NOAA indices; no browser ingestion.
step('clima-vivo', [resolve(ROOT, 'datasource', 'jobs', 'climate_snapshot.py')], 10 * 60_000, findPython() ?? 'python3');
// Daily latest 4K still; lossless three-second movie rebuilt only every seven days.
const climateCodec = process.env.STRATOS_CLIMATE_PYTHON ?? resolve(ROOT, '..', 'climate-codec-venv', 'bin', 'python');
step('clima-animacion', [resolve(ROOT, 'datasource', 'jobs', 'climate_animation.py')], 30 * 60_000,
  existsSync(climateCodec) ? climateCodec : findPythonWith(['PIL']) ?? 'python3');
// El catalogo de boyas cambia poco pero pesa 7 kB: va en cada vuelta. El de
// IFOP son 1,2 MB y su muestreo es mensual, asi que basta una vez al dia.
// Ambos son el respaldo offline; medidos el 2026-09-22 llevaban 6,7 dias
// parados porque ninguna tarea programada los ejecutaba.
step('boyas', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'acs'], 5 * 60_000);
step('meteorologia', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'redmet'], 5 * 60_000);
  step('meteorologia-contexto', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'weather'], 5 * 60_000);
step('forzantes', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'forzantes'], 5 * 60_000);
step('rios', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'rios'], 5 * 60_000);
// La climatologia del Seno cambia con cada campana de IFOP, es decir al mes.
// Recalcularla cuesta unos segundos y evita que el riel quede sin normas si
// el archivo se pierde; sin ella las columnas medidas muestran valor pero
// no posicion.
{
  const climaPython = findPythonWith(['psycopg']);
  if (climaPython) {
    step('climatologia', [resolve(ROOT, 'datasource', 'jobs', 'climatologia_reloncavi.py')], 10 * 60_000, climaPython);
  } else {
    log('climatologia omitida: no hay interprete de Python');
  }
}
// Condiciones precursoras por boya ACS (sequía, radiación, calma, columna,
// mezcla, biomasa). Pide historia incremental a IFOP, ERA5 y GloFAS y el
// ensamble GFS: cada 6 h basta y evita cargar a los proveedores.
function condicionesDue() {
  const archivo = resolve(ROOT, 'public', 'datasource', 'condiciones-precursoras.json');
  if (process.argv.includes('--force') || !existsSync(archivo)) return true;
  try {
    const { generatedAt } = JSON.parse(readFileSync(archivo, 'utf8'));
    return Date.now() - Date.parse(generatedAt) > 6 * 3_600_000;
  } catch {
    return true;
  }
}
if (condicionesDue()) {
  const condPython = findPythonWith(['numpy']);
  if (condPython) step('condiciones', [resolve(ROOT, 'datasource', 'jobs', 'condiciones_precursoras.py')], 30 * 60_000, condPython);
  else log('condiciones omitidas: no hay Python con numpy');
}
const conditionsPython = findPythonWith(['numpy']);
if (conditionsPython) step('verificar-condiciones', [resolve(ROOT, 'datasource', 'jobs', 'verify_conditions.py')], 10 * 60_000, conditionsPython);
if (websigDue()) step('websig', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'websig'], 10 * 60_000);

// Copia cruda completa y versiones del Seno para validación prospectiva. No
// actualiza muestreo ni reetiqueta el modelo; el WFS reducido de la UI no sirve
// para cerrar integridad. La marca de la captura queda en el informe aparte.
function validationArchiveDue() {
  const path = '/var/lib/stratos/reports/validation-data-latest.json';
  if (process.argv.includes('--force') || !existsSync(path)) return true;
  try {
    const { source } = JSON.parse(readFileSync(path, 'utf8'));
    return !source?.capturedAt || Date.now() - Date.parse(source.capturedAt) > 24 * 3_600_000;
  } catch { return true; }
}
const validationIfopOk = !validationArchiveDue() ||
  step('validacion-ifop', [resolve(ROOT, 'db', 'archive-validation-ifop.mjs')], 20 * 60_000);
const validationInboxOk = step('validacion-laboratorio',
  [resolve(ROOT, 'db', 'import-validation-inbox.mjs')], 5 * 60_000);

/** El recorte de IFOP se rehace una vez al dia: su muestreo es mensual. */
function websigDue() {
  const archivo = resolve(ROOT, 'public', 'datasource', 'ifop-websig.json');
  if (process.argv.includes('--force') || !existsSync(archivo)) return true;
  try {
    const { generatedAt } = JSON.parse(readFileSync(archivo, 'utf8'));
    return Date.now() - Date.parse(generatedAt) > 24 * 3_600_000;
  } catch {
    return true;
  }
}

if (ingestDue()) {
  step('ingesta', [resolve(ROOT, 'datasource', 'jobs', 'snapshot.mjs'), 'copernicus'], 30 * 60_000);
  const python = findPython();
  if (python) step('archivo', [resolve(ROOT, 'datasource', 'jobs', 'archive_points.py')], 20 * 60_000, python);
  else log('archivo omitido: no hay intérprete de Python');
} else {
  log(`ingesta omitida: la última tiene menos de ${INGEST_EVERY_H} h`);
}
step('salud', ['--experimental-strip-types', resolve(ROOT, 'datasource', 'jobs', 'healthLoop.ts')], 10 * 60_000);
// Explicit opt-in: reuse existing provider snapshots; never download or train here.
// Absent configuration leaves the new store disabled. A failure cannot stop FAN.
if (process.env.STRATOS_OCEAN_STORE) {
  const oceanStore = process.env.STRATOS_OCEAN_STORE;
  const chonosSnapshot = resolve(oceanStore, 'chonos-ocean.json');
  if (process.env.STRATOS_OCEAN_CHONOS_ARCHIVE && process.env.STRATOS_OCEAN_GSW_PYTHON) {
    step('oceanografia-columna', [resolve(ROOT, 'datasource', 'jobs', 'ocean_chonos.py'),
      '--archive', process.env.STRATOS_OCEAN_CHONOS_ARCHIVE, '--store', oceanStore,
      '--quota-bytes', process.env.STRATOS_OCEAN_QUOTA_BYTES ?? '60000000000'],
      5 * 60_000, process.env.STRATOS_OCEAN_GSW_PYTHON);
  }
  step('oceanografia', [resolve(ROOT, 'datasource', 'jobs', 'ocean_intelligence.py'),
    '--inputs', resolve(ROOT, 'public', 'datasource'), '--store', oceanStore,
    '--quota-bytes', process.env.STRATOS_OCEAN_QUOTA_BYTES ?? '60000000000',
    ...(existsSync(chonosSnapshot) ? ['--chonos', chonosSnapshot] : [])],
    5 * 60_000, process.env.STRATOS_OCEAN_PYTHON ?? findPython() ?? 'python3');
}

// Retención de datos personales, partición del mes que viene y calidad de lo
// recién llegado. Sale con 0 si no hay base: el ciclo no se cae por esto.
step('base', [resolve(ROOT, 'db', 'mantenimiento.mjs')], 5 * 60_000);

const timesfmPython = servicePython();
if (timesfmPython) {
  step('timesfm-evaluacion', ['-m', 'app.jobs.evaluate_forecasts'], 15 * 60_000, timesfmPython, resolve(ROOT, 'services', 'timesfm'));
} else {
  log('timesfm-evaluacion omitida: services/timesfm/.venv no existe');
}

// El publicador es idempotente; una caída no pierde el historial y se reintenta.
const fanOk = step('publicar-fan', [resolve(ROOT, 'db', 'publish-fan.mjs')], 5 * 60_000);
const syncOk = step('publicar-timesfm', [resolve(ROOT, 'db', 'sync-timesfm.mjs')], 15 * 60_000);
// Verificación en sombra del índice: sólo lee lo publicado y agrega los días que
// maduraron. Si falla, el ciclo sigue: no toca lo que ve el usuario.
step('verificar-fan-sombra', [resolve(ROOT, 'db', 'verify-fan-shadow.mjs')], 5 * 60_000);
// Captura D14: después de verificar, lee emisiones y reportes ya archivados.
// El navegador no consulta proveedores al abrir Modelos.
const modelsD14Ok = step('modelos-d14', [resolve(ROOT, 'datasource', 'jobs', 'operational-models-d14.mjs')], 10 * 60_000);
// Shared multi-horizon capture: read-only SQLite and server snapshots, never provider calls.
const architectureOk = step('arquitectura-predictiva', [resolve(ROOT, 'datasource', 'jobs', 'predictive_architecture.py')],
  5 * 60_000, findPython() ?? 'python3');
// Fixed all-buoy candidates: daily cache, server inference and prospective pairing.
// Release controls are installed separately; a missing install is not silently enabled.
  const environmentV2Root = '/var/lib/stratos/environment-architecture-v2';
const environmentV2Python = process.env.STRATOS_ENV_V2_PYTHON ?? '/srv/stratos/environment-benchmark-lab-20261012/venv/bin/python';
const environmentV2Ok = !existsSync(resolve(environmentV2Root, 'control.json')) ||
  step('arquitectura-2', [resolve(ROOT, 'datasource', 'jobs', 'environment_v2.py')], 15 * 60_000, environmentV2Python);
const validationEmissionsOk = modelsD14Ok &&
  step('validacion-emisiones', [resolve(ROOT, 'db', 'archive-validation-forecasts.mjs')], 5 * 60_000);
const validationPairsOk = validationEmissionsOk &&
  step('validacion-pares', [resolve(ROOT, 'db', 'verify-validation-forecasts.mjs')], 5 * 60_000);
const validationIntegrityOk = step('validacion-integridad', [resolve(ROOT, 'db', 'report-validation-integrity.mjs')], 5 * 60_000);
if (!fanOk || !syncOk || !validationIfopOk || !validationInboxOk || !modelsD14Ok || !validationEmissionsOk ||
    !validationPairsOk || !validationIntegrityOk || !architectureOk || !environmentV2Ok)
  process.exitCode = 1;
