// Lectura de credenciales para los trabajos de Node.
//
// Estas claves NO llevan prefijo `VITE_` y eso no es un descuido: Vite sólo
// inyecta en el bundle las variables con ese prefijo, así que la ausencia del
// prefijo es precisamente lo que impide que las credenciales de Copernicus y CDS
// acaben publicadas en el JavaScript del navegador. Sólo las leen los procesos
// de esta carpeta y `server/serve.mjs`.
//
// `.env.local` ya está cubierto por el patrón `.env*` del .gitignore del proyecto.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const PROJECT_ROOT = path.resolve(HERE, '..', '..');

/** Orden de precedencia: el entorno del proceso gana sobre el archivo. */
const CANDIDATES = ['.env.local', '.env'];

/** Parser mínimo de dotenv: `CLAVE=valor`, comillas opcionales, `#` comenta. */
function parse(contents) {
  const values = {};
  for (const rawLine of contents.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const separator = line.indexOf('=');
    if (separator === -1) continue;
    const key = line.slice(0, separator).trim();
    let value = line.slice(separator + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (key) values[key] = value;
  }
  return values;
}

export function readCredentials() {
  const values = {};
  for (const name of CANDIDATES) {
    const file = path.join(PROJECT_ROOT, name);
    if (!fs.existsSync(file)) continue;
    Object.assign(values, parse(fs.readFileSync(file, 'utf8')));
  }
  // El entorno del proceso tiene la última palabra: así CI inyecta secretos sin
  // escribir archivos y una sesión puede sobrescribir una clave puntual.
  for (const key of Object.keys(values)) {
    if (process.env[key]) values[key] = process.env[key];
  }
  for (const key of [
    'COPERNICUSMARINE_SERVICE_USERNAME',
    'COPERNICUSMARINE_SERVICE_PASSWORD',
    'CDSAPI_URL',
    'CDSAPI_KEY',
    'DGA_API_URL',
  ]) {
    if (!values[key] && process.env[key]) values[key] = process.env[key];
  }
  return values;
}

/** Enmascara un secreto para poder registrarlo sin filtrarlo. */
export function mask(value) {
  if (!value) return 'AUSENTE';
  return value.length > 6 ? `${value.slice(0, 3)}***${value.slice(-2)}` : 'PRESENTE';
}
