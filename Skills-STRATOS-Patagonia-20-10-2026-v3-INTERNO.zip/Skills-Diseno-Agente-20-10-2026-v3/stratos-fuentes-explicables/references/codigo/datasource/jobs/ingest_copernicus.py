"""Ingesta real de Copernicus Marine y ERA5 para STRATOS.

Corre en Node/servidor, nunca en el navegador: las credenciales viven en
`.env.local` sin prefijo VITE_ y no salen de aquí.

Lo que hace, por fuente, es el ciclo completo que exige el catálogo:

    healthCheck -> fetch -> validate -> normalize

Una fuente sólo se declara operativa si supera los diez pasos: autenticación,
descubrimiento del dataset, recorte espacial, recorte temporal, descarga,
apertura, presencia de las variables esperadas, coordenadas válidas, timestamp
válido y valores numéricos utilizables. Responder HTTP 200 no basta.

Salida: un JSON por fuente en `public/datasource/`, con la forma que espera
`datasource/sources/copernicus/types.ts`, más un informe de estado que el
registro usa para decidir el `status` de cada fuente.

Uso:
    python datasource/jobs/ingest_copernicus.py [--quick]
"""

from __future__ import annotations

import datetime as dt
import glob
import io
import json
import os
import re
import sys
import warnings
import zipfile
from pathlib import Path

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[2]
OUT_DIR = ROOT / "public" / "datasource"
ENV_FILE = ROOT / ".env.local"

# ── Dominio ──────────────────────────────────────────────────────────────────
#
# No se descarga el océano global: sólo la ventana que STRATOS mira. La caja es
# configurable y arranca en Patagonia norte —Los Lagos y Aysén—, que es donde
# está la red de observación. Magallanes entra ampliando `south`.
BBOX = {
    "west": -75.5,
    "east": -71.5,
    "south": -47.0,
    "north": -41.0,
}

# Caja mínima para pruebas: Mar Interior de Chiloé y Seno de Reloncaví.
BBOX_QUICK = {"west": -73.6, "east": -72.0, "south": -42.7, "north": -41.4}

# El color del océano a 300 m se recorta más fino que el resto. A esa resolución
# la caja regional completa son ~780.000 celdas por variable: el snapshot salía
# de 9,7 MB, que es inviable para un archivo que descarga el navegador. Se acota
# al mar interior, que es donde los 300 m aportan algo que 4 km no da.
BBOX_OCEAN_COLOUR = {"west": -74.2, "east": -72.0, "south": -43.4, "north": -41.2}


def load_env() -> None:
    if not ENV_FILE.exists():
        return
    text = io.open(ENV_FILE, encoding="utf-8").read()
    for key in (
        "COPERNICUSMARINE_SERVICE_USERNAME",
        "COPERNICUSMARINE_SERVICE_PASSWORD",
        "CDSAPI_URL",
        "CDSAPI_KEY",
    ):
        match = re.search(rf"^{key}=(.*)$", text, re.M)
        if match and match.group(1).strip():
            os.environ.setdefault(key, match.group(1).strip())


# ── Robustez: reintento, timeout y circuit breaker ───────────────────────────
#
# Un proveedor externo no debe tumbar la corrida ni bloquear a nadie. Cada
# descarga tiene un tope de tiempo y se reintenta con espera exponencial; si un
# producto falla varias corridas seguidas, el circuito se abre y se deja de
# golpearlo durante un rato. Lo que ya estaba descargado no se toca: un fallo
# nunca borra el último dato bueno.

MAX_ATTEMPTS = 3
BASE_BACKOFF_S = 4.0
DATASET_TIMEOUT_S = 240
# Tras este número de corridas fallidas seguidas, el producto se salta…
BREAKER_THRESHOLD = 3
# …durante este tiempo.
BREAKER_COOLDOWN_S = 6 * 3600


def with_timeout(fn, timeout_s: float, label: str):
    """Ejecuta `fn` con un tope de tiempo. El hilo no se puede matar, pero la
    corrida deja de esperarlo: una descarga colgada no detiene las demás."""
    from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout

    executor = ThreadPoolExecutor(max_workers=1)
    future = executor.submit(fn)
    try:
        return future.result(timeout=timeout_s)
    except FutureTimeout as exc:
        raise TimeoutError(f"{label}: sin respuesta en {int(timeout_s)} s") from exc
    finally:
        executor.shutdown(wait=False, cancel_futures=True)


def with_retry(fn, label: str):
    """Reintento con espera exponencial (4 s, 8 s…). Un error de credencial no
    se reintenta: insistir no lo arregla y puede bloquear la cuenta."""
    import time

    last_error = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            return with_timeout(fn, DATASET_TIMEOUT_S, label)
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            text = str(exc).lower()
            if "credential" in text or "unauthorized" in text or "401" in text:
                break
            if attempt < MAX_ATTEMPTS:
                wait = BASE_BACKOFF_S * (2 ** (attempt - 1))
                print(f"     reintento {attempt}/{MAX_ATTEMPTS - 1} de {label} en {wait:.0f} s: {exc}"[:180])
                time.sleep(wait)
    raise last_error  # type: ignore[misc]


def previous_report() -> dict:
    """Informe de la corrida anterior, para arrastrar el último dato bueno y el
    estado del circuit breaker entre ejecuciones."""
    path = OUT_DIR / "ingest-report.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(io.open(path, encoding="utf-8").read())
        return {item["sourceId"]: item for item in data.get("sources", [])}
    except Exception:  # noqa: BLE001
        return {}


def breaker_open(previous: dict) -> bool:
    open_until = previous.get("breakerOpenUntil")
    if not open_until:
        return False
    return dt.datetime.fromisoformat(open_until) > dt.datetime.now(dt.UTC)


def carry_last_good(report: dict, previous: dict, now: dt.datetime) -> dict:
    """Si esta corrida falló, se conserva lo último que funcionó y se anota el
    error con su hora. Si funcionó, se reinicia el contador del breaker."""
    failed = report["connectorHealth"] != "healthy"
    if failed:
        for key in ("lastSuccessfulFetch", "lastValidTimestamp", "grids"):
            if key in previous and key not in report:
                report[key] = previous[key]
        report["lastError"] = "; ".join(report.get("errors", []))[:300] or "fallo sin detalle"
        report["lastErrorAt"] = now.isoformat()
        failures = int(previous.get("consecutiveFailures", 0)) + 1
        report["consecutiveFailures"] = failures
        if failures >= BREAKER_THRESHOLD:
            report["breakerOpenUntil"] = (now + dt.timedelta(seconds=BREAKER_COOLDOWN_S)).isoformat()
        # Hay dato anterior: el conector está degradado, no ausente.
        if report.get("lastValidTimestamp") and report["connectorHealth"] == "upstream_error":
            report["connectorHealth"] = "degraded"
    else:
        report["consecutiveFailures"] = 0
        report.pop("breakerOpenUntil", None)
        if previous.get("lastError"):
            report["lastError"] = previous["lastError"]
            report["lastErrorAt"] = previous.get("lastErrorAt")
    return report


# ── Catálogo de ingesta ──────────────────────────────────────────────────────
#
# `dataset_id` y variables verificados contra el servicio el 17-09-2026. El
# reparto no es obvio y equivocarse cuesta una descarga entera: el dataset
# DIARIO de la física global no trae temperatura ni corrientes —sólo nivel del
# mar, hielo y fondo—, así que las cinco variables de estado salen del horario.

# Compuesto de color del océano (decisión D1). Un día de OLCI cubre ~11 % del
# mar interior por nubes; 5 días cubren ~86 % con edad mediana del dato <= 2 días
# (validation/evidence/05-nubes.json). Cada píxel guarda el ÚLTIMO valor válido
# y su edad en días: no se promedia, así el número es una observación real con
# su fecha, no una mezcla de días distintos.
COMPOSITE_DAYS = 5


CMEMS_TARGETS = [
    {
        "snapshot": "copernicus-glorys.json",
        "source_id": "copernicus-marine",
        "product": "GLOBAL_ANALYSISFORECAST_PHY_001_024",
        "grids": [
            {
                "dataset": "cmems_mod_glo_phy_anfc_0.083deg_PT1H-m",
                "vars": {
                    "thetao": "waterTemperature",
                    "so": "salinity",
                    "uo": "currentU",
                    "vo": "currentV",
                    "zos": "seaLevel",
                },
                "resolution_m": 9000,
                "back_days": 2,
            }
        ],
    },
    {
        "snapshot": "copernicus-bgc.json",
        "source_id": "copernicus-bgc",
        "product": "GLOBAL_ANALYSISFORECAST_BGC_001_028",
        "grids": [
            {
                "dataset": "cmems_mod_glo_bgc-nut_anfc_0.25deg_P1D-m",
                "vars": {"no3": "nitrate", "po4": "phosphate", "si": "silicate"},
                "resolution_m": 25000,
                "back_days": 4,
            },
            {
                "dataset": "cmems_mod_glo_bgc-bio_anfc_0.25deg_P1D-m",
                "vars": {"o2": "dissolvedOxygen", "nppv": "primaryProduction"},
                "resolution_m": 25000,
                "back_days": 4,
            },
            {
                "dataset": "cmems_mod_glo_bgc-car_anfc_0.25deg_P1D-m",
                "vars": {"ph": "ph", "talk": "alkalinity", "dissic": "dissolvedInorganicCarbon"},
                "resolution_m": 25000,
                "back_days": 4,
            },
            {
                "dataset": "cmems_mod_glo_bgc-pft_anfc_0.25deg_P1D-m",
                "vars": {"chl": "chlorophyll", "phyc": "phytoplanktonCarbon"},
                "resolution_m": 25000,
                "back_days": 4,
            },
            {
                "dataset": "cmems_mod_glo_bgc-optics_anfc_0.25deg_P1D-m",
                "vars": {"kd": "diffuseAttenuation"},
                "resolution_m": 25000,
                "back_days": 4,
            },
        ],
    },
    {
        "snapshot": "copernicus-bgc-hindcast.json",
        "source_id": "copernicus-bgc-hindcast",
        "product": "GLOBAL_MULTIYEAR_BGC_001_029",
        "grids": [
            {
                "dataset": "cmems_mod_glo_bgc_my_0.25deg_P1D-m",
                "vars": {
                    "chl": "chlorophyll",
                    "no3": "nitrate",
                    "po4": "phosphate",
                    "si": "silicate",
                    "o2": "dissolvedOxygen",
                    "nppv": "primaryProduction",
                },
                "resolution_m": 25000,
                # El hindcast va meses por detrás: su último paso es el dato, no un fallo.
                "back_days": 400,
            }
        ],
    },
    {
        "snapshot": "copernicus-olci-300m.json",
        "source_id": "copernicus-olci-300m",
        "product": "OCEANCOLOUR_GLO_BGC_L3_NRT_009_101",
        "bbox": "ocean_colour",
        "grids": [
            {
                "dataset": "cmems_obs-oc_glo_bgc-plankton_nrt_l3-olci-300m_P1D",
                "vars": {"CHL": "chlorophyll"},
                "resolution_m": 620,  # 1/180°: «300m» es el sensor, no la malla
                "back_days": 12,
                "composite_days": COMPOSITE_DAYS,
            },
            {
                "dataset": "cmems_obs-oc_glo_bgc-reflectance_nrt_l3-olci-300m_P1D",
                "vars": {"RRS443": "remoteSensingReflectance"},
                "resolution_m": 620,
                "back_days": 12,
                "composite_days": COMPOSITE_DAYS,
            },
            {
                # Kd490, SPM y Secchi NO existen a 300 m: sólo el producto de 4 km
                # los publica. Se declara su resolución real, no la de la clorofila.
                "dataset": "cmems_obs-oc_glo_bgc-transp_nrt_l3-multi-4km_P1D",
                "vars": {
                    "KD490": "diffuseAttenuation",
                    "SPM": "suspendedMatter",
                },
                "resolution_m": 4640,  # 1/24°
                "back_days": 12,
                "composite_days": COMPOSITE_DAYS,
            },
        ],
    },
]




def latest_valid(values, times, days: int):
    """Último valor válido por píxel dentro de `days` días desde el paso más
    reciente, y su edad en días enteros (0 = el día más reciente)."""
    import numpy as np

    data = np.asarray(values, dtype="float64")
    while data.ndim > 3:  # profundidad de un solo nivel u otros ejes unitarios
        data = data.squeeze(axis=1)
    newest = times[-1]
    out = np.full(data.shape[1:], np.nan)
    age = np.full(data.shape[1:], np.nan)
    for k in range(len(times) - 1, -1, -1):
        days_old = int(round((newest - times[k]) / np.timedelta64(1, "D")))
        if days_old >= days:
            break
        fill = np.isnan(out) & np.isfinite(data[k])
        out[fill] = data[k][fill]
        age[fill] = days_old
    return out, age


def _load_gate():
    import importlib.util

    spec = importlib.util.spec_from_file_location("georef_gate", Path(__file__).parent / "georef_gate.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


georef_gate = _load_gate()


def ingest_cmems(bbox: dict) -> list[dict]:
    import copernicusmarine as cm
    import numpy as np

    now = dt.datetime.now(dt.UTC)
    reports = []
    history = previous_report()

    # ── healthCheck: sin credencial válida no se intenta nada más ────────────
    try:
        cm.login(
            username=os.environ["COPERNICUSMARINE_SERVICE_USERNAME"],
            password=os.environ["COPERNICUSMARINE_SERVICE_PASSWORD"],
            check_credentials_valid=True,
            force_overwrite=True,
        )
        auth_ok = True
    except Exception as exc:  # noqa: BLE001
        print(f"  auth_error: {exc}")
        auth_ok = False

    for target in CMEMS_TARGETS:
        report = {
            "sourceId": target["source_id"],
            "productId": target["product"],
            "connectorHealth": "healthy" if auth_ok else "auth_error",
            "dataAvailability": "no_observation",
            "grids": [],
            "errors": [],
        }
        if not auth_ok:
            reports.append(report)
            continue

        previous = history.get(target["source_id"], {})
        if breaker_open(previous):
            print(f"  -- {target['source_id']}: circuito abierto hasta {previous['breakerOpenUntil']}, se salta")
            skipped = dict(previous)
            skipped["connectorHealth"] = "disabled"
            reports.append(skipped)
            continue

        payload_grids = []
        georef_failed = False
        # Una fuente puede pedir su propia ventana: la resolución manda sobre el
        # tamaño de la descarga, no al revés.
        window = BBOX_OCEAN_COLOUR if target.get("bbox") == "ocean_colour" else bbox
        for spec in target["grids"]:
            try:
                # El fin de la ventana es AHORA, no el final del día: los productos
                # de análisis+pronóstico traen pasos futuros, y el último paso de
                # un recorte que describe el estado actual no puede ser un pronóstico.
                ds = with_retry(
                    lambda spec=spec: cm.open_dataset(
                        dataset_id=spec["dataset"],
                        minimum_longitude=window["west"],
                        maximum_longitude=window["east"],
                        minimum_latitude=window["south"],
                        maximum_latitude=window["north"],
                        start_datetime=(now - dt.timedelta(days=spec["back_days"])).strftime(
                            "%Y-%m-%dT00:00:00"
                        ),
                        end_datetime=now.strftime("%Y-%m-%dT%H:%M:%S"),
                        maximum_depth=1,
                    ),
                    spec["dataset"],
                )
                if ds.sizes.get("time", 0) == 0:
                    raise ValueError("sin pasos de tiempo en la ventana pedida")

                # La resolución la dice el proveedor (`grid_resolution`, en km) cuando
                # la publica; la del spec queda de respaldo y de control: si difieren
                # más de un 10 %, se registra, porque entonces el catálogo miente.
                resolution_m = spec["resolution_m"]
                declared_km = ds.attrs.get("grid_resolution")
                if declared_km:
                    measured = int(round(float(declared_km) * 1000, -1))
                    if abs(measured - resolution_m) / resolution_m > 0.1:
                        report["errors"].append(
                            f"{spec['dataset']}: resolución del proveedor {measured} m, spec {resolution_m} m"
                        )
                    resolution_m = measured

                last = ds.isel(time=-1)
                stamp = str(np.datetime_as_string(ds.time.values[-1], unit="s")) + "Z"
                lon = ds.longitude.values
                lat = ds.latitude.values

                variables = []
                for native, canonical in spec["vars"].items():
                    if native not in ds.data_vars:
                        report["errors"].append(f"{spec['dataset']}: falta {native}")
                        continue
                    age = None
                    if spec.get("composite_days"):
                        arr, age = latest_valid(ds[native].values, ds.time.values, spec["composite_days"])
                    else:
                        arr = np.asarray(last[native].values, dtype="float64")
                        arr = np.squeeze(arr)
                    if arr.ndim != 2:
                        report["errors"].append(f"{spec['dataset']}/{native}: rango {arr.ndim}D")
                        continue
                    # Normalización: filas desde el NORTE, que es lo que espera el
                    # cliente. El eje de latitud llega ascendente.
                    if lat[0] < lat[-1]:
                        arr = arr[::-1, :]
                        age = age[::-1, :] if age is not None else None
                    finite = int(np.isfinite(arr).sum())
                    values = [None if not np.isfinite(v) else round(float(v), 6) for v in arr.ravel()]
                    entry = {
                        "id": canonical,
                        "nativeName": native,
                        "unit": str(ds[native].attrs.get("units", "")),
                        "values": values,
                        "observed": finite,
                    }
                    if age is not None:
                        # Edad del píxel en días respecto de `time` de la malla.
                        entry["ageDays"] = [None if not np.isfinite(a) else int(a) for a in age.ravel()]
                    variables.append(entry)

                if not variables:
                    raise ValueError("ninguna variable esperada presente")

                grid = (
                    {
                        "datasetId": spec["dataset"],
                        "bounds": {
                            "west": float(lon.min()),
                            "east": float(lon.max()),
                            "south": float(lat.min()),
                            "north": float(lat.max()),
                        },
                        "width": int(len(lon)),
                        "height": int(len(lat)),
                        "resolutionM": resolution_m,
                        "time": stamp,
                        "depthM": 0,
                        "variables": variables,
                        **({"compositeDays": spec["composite_days"]} if spec.get("composite_days") else {}),
                    }
                )
                # Compuerta de georreferencia (D2): la costa de la malla tiene que
                # calzar en su lugar con una costa independiente. Si no, el recorte
                # entero NO se publica y queda el último bueno.
                check = georef_gate.check_grid(grid)
                grid["georef"] = {k: check[k] for k in ("status", "reason", "peak", "iou0", "waterRecall", "aggregatedBy") if k in check}
                if check["status"] == "fail":
                    georef_failed = True
                    report["errors"].append(f"{spec['dataset']}: georreferencia: {check['reason']}")
                payload_grids.append(grid)
                observed = sum(v["observed"] for v in variables)
                print(
                    f"  OK {spec['dataset'][:52]:52s} t={stamp} "
                    f"{observed} celdas con dato"
                )
                ds.close()
            except Exception as exc:  # noqa: BLE001
                message = f"{spec['dataset']}: {type(exc).__name__}: {exc}"[:200]
                report["errors"].append(message)
                print(f"  XX {message}")

        if georef_failed:
            # Un recorte con una malla corrida no se publica a medias: se conserva
            # el archivo anterior completo y la corrida cuenta como fallida.
            report["connectorHealth"] = "degraded"
        elif payload_grids:
            newest = max(g["time"] for g in payload_grids)
            age_days = (now - dt.datetime.fromisoformat(newest.replace("Z", "+00:00"))).days
            report["dataAvailability"] = (
                "historical_only" if age_days > 60 else "fresh" if age_days <= 7 else "stale"
            )
            report["lastValidTimestamp"] = newest
            report["lastSuccessfulFetch"] = now.isoformat()
            report["grids"] = [
                {"datasetId": g["datasetId"], "time": g["time"], "resolutionM": g["resolutionM"],
                 "variables": [v["id"] for v in g["variables"]],
                 "observed": sum(v["observed"] for v in g["variables"]),
                 "georef": g["georef"]["status"]}
                for g in payload_grids
            ]
            write_snapshot(target["snapshot"], target["source_id"],
                           {"generatedAt": now.isoformat(), "productId": target["product"],
                            "grids": payload_grids})
        else:
            report["connectorHealth"] = "upstream_error"

        reports.append(carry_last_good(report, previous, now))

    return reports


# ── ERA5 ─────────────────────────────────────────────────────────────────────

ERA5_VARS = {
    "t2m": "airTemperature",
    "u10": "windU",
    "v10": "windV",
    "tp": "precipitation",
    "ssrd": "shortwaveRadiation",
}


# ERA5 se distribuye en una malla de 0,25° (~28 km N-S), pero su resolución
# nativa es ~31 km (TL639, ECMWF). Se declara la nativa: es el detalle que el
# dato realmente tiene, y es la misma que dice el registro.
ERA5_RESOLUTION_M = 31000


def ingest_era5(bbox: dict) -> dict:
    """ERA5 es reanálisis, pero su CONECTOR puede ser operacional: el dataset se
    actualiza a diario con unos cinco días de latencia. `dataNature` permanece
    `reanalysis` aunque el estado sea operativo."""
    import cdsapi
    import numpy as np
    import xarray as xr

    now = dt.datetime.now(dt.UTC)
    previous = previous_report().get("era5-cds", {})
    if breaker_open(previous):
        print(f"  -- era5-cds: circuito abierto hasta {previous['breakerOpenUntil']}, se salta")
        return {**previous, "connectorHealth": "disabled"}
    report = {
        "sourceId": "era5-cds",
        "productId": "reanalysis-era5-single-levels",
        "connectorHealth": "healthy",
        "dataAvailability": "no_observation",
        "dataNature": "reanalysis",
        "errors": [],
    }
    # ERA5 publica con ~5 días de latencia: se pide una fecha que ya exista.
    day = now - dt.timedelta(days=8)
    work = OUT_DIR.parent / ".era5-tmp"
    # Se limpia entre corridas: un .nc viejo se colaría en el glob y se abriría
    # como si fuera el dato de hoy.
    if work.exists():
        for stale in work.rglob("*"):
            if stale.is_file():
                stale.unlink()
    (work / "extracted").mkdir(parents=True, exist_ok=True)
    archive = work / "era5.download"

    try:
        client = cdsapi.Client(
            url=os.environ["CDSAPI_URL"],
            key=os.environ["CDSAPI_KEY"],
            quiet=True,
            # El cliente del CDS ya sabe reintentar y esperar la cola: se acota.
            timeout=DATASET_TIMEOUT_S,
            retry_max=MAX_ATTEMPTS,
            sleep_max=60,
        )
        client.retrieve(
            "reanalysis-era5-single-levels",
            {
                "product_type": ["reanalysis"],
                "variable": [
                    "2m_temperature",
                    "10m_u_component_of_wind",
                    "10m_v_component_of_wind",
                    "total_precipitation",
                    "surface_solar_radiation_downwards",
                ],
                "year": [day.strftime("%Y")],
                "month": [day.strftime("%m")],
                "day": [day.strftime("%d")],
                "time": ["12:00"],
                "area": [bbox["north"], bbox["west"], bbox["south"], bbox["east"]],
                "data_format": "netcdf",
                "download_format": "unarchived",
            },
            str(archive),
        )

        # El servicio puede devolver un zip con un netCDF por tipo de paso
        # (instantáneo y acumulado); se aceptan ambas formas.
        # El CDS puede devolver el netCDF pelado o un zip con un archivo por tipo
        # de paso (instantáneo y acumulado). Se extrae a una carpeta aparte: si se
        # extrajera junto al descargado, el glob recogería también el propio zip y
        # el lector fallaría con «file signature not found».
        if zipfile.is_zipfile(archive):
            with zipfile.ZipFile(archive) as zf:
                zf.extractall(work / "extracted")
            members = [Path(p) for p in glob.glob(str(work / "extracted" / "*.nc"))]
        else:
            target = work / "extracted" / "era5.nc"
            target.write_bytes(archive.read_bytes())
            members = [target]

        variables, stamp, bounds, shape = [], None, None, None
        for member in members:
            ds = xr.open_dataset(member, engine="h5netcdf")
            time_coord = "valid_time" if "valid_time" in ds.coords else "time"
            stamp = str(np.datetime_as_string(np.atleast_1d(ds[time_coord].values)[-1], unit="s")) + "Z"
            lon, lat = ds.longitude.values, ds.latitude.values
            bounds = {
                "west": float(lon.min()), "east": float(lon.max()),
                "south": float(lat.min()), "north": float(lat.max()),
            }
            shape = (int(len(lon)), int(len(lat)))
            for native, canonical in ERA5_VARS.items():
                if native not in ds.data_vars:
                    continue
                arr = np.squeeze(np.asarray(ds[native].values, dtype="float64"))
                if arr.ndim != 2:
                    continue
                # ERA5 entrega la latitud descendente: ya viene desde el norte.
                if lat[0] < lat[-1]:
                    arr = arr[::-1, :]
                unit = str(ds[native].attrs.get("units", ""))
                # Normalización de unidades a las del catálogo STRATOS.
                if canonical == "airTemperature" and unit.lower() in ("k", "kelvin"):
                    arr, unit = arr - 273.15, "°C"
                elif canonical == "precipitation" and unit.lower() == "m":
                    arr, unit = arr * 1000.0, "mm"
                elif canonical == "shortwaveRadiation" and "j" in unit.lower():
                    arr, unit = arr / 3600.0, "W/m²"
                variables.append(
                    {
                        "id": canonical,
                        "nativeName": native,
                        "unit": unit,
                        "values": [None if not np.isfinite(v) else round(float(v), 4) for v in arr.ravel()],
                        "observed": int(np.isfinite(arr).sum()),
                    }
                )
            ds.close()

        if not variables:
            raise ValueError("el archivo no trae ninguna variable esperada")

        report["dataAvailability"] = "fresh"
        report["lastValidTimestamp"] = stamp
        report["lastSuccessfulFetch"] = now.isoformat()
        report["variables"] = [v["id"] for v in variables]
        report["resolutionM"] = ERA5_RESOLUTION_M
        write_snapshot(
            "era5.json",
            "era5-cds",
            {
                "generatedAt": now.isoformat(),
                "productId": "reanalysis-era5-single-levels",
                "dataNature": "reanalysis",
                "grids": [
                    {
                        "datasetId": "reanalysis-era5-single-levels",
                        "bounds": bounds,
                        "width": shape[0],
                        "height": shape[1],
                        "resolutionM": ERA5_RESOLUTION_M,
                        "time": stamp,
                        "depthM": None,
                        "variables": variables,
                    }
                ],
            },
        )
        print(f"  OK ERA5 t={stamp} {len(variables)} variables")
    except Exception as exc:  # noqa: BLE001
        report["connectorHealth"] = "upstream_error"
        report["errors"].append(f"{type(exc).__name__}: {exc}"[:200])
        print(f"  XX ERA5: {exc}")

    return carry_last_good(report, previous, now)


def write_snapshot(filename: str, source_id: str, data: dict) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    envelope = {
        "generatedAt": dt.datetime.now(dt.UTC).isoformat(),
        "source": source_id,
        "data": data,
    }
    path = OUT_DIR / filename
    io.open(path, "w", encoding="utf-8").write(json.dumps(envelope, ensure_ascii=False))
    print(f"     -> {filename} ({path.stat().st_size // 1024} KB)")


def main() -> int:
    load_env()
    quick = "--quick" in sys.argv
    bbox = BBOX_QUICK if quick else BBOX
    print(f"dominio: {bbox}")

    print("\nCopernicus Marine")
    reports = ingest_cmems(bbox)

    print("\nERA5 / Climate Data Store")
    reports.append(ingest_era5(bbox))

    report_path = OUT_DIR / "ingest-report.json"
    io.open(report_path, "w", encoding="utf-8").write(
        json.dumps(
            {"generatedAt": dt.datetime.now(dt.UTC).isoformat(), "bbox": bbox, "sources": reports},
            ensure_ascii=False,
            indent=1,
        )
    )
    healthy = sum(1 for r in reports if r["connectorHealth"] == "healthy")
    print(f"\nconectores sanos: {healthy}/{len(reports)}  ->  {report_path.name}")
    return 0 if healthy == len(reports) else 1


if __name__ == "__main__":
    raise SystemExit(main())
