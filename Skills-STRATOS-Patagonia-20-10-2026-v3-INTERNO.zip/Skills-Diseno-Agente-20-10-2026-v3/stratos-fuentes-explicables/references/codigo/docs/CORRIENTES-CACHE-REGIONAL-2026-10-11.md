# Corrientes regionales persistidas · 11-10-2026

## Comprobación y alcance

La consulta nueva al catálogo oficial CHONOS/MOSA desde el servidor publicó `mosa_chiloe_1km_20261009` y `mosa_magallanes_3km_20261010`. Antes, el trabajo horario materializaba sólo el primer dominio de 1 km. La vista podía buscar otros dominios directamente en el proveedor y caer a consultas por puntos de Open-Meteo Marine.

El dominio Chiloé cubre también las boyas de Aysén: su malla real abarca aproximadamente 78,993–72,007°W y 46,995–40,999°S. No se duplica ese mismo campo ni se inventa una malla de Aysén. Magallanes usa su dominio nativo de 3 km. Son corrientes **modeladas** CROCO, no observaciones de las boyas ni una atribución de conectividad.

## Contrato de almacenamiento y navegación

- `snapshot.mjs currents`, ya ejecutado por el ciclo horario, captura todos los dominios publicados. No se agrega un cron por navegador ni por zona.
- `public/datasource/currents/` conserva pares JSON + Float32 originales por dataset, instante y profundidad superficial. El SHA-256 del binario identifica la versión; no hay remuestreo, compresión destructiva ni eliminación del archivo anterior.
- `chonos-currents-index.json` apunta a los pares completos con dominio, dataset, extensión **real de la malla**, fecha válida, versión y URLs. Se publica después de los binarios y metadatos, mediante reemplazos atómicos. La pareja antigua `chonos-currents.json/.bin` sigue disponible para compatibilidad.
- Se conservan ejes, pasos de tiempo, profundidad, resolución, `validTime`, `availableAt` y versión. `issuedAt` continúa siendo la fecha inferida del nombre de corrida: no acredita su hora real de emisión. Las celdas sin dato conservan su valor original; no se rellenan costas.
- Repetir el mismo paso usa el archivo ya capturado, sin pedir otro ráster. La revisión del catálogo sigue siendo una petición por ejecución del trabajo; se reutilizan los ejes mientras no cambie el dataset. No se comprueban revisiones del proveedor del mismo dataset/paso ya archivado.
- Si falla un dominio, se conserva exclusivamente su captura anterior con su fecha válida original. No se rejuvenece por la fecha de descarga. Si no hay ningún campo válido, el trabajo falla y conserva el índice anterior.
- La vista operacional superficial consume únicamente esos archivos del servidor. Comparte las descargas concurrentes y conserva en memoria un campo por dominio vigente; refresca el índice cada cinco minutos. Cambiar repetidamente de zona no vuelve a consultar CHONOS ni Open-Meteo Marine. Fuera de cobertura se declara ausencia de campo, sin consultas masivas de respaldo.
- Las consultas explícitas de fecha/profundidad para investigación y el replay archivado Taraba mantienen sus rutas propias. El viento conserva su contrato existente; este cambio no generaliza el caché a otras fuentes.

## Encuadres y verificación

El selector centra Aysén en ACS 27 / 28B / 32 (−73,25°, −45,31°, zoom 8,75) y Magallanes en ACS 43A / 46 / 48 (−73,106°, −51,999°, zoom 9). Se eligieron los grupos de tres fondeos más concentrados del catálogo vigente, con las tres boyas dentro del área útil entre paneles. Son encuadres de navegación, no límites administrativos ni cobertura científica nueva.

En la ejecución aislada del servidor se capturaron 2.427.264 bytes para Chiloé y 3.379.728 para Magallanes, válidos el 12-10-2026 00:00 UTC; una segunda ejecución reutilizó ambos. Las pruebas verifican identidad binaria, reutilización, conservación por fallo parcial, descargas compartidas y ausencia de consultas externas al navegar fuera de cobertura. No cambian predictores, pesos, gates, alertas FAN ni afirmaciones de capacidad biológica.
