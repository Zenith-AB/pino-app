# Contrato permanente de arquitectura por etapas

Acuerdo con el usuario del **12-10-2026**. La referencia completa y única se mantiene en [STRATOS — Especificación Causal Predictiva FAN v1.0](STRATOS-ESPECIFICACION-CAUSAL-PREDICTIVA-FAN-V1.0.md).

**Observación → interpretación física → pronóstico ambiental multihorizonte → inteligencia biológica por especie → predicción probabilística validada.**

Modelos y horizontes se eligen por evidencia previa del mismo objetivo/lugar; las relaciones causales son hipótesis contrastables. El estado de implementación y las pruebas figuran en la especificación, sin convertir una dirección de arquitectura en capacidad predictiva aprobada.

## Especialización local obligatoria — acuerdo 13-10-2026

Cada boya y cada centro tiene su propio contrato de predicción. La unidad de selección, ajuste, calibración, evaluación y aprobación es **tipo de entidad + identificador + variable/objetivo + profundidad/soporte espacial + horizonte**. Para biología incluye además el taxón y la definición del evento. D7, D14 y D30 son decisiones separadas: un sitio puede tener diferentes candidatos seleccionados por variable y horizonte.

«Modelo propio» exige identidad, datos admisibles, artefacto/versionado, métricas y decisión locales. Dos sitios pueden seleccionar el mismo algoritmo; eso no autoriza compartir automáticamente sus parámetros, calibración, aprobación ni métricas. Persistencia o climatología también pueden ser el modelo local seleccionado. Compartir una arquitectura, ingesta o representación preentrenada es compatible con este contrato; un ajuste conjunto o transferencia entre sitios debe evaluarse explícitamente contra las alternativas locales antes de usarse.

Un centro no hereda el modelo ni la precisión de la boya más cercana. Sus entradas deben conservar su soporte: medición del centro, contexto observado en otra ubicación o campo modelado. Sin datos/referencia suficientes, el contrato del centro queda pendiente o no evaluable; no se inventa un entrenamiento local. La especialización busca mejorar el desempeño, pero su mejora se comprueba sobre datos posteriores y baselines del mismo objetivo, no se presume por tener más modelos.

**Estado al acuerdo:** el benchmark de especialistas ya ajusta y selecciona por boya/variable/D7–D14–D30 en cinco boyas, conservando profundidad y unidad de cada serie. Eso no representa todas las boyas ni acredita modelos entrenados por centro. La extensión a centros y otros canales/profundidades sigue pendiente de dataset, preregistro y evaluación propios. Este acuerdo no promueve candidatos de laboratorio ni modifica emisiones o alertas.

**Ejecución posterior del 13-10-2026:** [entrenamiento de las15 boyas ACS](ENTRENAMIENTO-TODAS-BOYAS-2026-10-13.md) con artefactos separados por sensor/unidad/profundidad/horizonte. Se verificaron 628 artefactos históricos y5.851 pares; además743 artefactos actuales en todas las boyas y382 emisiones futuras en sombra. La ampliación a boyas está ejecutada en laboratorio, con abstenciones explícitas. La versión actual requiere test prospectivo propio; no hereda la precisión de pesos anteriores. Centros, aprobación productiva y biología siguen siendo tareas/evidencias distintas.


**Integración ambiental 2.0 del 13-10-2026:** [control diario y operación](ARQUITECTURA-PREDICTIVA-2.0-2026-10-13.md) conecta los artefactos actuales de las 15 boyas con emisión experimental y verificación prospectiva propia. El despliegue de software no aprueba un ganador científico, centros ni la salida probabilística biológica. No se cambia el criterio de aprobación para acomodar los resultados.
