---
name: stratos-centro-inmersivo
description: "Construye o adapta el recorrido STRATOS mapa vivo → foco de centro → escena lateral submarina, con sensores, partículas y extensión de videos de detección. Úsala para esa interacción espacial."
---

# Centro inmersivo

Lee [recorrido y escena](references/recorrido.md) para selección/cámara y [videos](references/videos.md)
si se incorpora detección. Los componentes y el asset submarino real están en `references/codigo/`
y `assets/`. Consulta `references/FUENTES.json` para procedencia del snapshot, no para afirmar producción.

## Mantener continuidad

Mapa, foco y escena representan el mismo centerId, periodo y contexto. Al volver, conserva cámara y
filtros del mapa. Escape primero cierra detalle y luego libera foco. Cancelar una transición anterior
al seleccionar otro centro; no dejar que una respuesta tardía pinte otra identidad.

La implementación inspeccionada no escucha un doble clic literal para abrir detalle: el reducer
enfoca con el primer clic y abre con otro clic sobre el mismo centro cuando ya está cerca. Para la
demo haz visible el botón «Vista submarina». Si se requiere doble clic literal, implementar un gesto
explícito sin carreras con zoom de Leaflet y conservar el botón y teclado equivalentes.

## Escena

CenterDetailStage + CenterDetailHero, cámara de escena y FlowParticleField. Imagen lateral a sangre,
horizonte y fondo calibrados; sondas colocadas con profundidad de la lectura. No es una fotografía
submarina, un gemelo digital levantado ni un inventario verificado. Conservar ese pie.
La línea decorativa de capa no es termoclina medida. Una sonda de 60 m no se dibuja bajo un fondo de 42 m.
Los datos contextuales de boya nunca se convierten visualmente en sondas instaladas en las jaulas.

## Evidencia y degradación

Corrientes CHONOS son modeladas; ausencia de modelo no habilita una animación con valor inventado.
Distinguir efectos ambientales puramente ilustrativos de partículas dirigidas por datos. Rail de
fuentes y fichas exponen ubicación, distancia, profundidad, hora y QC. No dibujar conexiones por proximidad.
Probar pan/zoom, fondo sin asset, carga lenta, cambio rápido de centro, vuelta y reduced-motion.

Índice de código y assets: [references/INDICE.md](references/INDICE.md).
