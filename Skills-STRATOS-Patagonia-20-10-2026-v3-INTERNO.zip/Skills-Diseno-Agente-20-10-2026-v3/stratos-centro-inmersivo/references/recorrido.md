# Mapa, cámara y escena

## Recorrido inspeccionado

`centerSelectionState.ts`: overview → centerClicked distinto selecciona y avanza focusNonce;
mismo centro + isClose abre center-detail. `focusCenter` siempre reencuadra. `openDetail` permite
entrada explícita; `escape` cierra y luego limpia. No documentar doble clic nativo como ya implementado.
`StratosMapView.tsx` usa fadeFlight para llegar nítido al zoom de inspección; controles no deben pelear
con el arrastre del lienzo. El centro tiene camera offset para compensar paneles.

Stack: Leaflet, Esri World Imagery satelital y Esri Dark Gray oscuro. Detalle submétrico desde z12;
maxNativeZoom 18 según configuración: zoom superior amplía la imagen, no crea resolución.
HighResolutionImageryLayer y metadatos Esri conservan atribución/fecha cuando disponible.
CROCO/CHONOS alimenta el campo de partículas; máscaras impiden trazos sobre tierra. Mantener el
presupuesto frameBudget/renderTier y pausar capas no visibles. La deformación cartográfica y el
rumbo geográfico no se sustituyen por una dirección de pantalla arbitraria.

## Escena lateral

`CenterDetailStage.tsx` conserva la escena saliente durante el fade, recentra al entrar y usa
`useSceneCamera`. `CenterDetailHero.tsx` posiciona imagen y anclas con la misma transformación.
Función de referencia: y = waterlineY + depthM/siteDepthM × (seabedY-waterlineY).
Sólo se utiliza si la escala está justificada; los números del asset son calibración ilustrativa,
no un sondaje nuevo. Sin profundidad/escala, mostrar la escena sin anclas cuantitativas.

Configuración Reloncaví local: imagen 1916×821, waterline .368, seabed .85, profundidad declarada
42 m, línea de capa 14 m, zoom inspección 17.25. Son parámetros de este sitio/ilustración; no copiar
a otros centros como medición. El alt original declara seis jaulas representadas e inventario no verificado.

Rail de fuentes en borde opuesto a las partículas; controles en banda libre; ocultar etiquetas ocluidas
por paneles; instrumentos en glass sin tapar la jaula seleccionada. La profundidad real de un sensor
contextual no legitima colocarlo como instrumento local: identificar su origen o moverlo a un rail separado.

## Videos y agente

La detección se abre desde una región/cámara seleccionada o acción del agente, con selección explícita.
Preguntar sobre un clip incorpora cameraId/videoId/intervalo al estado. Los gráficos conservan el
periodo ambiental; sólo sincronizan si hay timestamps compatibles. Ofrecer volver al instante anterior.
