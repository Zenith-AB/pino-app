// Configuración de sitio de Centro Reloncaví: geometría sobre el mapa y calibración
// de la vista lateral. Es lo único que no viene de una fuente — el levantamiento de
// la concesión y las medidas tomadas sobre la imagen Vivid (Esri, 2026-03-08)— y por
// eso vive aquí y no en la telemetría, que la arma `lib/centers/sensorTelemetry`.

import type { CenterHeroConfig, CenterSite } from './centerDetail.types.ts';

/** Dos módulos de 2×5 jaulas medidos sobre la imagen Vivid (Esri, 2026-03-08). */
export const RELONCAVI_SITE: CenterSite = {
  footprint: [
    [
      [-41.700902, -72.637733],
      [-41.701231, -72.637062],
      [-41.702733, -72.638323],
      [-41.702412, -72.639047],
    ],
    [
      [-41.701591, -72.636257],
      [-41.701892, -72.635453],
      [-41.703494, -72.636767],
      [-41.703153, -72.637411],
    ],
  ],
  influenceRadiusM: 420,
  // ~150 m aguas arriba (NE) sobre el eje del canal entre módulos, en agua abierta.
  simulationOrigin: { longitude: -72.63646, latitude: -41.70107 },
  // Cubre ambos módulos: la pluma pasa por el canal central y bordea las jaulas exteriores.
  flowHalfWidthM: 420,
  spawnRadiusM: 150,
  inspectionZoom: 17.25,
  depthM: 42,
  layerLineDepthM: 14,
};

export const RELONCAVI_HERO: CenterHeroConfig = {
  imageSrc: '/assets/stratos/centers/centro-reloncavi-lateral.png',
  imageWidth: 1916,
  imageHeight: 821,
  alt: 'Ilustración lateral submarina del centro: seis jaulas representadas con redes, fondeos y fondo marino del fiordo; no corresponde a un inventario verificado',
  caption: 'Ilustración submarina · inventario actual no verificado',
  waterlineY: 0.368,
  seabedY: 0.85,
  cages: [
    [0.034, 0.137, 0.635],
    [0.187, 0.3, 0.64],
    [0.349, 0.458, 0.655],
    [0.506, 0.618, 0.655],
    [0.672, 0.783, 0.65],
    [0.836, 0.948, 0.65],
  ],
  flowScreenDirection: 1,
  // Canal entre la 2ª y 3ª jaula, capa superficial: aguas arriba del tramo que abre el encuadre inicial.
  simulationOrigin: { x: 0.33, y: 0.44 },
  focus: { x: 0.5, y: 0.6 },
  // Las seis sondas de columna de la boya cuelgan del mismo cable: se reparten en
  // horizontal sobre la escena, pero cada tarjeta se ancla a la profundidad real de
  // su lectura (`sensorTelemetry`), no a una decorativa. Como todas las de
  // superficie caen en la misma fila, el reparto deja libre el tramo del origen de
  // simulación (x 0.33): ahí vive su propia etiqueta y dos tarjetas se pisarían.
  probes: [
    { reading: 'turbidity', x: 0.105 },
    { reading: 'chlorophyll', x: 0.24 },
    { reading: 'surfaceTemperature', x: 0.482 },
    { reading: 'depthTemperature', x: 0.482 },
    { reading: 'dissolvedOxygen', x: 0.645 },
    { reading: 'salinity', x: 0.805 },
  ],
};
