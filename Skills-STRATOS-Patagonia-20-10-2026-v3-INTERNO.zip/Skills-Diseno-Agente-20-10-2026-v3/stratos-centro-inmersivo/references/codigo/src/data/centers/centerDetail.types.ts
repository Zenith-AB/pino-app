// Modelo del detalle de un centro de cultivo. Separa lecturas crudas (telemetría),
// geometría del sitio en el mapa y la vista lateral: la telemetría la arma
// `lib/centers/sensorTelemetry` a partir de las fuentes reales; el formateo y los
// umbrales viven en lib/centers.
//
// Ninguna lectura es obligatoria. `value: null` es una respuesta legítima —no hay
// sonda, o la que hay publica un valor que IFOP no certifica— y la interfaz la
// pinta como tal. Rellenar ese hueco con un escenario sería exactamente lo que
// esta capa existe para impedir.

import type { Provenance, ResolvedBuoy } from '@datasource';
import type { LngLat } from '../../config/map/types.ts';
import type { CultivationCenter } from '../stratosTypes.ts';

/** Estado operativo del centro tal como se comunica al usuario. */
export type CenterStatus = 'normal' | 'vigilancia' | 'riesgo';

/**
 * Qué tan lejos está una lectura de ser un número publicable.
 *
 * `suspect` y `missing` no son lo mismo y piden acciones distintas: en la primera
 * hay una sonda reportando algo que el proveedor no certifica; en la segunda no
 * hay sonda. La interfaz muestra `—` en ambos casos, pero lo dice distinto.
 */
export type ReadingQuality = 'good' | 'suspect' | 'missing';

export interface SensorReading {
  /** `null` si no hay medición utilizable. Nunca se sustituye por un escenario. */
  value: number | null;
  /** Variación en las últimas 24 h, en la unidad de la lectura. */
  delta24h?: number;
  /** Profundidad de la sonda que la midió. */
  depthM?: number | null;
  /** Unidad tal como la publica la fuente (`mg/m³`, `PSU`, `NTU`…). */
  unit?: string;
  quality: ReadingQuality;
  /**
   * La misma variable en la sonda profunda de la misma boya. La boya mide toda la
   * columna y hasta ahora sólo se publicaba la mitad de arriba; con las dos, cada
   * tarjeta dice si el valor de superficie es la columna entera o sólo su techo.
   * Nunca anida a su vez: una lectura profunda no tiene otra debajo.
   */
  deep?: Omit<SensorReading, 'deep' | 'delta24h'>;
}

export interface CenterTelemetry {
  /** Última transmisión recibida (ISO 8601), o `null` si nunca llegó una. */
  updatedAt: string | null;
  /** Procedencia del conjunto de la columna de agua: lo que la cabecera declara. */
  provenance: Provenance;
  /** Instrumento que sostiene la columna de agua ("Boya ACS1 · 5 m"), para trazar el número. */
  columnSource: string | null;
  /** La boya que la red asignó a este centro, con su distancia a las jaulas. */
  buoy: ResolvedBuoy | null;
  /** Códigos de variable que la boya está reportando en la ventana. */
  columnVariables: string[];
  surfaceTemperatureC: SensorReading;
  depthTemperatureC: SensorReading;
  salinityPsu: SensorReading;
  dissolvedOxygenMgL: SensorReading;
  chlorophyllUgL: SensorReading;
  turbidityNtu: SensorReading;
  current: {
    speedMs: number | null;
    /** Rumbo HACIA donde fluye la corriente (grados desde el norte, horario). */
    towardBearingDeg: number | null;
    delta24h?: number;
    /**
     * Procedencia del valor. `model` = CHONOS/MOSA (IFOP), celda de agua más
     * cercana al centro; `none` = el modelo no respondió y no hay valor que mostrar.
     */
    origin?: { kind: 'model'; label: string; validTime: string; distanceKm: number } | { kind: 'none' };
  };
  /**
   * Favorabilidad FAN publicada para el centro: índice 0–100 sin calibrar.
   * No es una probabilidad de floración y no debe presentarse como tal.
   */
  fanFavorability: { index: number; label: string; issuedAt: string | null } | null;
  /**
   * Gradiente térmico medido entre las dos sondas de la boya. `betweenM` son las
   * profundidades reales que se restaron: sin ellas «ΔT 0,9 °C» no significa nada.
   */
  stratification: {
    state: 'Débil' | 'Moderada' | 'Fuerte' | 'Sin dato';
    deltaTempC: number | null;
    betweenM: [surface: number, deep: number] | null;
  };
  /** Forzante continental cercana (río); null si no hay caudal publicado. */
  continentalForcing: {
    source: string;
    model: string;
    dischargeM3s: number;
    changePct: number | null;
    /** Día observado de la cifra (ISO), no el del pronóstico. */
    at: string | null;
  } | null;
}

/** Geometría del centro sobre el mapa y sondaje del sitio. */
export interface CenterSite {
  /** Un anillo [lat, lng] por módulo de jaulas. */
  footprint: Array<Array<[latitude: number, longitude: number]>>;
  influenceRadiusM: number;
  /** Punto aguas arriba desde el que nace la simulación de partículas. */
  simulationOrigin: LngLat;
  /** Semiancho del canal de simulación alrededor del eje que pasa por el origen. */
  flowHalfWidthM: number;
  /** Dispersión del nacimiento de partículas alrededor del origen (m). */
  spawnRadiusM: number;
  /** Zoom de inspección: el footprint completo debe caber sobre el panel de detalle. */
  inspectionZoom: number;
  /**
   * Sondaje del fondo bajo los módulos (m). Es un dato del sitio —levantamiento
   * de la concesión—, no una lectura de sensor: no hay batimetría en las fuentes.
   */
  depthM: number | null;
  /**
   * Profundidad de la línea punteada que la vista lateral dibuja como límite de
   * capa. Es calibración de la escena, no una termoclina medida: con sondas sólo
   * a 5 y 60 m no hay perfil del que sacarla.
   */
  layerLineDepthM: number | null;
}

/** Sonda anclada en la vista lateral: se ubica por profundidad real, no por píxel. */
export interface HeroProbe {
  reading: 'surfaceTemperature' | 'depthTemperature' | 'dissolvedOxygen' | 'chlorophyll' | 'salinity' | 'turbidity';
  /** Posición horizontal normalizada (0–1) sobre la imagen. */
  x: number;
}

/** Calibración de la imagen lateral submarina: coordenadas normalizadas (0–1). */
export interface CenterHeroConfig {
  imageSrc: string;
  imageWidth: number;
  imageHeight: number;
  alt: string;
  caption: string;
  /** y de la superficie del agua y del fondo marino. */
  waterlineY: number;
  seabedY: number;
  /** Redes de jaulas: [x inicial, x final, y del fondo de la red]. */
  cages: Array<[x0: number, x1: number, bottomY: number]>;
  /** Sentido del flujo en pantalla (1 = izquierda → derecha). */
  flowScreenDirection: 1 | -1;
  /** Origen de simulación sobre la imagen: ahí nacen e intensifican las partículas. */
  simulationOrigin: { x: number; y: number };
  /** Punto de la imagen que el encuadre inicial deja al centro del área libre. */
  focus: { x: number; y: number };
  probes: HeroProbe[];
}

export interface CenterDetail {
  center: CultivationCenter;
  subtitle: string;
  status: CenterStatus;
  cages: number;
  /** Sondas de columna que reportan en el centro. 0 mientras la red no responde. */
  sensors: number;
  telemetry: CenterTelemetry;
  site: CenterSite;
  /** Sin vista lateral calibrada el panel muestra sólo KPIs. */
  hero: CenterHeroConfig | null;
}
