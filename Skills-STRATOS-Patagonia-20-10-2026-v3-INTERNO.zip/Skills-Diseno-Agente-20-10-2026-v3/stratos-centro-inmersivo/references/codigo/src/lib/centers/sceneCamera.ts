// Cámara 2D de la vista de detalle: la imagen cubre siempre todo el stage (como el
// mapa) y el usuario la recorre con pan y zoom acotados. Pura, sin DOM.

export interface Size {
  width: number;
  height: number;
}

export interface SceneCamera {
  /** 1 = cubre el stage con un leve margen para permitir pan vertical. */
  zoom: number;
  /** Posición de la esquina superior izquierda de la escena, en px del stage. */
  tx: number;
  ty: number;
}

export const SCENE_MIN_ZOOM = 1;
/** Tope por nitidez: la imagen fuente mide 1916 px; más allá se ve el reescalado. */
export const SCENE_MAX_ZOOM = 1.8;
/** Sobre-escala base: incluso a zoom 1 queda recorrido vertical y horizontal. */
const OVERSCAN = 1.12;

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

export function sceneSize(viewport: Size, image: Size, zoom: number): Size {
  const cover = Math.max(viewport.width / image.width, viewport.height / image.height) * OVERSCAN;
  return { width: image.width * cover * zoom, height: image.height * cover * zoom };
}

/** Nunca deja ver un borde de la escena: la imagen siempre llena el stage. */
export function clampCamera(camera: SceneCamera, viewport: Size, image: Size): SceneCamera {
  const zoom = clamp(camera.zoom, SCENE_MIN_ZOOM, SCENE_MAX_ZOOM);
  const size = sceneSize(viewport, image, zoom);
  return {
    zoom,
    tx: clamp(camera.tx, viewport.width - size.width, 0),
    ty: clamp(camera.ty, viewport.height - size.height, 0),
  };
}

/** Ubica un punto normalizado de la imagen (0–1) sobre un punto del stage (px). */
export function focusCamera(viewport: Size, image: Size, zoom: number, focus: { x: number; y: number }, target: { x: number; y: number }) {
  const size = sceneSize(viewport, image, zoom);
  return clampCamera({ zoom, tx: target.x - focus.x * size.width, ty: target.y - focus.y * size.height }, viewport, image);
}

/** Zoom alrededor de un punto del stage: lo que está bajo el cursor se queda bajo el cursor. */
export function zoomAt(camera: SceneCamera, viewport: Size, image: Size, factor: number, point: { x: number; y: number }) {
  const zoom = clamp(camera.zoom * factor, SCENE_MIN_ZOOM, SCENE_MAX_ZOOM);
  const ratio = zoom / camera.zoom;
  return clampCamera(
    { zoom, tx: point.x - (point.x - camera.tx) * ratio, ty: point.y - (point.y - camera.ty) * ratio },
    viewport,
    image,
  );
}

export function panBy(camera: SceneCamera, viewport: Size, image: Size, dx: number, dy: number) {
  return clampCamera({ ...camera, tx: camera.tx + dx, ty: camera.ty + dy }, viewport, image);
}

/** Punto normalizado de la imagen → px del stage. */
export function toStage(camera: SceneCamera, viewport: Size, image: Size, x: number, y: number) {
  const size = sceneSize(viewport, image, camera.zoom);
  return { x: camera.tx + x * size.width, y: camera.ty + y * size.height };
}

export function interpolateCamera(from: SceneCamera, to: SceneCamera, t: number): SceneCamera {
  return { zoom: from.zoom + (to.zoom - from.zoom) * t, tx: from.tx + (to.tx - from.tx) * t, ty: from.ty + (to.ty - from.ty) * t };
}
