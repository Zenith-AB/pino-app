// Estado de selección de centros y modo del stage central. Puro (sin React) para testearlo.
//
//   overview ──click centro (lejos)──▶ overview + centro en foco (vuelo satelital, sidebars del centro)
//   foco y cerca ──click mismo centro──▶ center-detail (el mapa muta a la vista lateral)
//   center-detail ──Volver / Esc──▶ overview con el centro aún en foco
//   foco ──Esc / cambio de zona──▶ overview regional

export type StageMode = 'overview' | 'center-detail';

export interface CenterSelectionState {
  /** Centro en foco: marcador activo, partículas locales y sidebars con su contexto. */
  selectedId: string | null;
  /** El stage central muestra la vista lateral del centro en foco. */
  detailOpen: boolean;
  /**
   * Contador de peticiones explícitas de encuadre.
   *
   * Existe porque un clic en la tarjeta de un centro ya enfocado no cambia el
   * resto del estado, y sin una marca que avance el mapa no tendría motivo para
   * volver a volar. Con ella, "llévame a este centro" funciona también cuando el
   * usuario ya lo tenía seleccionado y se alejó navegando por el mapa.
   */
  focusNonce: number;
}

export type CenterSelectionAction =
  /** `isClose`: el mapa ya está a zoom de inspección del centro clickeado. */
  | { type: 'centerClicked'; centerId: string; isClose: boolean }
  /** Petición explícita de encuadre, venga de donde venga (tarjeta, buscador, alerta). */
  | { type: 'focusCenter'; centerId: string }
  | { type: 'openDetail'; centerId: string }
  | { type: 'closeDetail' }
  | { type: 'clear' }
  /** Esc: primero sale del detalle; fuera de él, suelta el foco. */
  | { type: 'escape' };

export const INITIAL_CENTER_SELECTION: CenterSelectionState = {
  selectedId: null,
  detailOpen: false,
  focusNonce: 0,
};

export function stageModeOf(state: CenterSelectionState): StageMode {
  return state.selectedId !== null && state.detailOpen ? 'center-detail' : 'overview';
}

export function centerSelectionReducer(state: CenterSelectionState, action: CenterSelectionAction): CenterSelectionState {
  switch (action.type) {
    case 'centerClicked':
      // En overview sólo hay mapa: un centro distinto se enfoca; el mismo, ya cerca, abre su detalle.
      if (state.selectedId !== action.centerId) {
        return { selectedId: action.centerId, detailOpen: false, focusNonce: state.focusNonce + 1 };
      }
      return action.isClose && !state.detailOpen ? { ...state, detailOpen: true } : state;
    case 'focusCenter':
      // Siempre avanza el contador: el encuadre se pidió, aunque el centro ya
      // estuviera en foco y el resto del estado no tenga nada que cambiar.
      return {
        selectedId: action.centerId,
        detailOpen: state.selectedId === action.centerId ? state.detailOpen : false,
        focusNonce: state.focusNonce + 1,
      };
    case 'openDetail':
      return { selectedId: action.centerId, detailOpen: true, focusNonce: state.focusNonce + 1 };
    case 'closeDetail':
      return state.detailOpen ? { ...state, detailOpen: false } : state;
    case 'clear':
      return state.selectedId === null && !state.detailOpen
        ? state
        : { ...INITIAL_CENTER_SELECTION, focusNonce: state.focusNonce };
    case 'escape':
      if (state.detailOpen) return { ...state, detailOpen: false };
      return state.selectedId ? { ...INITIAL_CENTER_SELECTION, focusNonce: state.focusNonce } : state;
    default:
      return state;
  }
}
