// De qué está hecho lo que muestra la vista de un centro.
//
// Cuatro proveedores sostienen esta pantalla y hasta ahora sólo se nombraban de
// refilón, repartidos entre una cabecera y el pie de una tarjeta. Aquí se reúnen
// en una lista con lo que hace falta para juzgar cada uno: qué entrega, a qué
// distancia del centro está midiendo y de cuándo es su último dato.
//
// Nada se declara si no llegó. Una fuente que no respondió aparece con su estado
// y sin cifras, que es distinto de no aparecer: el operador tiene que poder ver
// que el caudal falta, no deducirlo de un hueco.

import type { Icon } from '@phosphor-icons/react';
import { ChartLineUp, CloudRain, Lifebuoy, Waves } from '@phosphor-icons/react';
import type { CenterDetail } from '../../data/centers/centerDetail.types';
import { SENSOR_VARIABLES } from '../sensors/sensorCards.ts';

/** Qué clase de número entrega la fuente. Condiciona cómo se puede leer. */
export type SourceKind = 'observación' | 'modelo' | 'pronóstico';

export interface CenterSource {
  id: string;
  /** Nombre corto para el icono y la cabecera de la ficha. */
  label: string;
  /** Organismo o producto responsable del dato. */
  provider: string;
  kind: SourceKind;
  icon: Icon;
  /** Qué entrega, en el vocabulario de la interfaz. */
  variables: string[];
  /** Del instrumento o celda a las jaulas. `null` cuando la fuente no es puntual. */
  distanceKm: number | null;
  /** Instante del último dato (ISO), para "actualizado hace…". */
  updatedAt: string | null;
  /** Salvedad que hay que leer junto a la cifra, si la hay. */
  caveat?: string;
  /** Hay dato utilizable ahora mismo. */
  live: boolean;
}

/** `water_temperature` → «Temperatura», con el mismo nombre que la vista Sensores. */
function variableLabel(code: string): string {
  return SENSOR_VARIABLES[code]?.label ?? code;
}

export function centerSources(detail: CenterDetail): CenterSource[] {
  const t = detail.telemetry;
  const { buoy, current, continentalForcing: river, fanFavorability: fan } = t;

  const sources: CenterSource[] = [
    {
      id: 'acs',
      label: buoy ? `Boya ${buoy.code.toUpperCase()}` : 'Boya ACS',
      provider: 'IFOP · red ACS/SOTRACS',
      kind: 'observación',
      icon: Lifebuoy,
      // Las que la sonda está reportando en la ventana, no las que el catálogo promete.
      variables: t.columnVariables.map(variableLabel),
      distanceKm: buoy && !buoy.assumed ? buoy.distanceKm : null,
      updatedAt: t.updatedAt,
      caveat:
        buoy?.assumed
          ? 'Asignación sin verificar: el catálogo de la red no respondió'
          : buoy && buoy.estatus !== 'operativa'
            ? `Estación ${buoy.estatus.replace(/_/g, ' ')}`
            : undefined,
      live: t.provenance === 'live' && t.columnVariables.length > 0,
    },
    {
      id: 'chonos',
      label: 'CHONOS / MOSA',
      provider: 'IFOP · CROCO 1 km',
      kind: 'modelo',
      icon: Waves,
      variables: ['Velocidad de corriente', 'Dirección de corriente'],
      distanceKm: current.origin?.kind === 'model' ? current.origin.distanceKm : null,
      updatedAt: current.origin?.kind === 'model' ? current.origin.validTime : null,
      caveat: 'Campo modelado, no medido',
      live: current.speedMs !== null,
    },
    {
      id: 'glofas',
      label: river ? river.source : 'Caudal continental',
      provider: `${river?.model ?? 'GloFAS'} · Open-Meteo`,
      kind: 'modelo',
      icon: CloudRain,
      variables: ['Caudal del cauce principal'],
      distanceKm: null,
      updatedAt: river?.at ?? null,
      // GloFAS es un modelo hidrológico global, no una estación de aforo.
      caveat: 'Modelo global, no aforo',
      live: river !== null,
    },
    {
      id: 'fan',
      label: 'Favorabilidad FAN',
      provider: 'STRATOS · ensemble GEFS',
      kind: 'pronóstico',
      icon: ChartLineUp,
      variables: ['Índice 0–100 por día', 'Cuantiles p10–p90'],
      distanceKm: null,
      updatedAt: fan?.issuedAt ?? null,
      caveat: 'Índice sin calibrar: no es una probabilidad de floración',
      live: fan !== null,
    },
  ];

  return sources;
}

/** «28 km», «0,4 km»: bajo el kilómetro la cifra redonda diría que está encima. */
export function distanceLabel(km: number | null): string | null {
  if (km === null) return null;
  return `${km < 10 ? km.toFixed(1) : Math.round(km)} km`;
}
