// Fuente del detalle de centros.
//
// Aquí vive lo que NO viene de una fuente de datos: la geometría del sitio sobre el
// mapa, la calibración de la vista lateral y el sondaje de la concesión. La
// telemetría no se arma en este archivo — la compone `useCenterDetail` a partir de
// las sondas ACS, el modelo CHONOS, el caudal GloFAS y el pronóstico del centro—,
// de modo que un centro sin fuentes abre con la escena dibujada y las lecturas en
// blanco, no con números inventados.

import type { CenterDetail, CenterSite, CenterTelemetry } from '../../data/centers/centerDetail.types.ts';
import { RELONCAVI_HERO, RELONCAVI_SITE } from '../../data/centers/reloncavi.site.ts';
import type { CultivationCenter } from '../../data/stratosTypes.ts';
import { METERS_PER_DEG_LAT, metersPerDegLon } from '../particles/velocityField.ts';
import { centerStatusFromState } from './sensorKpis.ts';
import { EMPTY_WATER_COLUMN } from './sensorTelemetry.ts';

export interface CenterDetailSource {
  load(center: CultivationCenter, signal?: AbortSignal): Promise<CenterDetail>;
}

const SUBTITLE = 'Vista hidrodinámica y sensórica';

type CenterConfig = {
  site: CenterSite;
  hero: CenterDetail['hero'];
};

/** Configuración estable por centro. Agregar un centro = agregar una entrada. */
const CENTER_CONFIGS: Record<string, CenterConfig> = {
  reloncavi: { site: RELONCAVI_SITE, hero: RELONCAVI_HERO },
};

/**
 * Centro sin configuración: sólo el canal de simulación que necesitan las
 * partículas del mapa. Sin levantamiento no hay sondaje ni vista lateral, y eso
 * se declara con `null` en vez de con una cifra plausible.
 */
function derivedConfig(center: CultivationCenter): CenterConfig {
  const bearing = 225;
  const upstream = 150;
  const radians = ((bearing + 180) * Math.PI) / 180;
  return {
    hero: null,
    site: {
      footprint: [],
      influenceRadiusM: 400,
      simulationOrigin: {
        longitude: center.lng + (Math.sin(radians) * upstream) / metersPerDegLon(center.lat),
        latitude: center.lat + (Math.cos(radians) * upstream) / METERS_PER_DEG_LAT,
      },
      flowHalfWidthM: 300,
      spawnRadiusM: 110,
      inspectionZoom: 17.25,
      depthM: null,
      layerLineDepthM: null,
    },
  };
}

/** Telemetría sin ninguna fuente resuelta: la que el detalle trae antes del merge. */
export function emptyTelemetry(): CenterTelemetry {
  return {
    updatedAt: EMPTY_WATER_COLUMN.updatedAt,
    provenance: EMPTY_WATER_COLUMN.provenance,
    columnSource: EMPTY_WATER_COLUMN.columnSource,
    buoy: EMPTY_WATER_COLUMN.buoy,
    columnVariables: EMPTY_WATER_COLUMN.variables,
    surfaceTemperatureC: EMPTY_WATER_COLUMN.surfaceTemperatureC,
    depthTemperatureC: EMPTY_WATER_COLUMN.depthTemperatureC,
    salinityPsu: EMPTY_WATER_COLUMN.salinityPsu,
    dissolvedOxygenMgL: EMPTY_WATER_COLUMN.dissolvedOxygenMgL,
    chlorophyllUgL: EMPTY_WATER_COLUMN.chlorophyllUgL,
    turbidityNtu: EMPTY_WATER_COLUMN.turbidityNtu,
    current: { speedMs: null, towardBearingDeg: null, origin: { kind: 'none' } },
    fanFavorability: null,
    stratification: EMPTY_WATER_COLUMN.stratification,
    continentalForcing: null,
  };
}

export function getCenterDetail(center: CultivationCenter): CenterDetail {
  const config = CENTER_CONFIGS[center.id] ?? derivedConfig(center);
  return {
    center,
    subtitle: SUBTITLE,
    status: centerStatusFromState(center.state),
    cages: center.cages ?? 12,
    sensors: 0,
    telemetry: emptyTelemetry(),
    site: config.site,
    hero: config.hero,
  };
}

/** Sitio y escena del centro. La telemetría la ponen las fuentes, encima de esto. */
export const siteCenterDetailSource: CenterDetailSource = {
  async load(center) {
    return getCenterDetail(center);
  },
};
