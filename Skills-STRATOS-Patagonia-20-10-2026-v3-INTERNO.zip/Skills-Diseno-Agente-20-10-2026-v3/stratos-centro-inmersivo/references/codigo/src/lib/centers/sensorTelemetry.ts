// Sondas reales de un centro → la telemetría que pintan la vista lateral y sus KPIs.
//
// La fuente es la misma red ACS/SOTRACS de 72 h que ya sostiene las tarjetas del
// panel izquierdo y la vista «Sensores» (`sensorNetworkStore`), así que el detalle
// de un centro no pide nada por su cuenta: lee lo que ya está cargado y lo traduce.
//
// Dos reglas gobiernan todo lo de aquí:
//
//   · Una lectura que IFOP no marca `GOOD` no se promueve a cifra. Existe —y se
//     dice que existe, con `quality: 'suspect'`—, pero no ocupa el lugar de una
//     medición certificada. acs17a lleva la salinidad entera en `SUSPECT` con
//     36,7 PSU en superficie de fiordo, que es una avería de sonda.
//   · Lo que no hay se declara `null`. Ningún hueco se rellena con un escenario.

import type { CenterSensors, SensorChannel } from '../../../datasource/sources/acs-sotracs/centers.ts';
import type { ResolvedBuoy } from '../../../datasource/sources/acs-sotracs/buoyBinding.ts';
import type { AcsPoint } from '../../../datasource/sources/acs-sotracs/types.ts';
import type { SourceResult } from '../../../datasource/core/types.ts';
import type { CenterTelemetry, SensorReading } from '../../data/centers/centerDetail.types.ts';

/**
 * Profundidad nominal de la sonda de superficie en la red ACS. Sólo se usa como
 * respaldo del rótulo: la profundidad buena es la que publica cada sonda.
 */
const SURFACE_M = 5;

/**
 * Las dos sondas de columna de una boya, por su código de instrumento.
 *
 * Se eligen por instrumento y no por cercanía a una profundidad: preguntando por
 * «la más próxima a 60 m» una boya que sólo monta la de superficie devolvía esa
 * misma, y la tarjeta acababa mostrando el valor de 5 m repetido como si fuera el
 * del fondo. No hay profundidad a la que una sonda deje de ser la que es.
 */
const SURFACE_PROBE = 'sonda_sup';
const DEEP_PROBE = 'sonda_prof';

/** Lecturas recientes que se miran para encontrar una buena: las últimas ~6 horas. */
const LOOKBACK_POINTS = 6;

/** Tolerancia al emparejar la lectura de hace 24 h: la boya publica por hora. */
const DELTA_WINDOW_MS = 90 * 60_000;

const isGood = (point: AcsPoint) => point.flag.symbol === 'GOOD';

/** «0,4» o «28»: bajo el kilómetro la cifra redonda diría que la boya está encima. */
const decimalKm = (km: number) => (km < 10 ? km.toFixed(1) : String(Math.round(km)));

/** Sin lectura no hay número: es la respuesta por defecto de toda variable. */
const NO_READING: SensorReading = { value: null, quality: 'missing' };

/** Canal de una variable en una de las dos sondas. `null` si esa sonda no la mide. */
function channelOf(channels: SensorChannel[], variableCode: string, instrumentCode: string): SensorChannel | null {
  return (
    channels.find((channel) => channel.variableCode === variableCode && channel.instrumentCode === instrumentCode) ?? null
  );
}

/**
 * Variación en 24 h de una serie horaria: se compara la última lectura buena con la
 * buena más próxima a 24 h antes. Si no hay pareja dentro de la tolerancia no se
 * devuelve nada — una diferencia contra una lectura de hace 40 h no es «24 h».
 */
function delta24h(points: AcsPoint[], latest: AcsPoint): number | undefined {
  const target = Date.parse(latest.time) - 24 * 3_600_000;
  let best: AcsPoint | null = null;
  let bestGap = DELTA_WINDOW_MS;
  for (const point of points) {
    if (!isGood(point)) continue;
    const gap = Math.abs(Date.parse(point.time) - target);
    if (gap <= bestGap) {
      best = point;
      bestGap = gap;
    }
  }
  return best ? latest.value - best.value : undefined;
}

/**
 * Última lectura utilizable de un canal. Se busca una `GOOD` entre las recientes;
 * si no la hay, la más nueva se devuelve como dudosa y sin valor: el número no se
 * publica, pero la interfaz puede decir que el sensor está reportando basura.
 */
export function readingFrom(channel: SensorChannel | null): SensorReading {
  if (!channel || channel.points.length === 0) return NO_READING;
  const recent = channel.points.slice(-LOOKBACK_POINTS).reverse();
  const good = recent.find(isGood);
  if (!good) {
    return { value: null, quality: 'suspect', depthM: channel.depthM, unit: channel.unit };
  }
  return {
    value: good.value,
    delta24h: delta24h(channel.points, good),
    depthM: channel.depthM,
    unit: channel.unit,
    quality: 'good',
  };
}

/** Hora de la lectura mostrada, para la línea de «actualizado hace…». */
function latestGoodTime(channels: SensorChannel[]): string | null {
  let newest: string | null = null;
  for (const channel of channels) {
    for (const point of channel.points) {
      if (!isGood(point)) continue;
      if (!newest || Date.parse(point.time) > Date.parse(newest)) newest = point.time;
    }
  }
  return newest;
}

/**
 * Estratificación medida: la resta entre las dos sondas de la misma boya,
 * emparejadas por hora. Los umbrales siguen la práctica del mar interior — por
 * debajo de ~1 °C en 55 m de columna la mezcla domina y la retención superficial
 * que favorece una floración deja de sostenerse.
 */
export function stratificationFrom(channels: SensorChannel[]): CenterTelemetry['stratification'] {
  const surface = channelOf(channels, 'water_temperature', SURFACE_PROBE);
  const deep = channelOf(channels, 'water_temperature', DEEP_PROBE);
  if (!surface || !deep || surface.depthM === null || deep.depthM === null || surface.depthM === deep.depthM) {
    return { state: 'Sin dato', deltaTempC: null, betweenM: null };
  }

  const deepByTime = new Map(deep.points.filter(isGood).map((point) => [point.time, point.value]));
  let deltaTempC: number | null = null;
  for (const point of surface.points.filter(isGood)) {
    const deepValue = deepByTime.get(point.time);
    if (deepValue === undefined) continue;
    deltaTempC = Number((point.value - deepValue).toFixed(2));
  }

  if (deltaTempC === null) return { state: 'Sin dato', deltaTempC: null, betweenM: null };
  const magnitude = Math.abs(deltaTempC);
  return {
    state: magnitude >= 2 ? 'Fuerte' : magnitude >= 1 ? 'Moderada' : 'Débil',
    deltaTempC,
    betweenM: [surface.depthM as number, deep.depthM as number],
  };
}

export interface WaterColumn {
  updatedAt: string | null;
  provenance: CenterTelemetry['provenance'];
  columnSource: string | null;
  /** La boya que la red asignó al centro. `null` mientras no hay red. */
  buoy: ResolvedBuoy | null;
  /** Códigos de variable presentes en la ventana, sin repetir y en orden de lectura. */
  variables: string[];
  /** Sondas de columna que reportaron en la ventana. */
  probeCount: number;
  surfaceTemperatureC: SensorReading;
  depthTemperatureC: SensorReading;
  salinityPsu: SensorReading;
  dissolvedOxygenMgL: SensorReading;
  chlorophyllUgL: SensorReading;
  turbidityNtu: SensorReading;
  stratification: CenterTelemetry['stratification'];
}

/** Columna de agua sin ninguna sonda: la forma que la interfaz pinta como «—». */
export const EMPTY_WATER_COLUMN: WaterColumn = {
  updatedAt: null,
  provenance: 'missing',
  columnSource: null,
  buoy: null,
  variables: [],
  probeCount: 0,
  surfaceTemperatureC: NO_READING,
  depthTemperatureC: NO_READING,
  salinityPsu: NO_READING,
  dissolvedOxygenMgL: NO_READING,
  chlorophyllUgL: NO_READING,
  turbidityNtu: NO_READING,
  stratification: { state: 'Sin dato', deltaTempC: null, betweenM: null },
};

/**
 * Estado de la columna de agua de un centro a partir de su red de sondas.
 *
 * La clorofila es la fluorescencia a 5 m —la señal de biomasa medida in situ— y
 * `mg/m³` es numéricamente `µg/L`: la unidad que viaja es la que publica IFOP.
 */
export function waterColumnFrom(result: SourceResult<CenterSensors> | null | undefined): WaterColumn {
  const sensors = result?.data;
  // Sin boya no hay procedencia que declarar, y una cifra sin procedencia no se
  // publica. Pasa si una red guardada por otra versión del código llega hasta
  // aquí: se trata como ausencia, que es visible, y no se revienta la pantalla.
  if (!result || !sensors?.buoy) return EMPTY_WATER_COLUMN;
  const { channels } = sensors;
  const surface = (variableCode: string) => readingFrom(channelOf(channels, variableCode, SURFACE_PROBE));
  /**
   * Lectura de superficie con su contrapartida a 60 m. La temperatura queda fuera
   * a propósito: su sonda profunda ya tiene KPI propio y repetirla dentro de la
   * de superficie sería el mismo número dos veces en tarjetas contiguas.
   */
  const column = (variableCode: string) => ({
    ...surface(variableCode),
    deep: readingFrom(channelOf(channels, variableCode, DEEP_PROBE)),
  });

  return {
    updatedAt: latestGoodTime(channels),
    provenance: result.state,
    buoy: sensors.buoy,
    variables: [...new Set(channels.map((channel) => channel.variableCode))],
    // La profundidad de la sonda la declara la propia sonda; SURFACE_M es el
    // valor nominal de la red y sólo se usa si ninguna la publica. La distancia
    // va delante del resto: es lo que decide si el número describe este centro.
    columnSource: [
      `Boya ${sensors.buoy.code.toUpperCase()}`,
      sensors.buoy.assumed ? 'asignación sin verificar' : `a ${decimalKm(sensors.buoy.distanceKm)} km`,
      `${Math.round(channelOf(channels, 'water_temperature', SURFACE_PROBE)?.depthM ?? SURFACE_M)} m`,
    ].join(' · '),
    probeCount: channels.length,
    surfaceTemperatureC: surface('water_temperature'),
    depthTemperatureC: readingFrom(channelOf(channels, 'water_temperature', DEEP_PROBE)),
    salinityPsu: column('salinity'),
    dissolvedOxygenMgL: column('oxygen_conc'),
    chlorophyllUgL: column('fluorescence'),
    turbidityNtu: column('turbidity'),
    stratification: stratificationFrom(channels),
  };
}
