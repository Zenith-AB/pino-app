// Detalle de centro con la corriente del modelo real: el mismo campo CHONOS/MOSA
// que dibujan el mapa y las partículas. El resto de la telemetría no pasa por aquí
// —la columna de agua viene de las sondas ACS y se mezcla en `useCenterDetail`—,
// así que este módulo sólo resuelve `telemetry.current`.

import type { CenterDetail } from '../../data/centers/centerDetail.types';
import { loadChonosCurrents } from '../currents/chonosCurrents';
import { sampleNearestWater, vectorToCourse } from '../currents/currentGrid';
import { siteCenterDetailSource, type CenterDetailSource } from './centerDetailSource';

/** Un centro está en la costa: se admite la celda de agua más cercana hasta esta distancia. */
const MAX_CELL_DISTANCE_KM = 3;

export function withChonosCurrent(base: CenterDetailSource): CenterDetailSource {
  return {
    async load(center, signal) {
      const detail = await base.load(center, signal);
      try {
        const result = await loadChonosCurrents(center.lng, center.lat);
        const sample = result && sampleNearestWater(result.grid, center.lng, center.lat, MAX_CELL_DISTANCE_KM);
        if (!result || !sample) return detail;
        const { speedMs, towardBearingDeg } = vectorToCourse(sample);
        return {
          ...detail,
          telemetry: {
            ...detail.telemetry,
            current: {
              speedMs,
              towardBearingDeg,
              origin: {
                kind: 'model',
                label: `${result.grid.source}${result.stale ? ' · desfasado' : ''}`,
                validTime: result.grid.validTime,
                distanceKm: sample.distanceKm,
              },
            },
          },
        };
      } catch (error) {
        console.warn('[STRATOS:centerDetail] corriente CHONOS no disponible:', (error as Error)?.message);
        // Sin modelo no hay corriente que mostrar: el detalle la deja en `none`.
        return detail;
      }
    },
  };
}

export const chonosCenterDetailSource = withChonosCurrent(siteCenterDetailSource);
