// Vuelo de cámara con fundido.
//
// Un `flyTo` de Leaflet hasta el zoom de inspección (18) escala los tiles de los
// niveles que atraviesa: durante el vuelo y al llegar —mientras cargan los del
// nivel final— el mapa se ve pixelado. En vez de mostrar ese tránsito, el lienzo se
// funde, la cámara salta a su encuadre final a oscuras y el mapa vuelve cuando las
// capas de tiles terminaron de cargar, ya nítido.

export const CAMERA_FADE = {
  /** Salida corta: el gesto responde al clic de inmediato. */
  outMs: 220,
  /** Entrada más larga, que se posa. */
  inMs: 480,
  /** Tiempo mínimo a oscuras: deja montar capas que llegan un render después (imagen submétrica). */
  minSettleMs: 160,
  /** Tope de espera: una capa lenta o caída no deja el mapa oculto. */
  maxSettleMs: 1600,
} as const;

export type CameraFadePhase = 'idle' | 'out' | 'in';

/** Lo que el vuelo necesita del mapa (Leaflet lo cumple). */
export interface TileAwareMap {
  eachLayer(callback: (layer: unknown) => void): unknown;
}

export interface FadeFlightEnvironment {
  setPhase: (phase: CameraFadePhase) => void;
  /** Mueve la cámara al encuadre final sin animación. */
  jump: () => void;
  /** Hay capas de tiles cargando. */
  tilesLoading: () => boolean;
  /** Espera `ms`; resuelve `false` si se canceló. */
  sleep: (ms: number, signal: AbortSignal) => Promise<boolean>;
  /** Siguiente fotograma; resuelve `false` si se canceló. */
  nextFrame: (signal: AbortSignal) => Promise<boolean>;
  now: () => number;
  reducedMotion: boolean;
}

/** Alguna capa de tiles del mapa sigue cargando (`L.GridLayer#isLoading`). */
export function mapTilesLoading(map: TileAwareMap): boolean {
  let loading = false;
  map.eachLayer((layer) => {
    const grid = layer as { isLoading?: () => boolean };
    if (typeof grid.isLoading === 'function' && grid.isLoading()) loading = true;
  });
  return loading;
}

/**
 * Funde, salta, espera tiles y vuelve. Cancelable: un vuelo nuevo aborta el anterior
 * y toma el control de la fase. Con movimiento reducido, sólo salta.
 */
export async function fadeFlight(environment: FadeFlightEnvironment, signal: AbortSignal): Promise<void> {
  const { setPhase, jump, tilesLoading, sleep, nextFrame, now, reducedMotion } = environment;
  if (reducedMotion) {
    jump();
    return;
  }

  setPhase('out');
  if (!(await sleep(CAMERA_FADE.outMs, signal))) return;

  jump();
  const started = now();
  // Dos fotogramas seguidos sin carga, pasado el mínimo: las capas que se montan un
  // render después ya tuvieron ocasión de empezar a pedir sus tiles.
  let quietFrames = 0;
  while (now() - started < CAMERA_FADE.maxSettleMs) {
    if (!(await nextFrame(signal))) return;
    quietFrames = tilesLoading() ? 0 : quietFrames + 1;
    if (quietFrames >= 2 && now() - started >= CAMERA_FADE.minSettleMs) break;
  }

  setPhase('in');
  if (!(await sleep(CAMERA_FADE.inMs, signal))) return;
  setPhase('idle');
}
