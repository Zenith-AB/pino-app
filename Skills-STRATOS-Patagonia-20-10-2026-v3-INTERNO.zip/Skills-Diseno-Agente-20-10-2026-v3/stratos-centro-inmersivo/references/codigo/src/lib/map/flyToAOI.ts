import type { StratosAOI } from '../../config/map/types.ts';

type PointLike = { x: number; y: number };

/** Subconjunto de la API de mapa que necesita el encuadre (Leaflet lo cumple). */
export interface CameraMap {
  project(latlng: [number, number], zoom: number): PointLike;
  unproject(point: [number, number], zoom: number): unknown;
  flyTo(target: unknown, zoom: number, options?: { duration?: number }): unknown;
  setView(target: unknown, zoom: number, options?: { animate?: boolean }): unknown;
}

export interface FlyToAoiOptions {
  animate?: boolean;
  /** Desplazamiento (px) del centro visible respecto del centro del contenedor. */
  offset?: PointLike;
  duration?: number;
}

/**
 * Encuadra un AOI dejándolo en el centro del área de mapa visible entre paneles.
 * pitch/bearing se conservan en la configuración para motores 3D; Leaflet no los usa.
 */
export function flyToAOI(map: CameraMap, aoi: StratosAOI, options: FlyToAoiOptions = {}) {
  return flyToLocation(map, aoi.camera, options);
}

/** Zoom de inspección de un centro de cultivo: último nivel nativo de la imagen submétrica. */
export const CULTIVATION_CENTER_ZOOM = 18;

export function flyToLocation(
  map: CameraMap,
  camera: { longitude: number; latitude: number; zoom: number },
  options: FlyToAoiOptions = {},
) {
  const offset = options.offset ?? { x: 0, y: 0 };
  const projected = map.project([camera.latitude, camera.longitude], camera.zoom);
  const target = map.unproject([projected.x - offset.x, projected.y - offset.y], camera.zoom);
  if (options.animate === false) {
    map.setView(target, camera.zoom, { animate: false });
  } else {
    map.flyTo(target, camera.zoom, { duration: options.duration ?? 1.2 });
  }
  return target;
}
