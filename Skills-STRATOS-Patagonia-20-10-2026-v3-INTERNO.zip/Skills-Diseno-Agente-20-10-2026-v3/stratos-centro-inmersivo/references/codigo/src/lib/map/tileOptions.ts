import type { HighResolutionImageryScene } from '../../config/map/types.ts';

/**
 * Retina manual. `detectRetina` de Leaflet suma +1 al nivel pedido sin descontar `maxNativeZoom`
 * (a zoom máximo pide niveles inexistentes) y trata DPR 1.0000000149 como retina.
 */
export function retinaTileOptions(scene: Pick<HighResolutionImageryScene, 'tileSize' | 'maxNativeZoom'>, devicePixelRatio: number) {
  const retina = devicePixelRatio >= 1.5;
  return retina
    ? { tileSize: scene.tileSize / 2, zoomOffset: 1, maxNativeZoom: scene.maxNativeZoom - 1 }
    : { tileSize: scene.tileSize, zoomOffset: 0, maxNativeZoom: scene.maxNativeZoom };
}
