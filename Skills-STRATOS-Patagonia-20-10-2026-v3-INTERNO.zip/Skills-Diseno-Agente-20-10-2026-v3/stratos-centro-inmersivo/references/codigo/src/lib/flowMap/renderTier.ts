/**
 * Nivel de render del Mapa Vivo según lo que tarda de verdad cada fotograma.
 *
 * Complementa a `frameBudget.ts`, que sólo ve el trabajo en JavaScript y por eso
 * no reacciona cuando el cuello de botella es la composición. Medido con GPU real
 * en 4K: 42 fps con el trabajo propio dentro de presupuesto, y 53–58 fps al
 * retirar los `backdrop-filter` que quedan sobre el mapa animado (panel de
 * alertas y marcadores). Ese coste es exactamente el que este nivel controla.
 *
 * Sólo se degrada si el intervalo entre fotogramas es lento **y** el presupuesto
 * de densidad ya no puede remediarlo. En 4K los rellenos a pantalla completa del
 * lienzo esperan a la GPU y se miden como trabajo de JS, así que «el JS excede su
 * presupuesto» no basta para descartar la composición: hay que agotar antes la densidad.
 */

export type RenderTier = 'full' | 'reduced';

const WINDOW_MS = 1000;
const MIN_FRAMES = 20;
const PERCENTILE = 0.9;
/** Percentil 90 por encima del cual la ventana cuenta como lenta (≈ 42 fps). */
const SLOW_FRAME_MS = 24;
/** Percentil 90 por debajo del cual la ventana cuenta como holgada (≈ 53 fps). */
const RECOVERED_FRAME_MS = 19;
/** Intervalos mayores no describen el render: pestaña oculta, pausa del sistema. */
const IGNORE_INTERVAL_MS = 250;
const SLOW_WINDOWS_TO_REDUCE = 2;
/** Holgura sostenida antes de volver a intentar el material completo. */
const CALM_WINDOWS_TO_RETRY = 10;
/**
 * Tras esta cantidad de degradaciones se queda en reducido: si el material
 * completo vuelve a no caber, reintentarlo sólo produce un parpadeo periódico.
 */
const MAX_REDUCTIONS = 2;

export interface RenderTierMonitor {
  /**
   * Declara el intervalo desde el fotograma anterior.
   * @param scriptOverBudget el JS excede su presupuesto y recortar densidad aún
   *   puede remediarlo (`FrameBudget.canStillShrink`): mientras sea así, se espera.
   */
  sample: (intervalMs: number, scriptOverBudget: boolean, now: number) => void;
  /** Olvida la ventana y las rachas en curso; el nivel vigente se conserva. */
  reset: () => void;
  readonly tier: RenderTier;
}

export function createRenderTierMonitor(onChange: (tier: RenderTier) => void): RenderTierMonitor {
  let tier: RenderTier = 'full';
  let reductions = 0;
  let slowStreak = 0;
  let calmStreak = 0;
  let windowStart = 0;
  let scriptExplains = false;
  const intervals: number[] = [];

  const setTier = (next: RenderTier) => {
    tier = next;
    slowStreak = 0;
    calmStreak = 0;
    onChange(next);
  };

  const evaluate = () => {
    intervals.sort((a, b) => a - b);
    const p90 = intervals[Math.min(intervals.length - 1, Math.floor(intervals.length * PERCENTILE))];
    const explained = scriptExplains;
    intervals.length = 0;
    scriptExplains = false;

    if (tier === 'full') {
      slowStreak = p90 > SLOW_FRAME_MS && !explained ? slowStreak + 1 : 0;
      if (slowStreak >= SLOW_WINDOWS_TO_REDUCE) {
        reductions += 1;
        setTier('reduced');
      }
      return;
    }

    if (reductions >= MAX_REDUCTIONS) return;
    calmStreak = p90 < RECOVERED_FRAME_MS ? calmStreak + 1 : 0;
    if (calmStreak >= CALM_WINDOWS_TO_RETRY) setTier('full');
  };

  return {
    sample(intervalMs, scriptOverBudget, now) {
      if (!(intervalMs > 0) || intervalMs > IGNORE_INTERVAL_MS) return;
      if (!windowStart) windowStart = now;
      intervals.push(intervalMs);
      if (scriptOverBudget) scriptExplains = true;
      if (intervals.length >= MIN_FRAMES && now - windowStart >= WINDOW_MS) {
        evaluate();
        windowStart = now;
      }
    },
    reset() {
      intervals.length = 0;
      windowStart = 0;
      scriptExplains = false;
      slowStreak = 0;
      calmStreak = 0;
    },
    get tier() {
      return tier;
    },
  };
}
