/**
 * Presupuesto de fotograma para las capas animadas del Mapa Vivo.
 *
 * Existe por una medición: con 4 000 partículas el hilo principal quedaba
 * bloqueado 315 ms por segundo, y con 3 500 bajaba a cero. Un 12 % de diferencia
 * separaba lo fluido de lo inservible, así que el número correcto no es una
 * constante —depende de la máquina, del zoom y de cuántas capas haya encendidas—
 * sino el que quepa en el fotograma de cada equipo.
 *
 * Lo que se mide es **el trabajo propio**, no la duración del fotograma. La
 * distinción importa: un fotograma puede ir lento por composición o rasterizado,
 * y recortar partículas no arreglaría nada, sólo empobrecería el dibujo. El
 * trabajo propio, en cambio, es exactamente lo que la densidad controla.
 *
 * El objetivo viene del modelo RAIL: 16 ms por fotograma para sostener 60 fps,
 * de los que el navegador necesita unos 6 ms para su propio render, dejando unos
 * 10 ms para el trabajo de la aplicación. https://web.dev/articles/rail
 */

/** Techo del trabajo propio por fotograma. */
const BUDGET_MS = 10;
/** Holgura por debajo de la cual se puede volver a subir la densidad. */
const COMFORTABLE_MS = 6;
/**
 * La ventana se mide en tiempo y no en fotogramas: contarla en fotogramas falla
 * justo cuando importa, porque si el sistema va lento la ventana se alarga y el
 * ajuste llega tarde. Medido a 6 fps, 45 fotogramas eran 7,5 s de atasco.
 */
const WINDOW_MS = 600;
const MIN_SAMPLES = 4;
/**
 * Se vigila el percentil 90 y no la mediana: el render de las plumas va a 12 Hz,
 * así que la mayoría de los fotogramas son baratos y la mediana no vería nunca
 * los caros, que son precisamente los que producen el tirón.
 */
const PERCENTILE = 0.9;
/** Bajar deprisa y subir despacio: es peor quedarse corto de fluidez que de densidad. */
const SHRINK = 0.72;
const GROW = 1.12;
const MIN_SCALE = 0.25;
/** Por debajo de esta diferencia no se avisa: reajustar cuesta más que el ajuste. */
const REPORT_EPSILON = 0.04;

export interface FrameBudget {
  /** Declara el trabajo propio de un fotograma, en milisegundos. */
  sample: (workMs: number, now?: number) => void;
  /** Olvida la ventana en curso (cambio de vista, capa apagada). */
  reset: () => void;
  /** Escala de densidad vigente, en (0, 1]. */
  readonly scale: number;
  /** Percentil 90 del trabajo propio en la última ventana evaluada (ms). */
  readonly work: number;
  /**
   * Excede el presupuesto y recortar densidad aún puede remediarlo. Falso en el
   * suelo de escala: lo que queda (rellenos a pantalla completa que esperan a la
   * GPU) no depende del número de partículas.
   */
  readonly canStillShrink: boolean;
}

/**
 * @param onChange recibe la nueva escala cuando cambia de forma apreciable.
 */
export function createFrameBudget(onChange: (scale: number) => void): FrameBudget {
  let scale = 1;
  let reported = 1;
  let windowStart = 0;
  let lastWork = 0;
  const samples: number[] = [];

  const evaluate = () => {
    const sorted = [...samples].sort((a, b) => a - b);
    const work = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * PERCENTILE))];
    lastWork = work;
    samples.length = 0;

    if (work > BUDGET_MS) scale = Math.max(MIN_SCALE, scale * SHRINK);
    else if (work < COMFORTABLE_MS && scale < 1) scale = Math.min(1, scale * GROW);

    if (Math.abs(scale - reported) >= REPORT_EPSILON || (scale === 1 && reported !== 1)) {
      reported = scale;
      onChange(scale);
    }
  };

  return {
    sample(workMs, now = performance.now()) {
      if (!windowStart) windowStart = now;
      samples.push(workMs);
      if (samples.length >= MIN_SAMPLES && now - windowStart >= WINDOW_MS) {
        evaluate();
        windowStart = now;
      }
    },
    reset() {
      samples.length = 0;
      windowStart = 0;
      lastWork = 0;
    },
    get scale() {
      return scale;
    },
    get work() {
      return lastWork;
    },
    get canStillShrink() {
      return lastWork > BUDGET_MS && scale > MIN_SCALE;
    },
  };
}
