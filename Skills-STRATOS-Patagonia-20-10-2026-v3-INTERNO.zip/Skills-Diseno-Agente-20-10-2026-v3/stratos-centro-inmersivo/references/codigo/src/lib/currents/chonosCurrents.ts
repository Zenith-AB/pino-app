// Corrientes superficiales reales de CHONOS/MOSA (IFOP): CROCO a ~1 km en Chiloé
// y ~3 km en Magallanes, pronóstico horario de 72 h. Pasa por el proxy `/ds/chonos`
// porque el servidor falla el handshake TLS contra el almacén de certificados local.
//
// Recorrido (API pública sin documentar, verificado el 2026-09-16):
//   1. mosa_domains_geojson → dominios con su corrida (`mosa_chiloe_1km_20260915`)
//   2. variables            → malla (lon/lat) y pasos de tiempo del dataset CROCO
//   3. raster (uvel+vvel)   → binario Float32 con el campo completo de un instante
//
// Una sola descarga (~2,4 MB) cubre toda la región: mover el mapa no vuelve a pedir
// nada, a diferencia de un servicio por puntos con cuota diaria.
//
// Límite conocido de la malla: a ~1 km los pasos angostos no se resuelven. Medido
// sobre `croco_chiloe_1km` en seis pasos de un ciclo de marea (17-09-2026), el
// Canal de Chacao marca ~0,5 m/s y el máximo de todo el dominio es 2,05 m/s, cuando
// la corriente real de Chacao supera los 4 m/s. La dirección y el contraste entre
// zonas son fieles; la rapidez de los canales más angostos queda sub-representada.

import { proxyUrl } from '@datasource/core/env';
import { gridContains, gridFromChonosRaster, type CurrentGrid } from './currentGrid';

const TIMEOUT_MS = 60_000;
const DOMAIN_TTL_MS = 60 * 60 * 1000;
/** Un instante válido a más de esto de "ahora" se declara desfasado. */
const STALE_AFTER_MS = 90 * 60 * 1000;

export interface ChonosDomain {
  id: string;
  dataset: string;
  bbox: { west: number; south: number; east: number; north: number };
  resolutionKm: number;
}

interface DatasetAxes {
  lon: number[];
  lat: number[];
  /** Segundos epoch UTC de cada paso. */
  times: number[];
}

export interface ChonosCurrents {
  grid: CurrentGrid;
  /** El instante válido dista más de 90 min de ahora (corrida vieja o sin pasos futuros). */
  stale: boolean;
}

async function getJson<T>(path: string): Promise<T> {
  const response = await fetch(proxyUrl('chonos', path), { signal: AbortSignal.timeout(TIMEOUT_MS) });
  if (!response.ok) throw new Error(`CHONOS ${path.split('?')[0]}: HTTP ${response.status}`);
  return (await response.json()) as T;
}

const options = (value: unknown) => `?options=${encodeURIComponent(JSON.stringify(value))}`;

let domainsCache: { at: number; promise: Promise<ChonosDomain[]> } | null = null;
const axesCache = new Map<string, Promise<DatasetAxes>>();
const rasterCache = new Map<string, Promise<CurrentGrid>>();

/** Dominios MOSA publicados, con su dataset CROCO y su caja. */
export function chonosDomains(): Promise<ChonosDomain[]> {
  if (domainsCache && Date.now() - domainsCache.at < DOMAIN_TTL_MS) return domainsCache.promise;
  const promise = getJson<{ features?: { geometry?: { coordinates?: number[][][] }; properties?: { id?: string } }[] }>(
    'mosa_domains_geojson',
  ).then((geo) =>
    (geo.features ?? []).flatMap((feature) => {
      const id = feature.properties?.id;
      const ring = feature.geometry?.coordinates?.[0];
      if (!id || !ring?.length) return [];
      const lons = ring.map((point) => point[0]);
      const lats = ring.map((point) => point[1]);
      const resolution = /_(\d+(?:\.\d+)?)km_/.exec(id);
      return [
        {
          id,
          // La corrida oceánica del dominio `mosa_<zona>_<res>_<fecha>` es `croco_<zona>_<res>_<fecha>`.
          dataset: id.replace(/^mosa_/, 'croco_'),
          bbox: { west: Math.min(...lons), east: Math.max(...lons), south: Math.min(...lats), north: Math.max(...lats) },
          resolutionKm: resolution ? Number(resolution[1]) : Number.NaN,
        },
      ];
    }),
  );
  domainsCache = { at: Date.now(), promise };
  // Un fallo no debe quedar en caché una hora.
  promise.catch(() => {
    if (domainsCache?.promise === promise) domainsCache = null;
  });
  return promise;
}

function datasetAxes(dataset: string): Promise<DatasetAxes> {
  const cached = axesCache.get(dataset);
  if (cached) return cached;
  const promise = getJson<{
    datasets?: Record<string, { time?: number[] }>;
    variables?: Record<string, { code: string; lon?: number[]; lat?: number[] }[]>;
  }>(`variables${options({ datasets: [{ code: dataset, t0: '_latest' }] })}`).then((payload) => {
    const uvel = payload.variables?.[dataset]?.find((variable) => variable.code === 'uvel');
    const times = payload.datasets?.[dataset]?.time ?? [];
    if (!uvel?.lon?.length || !uvel.lat?.length || times.length === 0) {
      throw new Error(`CHONOS ${dataset}: sin malla o pasos de tiempo para uvel`);
    }
    const lat = uvel.lat[0] < uvel.lat[uvel.lat.length - 1] ? uvel.lat : [...uvel.lat].reverse();
    return { lon: uvel.lon, lat, times };
  });
  axesCache.set(dataset, promise);
  promise.catch(() => axesCache.delete(dataset));
  return promise;
}

/**
 * Fecha de la corrida, leída del nombre del dataset (`croco_chiloe_1km_20260916`).
 * Es la etiqueta del día, no el instante real de emisión: la API no lo publica y
 * la corrida del 16 arranca su primer paso el 17 a las 00:00Z. Sirve para saber de
 * qué corrida viene el campo, no para medir su antigüedad —para eso está
 * `validTime`, que sí es el instante pronosticado.
 */
function issuedAtOf(dataset: string) {
  const stamp = /(20\d{6})$/.exec(dataset)?.[1];
  return stamp ? `${stamp.slice(0, 4)}-${stamp.slice(4, 6)}-${stamp.slice(6, 8)}T00:00:00.000Z` : '';
}

/** Extensión real de la malla del dataset, que es la que manda sobre la caja del dominio. */
function axesContain(axes: DatasetAxes, longitude: number, latitude: number) {
  const { lon, lat } = axes;
  return (
    longitude >= lon[0] &&
    longitude <= lon[lon.length - 1] &&
    latitude >= lat[0] &&
    latitude <= lat[lat.length - 1]
  );
}

function loadRaster(domain: ChonosDomain, axes: DatasetAxes, time: number, depthM: number): Promise<CurrentGrid> {
  const key = `${domain.dataset}:${time}:${depthM}`;
  const cached = rasterCache.get(key);
  if (cached) return cached;
  const promise = (async () => {
    const response = await fetch(
      proxyUrl('chonos', `raster${options({ dataset: domain.dataset, variable: 'uvel+vvel', time, z: depthM > 0 ? -depthM : 0, t0: '_latest' })}`),
      { signal: AbortSignal.timeout(TIMEOUT_MS) },
    );
    if (!response.ok) throw new Error(`CHONOS raster ${domain.dataset}: HTTP ${response.status}`);
    const buffer = await response.arrayBuffer();
    return gridFromChonosRaster(buffer, axes.lon, axes.lat, {
      id: key,
      source: `CHONOS/MOSA (IFOP) · CROCO ${domain.resolutionKm} km`,
      domain: domain.id,
      dataset: domain.dataset,
      issuedAt: issuedAtOf(domain.dataset),
      validTime: new Date(time * 1000).toISOString(),
      depthM,
      resolutionKm: domain.resolutionKm,
    });
  })();
  // Sólo se guarda el paso vigente por dataset y profundidad: 2,4 MB cada uno.
  for (const other of rasterCache.keys()) {
    if (other.startsWith(`${domain.dataset}:`) && other.endsWith(`:${depthM}`)) rasterCache.delete(other);
  }
  rasterCache.set(key, promise);
  promise.catch(() => rasterCache.delete(key));
  return promise;
}

/**
 * Campo de corrientes superficiales vigente para el dominio que contiene el
 * punto. `null` si ningún dominio CHONOS lo cubre: fuera de ellos no hay dato
 * de esta fuente y el llamador decide qué declarar.
 */
/**
 * Campo materializado por el servidor (`snapshot.mjs currents`), servido como
 * archivo local. Es la vía normal: el navegador no habla con CHONOS.
 *
 * Antes cada sesión encadenaba tres peticiones y bajaba 2,4 MB del proveedor, y
 * si fallaba caía a Open-Meteo Marine —cuota diaria, consultada desde el
 * cliente—. El binario es el mismo que publica CHONOS, así que lo interpreta el
 * parser de siempre.
 */
let snapshotPromise: Promise<CurrentGrid | null> | null = null;
let snapshotLoadedAt = 0;
const SNAPSHOT_TTL_MS = 5 * 60 * 1000;
interface SnapshotEntry {
  bbox: { west: number; south: number; east: number; north: number };
  jsonUrl: string; binUrl: string;
}
let indexPromise: Promise<SnapshotEntry[] | null> | null = null;
let indexLoadedAt = 0;
const regionGrids = new Map<string, Promise<CurrentGrid | null>>();

function loadSnapshotIndex(): Promise<SnapshotEntry[] | null> {
  if (!indexPromise || Date.now() - indexLoadedAt >= SNAPSHOT_TTL_MS) {
    indexLoadedAt = Date.now();
    indexPromise = (async () => {
      const response = await fetch('/datasource/chonos-currents-index.json', { cache: 'no-cache', signal: AbortSignal.timeout(15000) });
      if (!response.ok) return null;
      const envelope = await response.json() as { data?: { version?: number; domains?: SnapshotEntry[] } };
      if (envelope.data?.version !== 1 || !Array.isArray(envelope.data.domains)) return null;
      const entries = envelope.data.domains.filter(entry => Object.values(entry.bbox ?? {}).length === 4
        && Object.values(entry.bbox).every(Number.isFinite)
        && /^\/datasource\/currents\/[a-f0-9-]+\.json$/.test(entry.jsonUrl)
        && /^\/datasource\/currents\/[a-f0-9-]+\.bin$/.test(entry.binUrl));
      const active = new Set(entries.map(entry => entry.jsonUrl));
      for (const key of regionGrids.keys()) if (!active.has(key)) regionGrids.delete(key);
      return entries;
    })().catch(() => null);
  }
  return indexPromise;
}

async function loadRegionalSnapshot(longitude: number, latitude: number): Promise<CurrentGrid | null> {
  const entries = await loadSnapshotIndex();
  if (entries === null) return loadSnapshotGrid(); // Compatibility with deployments before the regional index.
  const entry = entries.find(({ bbox }) => longitude >= bbox.west && longitude <= bbox.east && latitude >= bbox.south && latitude <= bbox.north);
  if (!entry) return null;
  let promise = regionGrids.get(entry.jsonUrl);
  if (!promise) {
    promise = loadEnvelopeGrid(entry.jsonUrl, entry.binUrl).catch(() => null);
    regionGrids.set(entry.jsonUrl, promise);
    promise.then(grid => { if (!grid && regionGrids.get(entry.jsonUrl) === promise) regionGrids.delete(entry.jsonUrl); });
  }
  return promise;
}

/** Lee un par `.json` + `.bin` con el sobre del snapshot y el binario tal cual lo publica CHONOS. */
async function loadEnvelopeGrid(jsonUrl: string, binUrl: string, sourceSuffix = ''): Promise<CurrentGrid | null> {
  const [meta, binary] = await Promise.all([
    fetch(jsonUrl, { cache: 'no-cache', signal: AbortSignal.timeout(15_000) }),
    fetch(binUrl, { cache: 'no-cache', signal: AbortSignal.timeout(30_000) }),
  ]);
  if (!meta.ok || !binary.ok) return null;

  const envelope = (await meta.json()) as {
    data?: { lon?: number[]; lat?: number[]; meta?: Record<string, unknown> };
  };
  const lon = envelope.data?.lon;
  const rawLat = envelope.data?.lat;
  const info = envelope.data?.meta;
  if (!lon?.length || !rawLat?.length || !info) return null;

  // El parser espera la latitud de sur a norte; CHONOS la publica al revés.
  const lat = rawLat[0] < rawLat[rawLat.length - 1] ? rawLat : [...rawLat].reverse();
  const validTime = String(info.validTime ?? '');
  return gridFromChonosRaster(await binary.arrayBuffer(), lon, lat, {
    id: `${String(info.dataset ?? 'croco')}:${validTime}:0`,
    source: `CHONOS/MOSA (IFOP) · CROCO ${String(info.resolutionKm ?? '?')} km${sourceSuffix}`,
    domain: String(info.domain ?? ''),
    dataset: String(info.dataset ?? ''),
    issuedAt: String(info.issuedAt ?? ''),
    validTime,
    depthM: 0,
    resolutionKm: Number(info.resolutionKm ?? Number.NaN),
  });
}

/*
 * Campo archivado que fija un replay (caso Taraba 2026). CHONOS retira sus corridas
 * a los pocos días, así que el caso guarda las suyas y las sirve como archivo local.
 * Mientras está fijado manda sobre el snapshot y el camino en vivo donde cubre: las
 * partículas regionales y las locales leen el mismo campo, igual que en operación.
 */
let pinnedGrid: CurrentGrid | null = null;

export function pinChonosField(grid: CurrentGrid | null) {
  pinnedGrid = grid;
}

export function loadArchivedChonosField(baseUrl: string): Promise<CurrentGrid | null> {
  return loadEnvelopeGrid(`${baseUrl}.json`, `${baseUrl}.bin`, ' · corrida archivada');
}

function loadSnapshotGrid(): Promise<CurrentGrid | null> {
  if (!snapshotPromise || Date.now() - snapshotLoadedAt >= SNAPSHOT_TTL_MS) {
    snapshotLoadedAt = Date.now();
    const pending = loadEnvelopeGrid('/datasource/chonos-currents.json', '/datasource/chonos-currents.bin');
    snapshotPromise = pending;
    pending.then((grid) => { if (!grid && snapshotPromise === pending) snapshotPromise = null; }, () => {
      if (snapshotPromise === pending) snapshotPromise = null;
    });
  }
  // Un fallo no se queda pegado: la siguiente llamada reintenta y, si tampoco,
  // el camino en vivo sigue disponible.
  return snapshotPromise;
}

export async function loadChonosCurrents(
  longitude: number,
  latitude: number,
  { at = Date.now(), depthM = 0, preferSnapshot = true }: { at?: number; depthM?: number; preferSnapshot?: boolean } = {},
): Promise<ChonosCurrents | null> {
  // Un replay fija su campo: es el instante que se está mirando, no uno desfasado.
  const pinned = pinnedHere(longitude, latitude, depthM);
  if (pinned) return pinned;
  // Superficie: primero lo que ya tiene el servidor. Para otras profundidades no
  // hay snapshot y se sigue por el camino en vivo.
  if (depthM === 0 && preferSnapshot) {
    const grid = await loadRegionalSnapshot(longitude, latitude).catch(() => null);
    if (grid && gridContains(grid, longitude, latitude)) {
      const valid = Date.parse(grid.validTime);
      return { grid, stale: !Number.isFinite(valid) || Math.abs(valid - at) > STALE_AFTER_MS };
    }
    // Navigation reads the server archive only; it never starts an upstream download.
    return null;
  }

  const domains = await chonosDomains();
  const domain = domains.find(
    ({ bbox }) => longitude >= bbox.west && longitude <= bbox.east && latitude >= bbox.south && latitude <= bbox.north,
  );
  if (!domain) return null;
  const axes = await datasetAxes(domain.dataset);
  // La caja del dominio MOSA es mucho mayor que la malla CROCO que lo sirve (para
  // Chiloé, -79,7…-70,0 frente a -79,0…-72,0): sin esta comprobación un punto entre
  // ambas descarga 2,4 MB para descartarlos después contra la malla real.
  if (!axesContain(axes, longitude, latitude)) return null;
  // Los ejes tardan: si mientras tanto un replay fijó su campo, no se baja el ráster en vivo.
  const pinnedEarly = pinnedHere(longitude, latitude, depthM);
  if (pinnedEarly) return pinnedEarly;
  const target = at / 1000;
  const time = axes.times.reduce((best, step) => (Math.abs(step - target) < Math.abs(best - target) ? step : best));
  const grid = await loadRaster(domain, axes, time, depthM);
  // Una descarga en vivo que empezó antes de fijar un replay no puede pisarlo al llegar.
  const pinnedLate = pinnedHere(longitude, latitude, depthM);
  if (pinnedLate) return pinnedLate;
  if (!gridContains(grid, longitude, latitude)) return null;
  return { grid, stale: Math.abs(time * 1000 - at) > STALE_AFTER_MS };
}

function pinnedHere(longitude: number, latitude: number, depthM: number): ChonosCurrents | null {
  return depthM === 0 && pinnedGrid && gridContains(pinnedGrid, longitude, latitude) ? { grid: pinnedGrid, stale: false } : null;
}
