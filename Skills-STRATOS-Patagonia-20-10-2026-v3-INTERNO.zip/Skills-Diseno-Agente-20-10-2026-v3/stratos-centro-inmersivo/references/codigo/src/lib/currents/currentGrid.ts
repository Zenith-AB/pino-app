// Campo de corrientes superficiales en grilla, sin red ni DOM.
//
// Hoy lo alimenta CHONOS/MOSA (IFOP): salida CROCO a ~1 km para Chiloé y ~3 km
// para Magallanes, en proyección Mercator (longitud uniforme, latitud no). Las
// celdas de tierra llegan como NaN y se respetan: un campo que interpola sobre
// tierra dibuja corrientes que no existen.

export interface CurrentGridMeta {
  /** Identificador estable: dataset + instante válido. */
  id: string;
  /** Texto de procedencia para la interfaz. */
  source: string;
  domain: string;
  dataset: string;
  /** ISO-8601 UTC de emisión de la corrida. */
  issuedAt: string;
  /** ISO-8601 UTC del instante pronosticado que representa el campo. */
  validTime: string;
  resolutionKm: number;
  /** Profundidad en metros (0 = superficie). */
  depthM: number;
}

export interface CurrentGrid extends CurrentGridMeta {
  west: number;
  east: number;
  south: number;
  north: number;
  nx: number;
  ny: number;
  dx: number;
  /** Latitud de cada fila, ascendente (sur → norte). */
  lat: Float64Array;
  /** Componente Este (m/s); índice `iy * nx + ix`, con `iy` desde el sur. */
  u: Float32Array;
  /** Componente Norte (m/s); mismo índice que `u`. */
  v: Float32Array;
}

export interface CurrentVector {
  u: number;
  v: number;
}

/**
 * Construye la grilla a partir del binario de `/raster` de CHONOS.
 *
 * El binario trae primero todas las `u` y luego todas las `v`, en orden columna
 * por columna (`índice = iyNorte + ny · ix`) y con las filas contadas desde el
 * norte. Así lo lee el propio visor de CHONOS (`VectorGridLayer.js`) y así casa
 * con la geografía: verificado con tierra en Chiloé y agua en Chacao y el Golfo
 * de Ancud.
 */
export function gridFromChonosRaster(
  buffer: ArrayBuffer,
  lon: ArrayLike<number>,
  latAscending: ArrayLike<number>,
  meta: CurrentGridMeta,
): CurrentGrid {
  const nx = lon.length;
  const ny = latAscending.length;
  const raw = new Float32Array(buffer);
  if (raw.length !== 2 * nx * ny) {
    throw new Error(`grilla CHONOS inconsistente: ${raw.length} valores para ${nx}×${ny}`);
  }
  const u = new Float32Array(nx * ny);
  const v = new Float32Array(nx * ny);
  const half = nx * ny;
  for (let ix = 0; ix < nx; ix++) {
    for (let iyNorth = 0; iyNorth < ny; iyNorth++) {
      const source = iyNorth + ny * ix;
      const target = (ny - 1 - iyNorth) * nx + ix;
      u[target] = raw[source];
      v[target] = raw[half + source];
    }
  }
  const lat = Float64Array.from(latAscending);
  return {
    ...meta,
    west: lon[0],
    east: lon[nx - 1],
    south: lat[0],
    north: lat[ny - 1],
    nx,
    ny,
    dx: (lon[nx - 1] - lon[0]) / (nx - 1),
    lat,
    u,
    v,
  };
}

export function gridContains(grid: CurrentGrid, longitude: number, latitude: number) {
  return longitude >= grid.west && longitude <= grid.east && latitude >= grid.south && latitude <= grid.north;
}

/** Índice fraccional de fila para una latitud (filas no uniformes: Mercator). */
function rowIndex(lat: Float64Array, latitude: number) {
  let lo = 0;
  let hi = lat.length - 1;
  if (latitude < lat[lo] || latitude > lat[hi]) return -1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (lat[mid] <= latitude) lo = mid;
    else hi = mid;
  }
  return lo + (latitude - lat[lo]) / (lat[hi] - lat[lo]);
}

/**
 * Corriente en un punto, interpolada entre las cuatro celdas vecinas. `null`
 * fuera del dominio o si alguna vecina es tierra: junto a la costa se prefiere
 * no dibujar a inventar.
 */
export function sampleGrid(grid: CurrentGrid, longitude: number, latitude: number): CurrentVector | null {
  const fy = rowIndex(grid.lat, latitude);
  if (fy < 0) return null;
  const fx = (longitude - grid.west) / grid.dx;
  if (!(fx >= 0 && fx <= grid.nx - 1)) return null;
  const x0 = Math.floor(fx);
  const y0 = Math.floor(fy);
  const x1 = Math.min(x0 + 1, grid.nx - 1);
  const y1 = Math.min(y0 + 1, grid.ny - 1);
  const tx = fx - x0;
  const ty = fy - y0;
  const { u, v, nx } = grid;
  const i00 = y0 * nx + x0;
  const i10 = y0 * nx + x1;
  const i01 = y1 * nx + x0;
  const i11 = y1 * nx + x1;
  const u00 = u[i00], u10 = u[i10], u01 = u[i01], u11 = u[i11];
  if (!(Number.isFinite(u00) && Number.isFinite(u10) && Number.isFinite(u01) && Number.isFinite(u11))) return null;
  const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
  return {
    u: lerp(lerp(u00, u10, tx), lerp(u01, u11, tx), ty),
    v: lerp(lerp(v[i00], v[i10], tx), lerp(v[i01], v[i11], tx), ty),
  };
}

/**
 * Corriente de la celda de agua más cercana, para puntos junto a la costa (un
 * centro de cultivo suele estar a menos de una celda de tierra). Devuelve la
 * distancia para poder declararla; nunca busca más allá de `maxKm`.
 */
export function sampleNearestWater(
  grid: CurrentGrid,
  longitude: number,
  latitude: number,
  maxKm = 3,
): (CurrentVector & { distanceKm: number }) | null {
  const direct = sampleGrid(grid, longitude, latitude);
  if (direct) return { ...direct, distanceKm: 0 };
  const fy = rowIndex(grid.lat, latitude);
  const fx = (longitude - grid.west) / grid.dx;
  if (fy < 0 || fx < 0 || fx > grid.nx - 1) return null;
  const cx = Math.round(fx);
  const cy = Math.round(fy);
  const kmPerDegLon = 111.32 * Math.cos((latitude * Math.PI) / 180);
  const reach = Math.ceil(maxKm / Math.max(0.1, grid.dx * kmPerDegLon)) + 1;
  let best: (CurrentVector & { distanceKm: number }) | null = null;
  for (let dy = -reach; dy <= reach; dy++) {
    const iy = cy + dy;
    if (iy < 0 || iy >= grid.ny) continue;
    for (let dxCell = -reach; dxCell <= reach; dxCell++) {
      const ix = cx + dxCell;
      if (ix < 0 || ix >= grid.nx) continue;
      const index = iy * grid.nx + ix;
      if (!Number.isFinite(grid.u[index])) continue;
      const cellLon = grid.west + ix * grid.dx;
      const distanceKm = Math.hypot((cellLon - longitude) * kmPerDegLon, (grid.lat[iy] - latitude) * 111.32);
      if (distanceKm > maxKm || (best && distanceKm >= best.distanceKm)) continue;
      best = { u: grid.u[index], v: grid.v[index], distanceKm };
    }
  }
  return best;
}

export interface RegularCrop {
  bounds: { west: number; south: number; east: number; north: number };
  width: number;
  height: number;
  /** Filas desde el norte, como espera leaflet-velocity; `null` = tierra. */
  u: Array<number | null>;
  v: Array<number | null>;
  valid: number;
  total: number;
}

/**
 * Recorte a una grilla regular en grados, que es lo que admite leaflet-velocity.
 * Las columnas coinciden con las del modelo; las filas se muestrean cada `dx·cos φ`
 * (el paso Mercator local), así que no se pierde resolución.
 */
export function cropToRegularGrid(
  grid: CurrentGrid,
  view: { west: number; south: number; east: number; north: number },
): RegularCrop | null {
  const ix0 = Math.max(0, Math.floor((view.west - grid.west) / grid.dx));
  const ix1 = Math.min(grid.nx - 1, Math.ceil((view.east - grid.west) / grid.dx));
  const south = Math.max(grid.south, view.south);
  const north = Math.min(grid.north, view.north);
  if (ix1 <= ix0 || north <= south) return null;

  const midLat = ((south + north) / 2) * (Math.PI / 180);
  const dy = grid.dx * Math.cos(midLat);
  const height = Math.max(2, Math.round((north - south) / dy) + 1);
  const width = ix1 - ix0 + 1;
  const stepLat = (north - south) / (height - 1);
  const u: Array<number | null> = new Array(width * height);
  const v: Array<number | null> = new Array(width * height);
  let valid = 0;

  for (let row = 0; row < height; row++) {
    const latitude = north - row * stepLat;
    const fy = rowIndex(grid.lat, latitude);
    const y0 = Math.max(0, Math.floor(fy));
    const y1 = Math.min(grid.ny - 1, y0 + 1);
    const ty = fy - y0;
    for (let column = 0; column < width; column++) {
      const ix = ix0 + column;
      const a = y0 * grid.nx + ix;
      const b = y1 * grid.nx + ix;
      const out = row * width + column;
      const ua = grid.u[a], ub = grid.u[b];
      if (Number.isFinite(ua) && Number.isFinite(ub)) {
        u[out] = ua + (ub - ua) * ty;
        v[out] = grid.v[a] + (grid.v[b] - grid.v[a]) * ty;
        valid++;
      } else {
        u[out] = null;
        v[out] = null;
      }
    }
  }

  return {
    bounds: { west: grid.west + ix0 * grid.dx, east: grid.west + ix1 * grid.dx, south, north },
    width,
    height,
    u,
    v,
    valid,
    total: width * height,
  };
}

/** Rumbo HACIA donde fluye (grados desde el norte, horario) y rapidez. */
export function vectorToCourse({ u, v }: CurrentVector) {
  return { speedMs: Math.hypot(u, v), towardBearingDeg: ((Math.atan2(u, v) * 180) / Math.PI + 360) % 360 };
}
