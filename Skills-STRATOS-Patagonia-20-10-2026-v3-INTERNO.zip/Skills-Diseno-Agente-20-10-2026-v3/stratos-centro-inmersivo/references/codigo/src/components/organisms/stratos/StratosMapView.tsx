import { CrocoSimulationView } from '../../map/CrocoSimulationView';
import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import L from 'leaflet';
import {
  ArrowUpRight,
  CrosshairSimple,
  GlobeHemisphereWest,
  MapPinArea,
  Minus,
  Plus,
  Triangle,
} from '@phosphor-icons/react';
import { GlassSurface } from '../../atoms';
import { MapLayerMenu, PillSelector } from '../../molecules/stratos';
import { StratosMapContext, STRATOS_PANE_Z } from '../../map/StratosMapContext';
import type { StratosMapContextValue } from '../../map/StratosMapContext';
import type { MapHoverTarget } from '../../map/hoverTypes';
import { HighResolutionImageryLayer } from '../../map/layers/HighResolutionImageryLayer';
import { ParticleFieldLayer } from '../../map/layers/ParticleFieldLayer';
import { CurrentVectorLayer } from '../../map/layers/CurrentVectorLayer';
import { SensorLayer } from '../../map/layers/SensorLayer';
import { SotracsBuoyLayer } from '../../map/layers/SotracsBuoyLayer';
import { CenterSensorLinkLayer } from '../../map/layers/CenterSensorLinkLayer';
import { LandSourceLayer } from '../../map/layers/LandSourceLayer';
import { fetchWeatherContexts, type WeatherLocation } from '../../../data/weatherContext';
import { SotracsStationCard } from '../../map/layers/SotracsStationCard';
import { MapLegend } from '../../map/legend/MapLegend';
import { VariableCard } from '../../map/variables/VariableCard';
import { getEnvironmentalVariable } from '../../../data/environmentalVariables';
import { useSensorNetwork } from '../../../hooks/useSensorNetwork';
import { useReloncaviExplanation } from '../../../hooks/useReloncaviExplanation';
import { DEFAULT_SENSOR_WINDOW_HOURS } from '../../../lib/sensors/sensorNetworkStore';
import { IconListDetails } from '@tabler/icons-react';
import type { SotracsStation } from '../../../data/sotracsStations';
import type { MapSourceSelection } from '../../../data/mapSourceSelection';
import { SOTRACS_STATIONS, stationsFromBuoys } from '../../../data/sotracsStations';
import { acs, redmet, rivers } from '@datasource';
import type { RedmetStation } from '../../../../datasource/sources/chonos-redmet/stations';
import { CultivationCenterLayer } from '../../map/layers/CultivationCenterLayer';
import { CenterSiteLayer } from '../../map/centers/CenterSiteLayer';
import type { CenterDetail } from '../../../data/centers/centerDetail.types';
import { RegionalFlowLayer, RiskLayer } from '../../map/layers/flowEngineLayers';
import { ObservedChlorophyllLayer } from '../../map/layers/ObservedChlorophyllLayer';
import { PrecursorConditionLayer } from '../../map/layers/PrecursorConditionLayer';
import type { PrecursorAlertsModel, PrecursorNetworkSite } from '../../../lib/stratos/domain/precursorConditions';
import { conditionBand } from '../../../lib/stratos/domain/precursorConditions';
import { buildPrecursorSiteCard } from '../../../lib/stratos/domain/precursorSiteCard';
import { PrecursorSiteCard } from '../../map/layers/PrecursorSiteCard';
import { createFlowEngine } from '../../../lib/flowMap/engine';
import type { BloomHotspot, FlowEngine, FlowFieldState } from '../../../lib/flowMap/engine';
import { loadArchivedChonosField, pinChonosField } from '../../../lib/currents/chonosCurrents';
import type { SatelliteFrames } from '../../../data/cases/tarabaCase.types';
import { flyToAOI, flyToLocation } from '../../../lib/map/flyToAOI';
import { CAMERA_FADE, fadeFlight, mapTilesLoading, type CameraFadePhase } from '../../../lib/map/fadeFlight';
import { prefersReducedMotion } from '../../../lib/stage/stageTiming';
import { DETAIL_ZOOM, zoomSnapFor } from '../../../lib/map/zoomInterpolate';
import { createInitialMapState, stratosMapReducer } from '../../../lib/map/layerState';
import { MAP_PREFERENCES_KEY, restoreMapPreferences, serializeMapPreferences } from '../../../lib/map/preferences';
import { useReducedMapMotion } from '../../../hooks/useReducedMapMotion';
import type { VelocityField } from '../../../lib/particles/velocityField';
import { usesLocalFlow } from '../../../lib/map/flowVisibility';
import type { ImageryStatus } from '../../../lib/map/layerState';
import { AOI_LIST, DEFAULT_AOI_ID, DEFAULT_MAP_LAYERS, getAOI, STRATOS_AOIS, TARABA_CASE_AOI_ID } from '../../../config/map/areas';
import { BASE_LAYER_OPTIONS, DEFAULT_HIGH_RESOLUTION_SCENE_ID, GLOBAL_DETAIL_IMAGERY, getHighResolutionScene } from '../../../config/map/imagery';
import { fetchImageryMetadata } from '../../../lib/map/esriImageryMetadata';
import type { ImageryCaptureMetadata } from '../../../lib/map/esriImageryMetadata';
import { MAP_IDLE_MS } from '../../../lib/map/interaction';
import { visibleStageArea } from '../../../lib/layout/visibleStageArea';
import type { BaseLayerId, HighResolutionImageryScene, StratosAOI } from '../../../config/map/types';
import { useVelocityField } from '../../../hooks/useVelocityField';
import { MAX_CENTER_SENSOR_DISTANCE_KM } from '../../../../datasource/sources/acs-sotracs/buoyBinding';
import { buildCenterSensorLinks } from '../../../lib/map/centerSensorLinks';
import {
  CULTIVATION_CENTERS,
  MAP_PLACE_LABELS,
} from '../../../data/stratosReference';
import type { CultivationCenter, DataMode, MapPoint, RiskPopupModel, StratosTab, StratosTone } from '../../../data/stratosTypes';
import './StratosMapView.css';

const SATELLITE_URL = GLOBAL_DETAIL_IMAGERY.tilesUrl;
// CARTO dejó de servir basemaps sin API key; Esri Dark Gray no la requiere.
const DARK_URL = 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}';
const MAP_MAX_ZOOM = 19;

/** Los instrumentos operacionales entran por la red SOTRACS vinculada; estos puntos son condiciones del mapa. */
const REGIONAL_CONDITION_KINDS = new Set<MapPoint['kind']>(['vigilancia', 'alerta']);

/** Lo que un replay pone en el mapa para la fecha elegida (caso Taraba 2026). */
export interface MapCaseScene {
  date: string;
  centers: CultivationCenter[];
  /** Focos de pluma: sólo centros con FAN reportada en esa fecha. */
  hotspots: BloomHotspot[];
  /** Base (sin extensión) del campo CHONOS archivado que mueve partículas y plumas. */
  currentsUrl: string | null;
  frames: SatelliteFrames | null;
}

interface StratosMapViewProps {
  points: MapPoint[];
  popup: RiskPopupModel;
  dataMode: DataMode;
  dataLabel: string;
  dataTone: StratosTone;
  onToggleDataMode: () => void;
  onOpenPopup: () => void;
  /** Fuera de "Mapa Vivo" el mapa queda como fondo: sin título, popup ni controles. */
  showOverlays?: boolean;
  alertsOpen?: boolean;
  /** Capas animadas (corrientes, riesgo) sin la interfaz del mapa. Por defecto, `showOverlays`. */
  layersLive?: boolean;
  /** Centro de cultivo en foco (estado del dashboard). */
  selectedCenter?: CultivationCenter | null;
  /** Detalle del centro en foco: sitio, origen de simulación y corriente medida. */
  centerDetail?: CenterDetail | null;
  /**
   * Contador de peticiones de encuadre. Cuando avanza, el mapa vuelve a volar al
   * centro en foco aunque no haya cambiado: es lo que hace que pulsar la tarjeta
   * de un centro ya seleccionado devuelva la cámara sobre él.
   */
  focusFrame?: number;
  /** Cada pulsación del wordmark devuelve cámara y selección a la vista principal. */
  homeFrame?: number;
  /** `isClose`: el mapa ya está a zoom de inspección y el centro está en vista. */
  onCenterClick?: (centerId: string, isClose: boolean) => void;
  onClearCenter?: () => void;
  /** Replay abierto: escena del día. null fuera del caso. */
  caseScene?: MapCaseScene | null;
  /** El replay está abierto (aunque sus datos aún no lleguen). */
  caseOpen?: boolean;
  /** Elegir (o abandonar) la zona del caso abre (o cierra) el replay. */
  onCaseToggle?: (open: boolean) => void;
  onSourceSelect?: (source: MapSourceSelection | null) => void;
  /** Cambiar de pestaña: una capa puede vivir en otra vista (ENSO, Modelos, Data). */
  onNavigate?: (tab: StratosTab) => void;
  /** Red de condiciones precursoras: halos en el mapa y ficha del sitio elegido. */
  precursors?: PrecursorAlertsModel | null;
  /** Sitio con la ficha abierta (desde el panel o un halo). */
  precursorFocus?: string | null;
  onPrecursorFocus?: (code: string | null) => void;
}

/*
 * La variable abierta vive en la URL (`?variable=temperature_water`), no la
 * fuente: la fuente la decide STRATOS. Sólo si un usuario avanzado fija una
 * aparece `&source=`, y al volver a automático desaparece.
 */
function readUrlSelection(): { variable: string | null; source: string | null } {
  if (typeof window === 'undefined') return { variable: null, source: null };
  const params = new URLSearchParams(window.location.search);
  const variable = params.get('variable');
  return { variable: getEnvironmentalVariable(variable) ? variable : null, source: params.get('source') };
}

function writeUrlSelection(variable: string | null, source: string | null) {
  if (typeof window === 'undefined') return;
  const url = new URL(window.location.href);
  if (variable) url.searchParams.set('variable', variable);
  else url.searchParams.delete('variable');
  if (variable && source) url.searchParams.set('source', source);
  else url.searchParams.delete('source');
  window.history.replaceState(window.history.state, '', url);
}

/** Desde este zoom un click sobre el centro abre su detalle en vez de volar hacia él. */
const CENTER_CLOSE_ZOOM = 15.5;

/** Desplazamiento entre el centro del contenedor y el centro del área de mapa visible entre paneles. */
function visibleCenterOffset(container: HTMLElement) {
  const area = visibleStageArea(container);
  return { x: area.centerX - container.clientWidth / 2, y: area.centerY - container.clientHeight / 2 };
}

const MONTHS = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];

function imageryStatusLabel(
  status: ImageryStatus,
  scene: HighResolutionImageryScene | null,
  capture: ImageryCaptureMetadata | null,
) {
  if (!scene) return 'Sin escena disponible';
  switch (status) {
    case 'loading':
      return 'Cargando…';
    case 'ready': {
      // Metadata real de la captura bajo el centro de la vista; si no llegó, sólo el estado.
      if (!capture) return 'Activa';
      const [year, month, day] = (capture.date ?? '').split('-');
      const date = year ? ` · ${day} ${MONTHS[Number(month) - 1]} ${year}` : '';
      return `Activa · ${capture.product} ${capture.resolutionCm} cm${date}`;
    }
    case 'error':
      return 'Imagen de alta resolución no disponible';
    case 'outside':
      return 'Fuera de cobertura';
    case 'idle':
      return `Visible desde zoom ${scene.minZoom}`;
    default:
      return 'Desactivada';
  }
}

/** Hora local en 24 h: es una lectura técnica, no una fecha de redacción. */
const FIELD_TIME = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});

const fieldTime = (ms: number) => FIELD_TIME.format(ms).replace(',', ' ·');

/**
 * La animación comprime el tiempo para que la corriente se vea: la dirección y el
 * contraste entre zonas son los del modelo, el ritmo en pantalla no. Se declara
 * aquí y no en un rótulo permanente porque nadie debería leer rapidez del trazo:
 * para eso está el valor en m/s de la ficha del centro.
 */
const FLOW_ANIMATION_NOTE =
  'La dirección y la intensidad relativa son las del modelo. El ritmo de la animación está acelerado ' +
  'y varía con el zoom: no representa tiempo real. La rapidez en m/s se lee en la ficha del centro.';

/**
 * Procedencia del campo que se está pintando. El motor resuelve CHONOS, Open-Meteo
 * o la última captura guardada sin avisar; sin esta línea el usuario no puede saber
 * cuál de las tres está viendo, ni de cuándo es. `tone` marca lo que no es dato
 * fresco: `stale` y las capturas viejas no se presentan como si fueran de ahora.
 */
function fieldProvenance(field: FlowFieldState | null, error: string | null, mode: 'water' | 'wind' = 'water') {
  if (error) return { text: error, tone: 'critical' as const };
  if (!field) return { text: `${mode === 'water' ? 'Corrientes' : 'Viento'} · cargando…`, tone: 'neutral' as const };
  const what = field.mode === 'water' ? 'Corrientes' : 'Viento';
  const valid = Date.parse(field.date);
  const when = Number.isFinite(valid) ? ` · válido ${fieldTime(valid)}` : '';
  if (field.fromCache) {
    const captured = Date.parse(field.capturedAt ?? '');
    const age = Number.isFinite(captured) ? ` de ${fieldTime(captured)}` : '';
    return { text: `${what} · ${field.source} · última captura${age}`, tone: 'attention' as const };
  }
  if (field.stale) return { text: `${what} · ${field.source}${when} · desfasado`, tone: 'attention' as const };
  return { text: `${what} · ${field.source}${when}`, tone: 'neutral' as const };
}

const NO_SITES: PrecursorNetworkSite[] = [];

/*
 * Posición de la ficha de condiciones: a la derecha del punto, separada del halo;
 * si chocaría con el panel de alertas, a la izquierda. Verticalmente centrada en
 * el punto y contenida entre el título del mapa y la franja inferior.
 */
const POP_HEIGHT = 350;
const POP_GAP = 34;
const RIGHT_RESERVED = 400;
function precursorPopPosition(anchor: { x: number; y: number; w: number; h: number }) {
  const width = Math.min(window.matchMedia('(min-width: 2200px) and (min-height: 1200px)').matches ? 400 : 352, anchor.w - 32);
  const fitsRight = anchor.x + POP_GAP + width <= anchor.w - RIGHT_RESERVED;
  const dock = document.querySelector('.left-dock-frame[aria-hidden="false"]');
  const dockRight = dock?.getBoundingClientRect().right ?? 0;
  const left = Math.min(anchor.w - width - 16, Math.max(dockRight + 12, fitsRight ? anchor.x + POP_GAP : anchor.x - POP_GAP - width, 16));
  const top = Math.min(Math.max(96, anchor.y - POP_HEIGHT / 2), Math.max(96, anchor.h - POP_HEIGHT - 260));
  return { left, top };
}

export function StratosMapView({
  points,
  popup,
  dataLabel,
  dataTone,
  onOpenPopup,
  onNavigate,
  showOverlays = true,
  alertsOpen = false,
  layersLive = showOverlays,
  selectedCenter = null,
  focusFrame = 0,
  homeFrame = 0,
  centerDetail = null,
  onCenterClick,
  onClearCenter,
  onSourceSelect,
  caseScene = null,
  caseOpen = false,
  onCaseToggle,
  precursors = null,
  precursorFocus = null,
  onPrecursorFocus,
}: StratosMapViewProps) {
  const centerHandlersRef = useRef({ onCenterClick });
  centerHandlersRef.current = { onCenterClick };
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const darkLayerRef = useRef<L.TileLayer | null>(null);
  const hoverRef = useRef<MapHoverTarget | null>(null);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  // Store único del mapa: AOI, capas, base, profundidad, instante, escena y estado de imagen.
  const [mapState, dispatch] = useReducer(stratosMapReducer, undefined, () => {
    const initial = createInitialMapState(STRATOS_AOIS[DEFAULT_AOI_ID], DEFAULT_MAP_LAYERS, DEFAULT_HIGH_RESOLUTION_SCENE_ID);
    try { return restoreMapPreferences(initial, localStorage.getItem(MAP_PREFERENCES_KEY)); } catch { return initial; }
  });
  useEffect(() => {
    try { localStorage.setItem(MAP_PREFERENCES_KEY, serializeMapPreferences(mapState)); } catch { /* Storage may be disabled. */ }
  }, [mapState]);
  const reducedMapMotion = useReducedMapMotion();
  const [flowMode, setFlowMode] = useState<'water' | 'wind'>('water');
  const [flowPaused, setFlowPaused] = useState(false);
  const animateFlow = !flowPaused && !reducedMapMotion;
  const [context, setContext] = useState<StratosMapContextValue | null>(null);
  const [crocoOpen, setCrocoOpen] = useState(false);
  const closeCroco = useCallback(() => setCrocoOpen(false), []);
  useEffect(() => {
    const open = () => setCrocoOpen(true);
    window.addEventListener('stratos:croco-spatial', open);
    return () => window.removeEventListener('stratos:croco-spatial', open);
  }, []);
  const [detailZoom, setDetailZoom] = useState(false);
  const [settledView, setSettledView] = useState<{ longitude: number; latitude: number; zoom: number } | null>(null);
  const [capture, setCapture] = useState<ImageryCaptureMetadata | null>(null);
  const [hover, setHover] = useState<MapHoverTarget | null>(null);
  const [hoverPos, setHoverPos] = useState<{ x: number; y: number } | null>(null);
  // Procedencia del campo vigente. Un estado por recarga del campo (media hora), no por frame.
  const [flowField, setFlowField] = useState<FlowFieldState | null>(null);
  const [flowError, setFlowError] = useState<string | null>(null);
  // Estación SOTRACS abierta. El hover no abre nada: sólo el click.
  const [station, setStation] = useState<SotracsStation | null>(null);
  // Ficha de condiciones precursoras: el sitio vive en el panel/mapa; aquí sólo se arma y se vuela.
  const precursorSite = useMemo(() => {
    if (precursorFocus) return precursors?.sites.find((site) => site.codigo === precursorFocus) ?? null;
    // Cualquier boya del mapa abre la misma ficha (con su proyección) si tiene condiciones calculadas.
    if (station) return precursors?.sites.find((site) => site.codigo === station.buoyCode && (site.tipo ?? 'boya') === 'boya') ?? null;
    return null;
  }, [precursorFocus, precursors, station]);
  // Abierta desde una boya (no desde una alerta): cerrarla suelta la boya, como la ficha anterior.
  const cardFromStation = !precursorFocus && precursorSite != null;
  const precursorCard = useMemo(() => (precursorSite ? buildPrecursorSiteCard(precursorSite) : null), [precursorSite]);
  // Cifra de condiciones por boya, para su etiqueta de hover.
  const buoyConditions = useMemo(() => new Map(
    (precursors?.sites ?? [])
      .filter((site) => (site.tipo ?? 'boya') === 'boya' && site.cadena)
      .map((site) => [site.codigo, { score: site.cadena!.puntaje, band: conditionBand(site.cadena!.puntaje, site.cadena!.cobertura)?.key ?? null }] as const),
  ), [precursors]);
  const precursorFlightRef = useRef<string | null>(null);
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !precursorSite) {
      if (!precursorSite) precursorFlightRef.current = null;
      return;
    }
    // Volar sólo al elegir el sitio, no en cada refresco del archivo.
    if (precursorFlightRef.current === precursorSite.codigo) return;
    precursorFlightRef.current = precursorSite.codigo;
    // Desde una alerta se cierra la boya abierta; desde la boya misma, la ficha ES la boya.
    if (precursorFocus) setStation(null);
    const zoom = (precursorSite.tipo ?? 'boya') === 'boya' ? 10.5 : 9.5;
    flyToLocation(map, { longitude: precursorSite.lon, latitude: precursorSite.lat, zoom }, { offset: visibleCenterOffset(map.getContainer()) });
  }, [precursorSite, precursorFocus]);
  // La ficha vive junto a su punto: se recalcula al mover o hacer zoom.
  const [precursorAnchor, setPrecursorAnchor] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !precursorSite) {
      setPrecursorAnchor(null);
      return;
    }
    const update = () => {
      const point = map.latLngToContainerPoint([precursorSite.lat, precursorSite.lon]);
      const size = map.getSize();
      setPrecursorAnchor({ x: point.x, y: point.y, w: size.x, h: size.y });
    };
    update();
    map.on('move zoom resize', update);
    return () => {
      map.off('move zoom resize', update);
    };
  }, [precursorSite]);
  const reloncaviExplanation = useReloncaviExplanation(station?.buoyCode === 'acs1');
  // Variable abierta y, sólo si alguien la fijó, su fuente. Por defecto decide STRATOS.
  const [activeVariableId, setActiveVariableId] = useState<string | null>(() => readUrlSelection().variable);
  const [sourceOverride, setSourceOverride] = useState<string | null>(() => readUrlSelection().source);
  const activeVariable = getEnvironmentalVariable(activeVariableId);
  const selectVariable = useCallback((id: string | null) => {
    setActiveVariableId(id);
    // Cambiar de variable devuelve la elección de fuente a STRATOS.
    setSourceOverride(null);
  }, []);
  useEffect(() => {
    writeUrlSelection(activeVariableId, sourceOverride);
  }, [activeVariableId, sourceOverride]);
  const sensorNetwork = useSensorNetwork(DEFAULT_SENSOR_WINDOW_HOURS);
  const [sotracsStations, setSotracsStations] = useState<SotracsStation[]>(SOTRACS_STATIONS);
  const precursorStation = sotracsStations.find(item => item.buoyCode === precursorCard?.code);
  const precursorLocation = precursorStation && precursorStation.sector !== precursorStation.region
    ? `${precursorStation.sector} · ${precursorStation.region}` : undefined;
  const [weatherStations, setWeatherStations] = useState<RedmetStation[]>([]);
  const [weatherContexts, setWeatherContexts] = useState<Record<string, WeatherLocation>>({});
  useEffect(() => {
    let active = true;
    void acs.fetchBuoys().then((result) => {
      if (active && result.data) setSotracsStations(stationsFromBuoys(result.data));
    });
    const refreshWeather = () => void redmet.fetchStations().then(async (result) => {
      if (!active || !result.data) return;
      setWeatherStations(result.data);
      const contexts = await fetchWeatherContexts(result.data);
      if (active) setWeatherContexts(contexts);
    });
    refreshWeather();
    const weatherTimer = window.setInterval(refreshWeather, 15 * 60_000);
    return () => {
      active = false;
      window.clearInterval(weatherTimer);
    };
  }, []);
  const centerSensorLinks = useMemo(
    () =>
      buildCenterSensorLinks(
        CULTIVATION_CENTERS,
        sotracsStations,
        sensorNetwork.centers.flatMap((result) => {
          const data = result.data;
          if (!data) return [];
          return [{
            centerId: data.center.id,
            buoyCode: data.buoy.code,
            distanceKm: data.buoy.distanceKm,
            assumed: data.buoy.assumed,
            state: result.state,
          }];
        }),
        MAX_CENTER_SENSOR_DISTANCE_KM,
      ),
    [sensorNetwork.centers, sotracsStations],
  );
  const linkedCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const link of centerSensorLinks) counts.set(link.center.id, (counts.get(link.center.id) ?? 0) + 1);
    return counts;
  }, [centerSensorLinks]);
  const regionalConditions = useMemo(
    () => points.filter((point) => REGIONAL_CONDITION_KINDS.has(point.kind)),
    [points],
  );
  const selectedStationLink = useMemo(
    () => centerSensorLinks.find((link) => link.station.id === station?.id) ?? null,
    [centerSensorLinks, station?.id],
  );
  useEffect(() => {
    if (station && !sotracsStations.some((candidate) => candidate.id === station.id)) setStation(null);
  }, [sotracsStations, station]);
  // La leyenda arranca cerrada: se consulta, no se vigila.
  const [legendOpen, setLegendOpen] = useState(false);

  const selectedAoi: StratosAOI = getAOI(mapState.selectedAoiId) ?? STRATOS_AOIS[DEFAULT_AOI_ID];
  /*
   * Dónde se lee la variable: el centro de lo que se está mirando. Se redondea a
   * ~1 km para que un paneo mínimo no dispare otra lectura.
   */
  const viewLat = settledView?.latitude ?? selectedAoi.camera.latitude;
  const viewLon = settledView?.longitude ?? selectedAoi.camera.longitude;
  const variableLocation = useMemo(
    () => ({ lat: Math.round(viewLat * 100) / 100, lon: Math.round(viewLon * 100) / 100 }),
    [viewLat, viewLon],
  );
  // El campo local pertenece al AOI con proveedor; se mantiene aunque se navegue a otra zona regional.
  // Partículas locales del centro en foco: nacen en su origen de simulación (aguas arriba) y siguen
  // la misma corriente que muestran sus KPIs, para que mapa y detalle cuenten lo mismo.
  const centerAoi = useMemo<StratosAOI | null>(() => {
    if (!centerDetail) return null;
    const { center, site } = centerDetail;
    return {
      id: `center-${center.id}`,
      label: center.name,
      region: 'Centro de cultivo',
      camera: { longitude: center.lng, latitude: center.lat, zoom: site.inspectionZoom },
      particleOrigin: site.simulationOrigin,
      // Mismo campo real que el KPI de corriente del centro (CHONOS, CROCO 1 km).
      velocityProvider: { id: 'chonos-croco' },
    };
  }, [centerDetail]);
  // Cada campo archivado que fija el replay es otro instante: el campo local se vuelve a resolver.
  const [pinnedFieldId, setPinnedFieldId] = useState<string | null>(null);
  const baseParticleAoi: StratosAOI = centerAoi ?? (selectedAoi.velocityProvider ? selectedAoi : STRATOS_AOIS.caletaLaArena);
  const particleAoi = useMemo(() => ({ ...baseParticleAoi }), [baseParticleAoi, pinnedFieldId]);
  const velocityField = useVelocityField(particleAoi, mapState.selectedDepth, mapState.selectedTimestamp);
  const vectorField = useMemo<VelocityField | null>(() => {
    const map = context?.map;
    if (!map || !context.flowEngine) return null;
    const view = map.getBounds();
    if (usesLocalFlow(flowMode, settledView?.zoom ?? map.getZoom(), velocityField?.bounds,
      [view.getWest(), view.getSouth(), view.getEast(), view.getNorth()])) return velocityField;
    if (!flowField || flowField.mode !== flowMode) return null;
    const engine = context.flowEngine;
    return { id: `${flowField.mode}:${flowField.date}:${flowField.source}`, source: flowField.source,
      bounds: [-180, -90, 180, 90], depth: 0, availableDepths: [0], referenceTime: Date.parse(flowField.date),
      sample: (longitude, latitude) => engine.sampleFlow(longitude, latitude) };
  }, [context, velocityField, flowField, flowMode, settledView]);
  const highResScene = getHighResolutionScene(mapState.highResolutionSceneId ?? undefined);
  const layers = mapState.activeLayers;

  const updatePopupPosition = useCallback(() => {
    const map = mapRef.current;
    const target = hoverRef.current;
    if (!map || !target) return;
    const point = map.latLngToContainerPoint([target.lat, target.lng]);
    if (Number.isFinite(point.x) && Number.isFinite(point.y)) setHoverPos({ x: point.x, y: point.y });
  }, []);

  const showHover = useCallback(
    (target: MapHoverTarget) => {
      clearTimeout(hideTimerRef.current);
      hoverRef.current = target;
      setHover(target);
      updatePopupPosition();
    },
    [updatePopupPosition],
  );

  // Pequeña gracia al salir del punto: permite llevar el mouse hasta la card sin que desaparezca.
  const scheduleHide = useCallback(() => {
    clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => {
      hoverRef.current = null;
      setHover(null);
    }, 180);
  }, []);

  // Instancia única de Leaflet: basemap global, señalética fija y motor hidrodinámico regional.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const map = L.map(container, {
      zoomControl: false,
      attributionControl: false,
      preferCanvas: true,
      zoomSnap: 0.25,
      minZoom: 6,
      maxZoom: MAP_MAX_ZOOM,
    });
    mapRef.current = map;
    flyToAOI(map, STRATOS_AOIS[DEFAULT_AOI_ID], { animate: false, offset: visibleCenterOffset(container) });

    // Misma fuente que el detalle: evita depender de EOX para cargar la vista regional.
    const satellite = L.tileLayer(SATELLITE_URL, {
      minZoom: 2,
      maxNativeZoom: GLOBAL_DETAIL_IMAGERY.maxNativeZoom,
      maxZoom: MAP_MAX_ZOOM,
      keepBuffer: 6,
      updateWhenZooming: false,
      crossOrigin: true,
      attribution: GLOBAL_DETAIL_IMAGERY.attribution,
      className: 'stratos-satellite-tiles',
    }).addTo(map);

    const pane = (name: string, zIndex: number, interactive = true) => {
      const created = map.getPane(name) ?? map.createPane(name);
      created.style.zIndex = String(zIndex);
      if (!interactive) created.style.pointerEvents = 'none';
    };
    pane('stratosBasemapPane', STRATOS_PANE_Z.darkBasemap, false);
    pane('stratosRoutesPane', STRATOS_PANE_Z.routes, false);
    pane('stratosLabelsPane', STRATOS_PANE_Z.labels, false);
    pane('stratosSelectedPane', STRATOS_PANE_Z.selected);

    MAP_PLACE_LABELS.forEach((label) => {
      L.marker([label.lat, label.lng], {
        pane: 'stratosLabelsPane',
        interactive: false,
        keyboard: false,
        icon: L.divIcon({
          className: 'stratos-place-icon',
          html: `<span class="stratos-place stratos-place--${label.kind}">${label.name}</span>`,
          iconSize: [0, 0],
          iconAnchor: [0, 0],
        }),
      }).addTo(map);
    });

    const engine: FlowEngine = createFlowEngine(map, {
      satelliteLayer: satellite,
      // No existe hoy un campo espacial FAN observado/validado. Un arreglo vacío
      // evita que una mancha ilustrativa se confunda con evidencia operacional.
      hotspots: [],
      riskPaneZIndex: STRATOS_PANE_Z.risk,
      // Qué fuente está pintando y de cuándo es: se declara en la atribución del mapa.
      onFieldChange: (state, error) => {
        setFlowField(state);
        setFlowError(error ?? null);
        if (state?.warning) console.info('[STRATOS:flowMap]', state.warning);
      },
      // Sin estado React: el nivel sólo conmuta CSS (ver glass.css, `data-render-tier`).
      onRenderTier: (tier) => {
        document.documentElement.dataset.renderTier = tier;
      },
    });
    setContext({ map, flowEngine: engine });

    map.on('move zoom resize', updatePopupPosition);
    map.whenReady(() => map.invalidateSize());

    // Nitidez a zoom de detalle: pasos de 0.5 y atmósfera del dashboard atenuada sobre la imagen.
    const syncDetailZoom = () => {
      const zoom = map.getZoom();
      map.options.zoomSnap = zoomSnapFor(zoom);
      setDetailZoom(zoom >= DETAIL_ZOOM);
    };
    syncDetailZoom();
    map.on('zoomend', syncDetailZoom);

    // Vista "asentada": sólo cuando el usuario deja de mover el mapa (un estado React por pausa, no por frame).
    let settleTimer: ReturnType<typeof setTimeout> | undefined;
    const settleView = () => {
      clearTimeout(settleTimer);
      settleTimer = setTimeout(() => {
        const center = map.getCenter();
        setSettledView({ longitude: center.lng, latitude: center.lat, zoom: map.getZoom() });
      }, MAP_IDLE_MS);
    };
    const cancelSettle = () => clearTimeout(settleTimer);
    settleView();
    map.on('moveend', settleView);
    map.on('movestart', cancelSettle);

    const observer = new ResizeObserver(() => map.invalidateSize({ animate: false }));
    observer.observe(container);

    return () => {
      clearTimeout(hideTimerRef.current);
      observer.disconnect();
      setContext(null);
      engine.destroy();
      delete document.documentElement.dataset.renderTier;
      clearTimeout(settleTimer);
      map.off('moveend', settleView);
      map.off('movestart', cancelSettle);
      map.off('zoomend', syncDetailZoom);
      map.off('move zoom resize', updatePopupPosition);
      map.remove();
      mapRef.current = null;
      darkLayerRef.current = null;
    };
  }, [updatePopupPosition, showHover, scheduleHide]);

  // Metadata real de la captura (resolución, producto, fecha) bajo el centro de la vista asentada.
  const wantsCaptureInfo = Boolean(settledView && layers.highResolutionImagery && settledView.zoom >= DETAIL_ZOOM);
  useEffect(() => {
    if (!wantsCaptureInfo || !settledView) {
      setCapture(null);
      return;
    }
    let cancelled = false;
    fetchImageryMetadata(settledView.longitude, settledView.latitude).then((metadata) => {
      if (!cancelled) setCapture(metadata);
    });
    return () => {
      cancelled = true;
    };
  }, [wantsCaptureInfo, settledView]);

  // Fuera de "Mapa Vivo" no queda ninguna card abierta.
  useEffect(() => {
    if (showOverlays) return;
    clearTimeout(hideTimerRef.current);
    hoverRef.current = null;
    setHover(null);
  }, [showOverlays]);

  // Base oscura superpuesta: la imagen satelital sigue debajo para la máscara tierra/agua.
  useEffect(() => {
    const map = context?.map;
    if (!map) return;
    if (mapState.baseLayer === 'oscuro' && !darkLayerRef.current) {
      darkLayerRef.current = L.tileLayer(DARK_URL, {
        pane: 'stratosBasemapPane',
        maxNativeZoom: 16,
        maxZoom: MAP_MAX_ZOOM,
        className: 'stratos-dark-tiles',
      }).addTo(map);
    }
    if (mapState.baseLayer === 'satelital' && darkLayerRef.current) {
      map.removeLayer(darkLayerRef.current);
      darkLayerRef.current = null;
    }
  }, [context, mapState.baseLayer]);

  const selectAoi = (id: string) => {
    const aoi = getAOI(id);
    if (!aoi) return;
    dispatch({ type: 'selectAoi', aoi });
    onClearCenter?.();
    onSourceSelect?.(null);
    setStation(null);
    onCaseToggle?.(id === TARABA_CASE_AOI_ID);
    if (mapRef.current) flyToAOI(mapRef.current, aoi, { offset: visibleCenterOffset(mapRef.current.getContainer()) });
  };

  // El replay también se abre desde la URL o se cierra desde su línea de tiempo: la
  // zona del mapa lo acompaña sin que el usuario tenga que elegirla.
  useEffect(() => {
    const map = context?.map;
    if (!map) return;
    const inCaseZone = mapState.selectedAoiId === TARABA_CASE_AOI_ID;
    if (caseOpen === inCaseZone) return;
    const aoi = caseOpen ? getAOI(TARABA_CASE_AOI_ID) : STRATOS_AOIS[DEFAULT_AOI_ID];
    if (!aoi) return;
    dispatch({ type: 'selectAoi', aoi });
    setStation(null);
    flyToAOI(map, aoi, { offset: visibleCenterOffset(map.getContainer()) });
  }, [caseOpen, context, mapState.selectedAoiId]);

  // Corrientes del replay: la corrida CHONOS archivada manda mientras el caso esté abierto.
  const caseCurrentsUrl = caseScene?.currentsUrl ?? null;
  useEffect(() => {
    const engine = context?.flowEngine;
    if (!caseCurrentsUrl) {
      pinChonosField(null);
      setPinnedFieldId(null);
      engine?.refresh();
      return;
    }
    let cancelled = false;
    loadArchivedChonosField(caseCurrentsUrl)
      .then((grid) => {
        if (cancelled) return;
        pinChonosField(grid);
        setPinnedFieldId(grid?.id ?? null);
        engine?.refresh();
      })
      .catch((error) => console.warn('[STRATOS:caso] corriente archivada no disponible:', (error as Error)?.message));
    return () => {
      cancelled = true;
    };
  }, [caseCurrentsUrl, context]);
  useEffect(() => () => pinChonosField(null), []);

  // Plumas: sólo desde centros con FAN reportada. Sin caso, sin focos y sin plumas.
  const caseHotspots = caseScene?.hotspots;
  useEffect(() => {
    context?.flowEngine?.setBloomHotspots(caseHotspots ?? []);
  }, [caseHotspots, context]);

  const flyToCaseCenter = useCallback((center: CultivationCenter) => {
    mapRef.current?.flyTo([center.lat, center.lng], Math.max(mapRef.current.getZoom(), 13), { duration: 0.8 });
  }, []);

  // Clic en un centro: desde lejos enfoca y vuela; ya cerca, abre o colapsa su detalle.
  const clickCenter = useCallback((center: CultivationCenter) => {
    const map = mapRef.current;
    if (!map) return;
    setStation(null);
    onSourceSelect?.(null);
    const isClose = map.getZoom() >= CENTER_CLOSE_ZOOM && map.getBounds().contains([center.lat, center.lng]);
    centerHandlersRef.current.onCenterClick?.(center.id, isClose);
  }, [onSourceSelect]);

  const homeSeen = useRef(homeFrame);
  useEffect(() => {
    if (homeFrame === homeSeen.current || !mapRef.current) return;
    homeSeen.current = homeFrame;
    const aoi = STRATOS_AOIS[DEFAULT_AOI_ID];
    dispatch({ type: 'selectAoi', aoi });
    setStation(null);
    setHover(null);
    flyToAOI(mapRef.current, aoi, { offset: visibleCenterOffset(mapRef.current.getContainer()) });
  }, [homeFrame, context]);

  // Enfocar un centro vuela una vez a su vista satelital. Al volver del detalle lateral
  // la cámara sigue donde estaba: el usuario reencuentra el centro en el mismo lugar.
  //
  // El encuadre se identifica por centro *y* petición (`focusFrame`), no sólo por
  // centro: pedirlo desde una tarjeta del panel debe volar aunque ese centro ya
  // estuviera en foco y el usuario se hubiera alejado navegando.
  const framedIdRef = useRef<string | null>(null);
  // Fase del fundido del lienzo al volar a un centro (ver `fadeFlight`).
  const [cameraFade, setCameraFade] = useState<CameraFadePhase>('idle');
  // El vuelo en curso se aborta sólo si empieza otro o se desmonta el mapa: un
  // re-render del efecto (p. ej. llega telemetría nueva) no debe dejarlo a oscuras.
  const flightRef = useRef<AbortController | null>(null);
  useEffect(() => () => flightRef.current?.abort(), []);
  useEffect(() => {
    const map = mapRef.current;
    if (!selectedCenter) framedIdRef.current = null;
    if (!map || !selectedCenter || centerDetail?.center.id !== selectedCenter.id) return;

    const frame = `${selectedCenter.id}:${focusFrame}`;
    if (framedIdRef.current === frame) return;
    framedIdRef.current = frame;

    dispatch({ type: 'setLayer', layer: 'highResolutionImagery', value: true });
    dispatch({ type: 'setLayer', layer: 'particles', value: true });
    const camera = { longitude: selectedCenter.lng, latitude: selectedCenter.lat, zoom: Math.max(map.getZoom(), centerDetail.site.inspectionZoom) };

    // Un flyTo hasta el zoom de inspección se ve pixelado: se funde, salta y vuelve nítido.
    flightRef.current?.abort();
    const flight = new AbortController();
    flightRef.current = flight;
    void fadeFlight(
      {
        setPhase: setCameraFade,
        jump: () => flyToLocation(map, camera, { animate: false, offset: visibleCenterOffset(map.getContainer()) }),
        tilesLoading: () => mapTilesLoading(map),
        sleep: (ms, signal) =>
          new Promise((resolve) => {
            const timer = window.setTimeout(() => resolve(!signal.aborted), ms);
            signal.addEventListener('abort', () => {
              window.clearTimeout(timer);
              resolve(false);
            }, { once: true });
          }),
        nextFrame: (signal) => new Promise((resolve) => requestAnimationFrame(() => resolve(!signal.aborted))),
        now: () => performance.now(),
        reducedMotion: prefersReducedMotion(),
      },
      flight.signal,
    );
  }, [selectedCenter, centerDetail, focusFrame]);

  const recenter = () => {
    if (mapRef.current) flyToAOI(mapRef.current, selectedAoi, { offset: visibleCenterOffset(mapRef.current.getContainer()) });
  };

  const onImageryStatus = useCallback((status: ImageryStatus) => dispatch({ type: 'setImageryStatus', status }), []);

  const aoiOptions = useMemo(() => AOI_LIST.map((aoi) => ({ id: aoi.id, label: aoi.label })), []);
  const barWidth = hover ? Math.max(0, Math.min(100, hover.value)) : 0;

  // Créditos de la imagen. La fuente del campo no se lista aquí de forma fija: se
  // declara aparte, porque cuál sirve el dato cambia en caliente (ver `provenance`).
  const attributions = [
    mapState.baseLayer === 'oscuro' ? '© Esri' : null,
    GLOBAL_DETAIL_IMAGERY.attribution,
    layers.highResolutionImagery && highResScene && (mapState.imageryStatus === 'ready' || mapState.imageryStatus === 'loading')
      ? highResScene.attribution
      : null,
    'Open-Meteo (CC BY 4.0)',
  ].filter(Boolean);
  const provenance = fieldProvenance(flowField, flowError, flowMode);

  return (
    <div
      className="stratos-map absolute inset-0 z-0 h-full w-full select-none overflow-hidden"
      data-camera-fade={cameraFade === 'idle' ? undefined : cameraFade}
      style={{ ['--camera-fade-out' as string]: `${CAMERA_FADE.outMs}ms`, ['--camera-fade-in' as string]: `${CAMERA_FADE.inMs}ms` }}
      data-detail-zoom={detailZoom ? 'true' : 'false'}
    >
      {crocoOpen && <CrocoSimulationView onClose={closeCroco} />}
      <div ref={containerRef} id="stratos-flow-map" className="absolute inset-0 z-0 h-full w-full cursor-grab active:cursor-grabbing" />

      {context && (
        <StratosMapContext.Provider value={context}>
          <HighResolutionImageryLayer scene={highResScene} visible={layers.highResolutionImagery} onStatusChange={onImageryStatus} />
          {caseScene && <ObservedChlorophyllLayer frames={caseScene.frames} date={caseScene.date} visible={layersLive} />}
          {/* Fuera de "Mapa Vivo" el mapa es fondo; sólo Modelos lo deja animar detrás de su vidrio. */}
          <RegionalFlowLayer visible={layersLive && layers.particles && animateFlow} mode={flowMode} localField={velocityField} />
          {centerDetail && (
            <CenterSiteLayer
              center={centerDetail.center}
              site={centerDetail.site}
              visible={layersLive && layers.cultivationCenters}
            />
          )}
          <ParticleFieldLayer
            origin={[particleAoi.particleOrigin!.longitude, particleAoi.particleOrigin!.latitude]}
            velocityField={velocityField}
            visible={layersLive && layers.particles && animateFlow && flowMode === 'water'}
            emitterLabelPermanent={Boolean(centerAoi)}
            spawnRadiusMeters={centerDetail && centerAoi ? centerDetail.site.spawnRadiusM : undefined}
          />
          <CurrentVectorLayer velocityField={vectorField} visible={layersLive && ((flowMode === 'water' && layers.currents) || (layers.particles && !animateFlow))} />
          <RiskLayer visible={layersLive && layers.risk && flowMode === 'water' && animateFlow} />
          <PrecursorConditionLayer
            sites={precursors?.network ?? NO_SITES}
            visible={layers.sensors}
            selected={precursorFocus}
            onSelect={(code) => onPrecursorFocus?.(code)}
          />
          <CenterSensorLinkLayer
            links={centerSensorLinks}
            visible={layersLive && layers.sensors && layers.cultivationCenters}
            focusId={station?.id ?? selectedCenter?.id ?? null}
          />
          <CultivationCenterLayer
            centers={CULTIVATION_CENTERS}
            visible={layers.cultivationCenters}
            selectedId={selectedCenter?.id ?? null}
            linkedCounts={linkedCounts}
            onHover={showHover}
            onLeave={scheduleHide}
            onSelect={clickCenter}
          />
          {caseScene && (
            <CultivationCenterLayer
              centers={caseScene.centers}
              visible={layers.cultivationCenters}
              onHover={showHover}
              onLeave={scheduleHide}
              onSelect={flyToCaseCenter}
            />
          )}
          <SensorLayer points={regionalConditions} visible={layers.sensors} onHover={showHover} onLeave={scheduleHide} />
          <LandSourceLayer
            weatherStations={weatherStations}
            weatherContexts={weatherContexts}
            rivers={rivers.RELONCAVI_RIVERS}
            visible={layers.sensors}
            onSelect={(source) => { setStation(null); onSourceSelect?.(source); }}
          />
          {/* Catálogo ACS completo; las líneas sólo aparecen donde existe asociación a centro. */}
          <SotracsBuoyLayer
            stations={sotracsStations}
            centers={CULTIVATION_CENTERS}
            showCenters={layers.cultivationCenters}
            links={centerSensorLinks}
            visible={layers.sensors}
            selectedId={station?.id ?? null}
            conditions={buoyConditions}
            onSelect={(next) => {
              setStation(next);
              onSourceSelect?.({ kind: 'buoy', station: next, link: centerSensorLinks.find((link) => link.station.id === next.id) ?? null });
            }}
          />
        </StratosMapContext.Provider>
      )}

      <div className="stratos-map-atmosphere stratos-map-vignette pointer-events-none absolute inset-0 z-[1]" />
      <div className="stratos-map-atmosphere pointer-events-none absolute bottom-0 left-0 top-0 z-[1] w-[clamp(380px,33vw,520px)] bg-gradient-to-r from-[var(--map-atmosphere)]/85 via-[var(--map-atmosphere)]/40 to-transparent" />
      <div className="stratos-map-atmosphere pointer-events-none absolute inset-y-0 right-0 z-[1] w-[clamp(280px,24vw,380px)] bg-gradient-to-l from-[var(--map-atmosphere)]/75 via-[var(--map-atmosphere)]/25 to-transparent" />

      {/* MapOverlayHeader */}
      <div
        hidden={!showOverlays}
        style={{ left: 'calc(var(--map-area-left) + var(--map-content-offset))' }}
        className="stratos-map-header pointer-events-auto absolute top-[var(--map-title-top)] z-20"
      >
        <h1 className="stratos-map-title">Monitor FAN</h1>

        <div className="stratos-map-pills">
          <div
            className="stratos-data-chip"
            data-tone={dataTone}
            role="status"
            aria-live="polite"
            title="Estado de las fuentes operacionales"
          >
            {/* El punto sólo acompaña un problema (reducido, sin datos); en operación normal basta la hora. */}
            {dataTone !== 'stable' && <span className="stratos-data-chip-dot" aria-hidden="true" />}
            <span>{dataLabel}</span>
          </div>
        </div>
      </div>

      {/* RiskMapPopup */}
      {showOverlays && hover && hoverPos && (
        <div
          key={hover.id}
          className="stratos-risk-popup-anchor pointer-events-auto absolute z-30"
          style={{ left: hoverPos.x, top: hoverPos.y }}
          onMouseEnter={() => clearTimeout(hideTimerRef.current)}
          onMouseLeave={scheduleHide}
        >
          <GlassSurface
            variant="floating"
            className="stratos-risk-popup"
            role="button"
            tabIndex={0}
            onClick={onOpenPopup}
            onKeyDown={(event) => {
              if (event.key === 'Enter' || event.key === ' ') onOpenPopup();
            }}
            aria-label={`${hover.title} ${hover.location}: ${hover.value}%, ${hover.change}`}
          >
            <div className="stratos-risk-popup-header">
              <span>{hover.title}</span>
              <ArrowUpRight size={13} weight="light" aria-hidden="true" />
            </div>
            <p className="stratos-risk-popup-location">{hover.location}</p>
            <div className="stratos-risk-popup-metric">
              <span className="stratos-risk-popup-value">{hover.value}</span>
              <span className="stratos-risk-popup-unit">%</span>
              <span className={`stratos-risk-popup-change is-${hover.changeDirection}`}>
                {hover.changeDirection !== 'flat' && <Triangle size={9} weight="fill" aria-hidden="true" />}
                {hover.change}
              </span>
            </div>
            <div className="stratos-risk-popup-bar" aria-hidden="true">
              <span style={{ width: `${barWidth}%` }} />
            </div>
            <p className="stratos-risk-popup-horizon">{popup.horizon}</p>
          </GlassSurface>
        </div>
      )}

      {/* Ficha de estación SOTRACS: sólo tras un click, nunca en hover. */}
      {/* Tarjetas del mapa: la variable abierta y, debajo, la estación elegida. */}
      {precursorCard && precursorAnchor && (
        <div className="precursor-pop-anchor pointer-events-auto absolute z-40" style={precursorPopPosition(precursorAnchor)}>
          <PrecursorSiteCard card={precursorCard} location={precursorLocation} onClose={() => (cardFromStation ? setStation(null) : onPrecursorFocus?.(null))} />
        </div>
      )}
      {(station || (activeVariable && variableLocation && showOverlays)) && (
        <div
          data-alerts-open={alertsOpen}
          className="stratos-map-detail-rail pointer-events-auto absolute z-30 flex flex-col gap-2"
        >
          {activeVariable && variableLocation && showOverlays && (activeVariable.measures.length > 0 || activeVariable.compose === 'index') && (
            <VariableCard
              variable={activeVariable}
              location={variableLocation}
              sensors={sensorNetwork.centers}
              sourceOverride={sourceOverride}
              onOverride={setSourceOverride}
              onClose={() => selectVariable(null)}
              onNavigate={(tab) => onNavigate?.(tab)}
            />
          )}
          {station && !cardFromStation && (
            <SotracsStationCard
              station={station}
              connection={selectedStationLink}
              reloncavi={station.buoyCode === 'acs1' ? reloncaviExplanation : undefined}
              onClose={() => setStation(null)}
            />
          )}
        </div>
      )}

      {/* Map controls */}
      <div
        hidden={!showOverlays}
        style={{ left: 'var(--map-area-left)', bottom: 'calc(var(--viewport-margin) + var(--bottom-height) + 12px)' }}
        className="map-pill-material stratos-map-controls pointer-events-auto absolute z-[25] flex items-center rounded-full p-1"
      >
        {/* Zona y mapa base viven en la misma barra que la navegación: todo lo que mueve el mapa, junto. */}
        <div className="stratos-map-controls-selectors">
          <button type="button" onClick={() => setCrocoOpen(true)} style={{ color: 'var(--stratos-amber, #ee9242)', padding: '8px 12px', fontSize: 12, whiteSpace: 'nowrap' }} aria-label="Abrir CROCO campos 3D y transporte">CROCO · 3D</button>
          <PillSelector
            id="map-zone-selector"
            mapMenu
            icon={<MapPinArea size={14} weight="light" />}
            options={aoiOptions}
            selectedId={mapState.selectedAoiId}
            onSelect={selectAoi}
            menuTitle="Zona de monitoreo"
          />
          <MapLayerMenu
            icon={<GlobeHemisphereWest size={14} weight="light" />}
            baseLayer={mapState.baseLayer}
            baseOptions={BASE_LAYER_OPTIONS}
            onSelectBase={(baseLayer: BaseLayerId) => dispatch({ type: 'setBaseLayer', baseLayer })}
            layers={layers}
            onToggleLayer={(layer) => dispatch({ type: 'toggleLayer', layer })}
            highResolution={{
              provider: highResScene?.provider ?? 'Alta resolución',
              sceneName: highResScene?.name ?? null,
              status: layers.highResolutionImagery ? mapState.imageryStatus : 'off',
              statusLabel: imageryStatusLabel(layers.highResolutionImagery ? mapState.imageryStatus : 'off', highResScene, capture),
            }}
            activeVariableId={activeVariableId}
            onSelectVariable={selectVariable}
            onNavigate={(tab) => onNavigate?.(tab)}
            placement="up"
            flowMode={flowMode}
            onFlowMode={setFlowMode}
            flowPaused={flowPaused || reducedMapMotion}
            onFlowPaused={() => setFlowPaused((current) => !current)}
            reducedMotion={reducedMapMotion}
            flowStatus={provenance.text}
            riskAvailable={Boolean(caseHotspots?.length)}
          />
        </div>
        <span className="stratos-map-controls-divider" aria-hidden="true" />
        <button type="button" onClick={() => mapRef.current?.zoomIn()} title="Acercar" aria-label="Acercar" className="map-control-button">
          <Plus size={14} weight="light" />
        </button>
        <button type="button" onClick={() => mapRef.current?.zoomOut()} title="Alejar" aria-label="Alejar" className="map-control-button">
          <Minus size={14} weight="light" />
        </button>
        <button type="button" onClick={recenter} title="Recentrar zona" aria-label="Recentrar zona" className="map-control-button">
          <CrosshairSimple size={14} weight="light" />
        </button>
        {/*
          La leyenda cuelga de esta misma barra en vez de ocupar su propio panel:
          es consulta puntual, no información permanente, y el mapa recupera el
          espacio que antes le comía una tarjeta siempre abierta.
        */}
        <div className="stratos-legend-anchor">
          <button
            type="button"
            onClick={() => setLegendOpen((open) => !open)}
            title="Leyenda del mapa"
            aria-label="Leyenda del mapa"
            aria-expanded={legendOpen}
            className="map-control-button"
            data-active={legendOpen || undefined}
          >
            <IconListDetails size={14} stroke={1.75} />
          </button>
          <MapLegend open={legendOpen} />
        </div>
      </div>

      <div
        hidden={!showOverlays}
        className="stratos-map-attribution pointer-events-auto absolute z-[25]"
        style={{ right: 'var(--viewport-margin)', bottom: 'calc(var(--viewport-margin) + var(--bottom-height) + 8px)' }}
      >
        <span
          className="stratos-field-provenance"
          data-tone={provenance.tone}
          aria-live="polite"
          title={FLOW_ANIMATION_NOTE}
        >
          {provenance.text}
        </span>
        <span>{attributions.join(' · ')}</span>
      </div>
    </div>
  );
}
