import { useMemo } from 'react';
import { PROVENANCE } from '@datasource';
import type { CenterDetail } from '../../data/centers/centerDetail.types';
import { useRelativeTime } from '../../hooks/useCenterDetail';
import { buildSensorKpis, currentOriginLabel, flowDirectionLabel } from '../../lib/centers/sensorKpis';
import { GlassCard } from '../molecules/stratos';
import surfaceStyles from '../instruments/instrumentSurface.module.css';
import { SensorKpiGrid } from './SensorKpiGrid';

const WATER_COLUMN = ['surface-temperature', 'depth-temperature', 'salinity', 'dissolved-oxygen', 'chlorophyll', 'turbidity'];
const HYDRODYNAMICS = ['current-speed', 'current-direction', 'site-depth', 'fan-favorability', 'stratification', 'continental-forcing'];

export interface CenterSensorInstrumentsProps {
  detail: CenterDetail;
}

/**
 * Los dos instrumentos inferiores en modo `center-detail`: misma carcasa, mismo tamaño,
 * contenido del centro. Los KPIs se reparten en dos lecturas coherentes, y cada
 * cabecera declara de qué instrumento sale lo que hay debajo.
 */
export function CenterSensorInstruments({ detail }: CenterSensorInstrumentsProps) {
  const kpis = useMemo(() => buildSensorKpis(detail), [detail]);
  const { telemetry } = detail;
  const updatedLabel = useRelativeTime(telemetry.updatedAt);
  const pick = (ids: string[]) => ids.flatMap((id) => kpis.filter((kpi) => kpi.id === id));

  // La cabecera de la columna de agua es su trazabilidad: qué sonda, cuántas
  // reportan, de cuándo es la lectura y con qué procedencia llegó.
  const columnContext = telemetry.columnSource
    ? [telemetry.columnSource, `${detail.sensors} sondas`, updatedLabel]
        .filter(Boolean)
        .join(' · ')
        .concat(telemetry.provenance === 'live' ? '' : ` · ${PROVENANCE[telemetry.provenance].label}`)
    : 'Sin red de sondas';

  const flowContext =
    telemetry.current.towardBearingDeg === null
      ? 'Corriente sin modelo'
      : `Corriente ${flowDirectionLabel(telemetry.current.towardBearingDeg)} · ${currentOriginLabel(telemetry.current.origin)}`;

  const groups = [
    { id: 'water', title: 'Columna de agua', context: columnContext, kpis: pick(WATER_COLUMN) },
    { id: 'hydro', title: 'Hidrodinámica y riesgo', context: flowContext, kpis: pick(HYDRODYNAMICS) },
  ];

  return (
    <>
      {groups.map((group) => (
        <GlassCard
          key={group.id}
          variant="instrument"
          corner="overlay"
          className={surfaceStyles.surface}
          contentClassName={`${surfaceStyles.content} center-instrument-content`}
          role="group"
          aria-label={`${group.title} · ${detail.center.name}`}
        >
          <header className={surfaceStyles.header}>
            <h2 className={surfaceStyles.title}>
              {group.title}
              <span className="center-instrument-context">{group.context}</span>
            </h2>
          </header>
          <SensorKpiGrid kpis={group.kpis} label={`${group.title} · ${detail.center.name}`} className="is-instrument" />
        </GlassCard>
      ))}
    </>
  );
}
