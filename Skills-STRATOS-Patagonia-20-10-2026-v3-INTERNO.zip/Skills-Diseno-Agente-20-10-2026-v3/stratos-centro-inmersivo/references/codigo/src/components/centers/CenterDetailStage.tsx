import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import { ArrowUp, CaretLeft, MapTrifold, SidebarSimple } from '@phosphor-icons/react';
import type { CenterDetail } from '../../data/centers/centerDetail.types';
import { useRelativeTime } from '../../hooks/useCenterDetail';
import { useSceneCamera } from '../../hooks/useSceneCamera';
import { toStage } from '../../lib/centers/sceneCamera';
import { visibleStageArea } from '../../lib/layout/visibleStageArea';
import {
  CENTER_STATUS_LABEL,
  centerMetaLine,
  flowDirectionLabel,
  maybeDecimal,
  NO_VALUE,
  stratificationNote,
} from '../../lib/centers/sensorKpis';
import { CenterDetailHero, depthToImageY } from './CenterDetailHero';
import { CenterSourceRail } from './CenterSourceRail';
import { FlowParticleField } from './FlowParticleField';
import './centerDetail.css';

export interface CenterDetailStageProps {
  detail: CenterDetail | null;
  active: boolean;
  onBack: () => void;
  /** Dock izquierdo oculto: la escena gana su espacio. */
  leftPanelCollapsed?: boolean;
  onToggleLeftPanel?: () => void;
  /** El usuario acercó la vista. */
  onZoomIn?: () => void;
}

type SceneProps = Required<Pick<CenterDetailStageProps, 'active' | 'onBack'>> &
  Omit<CenterDetailStageProps, 'detail' | 'active' | 'onBack'> & { detail: CenterDetail };

const HEADER_SELECTOR = '.center-stage-header';
/** Alto de la línea de estado sobre los instrumentos inferiores. */
const CONTROLS_BAND = 46;

/**
 * Stage central en modo `center-detail`: la vista lateral del centro reemplaza al mapa
 * en el mismo lienzo a sangre y se recorre como él (arrastre, rueda, teclado, controles).
 */
export function CenterDetailStage({ detail, ...props }: CenterDetailStageProps) {
  // Durante el fundido de salida se sigue pintando el último centro.
  const lastRef = useRef<CenterDetail | null>(null);
  if (detail?.hero) lastRef.current = detail;
  const shown = detail?.hero ? detail : lastRef.current;
  if (!shown?.hero) return null;
  return <CenterDetailScene detail={shown} {...props} />;
}

function CenterDetailScene({ detail, active, onBack, leftPanelCollapsed = false, onToggleLeftPanel, onZoomIn }: SceneProps) {
  const hero = detail.hero!;
  const { center, telemetry, site } = detail;
  // El sondaje del sitio es la escala vertical de la escena. Un centro sin
  // levantamiento no tiene regla de profundidad, y no se le inventa una.
  const siteDepthM = site.depthM;
  const stageRef = useRef<HTMLDivElement>(null);
  const image = useMemo(() => ({ width: hero.imageWidth, height: hero.imageHeight }), [hero.imageWidth, hero.imageHeight]);
  const scene = useSceneCamera(stageRef, image, hero.focus, HEADER_SELECTOR, onZoomIn);
  const updatedLabel = useRelativeTime(telemetry.updatedAt);
  const { recenter } = scene;

  // Cada entrada al detalle parte del mismo encuadre: el centro nunca aparece "perdido".
  useEffect(() => {
    if (active) recenter(false);
  }, [active, recenter, center.id]);

  const { camera, viewport } = scene;
  // Área libre entre paneles: se mide tras el commit (el dock y su pestaña ya están en su lugar).
  const [visibleArea, setVisibleArea] = useState<ReturnType<typeof visibleStageArea> | null>(null);
  useLayoutEffect(() => {
    if (viewport && stageRef.current) setVisibleArea(visibleStageArea(stageRef.current, HEADER_SELECTOR));
  }, [viewport, leftPanelCollapsed]);
  const stageY = (depthM: number) =>
    camera && viewport && siteDepthM ? toStage(camera, viewport, image, 0, depthToImageY(hero, siteDepthM, depthM)).y : 0;
  // La franja inferior del área libre es de los controles y la línea de estado (como en el mapa).
  const inFreeArea = (y: number) => !visibleArea || (y > visibleArea.top + 10 && y < visibleArea.bottom - CONTROLS_BAND);
  const depthTicks = siteDepthM
    ? Array.from({ length: Math.floor(siteDepthM / 10) + 1 }, (_, index) => index * 10).filter((depth) => siteDepthM - depth >= 5)
    : [];
  const bearing = telemetry.current.towardBearingDeg;
  const flowLabel =
    bearing === null
      ? 'corriente sin modelo'
      : `${maybeDecimal(telemetry.current.speedMs, 2)} m/s · ${flowDirectionLabel(bearing)}`;

  return (
    <div
      ref={stageRef}
      className="center-detail-stage"
      data-dragging={scene.dragging}
      aria-hidden={!active}
      inert={!active}
      tabIndex={0}
      role="application"
      aria-roledescription="vista navegable"
      aria-label={`Vista lateral submarina de ${center.name}. Arrastra o usa las flechas para recorrerla; rueda o + y − para acercar.`}
      {...scene.bind}
    >
      {camera && viewport && (
        <CenterDetailHero
          imageSrc={hero.imageSrc}
          imageWidth={hero.imageWidth}
          imageHeight={hero.imageHeight}
          alt={hero.alt}
          title={center.name}
          subtitle={hero.caption}
          status={detail.status}
          camera={camera}
          viewport={viewport}
          calibration={hero}
          telemetry={telemetry}
          siteDepthM={siteDepthM}
          layerLineDepthM={site.layerLineDepthM}
          visibleArea={visibleArea}
          particleLayer={
            <>
              <div className="center-detail-atmosphere" aria-hidden="true" />
              <FlowParticleField
                calibration={hero}
                image={image}
                cameraRef={scene.cameraRef}
                viewportRef={scene.viewportRef}
                speedMs={telemetry.current.speedMs ?? 0}
                animate={active}
              />
            </>
          }
        />
      )}

      {/* Escala de profundidad fija al borde del área libre; sigue a la imagen en vertical. */}
      {camera && viewport && siteDepthM && (
        <div className="center-stage-depth" aria-hidden="true">
          {depthTicks.map((depth) => (
            <span key={depth} className="center-stage-depth-tick" data-occluded={!inFreeArea(stageY(depth))} style={{ top: stageY(depth) }}>
              {depth === 0 ? '0 m' : depth}
            </span>
          ))}
          <span
            className="center-stage-depth-tick is-floor"
            data-occluded={!inFreeArea(stageY(siteDepthM))}
            style={{ top: stageY(siteDepthM) }}
          >
            {Math.round(siteDepthM)} m
          </span>
        </div>
      )}

      {/*
        La línea de capa cruza toda la escena, así que su etiqueta no cabe junto a
        la escala de profundidad sin pisar los números. Vive en el borde derecho —el
        que el dock nunca ocupa— y se lee de derecha a izquierda, como la atribución
        del mapa. La línea es calibración de la escena; lo que se mide es el
        gradiente entre las dos sondas, y eso es lo que declara el texto.
      */}
      {camera && viewport && siteDepthM && site.layerLineDepthM != null && telemetry.stratification.deltaTempC !== null && (
        <div className="center-stage-layer" aria-hidden="true">
          <span
            className="center-stage-layer-tick"
            data-occluded={!inFreeArea(stageY(site.layerLineDepthM))}
            style={{ top: stageY(site.layerLineDepthM) }}
          >
            Estratificación {telemetry.stratification.state.toLowerCase()} · {stratificationNote(telemetry.stratification)}
          </span>
        </div>
      )}

      {/*
        Dos estados, un solo juego de controles: con el dock abierto sólo se
        ofrece plegarlo (flecha a la altura de sus pestañas, ya fuera del panel);
        con el dock plegado aparece el rail de la escena. Ambos quedan montados
        para que el relevo sea un fundido y no un salto.
      */}
      {onToggleLeftPanel && (
        <button
          type="button"
          className="map-pill-material center-stage-collapse"
          data-visible={!leftPanelCollapsed}
          onClick={onToggleLeftPanel}
          tabIndex={leftPanelCollapsed ? -1 : 0}
          aria-hidden={leftPanelCollapsed}
          aria-label="Ocultar panel de indicadores"
          title="Ocultar panel"
        >
          <CaretLeft size={15} weight="light" aria-hidden="true" />
        </button>
      )}

      <div className="center-stage-rail" data-visible={leftPanelCollapsed} aria-label="Acciones de la vista del centro">
        <button
          type="button"
          className="map-pill-material center-stage-rail-button"
          onClick={onBack}
          tabIndex={leftPanelCollapsed ? 0 : -1}
          aria-hidden={!leftPanelCollapsed}
          title="Volver al Mapa Vivo (Esc)"
          aria-label="Volver al Mapa Vivo"
        >
          <MapTrifold size={18} weight="light" aria-hidden="true" />
        </button>
        {onToggleLeftPanel && (
          <button
            type="button"
            className="map-pill-material center-stage-rail-button"
            onClick={onToggleLeftPanel}
            tabIndex={leftPanelCollapsed ? 0 : -1}
            aria-hidden={!leftPanelCollapsed}
            aria-label="Mostrar panel de indicadores"
            title="Mostrar indicadores"
          >
            <SidebarSimple size={17} weight="light" aria-hidden="true" />
          </button>
        )}
      </div>

      <header className="stratos-map-header center-stage-header">
        <h1 className="type-display stratos-map-title">{center.name}</h1>
        {/* Un solo KPI: qué se está viendo, en qué estado y cómo se mueve el agua. */}
        <div
          className="map-pill-material center-stage-kpi"
          data-status={detail.status}
          role="group"
          aria-label={`Vista hidrodinámica y sensórica. Estado ${CENTER_STATUS_LABEL[detail.status]}. Corriente ${flowLabel}`}
        >
          <span className="center-stage-kpi-view">Hidrodinámica y sensórica</span>
          <span className="center-stage-kpi-rule" aria-hidden="true" />
          <span className="center-stage-kpi-status">
            <span className="center-status-dot" aria-hidden="true" />
            {CENTER_STATUS_LABEL[detail.status]}
          </span>
          <span className="center-stage-kpi-rule" aria-hidden="true" />
          <span className="center-stage-kpi-flow">
            {bearing !== null && (
              <span className="center-stage-kpi-compass" style={{ '--flow-bearing': `${bearing}deg` } as CSSProperties}>
                <ArrowUp size={13} weight="bold" aria-hidden="true" />
              </span>
            )}
            <b>{maybeDecimal(telemetry.current.speedMs, 2)}</b>
            {telemetry.current.speedMs !== null && <span className="center-stage-kpi-unit">m/s</span>}
            <span className="center-stage-kpi-course">{bearing === null ? 'sin modelo' : flowDirectionLabel(bearing)}</span>
          </span>
        </div>
        <p className="center-stage-meta">
          {centerMetaLine(detail)}
          {siteDepthM ? ` · Fondo ${Math.round(siteDepthM)} m` : ''}
          <span className="center-stage-live-dot" aria-hidden="true" />
          {updatedLabel ? `Actualizado ${updatedLabel}` : `Sin lectura ${NO_VALUE}`}
        </p>
      </header>

      {/* De qué está hecha la vista: un icono por proveedor, en el borde opuesto
          al pie de partículas. La ficha se abre al posarse o al enfocar. */}
      <CenterSourceRail detail={detail} />

      {/* Sin campo del modelo las partículas quedan quietas y el pie lo dice: una
          escena que se mueve sin corriente detrás sería una animación, no un dato.
          Va al borde derecho, sobre el mismo material de píldora que los controles:
          en texto suelto la escena iluminada se lo comía. */}
      <div
        className="stratos-field-status center-stage-status map-pill-material"
        data-state={bearing === null ? 'error' : 'live'}
      >
        <span className="stratos-field-status-dot" aria-hidden="true" />
        Partículas · {bearing === null ? 'Corriente sin modelo' : `Corriente modelada · ${flowLabel}`} · Arrastra para recorrer
      </div>
    </div>
  );
}
