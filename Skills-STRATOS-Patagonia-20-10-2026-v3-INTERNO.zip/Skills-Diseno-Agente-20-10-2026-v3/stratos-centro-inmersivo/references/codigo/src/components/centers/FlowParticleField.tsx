import { useEffect, useRef } from 'react';
import type { MutableRefObject } from 'react';
import type { CenterHeroConfig } from '../../data/centers/centerDetail.types';
import { sceneSize, type SceneCamera, type Size } from '../../lib/centers/sceneCamera';
import { particleRgba } from '../../styles/stratosColors';

export interface FlowParticleFieldProps {
  calibration: Pick<CenterHeroConfig, 'waterlineY' | 'seabedY' | 'cages' | 'flowScreenDirection' | 'simulationOrigin'>;
  image: Size;
  /** Cámara de la escena: se lee por frame, sin re-render de React. */
  cameraRef: MutableRefObject<SceneCamera | null>;
  viewportRef: MutableRefObject<Size | null>;
  /** Rapidez de corriente medida (m/s): escala la velocidad visual. */
  speedMs: number;
  animate: boolean;
}

const MAX_DPR = 2;
const REFERENCE_SPEED = 0.38;
/*
 * Fracción de los RENACIMIENTOS que ocurre en el origen de simulación. La
 * población inicial no nace ahí: con un 30 % agrupado en una elipse, lo primero
 * que se veía al abrir el centro era un disco lleno de partículas.
 */
const ORIGIN_SHARE = 0.14;
const ALPHA_BUCKETS = 5;
/** Fundido de entrada del campo completo, en segundos: aparece, no salta. */
const FADE_IN_S = 1.1;

type Particle = { x: number; y: number; px: number; py: number; age: number; life: number; phase: number };

/**
 * Trazadores hidrodinámicos sobre toda la columna de agua de la escena. Simula en
 * coordenadas de imagen (0–1) y dibuja con la cámara actual: el campo cubre todo lo
 * que el usuario recorre, no un recuadro. Visual, no un modelo.
 */
export function FlowParticleField({ calibration, image, cameraRef, viewportRef, speedMs, animate }: FlowParticleFieldProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const { waterlineY, seabedY, cages, flowScreenDirection: dir, simulationOrigin } = calibration;
    const top = waterlineY + 0.008;
    const bottom = seabedY - 0.02;
    const speedScale = Math.min(1.6, Math.max(0.35, speedMs / REFERENCE_SPEED));
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let dpr = 1;
    let particles: Particle[] = [];
    const buckets: Particle[][] = Array.from({ length: ALPHA_BUCKETS }, () => []);
    let frame = 0;
    let last = 0;
    let lastCameraKey = '';
    let sinceSeed = 0;

    const gaussian = () => (Math.random() + Math.random() + Math.random() - 1.5) / 1.5;

    const spawn = (initial: boolean): Particle => {
      let x: number;
      let y: number;
      if (!initial && Math.random() < ORIGIN_SHARE) {
        // Pluma, no disco: el nacimiento se estira aguas abajo del origen, que es
        // la forma que toma un trazador liberado en una corriente.
        x = simulationOrigin.x + Math.random() * 0.06 * dir + gaussian() * 0.008;
        y = simulationOrigin.y + gaussian() * 0.05;
      } else {
        // Nacimiento repartido en toda la sección: el campo cruza la escena completa.
        x = Math.random() * 1.04 - 0.02;
        y = top + Math.pow(Math.random(), 1.25) * (bottom - top);
      }
      y = Math.min(bottom, Math.max(top, y));
      const life = 4 + Math.random() * 6;
      /*
       * La edad inicial se reparte DENTRO de la vida de cada partícula. Antes era
       * «0–6 s» contra vidas de 4–10 s: un tercio moría en el primer fotograma y
       * renacía a la vez, y esa cohorte sincronizada avanzaba como una segunda
       * oleada ordenada.
       */
      return { x, y, px: x, py: y, age: initial ? Math.random() * life : 0, life, phase: Math.random() * Math.PI * 2 };
    };

    /*
     * Resultado reutilizado: `velocity` corre por partícula en cada fotograma y
     * devolver un objeto nuevo alimentaba al recolector de basura. La matemática
     * no cambia; sólo dónde se deja el resultado.
     */
    const flow = { vx: 0, vy: 0 };
    const velocity = (x: number, y: number, phase: number, time: number) => {
      const depth = (y - waterlineY) / (seabedY - waterlineY);
      // Perfil vertical: la capa superficial manda; capa límite junto al fondo.
      let speed = (0.35 + 0.85 * Math.pow(1 - depth, 1.3)) * 0.03 * speedScale;
      if (depth > 0.88) speed *= 0.45;
      let wobble = 0.0022;
      for (const [x0, x1, cageBottom] of cages) {
        if (x < x0 - 0.008 || x > x1 + 0.008) continue;
        if (y < cageBottom) {
          speed *= 0.55; // arrastre de la red
          wobble = 0.0045;
        } else if (y < cageBottom + 0.06) {
          speed *= 1.2; // aceleración bajo la red
        }
        break;
      }
      flow.vx = speed * dir;
      flow.vy = Math.sin(x * 22 + phase + time * 0.5) * wobble;
      return flow;
    };

    const resize = () => {
      const vp = viewportRef.current;
      const rect = canvas.getBoundingClientRect();
      const width = vp?.width ?? rect.width;
      const height = vp?.height ?? rect.height;
      dpr = Math.min(MAX_DPR, window.devicePixelRatio || 1);
      canvas.width = Math.max(1, Math.round(width * dpr));
      canvas.height = Math.max(1, Math.round(height * dpr));
      // Densidad por superficie de agua visible a zoom 1: cobertura amplia sin saturar.
      const water = sceneSize({ width, height }, image, 1);
      const count = Math.round(Math.min(3200, Math.max(900, (water.width * water.height * (bottom - top)) / 640)));
      /*
       * Un cambio de tamaño ajusta la cantidad, no resiembra. La entrada animada
       * del panel dispara varios resize seguidos, y cada uno recreaba el campo
       * entero: se veía aparecer varias veces.
       */
      if (particles.length === 0) sinceSeed = 0;
      if (count > particles.length) {
        for (let index = particles.length; index < count; index++) particles.push(spawn(true));
      } else {
        particles.length = count;
      }
      lastCameraKey = '';
    };

    const project = (camera: SceneCamera, vp: Size) => {
      const size = sceneSize(vp, image, camera.zoom);
      return (x: number, y: number) => [camera.tx + x * size.width, camera.ty + y * size.height] as const;
    };

    const drawStatic = () => {
      const camera = cameraRef.current;
      const vp = viewportRef.current;
      if (!camera || !vp) return;
      const toStage = project(camera, vp);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, vp.width, vp.height);
      ctx.lineWidth = 1;
      ctx.strokeStyle = particleRgba(0.28);
      for (let line = 0; line < 26; line++) {
        let x = dir > 0 ? 0 : 1;
        let y = top + ((line + 0.5) / 26) * (bottom - top);
        ctx.beginPath();
        ctx.moveTo(...toStage(x, y));
        for (let step = 0; step < 160 && x >= 0 && x <= 1; step++) {
          const { vx, vy } = velocity(x, y, line * 1.7, 0);
          x += Math.sign(vx) * 0.0065;
          y += (vy / Math.abs(vx || 1)) * 0.0065;
          ctx.lineTo(...toStage(x, y));
        }
        ctx.stroke();
      }
    };

    const tick = (timestamp: number) => {
      frame = requestAnimationFrame(tick);
      const camera = cameraRef.current;
      const vp = viewportRef.current;
      if (!camera || !vp) return;
      const dt = Math.min(0.05, last ? (timestamp - last) / 1000 : 0.016);
      last = timestamp;
      const time = timestamp / 1000;
      sinceSeed += dt;
      const fade = Math.min(1, sinceSeed / FADE_IN_S);

      // Si la cámara se movió, las estelas viejas quedarían desfasadas: se limpian.
      const cameraKey = `${camera.zoom.toFixed(4)}|${camera.tx.toFixed(1)}|${camera.ty.toFixed(1)}|${vp.width}|${vp.height}`;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      if (cameraKey !== lastCameraKey) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        lastCameraKey = cameraKey;
      } else {
        ctx.globalCompositeOperation = 'destination-out';
        ctx.fillStyle = `rgba(0, 0, 0, ${1 - Math.pow(0.94, dt * 60)})`;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.globalCompositeOperation = 'source-over';
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.lineCap = 'round';
      ctx.lineWidth = Math.min(2.2, 1.35 + (camera.zoom - 1) * 0.5);

      for (const bucket of buckets) bucket.length = 0;
      for (let index = 0; index < particles.length; index++) {
        const particle = particles[index];
        particle.age += dt;
        if (particle.age > particle.life || particle.x < -0.03 || particle.x > 1.03 || particle.y < top || particle.y > bottom) {
          particles[index] = spawn(false);
          continue;
        }
        particle.px = particle.x;
        particle.py = particle.y;
        const { vx, vy } = velocity(particle.x, particle.y, particle.phase, time);
        particle.x += vx * dt;
        particle.y += vy * dt;
        const life = particle.age / particle.life;
        const envelope = life < 0.15 ? life / 0.15 : 1 - (life - 0.15) / 0.85;
        buckets[Math.min(ALPHA_BUCKETS - 1, Math.floor(envelope * ALPHA_BUCKETS))].push(particle);
      }

      // Misma proyección que `toStage`, sin una tupla por extremo de trazo.
      const size = sceneSize(vp, image, camera.zoom);
      buckets.forEach((bucket, level) => {
        if (!bucket.length) return;
        // Opacidad media: trazadores legibles sobre el agua, nunca confeti.
        ctx.strokeStyle = particleRgba((0.14 + level * 0.12) * fade);
        ctx.beginPath();
        for (const particle of bucket) {
          const fx = camera.tx + particle.px * size.width;
          const fy = camera.ty + particle.py * size.height;
          const tx = camera.tx + particle.x * size.width;
          const ty = camera.ty + particle.y * size.height;
          if ((fx < -20 && tx < -20) || (fx > vp.width + 20 && tx > vp.width + 20) || fy < -20 || fy > vp.height + 20) continue;
          ctx.moveTo(fx, fy);
          ctx.lineTo(tx + 0.01, ty);
        }
        ctx.stroke();
      });
    };

    // Sin movimiento: trazos estáticos, redibujados sólo cuando la cámara cambia.
    const staticLoop = () => {
      frame = requestAnimationFrame(staticLoop);
      const camera = cameraRef.current;
      const vp = viewportRef.current;
      if (!camera || !vp) return;
      const cameraKey = `${camera.zoom.toFixed(4)}|${camera.tx.toFixed(1)}|${camera.ty.toFixed(1)}|${vp.width}|${vp.height}`;
      if (cameraKey === lastCameraKey) return;
      lastCameraKey = cameraKey;
      drawStatic();
    };

    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    resize();
    if (animate) frame = requestAnimationFrame(reducedMotion ? staticLoop : tick);

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, [animate, speedMs, calibration, image, cameraRef, viewportRef]);

  return <canvas ref={canvasRef} className="center-flow-field" aria-hidden="true" />;
}
