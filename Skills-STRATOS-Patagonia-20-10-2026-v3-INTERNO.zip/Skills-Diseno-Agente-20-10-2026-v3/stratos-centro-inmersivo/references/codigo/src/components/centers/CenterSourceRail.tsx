import { useState } from 'react';
import type { CenterDetail } from '../../data/centers/centerDetail.types';
import { useRelativeTime } from '../../hooks/useCenterDetail';
import { centerSources, distanceLabel, type CenterSource } from '../../lib/centers/centerSources';
import { GlassCard } from '../molecules/stratos';

export interface CenterSourceRailProps {
  detail: CenterDetail;
}

/**
 * De qué está hecha esta vista: un icono por proveedor, y al posarse encima la
 * ficha con lo que entrega, a qué distancia mide y de cuándo es su último dato.
 *
 * Va en la escena y no en un panel porque la pregunta «¿de dónde sale esto?»
 * aparece mirando el número, no navegando. El teclado llega igual: cada icono es
 * un botón y el foco abre la misma ficha que el puntero.
 */
export function CenterSourceRail({ detail }: CenterSourceRailProps) {
  const sources = centerSources(detail);
  const [openId, setOpenId] = useState<string | null>(null);

  return (
    <div className="center-source-rail" aria-label="Fuentes de datos de esta vista">
      {sources.map((source) => (
        <div
          key={source.id}
          className="center-source-slot"
          onMouseEnter={() => setOpenId(source.id)}
          onMouseLeave={() => setOpenId((current) => (current === source.id ? null : current))}
        >
          <button
            type="button"
            className="map-pill-material center-source-button"
            data-live={source.live}
            aria-expanded={openId === source.id}
            aria-label={`${source.label} · ${source.kind}${source.live ? '' : ' · sin dato'}`}
            onFocus={() => setOpenId(source.id)}
            onBlur={() => setOpenId((current) => (current === source.id ? null : current))}
            onClick={() => setOpenId((current) => (current === source.id ? null : source.id))}
          >
            <source.icon size={17} weight="light" aria-hidden="true" />
          </button>
          {openId === source.id && <SourceCard source={source} />}
        </div>
      ))}
    </div>
  );
}

function SourceCard({ source }: { source: CenterSource }) {
  const updated = useRelativeTime(source.updatedAt);
  const distance = distanceLabel(source.distanceKm);

  return (
    // El posicionado va en un envoltorio propio: `GlassCard` compone superficie y
    // esquina continua, y darle además la posición mezcla dos responsabilidades.
    <div className="center-source-pop" role="tooltip">
      <GlassCard variant="floating" corner="medium" className="center-source-card">
        <header className="center-source-card-head">
          <span className="center-source-card-title">{source.label}</span>
          <span className="center-source-card-kind" data-kind={source.kind}>
            {source.kind}
          </span>
        </header>
        <p className="center-source-card-provider">{source.provider}</p>

        <ul className="center-source-card-vars" aria-label="Variables que entrega">
          {source.variables.length > 0 ? (
            source.variables.map((variable) => <li key={variable}>{variable}</li>)
          ) : (
            <li data-empty="true">Sin variables reportando</li>
          )}
        </ul>

        <dl className="center-source-card-facts">
          <div>
            <dt>Distancia</dt>
            {/* Una fuente de campo no tiene distancia: cubre el punto, no se acerca a él. */}
            <dd>{distance ?? '—'}</dd>
          </div>
          <div>
            <dt>Actualizado</dt>
            <dd>{updated || '—'}</dd>
          </div>
        </dl>

        {source.caveat && <p className="center-source-card-caveat">{source.caveat}</p>}
      </GlassCard>
    </div>
  );
}
