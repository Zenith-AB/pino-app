import type { ReactNode } from 'react';
import type { CenterHeroConfig, CenterStatus, CenterTelemetry, HeroProbe } from '../../data/centers/centerDetail.types';
import { sceneSize, type SceneCamera, type Size } from '../../lib/centers/sceneCamera';
import { CENTER_STATUS_LABEL, maybeDecimal } from '../../lib/centers/sensorKpis';
import { variableIcon } from '../../lib/variables/variableIcons';

export type HeroCalibration = Pick<
  CenterHeroConfig,
  'waterlineY' | 'seabedY' | 'cages' | 'flowScreenDirection' | 'probes' | 'simulationOrigin' | 'focus'
>;

export interface CenterDetailHeroProps {
  /** Vista lateral submarina del centro: fondo principal del stage, a sangre. */
  imageSrc: string;
  imageWidth: number;
  imageHeight: number;
  alt: string;
  title: string;
  subtitle?: string;
  status?: CenterStatus;
  updatedAt?: string;
  /** Cámara actual y tamaño del stage: la escena se posiciona con ellos. */
  camera: SceneCamera;
  viewport: Size;
  /** Calibración de la imagen; sin ella se muestra la escena sin anclas técnicas. */
  calibration?: HeroCalibration;
  telemetry?: CenterTelemetry;
  /** Sondaje del sitio: la escala que convierte metros en altura de imagen. */
  siteDepthM?: number | null;
  /** Profundidad de la línea punteada de capa. Calibración de escena, no medición. */
  layerLineDepthM?: number | null;
  /** Capa a sangre dibujada entre la imagen y las anclas (p. ej. partículas). */
  particleLayer?: ReactNode;
  /** Área libre entre paneles (px del stage): una etiqueta fuera de ella se retira. */
  visibleArea?: { left: number; right: number; top: number; bottom: number } | null;
}

/** Margen para que una etiqueta no quede cortada bajo el borde de un panel. */
const LABEL_ROOM = { left: 8, right: 150, top: 12, bottom: 84 };

/**
 * Lectura que cuelga de una sonda de la escena.
 *
 * La profundidad sale de la propia lectura —es la de la sonda que la midió—, no
 * de un número decorativo: una tarjeta puesta a 3 m cuando el sensor está a 5 m
 * dibuja una columna que no existe. El icono es el de la variable en el
 * vocabulario común (`lib/variables/variableIcons`), el mismo que usa la tabla de
 * modelos: la tarjeta dice qué se mide antes de que se lea la cifra.
 *
 * `null` = la fuente no declara profundidad y la tarjeta no se puede anclar.
 */
export function probeReading(probe: HeroProbe, telemetry: CenterTelemetry) {
  const chip = (
    variableCode: string,
    label: string,
    reading: CenterTelemetry['surfaceTemperatureC'],
    unit: string,
    digits = 1,
  ) =>
    reading.depthM == null
      ? null
      : {
          label,
          value: maybeDecimal(reading.value, digits),
          unit: reading.unit || unit,
          depthM: reading.depthM,
          Icon: variableIcon(variableCode),
        };

  switch (probe.reading) {
    case 'surfaceTemperature':
      return chip('water_temperature', 'Temperatura', telemetry.surfaceTemperatureC, '°C');
    case 'depthTemperature':
      return chip('water_temperature', 'Temperatura', telemetry.depthTemperatureC, '°C');
    case 'dissolvedOxygen':
      return chip('oxygen_conc', 'Oxígeno', telemetry.dissolvedOxygenMgL, 'mg/L', 2);
    case 'chlorophyll':
      return chip('fluorescence', 'Clorofila-a', telemetry.chlorophyllUgL, 'mg/m³', 2);
    case 'salinity':
      return chip('salinity', 'Salinidad', telemetry.salinityPsu, 'PSU');
    case 'turbidity':
      return chip('turbidity', 'Turbidez', telemetry.turbidityNtu, 'NTU', 2);
  }
}

/** Profundidad real (m) → y normalizada sobre la imagen. */
export function depthToImageY(calibration: Pick<CenterHeroConfig, 'waterlineY' | 'seabedY'>, siteDepthM: number, depthM: number) {
  return calibration.waterlineY + (depthM / siteDepthM) * (calibration.seabedY - calibration.waterlineY);
}

const percent = (value: number) => `${(value * 100).toFixed(3)}%`;

/**
 * La escena del centro: imagen lateral a sangre, del tamaño que dicta la cámara, con
 * las anclas que viven en el agua (sondas, termoclina, origen de simulación). Todo lo
 * anclado se mueve con la imagen al recorrerla.
 */
export function CenterDetailHero({
  imageSrc,
  imageWidth,
  imageHeight,
  alt,
  title,
  subtitle,
  status,
  camera,
  viewport,
  calibration,
  telemetry,
  siteDepthM,
  layerLineDepthM,
  particleLayer,
  visibleArea,
}: CenterDetailHeroProps) {
  const size = sceneSize(viewport, { width: imageWidth, height: imageHeight }, camera.zoom);
  // Sin sondaje no hay escala de profundidad: las anclas del agua no se pueden
  // ubicar y la escena se muestra sin ellas antes que en un sitio inventado.
  const layers = calibration && telemetry && siteDepthM ? { calibration, telemetry, siteDepthM } : null;
  const occluded = (x: number, y: number) => {
    if (!visibleArea) return false;
    const sx = camera.tx + x * size.width;
    const sy = camera.ty + y * size.height;
    return (
      sx < visibleArea.left + LABEL_ROOM.left ||
      sx > visibleArea.right - LABEL_ROOM.right ||
      sy < visibleArea.top + LABEL_ROOM.top ||
      sy > visibleArea.bottom - LABEL_ROOM.bottom
    );
  };
  const frame = { width: size.width, height: size.height, transform: `translate3d(${camera.tx}px, ${camera.ty}px, 0)` };

  return (
    <>
      <figure className="center-scene" style={frame}>
        <img className="center-scene-image" src={imageSrc} width={imageWidth} height={imageHeight} alt={alt} decoding="async" draggable={false} />
        <figcaption className="sr-only">
          {title}
          {subtitle ? ` · ${subtitle}` : ''}
          {status ? ` · ${CENTER_STATUS_LABEL[status]}` : ''}
        </figcaption>
      </figure>

      {/* Entre la imagen y las anclas: el campo de partículas (sobre el agua, bajo las etiquetas). */}
      {particleLayer}

      {layers && (
        <div className="center-scene center-scene-anchors" style={frame}>
          {/* Límite de capa dibujado: calibración de la escena, no una termoclina medida. */}
          {layerLineDepthM != null && (
            <div
              className="center-scene-thermocline"
              style={{ top: percent(depthToImageY(layers.calibration, layers.siteDepthM, layerLineDepthM)) }}
              aria-hidden="true"
            />
          )}

          <div
            className="center-scene-origin"
            data-occluded={occluded(layers.calibration.simulationOrigin.x, layers.calibration.simulationOrigin.y)}
            style={{ left: percent(layers.calibration.simulationOrigin.x), top: percent(layers.calibration.simulationOrigin.y) }}
          >
            <span className="stratos-emitter" aria-hidden="true" />
            <span className="center-scene-chip">Origen de simulación</span>
          </div>

          <ul className="center-scene-probes" aria-label="Sondas del centro">
            {layers.calibration.probes.map((probe) => {
              const reading = probeReading(probe, layers.telemetry);
              // Una sonda más honda que el fondo de la escena —la de 60 m de la boya
              // sobre un sitio de 42 m— no se dibuja: no hay dónde ponerla sin mentir.
              if (!reading || reading.depthM > layers.siteDepthM) return null;
              const y = depthToImageY(layers.calibration, layers.siteDepthM, reading.depthM);
              return (
                <li
                  key={probe.reading}
                  className="center-scene-probe"
                  data-occluded={occluded(probe.x, y)}
                  style={{ left: percent(probe.x), top: percent(y) }}
                >
                  {/* Guía fina desde el punto medido hasta la tarjeta: el mismo
                      recurso que la escala de profundidad, sin punto luminoso. */}
                  <span className="center-scene-probe-lead" aria-hidden="true" />
                  <span className="center-scene-chip">
                    <reading.Icon className="center-scene-chip-icon" size={14} weight="light" aria-hidden="true" />
                    <span className="center-scene-chip-body">
                      <span className="center-scene-chip-label">{reading.label}</span>
                      <span className="center-scene-chip-reading">
                        <span className="center-scene-chip-value">{reading.value}</span>
                        <span className="center-scene-chip-unit">{reading.unit}</span>
                      </span>
                    </span>
                    <span className="center-scene-chip-meta">{Math.round(reading.depthM)} m</span>
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </>
  );
}
