import { ArrowUp, Triangle } from '@phosphor-icons/react';
import type { SensorKpi } from '../../lib/centers/sensorKpis';

export interface SensorKpiGridProps {
  kpis: SensorKpi[];
  label?: string;
  className?: string;
}

const TONE_LABEL = { normal: '', watch: 'en vigilancia', critical: 'crítico' } as const;

/**
 * Grid de KPIs sensóricos. La cifra va a la derecha de su etiqueta, en la misma
 * línea: apiladas, el valor empujaba hacia abajo todo lo demás y la tarjeta sólo
 * tenía sitio para una cosa más, así que la procedencia se caía cada vez que
 * había tendencia. En dos columnas caben las tres: de dónde sale el número, cómo
 * se movió en 24 h y qué dice la sonda profunda de la misma boya.
 */
export function SensorKpiGrid({ kpis, label = 'Indicadores sensóricos y ambientales', className = '' }: SensorKpiGridProps) {
  return (
    <ul className={`sensor-kpi-grid ${className}`} aria-label={label}>
      {kpis.map((kpi) => (
        <li key={kpi.id} className="sensor-kpi" data-tone={kpi.tone}>
          <span className="sensor-kpi-head">
            <span className="sensor-kpi-label">
              <span className="sensor-kpi-label-text">{kpi.label}</span>
              {kpi.tone !== 'normal' && (
                <span className="sensor-kpi-flag" role="img" aria-label={TONE_LABEL[kpi.tone]} title={TONE_LABEL[kpi.tone]} />
              )}
            </span>

            <span className="sensor-kpi-value type-numeric">
              {kpi.bearingDeg !== undefined && (
                <ArrowUp className="sensor-kpi-bearing" size={15} weight="light" aria-hidden="true" style={{ transform: `rotate(${kpi.bearingDeg}deg)` }} />
              )}
              <span className="sensor-kpi-number">{kpi.value}</span>
              {kpi.unit && <span className="sensor-kpi-unit">{kpi.unit}</span>}
            </span>
          </span>

          {(kpi.context || kpi.trend) && (
            <span className="sensor-kpi-foot type-numeric">
              <span className="sensor-kpi-context">{kpi.context}</span>
              {kpi.trend && (
                <span className={`sensor-kpi-trend is-${kpi.trend.direction}`}>
                  {kpi.trend.direction !== 'flat' && <Triangle size={7} weight="fill" aria-hidden="true" />}
                  {kpi.trend.label}
                </span>
              )}
            </span>
          )}

          {/* Misma variable, sonda profunda: la cifra de arriba es la superficie. */}
          {kpi.deep && (
            <span className="sensor-kpi-deep type-numeric">
              <span className="sensor-kpi-deep-label">{kpi.deep.label}</span>
              <span className="sensor-kpi-deep-value">
                {kpi.deep.value}
                {kpi.deep.unit && <span className="sensor-kpi-deep-unit">{kpi.deep.unit}</span>}
              </span>
            </span>
          )}
        </li>
      ))}
    </ul>
  );
}
