import { useEffect, useRef } from 'react';
import { MAP_TIP_CLASS, mapTip } from '../markers/mapTip';
import L from 'leaflet';
import { markerDivIcon } from '../markers/MapMarker';
import { fromPointState } from '../markers/markerState';
import type { CultivationCenter } from '../../../data/stratosTypes';
import type { HoverHandlers } from '../hoverTypes';
import { useStratosMap } from '../StratosMapContext';

export interface CenterMarkerProps extends HoverHandlers {
  center: CultivationCenter;
  pane: string;
  /** Centro en foco: halo, escala y borde definido sin cambiar de identidad (`farm`). */
  selected: boolean;
  onClick: (center: CultivationCenter) => void;
  linkedSensors?: number;
}

// Algo mayor que las boyas (30): es la entidad que se consulta. Con disco sólido,
// más de 32 px tapa la costa en la que está fondeado.
const MARKER_SIZE = 32;

/** Marcador de un centro de cultivo. El estado activo se aplica sin recrear el marcador. */
export function CenterMarker({ center, pane, selected, onClick, linkedSensors = 0 }: CenterMarkerProps) {
  const { map } = useStratosMap();
  const markerRef = useRef<L.Marker | null>(null);
  const handlersRef = useRef({ onClick, selected });
  handlersRef.current = { onClick, selected };

  useEffect(() => {
    const marker = L.marker([center.lat, center.lng], {
      pane,
      keyboard: true,
      alt: center.name,
      riseOnHover: true,
      // El glifo de jaulas dice que es infraestructura de cultivo; el estado, aparte,
      // dice cómo está. Antes era un disco de color sin símbolo: sólo el tono lo
      // distinguía de cualquier otro punto, y el tono ya significaba otra cosa.
      icon: markerDivIcon({
        kind: 'aquaculture_center',
        state: fromPointState(center.state),
        selected: handlersRef.current.selected,
        size: MARKER_SIZE,
        label: center.name,
      }),
    })
      // El hover sólo declara identidad legal y cobertura, nunca riesgo estático.
      .bindTooltip(() => mapTip({
        title: center.name,
        meta: [center.concessionId ? `Concesión ${center.concessionId}` : 'Centro de cultivo', linkedSensors ? `${linkedSensors} ${linkedSensors === 1 ? 'boya' : 'boyas'}` : null].filter(Boolean).join(' · '),
      }), { direction: 'top', offset: [0, -20], className: MAP_TIP_CLASS })
      .on('click', () => {
        handlersRef.current.onClick(center);
      })
      .addTo(map);
    markerRef.current = marker;
    return () => {
      marker.remove();
      markerRef.current = null;
    };
  }, [map, center, pane, linkedSensors]);

  useEffect(() => {
    const marker = markerRef.current;
    if (!marker) return;
    const body = marker.getElement()?.querySelector('.stratos-map-marker');
    if (selected) body?.setAttribute('data-selected', '');
    else body?.removeAttribute('data-selected');
    marker.setZIndexOffset(selected ? 1000 : 0);
  }, [selected, center, pane]);

  return null;
}
