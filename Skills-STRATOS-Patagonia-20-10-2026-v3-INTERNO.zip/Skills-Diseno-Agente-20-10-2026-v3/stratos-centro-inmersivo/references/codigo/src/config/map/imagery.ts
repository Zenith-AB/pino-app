// Imagen de detalle. Cada URL proviene de un servicio real: nunca se construye a mano.

import type { HighResolutionImageryScene } from './types.ts';

/**
 * Detalle submétrico global — Esri World Imagery.
 *
 * El visor de OpenAerialMap muestra en el mar interior su basemap "Mapbox Satellite"
 * (OAM no tiene escenas propias aquí). En Chiloé y el Seno de Reloncaví esa imagen es la
 * misma captura Vantor Vivid (0.34 m, 2025-12 a 2026-03) que sirve Esri: Dalcahue,
 * Castro, Calbuco, Ancud, Hornopirén, Quemchi y Caleta La Arena verificados con el
 * servicio `identify` (2026-09-13). Nativo hasta z18; por encima se reescala.
 */
export const GLOBAL_DETAIL_IMAGERY: HighResolutionImageryScene = {
  id: 'esri-world-imagery',
  name: 'Detalle submétrico',
  provider: 'Esri World Imagery',
  bounds: [-180, -85, 180, 85],
  tilesUrl: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  tileSize: 256,
  minZoom: 11,
  maxNativeZoom: 18,
  maxZoom: 21,
  attribution: '© Esri, Vantor, Earthstar Geographics',
  // El overlay de detalle se integra con el mapa base de la misma fuente.
  opacityStops: [
    [11, 0],
    [12, 1],
  ],
};

export const BASE_LAYER_OPTIONS = [
  {
    id: 'satelital',
    label: 'Mapa Satelital',
    detail: 'Esri World Imagery · detalle desde zoom 12',
  },
  {
    id: 'oscuro',
    label: 'Mapa Oscuro',
    detail: 'Esri Dark Gray',
  },
] as const;

export const HIGH_RESOLUTION_SCENES: Record<string, HighResolutionImageryScene> = {
  [GLOBAL_DETAIL_IMAGERY.id]: GLOBAL_DETAIL_IMAGERY,
};

export const DEFAULT_HIGH_RESOLUTION_SCENE_ID = GLOBAL_DETAIL_IMAGERY.id;

export function getHighResolutionScene(id: string | undefined) {
  return id ? HIGH_RESOLUTION_SCENES[id] ?? null : null;
}
