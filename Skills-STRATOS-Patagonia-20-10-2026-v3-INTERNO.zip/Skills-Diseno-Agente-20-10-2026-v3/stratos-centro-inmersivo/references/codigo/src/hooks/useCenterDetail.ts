import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';

import type { RiverDischarge, SourceResult } from '@datasource';
import type { CenterDetail, CenterTelemetry } from '../data/centers/centerDetail.types';
import type { CultivationCenter } from '../data/stratosTypes';
import { chonosCenterDetailSource } from '../lib/centers/chonosCenterDetailSource';
import type { CenterDetailSource } from '../lib/centers/centerDetailSource';
import { relativeTimeLabel } from '../lib/centers/sensorKpis';
import { waterColumnFrom } from '../lib/centers/sensorTelemetry';
import { DEFAULT_SENSOR_WINDOW_HOURS } from '../lib/sensors/sensorNetworkStore';
import { sensorNetworkStore } from './useSensorNetwork';

/**
 * Centros cuyo forzante continental relevante es el cauce que ya carga el panel.
 * El Puelo descarga en el estuario de Reloncaví; el Seno de Comau, 70 km al sur,
 * tiene su propia cuenca y ese caudal no lo describe.
 */
const PUELO_CENTERS = new Set(['reloncavi']);

/** Ventana de las sondas: la misma que la red mantiene al día desde el arranque. */
const WINDOW_HOURS = DEFAULT_SENSOR_WINDOW_HOURS;

/** Lo que el detalle necesita y que ya está cargado en otra parte del tablero. */
export interface CenterDetailFeeds {
  /** Caudal GloFAS del cauce principal, tal como lo trae `useCenterKpis`. */
  river?: SourceResult<RiverDischarge> | null;
  /** Favorabilidad FAN publicada para ESTE centro, o null si el pronóstico es de otro. */
  fan?: CenterTelemetry['fanFavorability'];
}

/**
 * Detalle del centro en foco: escena y sitio de `chonosCenterDetailSource`,
 * telemetría de las fuentes reales.
 *
 * La columna de agua sale de la red de sondas que ya se mantiene al día en
 * segundo plano, así que abrir un centro no dispara ninguna carga nueva; la
 * corriente es CHONOS/MOSA; el caudal y la favorabilidad FAN llegan del tablero.
 * Devuelve null hasta que la escena del centro pedido está resuelta: nunca datos
 * de un centro bajo el nombre de otro.
 */
export function useCenterDetail(
  center: CultivationCenter | null,
  feeds: CenterDetailFeeds = {},
  source: CenterDetailSource = chonosCenterDetailSource,
) {
  const [detail, setDetail] = useState<CenterDetail | null>(null);

  useEffect(() => {
    if (!center) {
      setDetail(null);
      return;
    }
    const controller = new AbortController();
    source
      .load(center, controller.signal)
      .then((next) => {
        if (!controller.signal.aborted) setDetail(next);
      })
      .catch((error) => {
        if (!controller.signal.aborted) console.warn('[STRATOS:centerDetail]', error);
      });
    return () => controller.abort();
  }, [center, source]);

  const network = useSyncExternalStore(
    sensorNetworkStore.subscribe,
    () => sensorNetworkStore.getSnapshot(WINDOW_HOURS),
    () => sensorNetworkStore.getSnapshot(WINDOW_HOURS),
  );
  // Sólo la ventana de 72 h describe este detalle; otra ventana cargada no la reemplaza.
  const sensors = useMemo(() => {
    if (!center || network.shownHours !== WINDOW_HOURS) return null;
    return network.centers.find((result) => result.data?.center.id === center.id) ?? null;
  }, [center, network.shownHours, network.centers]);

  const { river, fan } = feeds;

  return useMemo(() => {
    if (!detail || !center || detail.center.id !== center.id) return null;
    const column = waterColumnFrom(sensors);
    const discharge = PUELO_CENTERS.has(center.id) ? river?.data ?? null : null;

    const telemetry: CenterTelemetry = {
      ...detail.telemetry,
      updatedAt: column.updatedAt,
      provenance: column.provenance,
      columnSource: column.columnSource,
      buoy: column.buoy,
      columnVariables: column.variables,
      surfaceTemperatureC: column.surfaceTemperatureC,
      depthTemperatureC: column.depthTemperatureC,
      salinityPsu: column.salinityPsu,
      dissolvedOxygenMgL: column.dissolvedOxygenMgL,
      chlorophyllUgL: column.chlorophyllUgL,
      turbidityNtu: column.turbidityNtu,
      stratification: column.stratification,
      fanFavorability: fan ?? null,
      continentalForcing:
        discharge?.latest?.value != null
          ? {
              source: discharge.riverName,
              // GloFAS es un modelo global, no un aforo: el nombre del organismo
              // que sí afora le daría a la cifra una autoridad que no tiene.
              model: 'GloFAS',
              dischargeM3s: discharge.latest.value,
              changePct: discharge.weeklyChangePct,
              at: discharge.latest.date ?? null,
            }
          : null,
    };

    return { ...detail, sensors: column.probeCount, telemetry };
  }, [detail, center, sensors, river, fan]);
}

/** "hace 8 min", refrescado cada 30 s. */
export function useRelativeTime(iso: string | null | undefined) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!iso) return;
    setNow(Date.now());
    const timer = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(timer);
  }, [iso]);
  return iso ? relativeTimeLabel(iso, now) : '';
}
