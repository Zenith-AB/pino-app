import { useCallback, useEffect, useMemo, useReducer } from 'react';
import { centerSelectionReducer, INITIAL_CENTER_SELECTION, stageModeOf } from '../lib/centers/centerSelectionState';

/** Centro en foco + modo del stage central (`overview` | `center-detail`), con Esc como salida. */
export function useCenterSelectionState() {
  const [state, dispatch] = useReducer(centerSelectionReducer, INITIAL_CENTER_SELECTION);

  const clickCenter = useCallback(
    (centerId: string, isClose: boolean) => dispatch({ type: 'centerClicked', centerId, isClose }),
    [],
  );
  /** "Llévame a este centro": lo enfoca y pide encuadre, esté o no ya seleccionado. */
  const focusCenter = useCallback((centerId: string) => dispatch({ type: 'focusCenter', centerId }), []);
  const openDetail = useCallback((centerId: string) => dispatch({ type: 'openDetail', centerId }), []);
  const closeDetail = useCallback(() => dispatch({ type: 'closeDetail' }), []);
  const clearCenter = useCallback(() => dispatch({ type: 'clear' }), []);

  const active = state.selectedId !== null;
  useEffect(() => {
    if (!active) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape' || event.defaultPrevented) return;
      // Esc dentro de un campo o menú lo resuelve ese control.
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, [role="listbox"], [role="menu"]')) return;
      dispatch({ type: 'escape' });
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [active]);

  return useMemo(
    () => ({
      ...state,
      stageMode: stageModeOf(state),
      clickCenter,
      focusCenter,
      openDetail,
      closeDetail,
      clearCenter,
    }),
    [state, clickCenter, focusCenter, openDetail, closeDetail, clearCenter],
  );
}

export type CenterSelectionController = ReturnType<typeof useCenterSelectionState>;
