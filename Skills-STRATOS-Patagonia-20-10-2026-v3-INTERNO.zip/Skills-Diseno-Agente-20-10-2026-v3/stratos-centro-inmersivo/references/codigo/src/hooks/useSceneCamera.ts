import { useCallback, useEffect, useRef, useState } from 'react';
import type { KeyboardEvent, PointerEvent, RefObject } from 'react';
import {
  clampCamera,
  focusCamera,
  interpolateCamera,
  panBy,
  zoomAt,
  type SceneCamera,
  type Size,
} from '../lib/centers/sceneCamera';
import { visibleStageArea } from '../lib/layout/visibleStageArea';

const FRICTION = 0.9;
const KEY_STEP = 90;

/**
 * Navegación de la vista de detalle: arrastre con inercia, rueda con zoom al cursor,
 * teclado y controles animados. La cámara vive en un ref para los renders por frame
 * (partículas) y en estado para el DOM (imagen y anclas).
 */
export function useSceneCamera(
  containerRef: RefObject<HTMLElement | null>,
  image: Size,
  focus: { x: number; y: number },
  headerSelector?: string,
  /** El usuario acercó la vista (rueda, teclado o control): p. ej. para despejar paneles. */
  onZoomIn?: () => void,
) {
  const onZoomInRef = useRef(onZoomIn);
  onZoomInRef.current = onZoomIn;
  const [viewport, setViewport] = useState<Size | null>(null);
  const [camera, setCameraState] = useState<SceneCamera | null>(null);
  const [dragging, setDragging] = useState(false);
  const cameraRef = useRef<SceneCamera | null>(null);
  const viewportRef = useRef<Size | null>(null);
  const motionRef = useRef(0);
  const dragRef = useRef<{ id: number; x: number; y: number; vx: number; vy: number; t: number } | null>(null);

  const commit = useCallback((next: SceneCamera) => {
    cameraRef.current = next;
    setCameraState(next);
  }, []);

  const stopMotion = () => cancelAnimationFrame(motionRef.current);

  const homeCamera = useCallback(() => {
    const container = containerRef.current;
    const vp = viewportRef.current;
    if (!container || !vp) return null;
    const area = visibleStageArea(container, headerSelector);
    return focusCamera(vp, image, 1, focus, { x: area.centerX, y: area.centerY });
  }, [containerRef, image, focus, headerSelector]);

  const animateTo = useCallback(
    (target: SceneCamera, duration = 320) => {
      stopMotion();
      const from = cameraRef.current;
      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (!from || reduced) return commit(target);
      const start = performance.now();
      const step = (now: number) => {
        const t = Math.min(1, (now - start) / duration);
        commit(interpolateCamera(from, target, 1 - Math.pow(1 - t, 3)));
        if (t < 1) motionRef.current = requestAnimationFrame(step);
      };
      motionRef.current = requestAnimationFrame(step);
    },
    [commit],
  );

  const recenter = useCallback(
    (animate = true) => {
      const target = homeCamera();
      if (!target) return;
      if (animate) animateTo(target, 420);
      else commit(target);
    },
    [homeCamera, animateTo, commit],
  );

  // Tamaño del stage: al cambiar se conserva la cámara (acotada); la primera vez, encuadre inicial.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const observer = new ResizeObserver(() => {
      const next = { width: container.clientWidth, height: container.clientHeight };
      if (!next.width || !next.height) return;
      viewportRef.current = next;
      setViewport(next);
      const current = cameraRef.current;
      if (current) commit(clampCamera(current, next, image));
      else {
        const home = homeCamera();
        if (home) commit(home);
      }
    });
    observer.observe(container);
    return () => observer.disconnect();
  }, [containerRef, image, homeCamera, commit]);

  // Rueda: listener nativo no pasivo para que la página no haga scroll.
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const onWheel = (event: WheelEvent) => {
      const vp = viewportRef.current;
      const current = cameraRef.current;
      if (!vp || !current) return;
      event.preventDefault();
      stopMotion();
      const rect = container.getBoundingClientRect();
      const factor = Math.exp(-event.deltaY * 0.0016);
      if (factor > 1) onZoomInRef.current?.();
      commit(zoomAt(current, vp, image, factor, { x: event.clientX - rect.left, y: event.clientY - rect.top }));
    };
    container.addEventListener('wheel', onWheel, { passive: false });
    return () => container.removeEventListener('wheel', onWheel);
  }, [containerRef, image, commit]);

  useEffect(() => stopMotion, []);

  const onPointerDown = (event: PointerEvent<HTMLElement>) => {
    if (event.button !== 0 || (event.target as HTMLElement).closest('button, a, input')) return;
    stopMotion();
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = { id: event.pointerId, x: event.clientX, y: event.clientY, vx: 0, vy: 0, t: performance.now() };
    setDragging(true);
  };

  const onPointerMove = (event: PointerEvent<HTMLElement>) => {
    const drag = dragRef.current;
    const vp = viewportRef.current;
    const current = cameraRef.current;
    if (!drag || drag.id !== event.pointerId || !vp || !current) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    const now = performance.now();
    const dt = Math.max(1, now - drag.t);
    // Velocidad suavizada (px/frame a 60 fps) para una inercia sin saltos.
    drag.vx = drag.vx * 0.6 + ((dx / dt) * 16.7) * 0.4;
    drag.vy = drag.vy * 0.6 + ((dy / dt) * 16.7) * 0.4;
    drag.x = event.clientX;
    drag.y = event.clientY;
    drag.t = now;
    commit(panBy(current, vp, image, dx, dy));
  };

  const onPointerUp = (event: PointerEvent<HTMLElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.id !== event.pointerId) return;
    dragRef.current = null;
    setDragging(false);
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    let { vx, vy } = drag;
    const glide = () => {
      const vp = viewportRef.current;
      const current = cameraRef.current;
      if (!vp || !current || (Math.abs(vx) < 0.3 && Math.abs(vy) < 0.3)) return;
      commit(panBy(current, vp, image, vx, vy));
      vx *= FRICTION;
      vy *= FRICTION;
      motionRef.current = requestAnimationFrame(glide);
    };
    motionRef.current = requestAnimationFrame(glide);
  };

  const onKeyDown = (event: KeyboardEvent<HTMLElement>) => {
    const vp = viewportRef.current;
    const current = cameraRef.current;
    if (!vp || !current) return;
    const moves: Record<string, [number, number]> = {
      ArrowLeft: [KEY_STEP, 0],
      ArrowRight: [-KEY_STEP, 0],
      ArrowUp: [0, KEY_STEP],
      ArrowDown: [0, -KEY_STEP],
    };
    if (moves[event.key]) {
      event.preventDefault();
      animateTo(panBy(current, vp, image, ...moves[event.key]), 220);
    } else if (event.key === '+' || event.key === '=') zoomBy(1.25);
    else if (event.key === '-') zoomBy(0.8);
  };

  const zoomBy = (factor: number) => {
    const container = containerRef.current;
    const vp = viewportRef.current;
    const current = cameraRef.current;
    if (!container || !vp || !current) return;
    if (factor > 1) onZoomInRef.current?.();
    const area = visibleStageArea(container, headerSelector);
    animateTo(zoomAt(current, vp, image, factor, { x: area.centerX, y: area.centerY }));
  };

  return {
    camera,
    viewport,
    cameraRef,
    viewportRef,
    dragging,
    recenter,
    zoomIn: () => zoomBy(1.35),
    zoomOut: () => zoomBy(1 / 1.35),
    bind: { onPointerDown, onPointerMove, onPointerUp, onPointerCancel: onPointerUp, onKeyDown },
  };
}
