# Índice de implementación

Abrir sólo el archivo pertinente. Snapshots de referencia con imports originales; no starter autónomo.
Los documentos históricos dentro del snapshot no sustituyen las instrucciones vigentes de esta skill.

| Archivo | Origen |
|---|---|
| `references/codigo/src/hooks/useCenterDetail.ts` | repositorio local inspeccionado 19-10-2026: src/hooks/useCenterDetail.ts; puede incluir cambios sin commit |
| `references/codigo/src/hooks/useSceneCamera.ts` | repositorio local inspeccionado 19-10-2026: src/hooks/useSceneCamera.ts; puede incluir cambios sin commit |
| `references/codigo/src/hooks/useCenterSelectionState.ts` | repositorio local inspeccionado 19-10-2026: src/hooks/useCenterSelectionState.ts; puede incluir cambios sin commit |
| `references/codigo/src/data/centers/centerDetail.types.ts` | repositorio local inspeccionado 19-10-2026: src/data/centers/centerDetail.types.ts; puede incluir cambios sin commit |
| `references/codigo/src/data/centers/reloncavi.site.ts` | repositorio local inspeccionado 19-10-2026: src/data/centers/reloncavi.site.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/centers/centerSelectionState.ts` | repositorio local inspeccionado 19-10-2026: src/lib/centers/centerSelectionState.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/centers/sceneCamera.ts` | repositorio local inspeccionado 19-10-2026: src/lib/centers/sceneCamera.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/centers/chonosCenterDetailSource.ts` | repositorio local inspeccionado 19-10-2026: src/lib/centers/chonosCenterDetailSource.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/centers/sensorTelemetry.ts` | repositorio local inspeccionado 19-10-2026: src/lib/centers/sensorTelemetry.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/centers/centerSources.ts` | repositorio local inspeccionado 19-10-2026: src/lib/centers/centerSources.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/centers/centerDetailSource.ts` | repositorio local inspeccionado 19-10-2026: src/lib/centers/centerDetailSource.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/map/fadeFlight.ts` | repositorio local inspeccionado 19-10-2026: src/lib/map/fadeFlight.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/map/flyToAOI.ts` | repositorio local inspeccionado 19-10-2026: src/lib/map/flyToAOI.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/map/tileOptions.ts` | repositorio local inspeccionado 19-10-2026: src/lib/map/tileOptions.ts; puede incluir cambios sin commit |
| `references/codigo/src/config/map/imagery.ts` | repositorio local inspeccionado 19-10-2026: src/config/map/imagery.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/currents/chonosCurrents.ts` | repositorio local inspeccionado 19-10-2026: src/lib/currents/chonosCurrents.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/currents/currentGrid.ts` | repositorio local inspeccionado 19-10-2026: src/lib/currents/currentGrid.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/flowMap/frameBudget.ts` | repositorio local inspeccionado 19-10-2026: src/lib/flowMap/frameBudget.ts; puede incluir cambios sin commit |
| `references/codigo/src/lib/flowMap/renderTier.ts` | repositorio local inspeccionado 19-10-2026: src/lib/flowMap/renderTier.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/map/centers/CenterMarker.tsx` | repositorio local inspeccionado 19-10-2026: src/components/map/centers/CenterMarker.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/organisms/stratos/StratosMapView.tsx` | repositorio local inspeccionado 19-10-2026: src/components/organisms/stratos/StratosMapView.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/organisms/stratos/StratosMapView.css` | repositorio local inspeccionado 19-10-2026: src/components/organisms/stratos/StratosMapView.css; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/centerDetail.css` | repositorio local inspeccionado 19-10-2026: src/components/centers/centerDetail.css; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/CenterDetailHero.tsx` | repositorio local inspeccionado 19-10-2026: src/components/centers/CenterDetailHero.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/CenterDetailStage.tsx` | repositorio local inspeccionado 19-10-2026: src/components/centers/CenterDetailStage.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/CenterSensorInstruments.tsx` | repositorio local inspeccionado 19-10-2026: src/components/centers/CenterSensorInstruments.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/CenterSourceRail.tsx` | repositorio local inspeccionado 19-10-2026: src/components/centers/CenterSourceRail.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/FlowParticleField.tsx` | repositorio local inspeccionado 19-10-2026: src/components/centers/FlowParticleField.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/index.ts` | repositorio local inspeccionado 19-10-2026: src/components/centers/index.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/SensorKpiGrid.tsx` | repositorio local inspeccionado 19-10-2026: src/components/centers/SensorKpiGrid.tsx; puede incluir cambios sin commit |
| `assets/centro-reloncavi-lateral.png` | asset ilustrativo STRATOS, no inventario verificado |
