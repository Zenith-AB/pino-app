# Extensión de video · propuesta, no implementada en el snapshot

Mantener la escena como lienzo. Un indicador discreto de cámara/jaula abre un panel lateral glass
con player 16:9, fecha, origen y timeline. La detección usa overlays en el player; nunca cajas sobre
toda la interfaz. El modo ampliado prioriza video y permite regresar a la escena conservando selección.

Campos mínimos del adaptador:
videoId, centerId, cameraId, sourceKind(live|recorded|demo), url autorizada, capturedAtStart/End,
timezone, durationSec, dimensions, modelId/version, detectionTask, processingStatus y detections[]
con id, trackId opcional, label, score bruto, bbox normalizada, frameTimeSec y revisión humana si existe.

No almacenar una URL firmada de larga duración en skills ni logs. Acceso se autoriza por usuario/centro
en backend. No usar la clave CDS/Marine para videos: son credenciales de otro servicio.
Distinguir sin clip, cargando, reproduciendo, procesando, sin detecciones, error y permiso denegado.
No afirmar «sin fenómeno» por no detectar ni convertir score en probabilidad calibrada.

Movimiento: reproducción sólo en player visible; al cerrar/ocultar/Background, pausar video y cancelar
RAF/streams; liberar URLs temporales. No autoplay con sonido. Usar poster, controles y subtítulos o
descripción pertinente. Reduced-motion detiene partículas ornamentales sin bloquear reproducción elegida.

Demo: si no hay un clip legítimo, mostrar «Sin video conectado» y conservar el espacio diseñado.
Un archivo de ejemplo se rotula demostración; sin modelo ejecutado no mostrar detecciones inventadas
como resultado real. El analizador del agente obtiene sólo evidencia procesada y autorizada.
