"""Verifica paquete o instalación; exige catálogo no vacío y falla ante fuentes/rutas ausentes."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys

NAMES = ('prototipo-desde-referencias', 'stratos-diseno-instrumental', 'stratos-centro-inmersivo',
         'stratos-fuentes-explicables', 'agente-analitico-clef', 'agente-vista-visual')

def verify(root):
    errors = []
    total = 0
    if not root.is_dir():
        return ['La raíz no existe'], 0
    for name in NAMES:
        skill = root/name
        entry = skill/'SKILL.md'
        if not entry.is_file():
            errors.append('Falta skill: '+name)
            continue
        text = entry.read_text(encoding='utf-8')
        if not re.match(r'^---\nname: '+re.escape(name)+r'\ndescription: .+\n---\n',text):
            errors.append('Metadatos incorrectos: '+name)
        for link in re.findall(r'\]\(([^)]+)\)',text):
            if '://' in link or link.startswith('#'):
                continue
            path=(skill/link.split('#')[0]).resolve()
            if not path.is_relative_to(skill.resolve()) or not path.is_file():
                errors.append('Referencia ausente/fuera de skill: '+name+'/'+link)
        manifest=skill/'references/FUENTES.json'
        if not manifest.is_file():
            errors.append('Falta procedencia: '+name)
            continue
        rows=json.loads(manifest.read_text(encoding='utf-8'))
        if name!='prototipo-desde-referencias' and not rows:
            errors.append('Procedencia vacía: '+name)
        for row in rows:
            path=(skill/row['path']).resolve()
            if not path.is_relative_to(skill.resolve()) or not path.is_file():
                errors.append('Fuente ausente/fuera de skill: '+name+'/'+row['path'])
            elif hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
                errors.append('Huella distinta: '+name+'/'+row['path'])
            total+=1
    inventory = root/'MANIFIESTO.json'
    if inventory.is_file():
        entries = json.loads(inventory.read_text(encoding='utf-8'))['files']
        seen = set()
        for row in entries:
            rel = row['path']
            path = (root/rel).resolve()
            if rel in seen or not path.is_relative_to(root.resolve()) or not path.is_file():
                errors.append('Inventario inválido: '+rel)
            elif hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
                errors.append('Integridad global distinta: '+rel)
            seen.add(rel)
        actual = {p.relative_to(root).as_posix() for p in root.rglob('*')
                  if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'
                  and p.name != 'MANIFIESTO.json'}
        for rel in sorted(actual-seen):
            errors.append('Archivo no inventariado: '+rel)
    return errors,total

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    args=p.parse_args()
    try:
        errors,total=verify(args.root.resolve())
    except Exception:
        print('VERIFICACION FALLIDA: estructura o manifiesto inválido')
        return 1
    for error in errors:
        print(error)
    print(('OK' if not errors else 'FALLO'), '· 6 skills requeridas ·',total,'referencias comprobadas')
    print('No acredita evaluación de Clef, calidad visual ni ausencia universal de secretos.')
    return 1 if errors else 0

if __name__ == '__main__':
    sys.exit(main())
