"""Sirve sólo el atlas; las credenciales y el resto del paquete no son accesibles por HTTP."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8773)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent/'prototipo-desde-referencias/assets/atlas-visual'
    if not (root/'index.html').is_file():
        raise SystemExit('Atlas incompleto')
    handler=partial(SimpleHTTPRequestHandler,directory=str(root))
    server=ThreadingHTTPServer(('127.0.0.1',args.port),handler)
    print(f'Atlas V3 en http://127.0.0.1:{args.port} · Ctrl+C para detener',flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
