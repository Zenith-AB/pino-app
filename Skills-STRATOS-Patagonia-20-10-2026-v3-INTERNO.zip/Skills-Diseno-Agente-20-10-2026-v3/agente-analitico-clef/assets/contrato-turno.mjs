// Ejemplo de backend, no runtime Clef instalado. Callbacks de confianza sólo del servidor.
export function crearGuardia({ herramientas, presentar, autorizar, validarEvidencia,
  maxHerramientas = 7, timeoutMs = 40000 }) {
  if (typeof autorizar !== 'function' || typeof validarEvidencia !== 'function' ||
      typeof presentar !== 'function' || !Number.isInteger(maxHerramientas) || maxHerramientas < 1 ||
      !Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new TypeError('Configuración inválida');
  let version = 0, active, sequence = 0;
  function congelar(value) {
    if (value && typeof value === 'object') { Object.freeze(value); Object.values(value).forEach(congelar); }
    return value;
  }
  function cambiarContexto() { version++; active?.abort('context_changed'); return version; }
  async function ejecutar({ decidir, contexto }) {
    active?.abort('superseded');
    const local = new AbortController(); active = local;
    const contextVersion = version, turnId = ++sequence;
    let timer, removeAbort;
    const vigente = () => !local.signal.aborted && version === contextVersion;
    const cancelado = () => ({ estado: local.signal.reason === 'timeout' ? 'timeout' : 'cancelled', turnId, contextVersion });
    const interrupted = new Promise(resolve => {
      removeAbort = () => resolve(cancelado());
      local.signal.addEventListener('abort', removeAbort, { once: true });
    });
    timer = setTimeout(() => local.abort('timeout'), timeoutMs);
    const work = async () => {
      try {
        const ctx = congelar(structuredClone(contexto));
        if (!ctx || typeof ctx.entityId !== 'string' || !ctx.entityId || typeof decidir !== 'function')
          return { estado: 'blocked_action', motivo: 'Contexto inválido' };
        const base = { contexto: ctx, signal: local.signal, contextVersion, turnId };
        const plan = await decidir(base);
        if (!vigente()) return cancelado();
        if (!plan || Object.keys(plan).some(k => k !== 'tools') || !Array.isArray(plan.tools) ||
            plan.tools.length > maxHerramientas || new Set(plan.tools).size !== plan.tools.length ||
            plan.tools.some(id => typeof id !== 'string' || !Object.hasOwn(herramientas, id) ||
              typeof herramientas[id] !== 'function'))
          return { estado: 'blocked_action', motivo: 'Plan inválido' };
        const ids = [...plan.tools];
        // Autorizar todo antes de ejecutar; revalidar antes de cada lectura por posible revocación.
        for (const id of ids) {
          const allowed = await autorizar({ ...base, id });
          if (!vigente()) return cancelado();
          if (allowed !== true) return { estado: 'blocked_action', motivo: 'Capacidad no autorizada' };
        }
        const evidencia = [], fallos = [];
        for (const id of ids) {
          if (!vigente()) return cancelado();
          if (await autorizar({ ...base, id }) !== true)
            return { estado: 'blocked_action', motivo: 'Permiso revocado' };
          if (!vigente()) return cancelado();
          try {
            const result = await herramientas[id](base);
            if (!vigente()) return cancelado();
            const coherent = result?.entityId === ctx.entityId && result.contextVersion === contextVersion &&
              result.turnId === turnId && typeof result.sourceId === 'string' && result.sourceId.length > 0;
            if (coherent && await validarEvidencia({ ...base, id, result }) === true)
              evidencia.push(congelar(structuredClone(result)));
            else fallos.push({ id, tipo: 'invalid_evidence' });
          } catch {
            if (!vigente()) return cancelado();
            fallos.push({ id, tipo: 'tool_error' });
          }
        }
        if (!vigente()) return cancelado();
        if (!evidencia.length) return { estado: 'insufficient_evidence', evidencia: [], fallos, turnId, contextVersion };
        const response = congelar({ estado: fallos.length ? 'partial_result' : 'respuesta',
          entityId: ctx.entityId, contextVersion, turnId, evidencia, fallos });
        presentar(response); // Callback síncrono de publicación; el adaptador UI debe conservar la correlación.
        return response;
      } catch {
        return vigente() ? { estado: 'error', motivo: 'No se pudo completar el turno', turnId, contextVersion } : cancelado();
      }
    };
    try { return await Promise.race([work(), interrupted]); }
    finally {
      clearTimeout(timer); local.signal.removeEventListener('abort', removeAbort);
      if (active === local) active = undefined;
    }
  }
  return { cambiarContexto, ejecutar, cancelar: () => active?.abort('user') };
}
