import test from 'node:test';
import assert from 'node:assert/strict';
import { crearGuardia } from './contrato-turno.mjs';
const ctx = () => ({entityId:'a',period:'hoy'});
const evidence = b => ({sourceId:'fixture',entityId:b.contexto.entityId,contextVersion:b.contextVersion,turnId:b.turnId,unit:'°C',value:12});
const setup = (opts={}) => crearGuardia({herramientas:{leer:async b=>evidence(b)},presentar:()=>{},autorizar:async()=>true,
  validarEvidencia:async({result})=>result.unit==='°C'&&Number.isFinite(result.value),...opts});
const execute=(g,extra={})=>g.ejecutar({contexto:ctx(),decidir:async()=>({tools:['leer']}),...extra});
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve}};
test('respuesta correlacionada',async()=>{let shown;const g=setup({presentar:r=>shown=r});const r=await execute(g);assert.equal(r.estado,'respuesta');assert.equal(shown.turnId,r.turnId)});
test('deniega callback de autorización aunque cliente declare permisos',async()=>{let calls=0;const g=setup({autorizar:async()=>false,herramientas:{leer:async()=>calls++}});assert.equal((await execute(g,{contexto:{...ctx(),permitidas:['leer']}})).estado,'blocked_action');assert.equal(calls,0)});
test('requiere callbacks de confianza',()=>assert.throws(()=>crearGuardia({herramientas:{},presentar:()=>{}}),TypeError));
test('contexto cambia antes de decisión',async()=>{const d=deferred();const g=setup({presentar:()=>assert.fail()});const p=execute(g,{decidir:()=>d.promise});g.cambiarContexto();assert.equal((await p).estado,'cancelled');d.resolve({tools:['leer']})});
test('turno nuevo invalida respuesta anterior',async()=>{const d=deferred();let n=0;const g=setup({presentar:()=>n++});const p=execute(g,{decidir:()=>d.promise});assert.equal((await execute(g)).estado,'respuesta');assert.equal((await p).estado,'cancelled');d.resolve({tools:['leer']});assert.equal(n,1)});
test('copia inmutable de contexto',async()=>{const d=deferred();let seen;const c=ctx();const g=setup({herramientas:{leer:async b=>{seen=b.contexto.period;assert.ok(Object.isFrozen(b.contexto));return evidence(b)}}});const p=execute(g,{contexto:c,decidir:()=>d.promise});c.period='ayer';d.resolve({tools:['leer']});await p;assert.equal(seen,'hoy')});
test('cancelar termina aunque dependencia ignore abort',async()=>{const g=setup({presentar:()=>assert.fail()});const p=execute(g,{decidir:()=>new Promise(()=>{})});g.cancelar();assert.equal((await p).estado,'cancelled')});
test('deadline propio sobre dependencia no cooperativa',async()=>{const g=setup({timeoutMs:10,presentar:()=>assert.fail()});assert.equal((await execute(g,{decidir:()=>new Promise(()=>{})})).estado,'timeout')});
test('fallo de decisión normalizado sin contenido sensible',async()=>{const r=await execute(setup(),{decidir:async()=>{throw Error('SECRETO')}});assert.equal(r.estado,'error');assert.ok(!JSON.stringify(r).includes('SECRETO'))});
test('herramienta fallida conserva evidencia parcial',async()=>{const g=setup({herramientas:{leer:async b=>evidence(b),otra:async()=>{throw Error('SECRETO')}}});const r=await execute(g,{decidir:async()=>({tools:['leer','otra']})});assert.equal(r.estado,'partial_result');assert.equal(r.evidencia.length,1);assert.ok(!JSON.stringify(r).includes('SECRETO'))});
for(const [name,patch] of [['otro centro',{entityId:'b'}],['otro turno',{turnId:99}],['otro contexto',{contextVersion:99}],['valor no finito',{value:NaN}],['unidad incorrecta',{unit:'PSU'}]])
 test('rechaza evidencia: '+name,async()=>{const g=setup({herramientas:{leer:async b=>({...evidence(b),...patch})},presentar:()=>assert.fail()});assert.equal((await execute(g)).estado,'insufficient_evidence')});
for(const tools of [['leer','leer'],['inexistente'],[null],Array(8).fill('leer')])
 test('rechaza plan inválido '+JSON.stringify(tools),async()=>assert.equal((await execute(setup(),{decidir:async()=>({tools})})).estado,'blocked_action'));
test('rechaza propiedades ejecutables extra del modelo',async()=>assert.equal((await execute(setup(),{decidir:async()=>({tools:['leer'],sql:'delete'})})).estado,'blocked_action'));
test('revocación antes de ejecutar no filtra evidencia',async()=>{let n=0,calls=0;const g=setup({autorizar:async()=>++n===1,herramientas:{leer:async()=>calls++}});assert.equal((await execute(g)).estado,'blocked_action');assert.equal(calls,0)});
test('sin herramientas es insuficiente',async()=>assert.equal((await execute(setup(),{decidir:async()=>({tools:[]})})).estado,'insufficient_evidence'));
