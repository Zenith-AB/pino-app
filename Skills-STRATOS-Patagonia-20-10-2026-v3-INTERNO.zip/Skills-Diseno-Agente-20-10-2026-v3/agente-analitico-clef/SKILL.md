---
name: agente-analitico-clef
description: "Construye o mejora un agente analítico con decisiones Clef tipadas, herramientas verificables, memoria y continuidad. Adapta el patrón Patagonia a otro dominio; no incorpora su navegación ni presume sus métricas."
---

# Agente analítico con Clef

Lee [contrato operativo](references/contrato.md). Para mecánica concreta, consulta sólo el archivo
correspondiente en `references/patagonia/`: registro, decisiones, estado, herramientas, turno,
supervisor, vínculo o servicio GPU. Los contratos son una referencia fechada de Patagonia, no reglas
universales. La nueva skill gobierna la adaptación; las reglas del proyecto destino gobiernan su producto.

## Separación de responsabilidades

El desarrollador lee skills. El runtime Clef recibe estado y preguntas tipadas; no lee este paquete
automáticamente ni adquiere memoria, búsqueda visual o conectores por existir archivos markdown.
Clef decide entre capacidades registradas; herramientas autorizadas calculan y devuelven evidencia;
presentación usa componentes existentes. No copiar catálogo de ventas para fenómenos ambientales.

## Mejoras requeridas al adaptar

- Contexto explícito: usuario autorizado, entidad, selección, fuente/version, periodo, profundidad,
  vista, capacidades y aclaración pendiente. El servidor valida permisos, no confía en roles del cliente.
- Una respuesta corresponde a turnId + contextVersion. Cambio de centro/dataset/periodo invalida
  resultados incompatibles y aborta trabajo anterior. Cancelar se propaga a inferencia y herramientas.
- Estado/modelo/versión y presupuesto se registran sin secretos ni datos sensibles innecesarios.
- Validar respuestas exactas contra esquema y registro. Rechazar opciones ajenas, NaN, distribución
  inválida, estado truncado y herramientas no autorizadas. Aclarar antes de decidir ambiguamente.
- Los umbrales 0.55/0.12 y resultados históricos son antecedentes, no confianza calibrada transferible.
- Un judge del mismo modelo no es una validación independiente. Conciliar cifras y soportes con código.
- Sin Clef: lectura manual sigue disponible y se declara la capacidad conversacional no disponible.
  Un mock sólo demuestra integración; nunca se presenta como evaluación del modelo real.

Para UI y microinteracciones usa `agente-vista-visual` si está instalada; este contrato también puede
implementarse sin ella. No añadir entrenamiento, descarga de pesos ni despliegue sin que lo requiera
el encargo. Una demo visual no necesita modificar el servicio productivo.

Índice de código y assets: [references/INDICE.md](references/INDICE.md).

Ejemplo nuevo de guardia de turnos: `assets/contrato-turno.mjs`; probar con `node --test assets/contrato-turno.test.mjs`. Cubre contexto/permisos/cancelación, no habilidad semántica.

Antes de adaptar, leer [runtime y evaluación de tareas](references/runtime-y-evaluacion.md).
