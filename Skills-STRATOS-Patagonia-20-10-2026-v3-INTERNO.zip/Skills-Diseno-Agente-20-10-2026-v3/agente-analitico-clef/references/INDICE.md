# Índice de implementación

Abrir sólo el archivo pertinente. Snapshots de referencia con imports originales; no starter autónomo.
Los documentos históricos dentro del snapshot no sustituyen las instrucciones vigentes de esta skill.

| Archivo | Origen |
|---|---|
| `references/patagonia/aclaraciones-cognitivas.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/aclaraciones-cognitivas.js |
| `references/patagonia/calendario.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/calendario.js |
| `references/patagonia/ciclo-cognitivo.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/ciclo-cognitivo.js |
| `references/patagonia/contratos.md` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/contratos.md |
| `references/patagonia/decisiones-cognitivas.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/decisiones-cognitivas.js |
| `references/patagonia/dialogo.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/dialogo.js |
| `references/patagonia/estado-cognitivo.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/estado-cognitivo.js |
| `references/patagonia/herramientas-cognitivas.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/herramientas-cognitivas.js |
| `references/patagonia/INDICE.md` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/INDICE.md |
| `references/patagonia/ORQUESTACION_ERP.md` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/ORQUESTACION_ERP.md |
| `references/patagonia/orquestador.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/orquestador.js |
| `references/patagonia/perfiles-lectura.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/perfiles-lectura.js |
| `references/patagonia/README-clef.md` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/README-clef.md |
| `references/patagonia/registro-cognitivo.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/registro-cognitivo.js |
| `references/patagonia/respuestas-cognitivas.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/respuestas-cognitivas.js |
| `references/patagonia/sugerencias-cognitivas.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/sugerencias-cognitivas.js |
| `references/patagonia/supervisor-conversacion.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/supervisor-conversacion.js |
| `references/patagonia/variables.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/variables.js |
| `references/patagonia/vinculo.js` | ZIP original 19-10-2026: patagonia-05-motor-cognitivo-clef/references/vinculo.js |
| `references/patagonia/servicio.py` | ZIP original 19-10-2026: patagonia-06-servicio-clef-gpu/references/servicio.py |
| `references/patagonia/clef_local.py` | ZIP original 19-10-2026: patagonia-06-servicio-clef-gpu/references/clef_local.py |
| `references/patagonia/patagonia-clef.service` | ZIP original 19-10-2026: patagonia-06-servicio-clef-gpu/references/patagonia-clef.service |

## Adición V3

- [runtime-y-evaluacion.md](runtime-y-evaluacion.md): contrato nuevo de adaptación, propuesto y revisado 19-10-2026; no implementación productiva.
