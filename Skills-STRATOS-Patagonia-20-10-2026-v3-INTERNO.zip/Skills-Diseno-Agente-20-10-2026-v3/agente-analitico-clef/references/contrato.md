# Contrato de adaptación del agente

## Ciclo

Petición + contexto autenticado → estado compacto → decisión tipada → validación y política →
herramienta autorizada → evidencia comprobada → juicio opcional → plan de respuesta → UI.
Evitar repetir inferencia si el resultado se puede resolver con datos/registro existentes.

## Interfaces del dominio nuevo

Request: turnId, conversationId, contextVersion, query, selection{entityId,location,depth,period},
visibleView y referencias autorizadas. El servidor resuelve identidad/permisos y sourceVersion.
ToolResult: id, estado, evidence[], coverage, limitations, observedAt/issuedAt/validAt y duration.
Evidence: id, variable, value nullable, unit, sourceId, nature, location, depth, QC, periodo y enlaces.
Response: estado, answerText, evidenceIds, limitations, presentation{componentId,propsValidadas},
followUps, contextVersion. Componentes y acciones se validan contra allowlist local.

Estados: respuesta, partial_result, insufficient_evidence, clarification, unsupported, blocked_action,
cancelled y error. «Procesando» es estado de trabajo, no resultado final.
No enviar SQL, HTML arbitrario, JavaScript ni nombres de componentes inventados desde el modelo al cliente.

## Memoria

Conservar selección, intención, entidades resueltas, aclaración y referencias de evidencia; no fijar
cifras viejas como actuales. Expirar por usuario, dominio, fuente/versión y política. HMAC evita
modificación inadvertida pero no cifra contenido ni autoriza acceso. No compartir secretos de firma
entre productos por copiar el ejemplo. Un vínculo vivo reconsulta evidencia al cambiar filtros/version.

## Presupuestos

Patagonia usa máximo 4 inferencias, 7 herramientas y 2 rondas; turno 40 s. Son límites de referencia.
Para demo decidir presupuesto según latencia medida; mostrar etapa real y cancelación inmediata,
no alargar el resultado para simular razonamiento. Timeouts abortan dependencias y limpian colas.

## Pruebas necesarias

Consulta directa; seguimiento «¿y ayer?»; cambio de centro; periodo ambiguo; dato ausente; comparación
con unidades incompatibles; cancelación; respuesta tardía; decisión inválida/truncada; permisos negados;
servicio caído; evidencia que no responde; intento de inyección en referencia; video sin detección.
Congelar casos de control antes de ajustar prompts/política. Separar resultados con mock de Clef real.
Medir resolución de tarea, errores silenciosos, aclaraciones útiles, latencia y abstención por soporte.
No transferir cifras de Patagonia como aprobación del agente nuevo.

## Clef local

Snapshot: endpoint POST /v1/systemone, estado y preguntas choice/noul/score; servicio autenticado en
localhost. La referencia GPU describe una adaptación NF4 con offload para una configuración concreta.
No asumir VRAM, versiones o compatibilidad de otro host. Revisar servicio y pesos fijados antes de operar.
No habilitar trust_remote_code ni ejecutar código de modelo no revisado sólo por una referencia.
