// Vínculo vivo entre una respuesta de Clef y el tablero. Clef decide UNA vez qué conectar (dominio, métricas, entidad,
// herramientas registradas, plantilla y componente); el vínculo no contiene cifras. Cada evaluación vuelve a ejecutar
// esas herramientas con las variables vigentes del tablero y la versión actual de los datos, sin llamar a Clef.
// Así la respuesta se mantiene al día cuando llegan registros o cuando la persona cambia filtros, sin volver a preguntar.
import { createHmac, timingSafeEqual } from 'node:crypto'
import { METRICAS, buscarCapacidades, validarPresentacion } from './registro-cognitivo.js'
import { resolverVariables, validarVariables } from './variables.js'
import { componerRespuesta, componerBalance } from './respuestas-cognitivas.js'
import { esTableroEnlazado } from './tipos-escenario.js'

export const VERSION_VINCULO = 'patagonia-vinculo-1'
const VIGENCIA_MS = 30 * 24 * 60 * 60 * 1000
const RESPONDE = ['respuesta', 'hallazgo', 'partial_result']

// Desde el resultado de un turno. Solo respuestas con evidencia verificada producen un vínculo.
// limitesJuicio: límites que provienen del juicio sobre la PREGUNTA (p. ej., respuesta parcial a lo pedido), no de los
// datos. Se conservan; los límites de las herramientas se recalculan en cada evaluación.
export function crearVinculo({ tipo, plan, resultados, plantilla, presentacion, escenario, perfil, metricasPerfil, consulta, limitesJuicio = [] }) {
  const verificados = resultados.filter((r) => r.verificado)
  if (!RESPONDE.includes(tipo) || !verificados.length || !METRICAS[plan.metrica]) return null
  const base = { dominio: plan.dominio, metrica: plan.metrica, entidad: plan.entidad && plan.entidad !== 'incierta' ? plan.entidad : null, orden_ranking: plan.orden_ranking ?? 'desc', alcance: plan.alcance ?? 'agregado', periodo_explicito: Boolean(plan.periodo_explicito), presentacion, consulta: String(consulta ?? '').slice(0, 160), limites_juicio: limitesJuicio.slice(0, 4) }
  if (plantilla === 'revision_perfil') return { ...base, clase: 'perfil', metricas: metricasPerfil, plantilla, perfil }
  const kpis = verificados.filter((r) => r.id === 'get_kpi')
  if (kpis.length > 1 && kpis.length === resultados.length) return { ...base, clase: 'metricas', metricas: kpis.map((r) => r.procedencia.metrica), plantilla: 'direct_metric' }
  const herramientas = [...new Set(resultados.map((r) => r.id))]
  return { ...base, clase: plantilla === 'recent_records' ? 'registros' : 'analisis', herramientas, plantilla }
}

export function firmarVinculo(vinculo, { secreto, usuario, escenario, perfil = null, ahora = Date.now() }) {
  const cuerpo = Buffer.from(JSON.stringify({ ...vinculo, version: VERSION_VINCULO, usuario, escenario, perfil, creado: ahora, expira: ahora + VIGENCIA_MS })).toString('base64url')
  return `${cuerpo}.${createHmac('sha256', secreto).update(cuerpo).digest('base64url')}`
}

// El navegador guarda el token, pero no puede cambiar métricas, herramientas, usuario, fuente ni perfil.
export function leerVinculo(token, { secreto, usuario, escenario, perfil = null, ahora = Date.now() }) {
  if (typeof token !== 'string' || token.length > 4000) return null
  try {
    const [cuerpo, firma, extra] = token.split('.')
    if (extra || !cuerpo || !firma) return null
    const esperado = createHmac('sha256', secreto).update(cuerpo).digest(), recibido = Buffer.from(firma, 'base64url')
    if (recibido.length !== esperado.length || !timingSafeEqual(recibido, esperado)) return null
    const v = JSON.parse(Buffer.from(cuerpo, 'base64url').toString())
    return v.version === VERSION_VINCULO && v.usuario === usuario && v.escenario === escenario && (v.perfil ?? null) === perfil && v.expira > ahora ? v : null
  } catch { return null }
}

// Evaluación determinística: mismas herramientas, mismas plantillas, variables y datos vigentes. Nunca llama a Clef.
export async function evaluarVinculo(v, { variables, escenario, ejecutar, signal }) {
  const vars = validarVariables({ ...variables, ...(esTableroEnlazado(escenario.id) && { foco: 'todos' }) })
  const r = resolverVariables(vars, escenario.cobertura)
  const plan = { dominio: v.dominio, metrica: v.metrica, entidad: v.entidad, orden_ranking: v.orden_ranking, alcance: v.alcance, periodo_explicito: v.periodo_explicito, variables: vars }
  const limites = [...(v.limites_juicio ?? [])], resultados = []
  const salida = (estado, texto, extra = {}) => ({ analisis: { estado, texto, periodo: r.actual?.corto ?? null, comparacion: r.anterior?.corto ?? null, herramientas: resultados.map((x) => x.id), evidencia: resultados, naturaleza_datos: escenario.naturaleza_datos, limites, ...extra }, response_plan: { plantilla: v.plantilla, presentacion: v.presentacion ? validarPresentacion(v.presentacion) : { componente: 'AgentDock', preset: null, props: {} } }, variables: vars })
  if (!r.actual) { limites.push(r.motivoComparacion ?? 'La cobertura no contiene el período seleccionado.'); return salida('insufficient_evidence', `No hay registros para el período seleccionado. ${limites.join(' ')}`) }
  const correr = async (id, p) => {
    if (!buscarCapacidades(escenario, p.dominio, p.metrica).some((c) => c.id === id)) throw new Error('Vínculo fuera del registro de capacidades.')
    const res = await ejecutar(id, p, { signal })
    if (res.id !== id || res.verificado && res.estado !== 'verificado') throw new Error('Resultado de herramienta inconsistente.')
    if (!res.verificado) limites.push(res.datos?.limite ?? res.limite ?? `Sin evidencia verificada en ${id}.`)
    resultados.push({ ...res, referencia: `e${resultados.length + 1}` })
    return res
  }
  if (v.clase === 'perfil' || v.clase === 'metricas') {
    for (const metrica of v.metricas) {
      const dominio = METRICAS[metrica]?.dominio
      if (!dominio || !buscarCapacidades(escenario, dominio, metrica).some((c) => c.id === 'get_kpi')) continue
      await correr('get_kpi', { ...plan, dominio, metrica })
    }
    const verificados = resultados.filter((x) => x.verificado)
    const texto = v.clase === 'perfil'
      ? componerBalance({ perfil: v.perfil, resultados, periodo: r.actual.corto, escenario })
      : resultados.map((x) => x.verificado ? componerRespuesta({ plan: { ...plan, metrica: x.procedencia.metrica }, resultados: [x], plantilla: 'direct_metric', periodo: r.actual.corto, escenario, limites: [] }).texto : `${METRICAS[x.procedencia.metrica].nombre}: sin medición para ${r.actual.corto}.`).join('\n')
    return salida(verificados.length === resultados.length && verificados.length ? 'respuesta' : verificados.length ? 'partial_result' : 'insufficient_evidence', texto)
  }
  for (const id of v.herramientas) {
    if (['find_drivers', 'detect_anomalies'].includes(id) && !resultados.some((x) => x.id === 'compare_periods')) await correr('compare_periods', plan)
    if (!resultados.some((x) => x.id === id)) await correr(id, plan)
  }
  const verificados = resultados.filter((x) => x.verificado)
  // Misma degradación que el ciclo: sin la evidencia que una plantilla exige, se usa la más simple que sí la tiene.
  let plantilla = v.plantilla
  const hay = (id) => verificados.some((x) => x.id === id)
  if (['diagnosis', 'recommendation'].includes(plantilla) && !['find_drivers', 'detect_anomalies', 'detect_stockout'].some(hay)) plantilla = 'comparison'
  if (['comparison', 'diagnosis', 'recommendation'].includes(plantilla) && !hay('compare_periods')) plantilla = 'direct_metric'
  if (!verificados.length) plantilla = 'insufficient_evidence'
  else if (verificados.length < resultados.length && plantilla === 'direct_metric') plantilla = 'partial_result'
  const { texto, principal } = componerRespuesta({ plan, resultados, plantilla, periodo: r.actual.corto, anterior: r.anterior?.corto, escenario, limites })
  return salida(!verificados.length ? 'insufficient_evidence' : verificados.length < resultados.length ? 'partial_result' : principal ? 'hallazgo' : 'respuesta', texto, { principal })
}
