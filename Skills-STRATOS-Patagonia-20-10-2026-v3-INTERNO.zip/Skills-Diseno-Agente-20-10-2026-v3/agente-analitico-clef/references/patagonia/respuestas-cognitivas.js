import { METRICAS } from './registro-cognitivo.js'
const fmt = (n) => n == null ? 'sin medición' : new Intl.NumberFormat('es-CL', { maximumFractionDigits: 2 }).format(Number(n))
const valor = (n, u) => `${fmt(n)} ${u}`
const importe = (n, u) => u==='CLP' && Math.abs(n)>=1e6 ? `${fmt(n/1e6)} millones CLP` : valor(n,u)
// Redacción de hechos registrados. El perfil cambia el énfasis, no inventa interpretaciones.
export function componerBalance({perfil,resultados,periodo,escenario}) {
  const mediciones=new Map(resultados.filter(r=>r.verificado).map(r=>[r.procedencia.metrica,r]))
  const dato=id=>{const r=mediciones.get(id),unidad=METRICAS[id]?.unidad==='moneda'?escenario.moneda:METRICAS[id]?.unidad;return r?importe(r.datos.valor,unidad):'sin medición'}
  const fecha=resultados.find(r=>r.verificado)?.procedencia.periodo?.hasta
  const corte=fecha?new Intl.DateTimeFormat('es-CL',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'}).format(new Date(Date.parse(fecha)-86400000)):'cierre del período'
  if(perfil==='gerente_general'&&['venta','margen','cartera','stock'].every(id=>mediciones.has(id)))return `En ${periodo}, la venta neta fue de ${dato('venta')} y el margen bruto de ${dato('margen')}.\n\nAl ${corte}, las cuentas por cobrar suman ${dato('cartera')} y las existencias están valorizadas en ${dato('stock')}.`
  if(perfil==='veterinaria'&&['vacas_retiro','leche_retiro','leche_producida','leche_rechazada'].every(id=>mediciones.has(id)))return `Al ${corte} hay ${dato('vacas_retiro')} en retiro.\n\nDurante ${periodo} se ordeñaron ${dato('leche_producida')}; ${dato('leche_retiro')} quedaron excluidos por retiro y ${dato('leche_rechazada')} fueron rechazados en recepción.`
  if(perfil==='direccion_comercial'&&['venta','margen','descuento','unidades'].every(id=>mediciones.has(id)))return `En ${periodo}, la venta neta fue de ${dato('venta')}, con un margen bruto de ${dato('margen')}. Se vendieron ${dato('unidades')} y los descuentos alcanzaron ${dato('descuento')}.`
  if(perfil==='ventas'&&['venta','unidades','descuento','cartera'].every(id=>mediciones.has(id)))return `En ${periodo} se vendieron ${dato('unidades')}, por una venta neta de ${dato('venta')}. Los descuentos alcanzaron ${dato('descuento')}.\n\nAl ${corte}, quedan ${dato('cartera')} por cobrar.`
  if(perfil==='granja'&&['leche_producida','leche_retiro','leche_aceptada','leche_rechazada'].every(id=>mediciones.has(id)))return `En ${periodo} se ordeñaron ${dato('leche_producida')}; ${dato('leche_retiro')} quedaron excluidos por retiro. Las plantas aceptaron ${dato('leche_aceptada')} y rechazaron ${dato('leche_rechazada')} en recepción.`
  if(perfil==='planta'&&['leche_aceptada','leche_rechazada','stock','costo'].every(id=>mediciones.has(id)))return `En ${periodo} se aceptaron ${dato('leche_aceptada')} de leche y se rechazaron ${dato('leche_rechazada')} en recepción. El costo de lo vendido fue de ${dato('costo')}.\n\nAl ${corte}, las existencias están valorizadas en ${dato('stock')}.`
  if(perfil==='operaciones'&&['stock','unidades','costo','venta'].every(id=>mediciones.has(id)))return `Al ${corte}, las existencias están valorizadas en ${dato('stock')}.\n\nEn ${periodo} se vendieron ${dato('unidades')}, por ${dato('venta')}, con un costo de ${dato('costo')}.`
  return `Balance de ${periodo}:\n${resultados.map(r=>`${METRICAS[r.procedencia.metrica].nombre}: ${r.verificado?dato(r.procedencia.metrica):'sin medición'}.`).join('\n')}`
}
export const RESPONSE_TEMPLATES = Object.freeze({
  recent_records: ({ registros, unidad }) => `Últimas ventas registradas (${registros?.alcance}):\n${registros?.filas.map(f => `${f.fecha} · ${f.id} · ${f.sucursal}: ${valor(f.valor, unidad)}`).join('\n') ?? 'sin registros'}.`,
  direct_metric: ({ nombre, kpi, periodo, unidad }) => `${nombre}: ${valor(kpi?.valor, unidad)} en ${periodo}.`,
  comparison: ({ nombre, comparacion, periodo, anterior, unidad }) => comparacion
    ? `${nombre} en ${periodo}: ${valor(comparacion.actual, unidad)} frente a ${valor(comparacion.anterior, unidad)} en ${anterior}. Diferencia: ${valor(comparacion.diferencia, comparacion.unidad_diferencia)}${comparacion.variacion_pct == null ? '; no hay base para una variación porcentual' : ` (${fmt(comparacion.variacion_pct)} %)`}.`
    : `No hay comparación cubierta para ${nombre} en ${periodo}.`,
  insufficient_evidence: ({ nombre, limites }) => `No hay evidencia suficiente para responder sobre ${nombre}. ${limites.join(' ')}`,
  partial_result: (p) => 'Resultado parcial: ' + (p.comparacion ? RESPONSE_TEMPLATES.comparison(p) : RESPONSE_TEMPLATES.direct_metric(p)),
  diagnosis: (p) => RESPONSE_TEMPLATES.comparison(p),
  recommendation: (p) => RESPONSE_TEMPLATES.comparison(p),
})
export function componerRespuesta({ plan, resultados, plantilla, periodo, anterior, escenario, limites }) {
  const obtener = (id) => resultados.find((r) => r.id === id && r.verificado)?.datos
  const kpi = obtener('get_kpi'), comparacion = obtener('compare_periods'), drivers = obtener('find_drivers'), anomalias = obtener('detect_anomalies'), ranking = obtener('rank_entities'), stockout = obtener('detect_stockout')
  const unidad = METRICAS[plan.metrica]?.unidad === 'moneda' ? escenario.moneda : METRICAS[plan.metrica]?.unidad ?? ''
  const p = { registros: obtener('get_recent_sales'), nombre: METRICAS[plan.metrica]?.nombre ?? 'la solicitud', kpi, comparacion, periodo, anterior, unidad, limites }
  let texto = (RESPONSE_TEMPLATES[plantilla] ?? RESPONSE_TEMPLATES.insufficient_evidence)(p)
  const principal = anomalias?.filas[0] ?? (plan.dominio === 'ventas' ? drivers?.filas.filter((f) => f.diferencia < 0)[0] : null)
  if (['diagnosis', 'recommendation'].includes(plantilla)) {
    if (principal) texto += ` ${principal.nombre} registró ${valor(principal.actual, escenario.moneda)}, una variación de ${fmt(principal.variacion_pct)} %; su diferencia de ${valor(principal.diferencia, escenario.moneda)} forma parte del desglose verificado.`
    if (plan.dominio === 'rentabilidad' && drivers) texto += ` Puente del margen bruto: ${drivers.filas.map((f) => `${f.nombre}: ${valor(f.contribucion, drivers.unidad_contribucion)}`).join('; ')}. Las contribuciones explican el cambio del importe, no prueban la causa del porcentaje de margen.`
    if (anomalias && !anomalias.filas.length) texto += ` Ninguna sucursal alcanzó el umbral de caída de ${Math.abs(anomalias.umbral_pct)} % usado en esta prueba.`
    if (drivers || anomalias) texto += ' Es evidencia de variación y contribución aritmética, no una causa operacional demostrada. Conviene revisar los registros antes de actuar.'
  }
  if (ranking) texto += ` Ranking de ${plan.entidad} (${plan.orden_ranking === 'asc' ? 'menor a mayor' : 'mayor a menor'}): ${ranking.filas.slice(0, 3).map((f) => `${f.nombre}: ${valor(f.valor, unidad)}`).join('; ')}.${ranking.resto != null ? ` Resto fuera del ranking: ${valor(ranking.resto, unidad)}.` : ''}`
  if (stockout) {
    const riesgo = stockout.filas.filter((f) => f.dia_quiebre != null)
    texto += ` Proyección condicional a ${stockout.horizonte_dias} días: ${riesgo.length} productos con quiebre previsto.${riesgo.length ? ' ' + riesgo.slice(0, 3).map((f) => `${f.nombre}, día ${f.dia_quiebre}`).join('; ') + '.' : ''} No es una certeza sobre el futuro.`
  }
  if (limites.length && plantilla !== 'insufficient_evidence') texto += ` Límites: ${limites.join(' ')}`
  if (escenario.naturaleza_datos !== 'sintetico') texto += ' Valor neto con cancelaciones y ajustes.'
  return { texto, principal }
}
