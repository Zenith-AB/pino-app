import { esTableroEnlazado } from './tipos-escenario.js'
import { registrosPeriodo, stockAlCorte, carteraAlCorte } from './indices-sinteticos.js'
import * as consultas from './consultas.js'
import { DATASET_SINTETICO, tableroSintetico } from './sintetico.js'
import { METRICAS, ONTOLOGIA, buscarCapacidades } from './registro-cognitivo.js'
import { resolverVariables } from './variables.js'

const sum = (xs, key) => xs.reduce((s, x) => s + (typeof key === 'function' ? key(x) : x[key]), 0)
const en = (fecha, p) => fecha >= p.desde && fecha < p.hasta
const cambio = (a, b) => Number(b) ? (Number(a) - Number(b)) / Math.abs(Number(b)) * 100 : null
const corteDe = (p) => new Date(Date.parse(p.hasta) - 86400000).toISOString().slice(0, 10)
// PostgreSQL devuelve NUMERIC como texto: conciliación y diferencias monetarias exactas en BigInt.
const escala = 10000000000n
const decimal = (v) => {
  const texto = String(v)
  if (!/^-?\d+(\.\d{1,10})?$/.test(texto)) throw new Error('Decimal financiero inválido.')
  const [entero, fraccion = ''] = texto.replace('-', '').split('.')
  const n = BigInt(entero) * escala + BigInt(fraccion.padEnd(10, '0'))
  return texto.startsWith('-') ? -n : n
}
const textoDecimal = (v) => `${v < 0n ? '-' : ''}${(v < 0n ? -v : v) / escala}.${((v < 0n ? -v : v) % escala).toString().padStart(10, '0')}`
const diferencia = (a, b) => textoDecimal(decimal(a) - decimal(b))
const concilia = (xs, total) => xs.reduce((s, x) => s + decimal(x), 0n) === decimal(total)

function metricaSintetica(dataset, p, id) {
  const fs = registrosPeriodo(dataset,'facturas',p), ls = registrosPeriodo(dataset,'lineas',p)
  const venta = sum(fs, 'venta'), costo = sum(fs, 'costo'), bruto = sum(fs, 'bruto'), corte = corteDe(p)
  const cartera=['cartera','vencida'].includes(id)?carteraAlCorte(dataset,corte):[]
  const stock=id==='stock'?stockAlCorte(dataset,corte):null
  const valores = {
    venta, costo, margen: venta ? (venta - costo) / venta * 100 : null,
    descuento: bruto ? (bruto - venta) / bruto * 100 : null,
    unidades: sum(ls, 'cantidad'), pagos: sum(registrosPeriodo(dataset,'pagos',p), 'monto'),
    cartera: sum(cartera, 'saldo'), vencida: sum(cartera.filter((f) => f.vencimiento < corte), 'saldo'),
    stock: stock?sum(stock,m=>m.final*m.costo_unitario):null,
    ebitda: p.dias ? null : venta - costo - sum(dataset.planes.filter((x) => x.mes >= p.desde.slice(0, 7) && x.mes < p.hasta.slice(0, 7)), 'gasto'),
  }
  if (dataset.ordenias) {
    const o=registrosPeriodo(dataset,'ordenias',p), r=registrosPeriodo(dataset,'recolecciones',p)
    Object.assign(valores,{leche_producida:sum(o,'litros'),leche_aceptada:sum(r,'aceptada_litros'),leche_retiro:sum(o,'retiro_litros'),leche_rechazada:sum(r,'rechazada_litros'),vacas_retiro:new Set(dataset.tratamientos.filter(t=>t.desde<=corte&&t.hasta>=corte).map(t=>t.animal)).size})
  }
  return valores[id]
}
export function crearEjecutor({ escenario, db, dataset = DATASET_SINTETICO }) {
  const sintetico = esTableroEnlazado(escenario.id)
  const memo = new Map()
  const tablero = (v) => {
    const clave = JSON.stringify(v)
    if (!memo.has(clave)) memo.set(clave, tableroSintetico(v, dataset))
    return memo.get(clave)
  }
  const baseUci = async (plan, p) => {
    const filtros = {}
    const id = plan.metrica === 'unidades' ? 'unidades_firmadas' : 'valor_neto_lineas'
    const metrica = { id, ...escenario.metricas[id] }
    if (plan.variables.foco === 'pais_principal') {
      // El líder se resuelve en el período ACTUAL y se conserva para la comparación.
      const actual = resolverVariables(plan.variables, escenario.cobertura).actual
      const ranking = await consultas.desglose(db, { metrica: { id: 'valor_neto_lineas', ...escenario.metricas.valor_neto_lineas }, dimension: 'pais', desde: actual.desde, hasta_exclusivo: actual.hasta, filtros: {}, limite: 1, orden: 'desc', convertir: Boolean(escenario.conversion) })
      if (!ranking.filas[0]) return null
      filtros.pais = ranking.filas[0].id
    }
    return { metrica, desde: p.desde, hasta_exclusivo: p.hasta, filtros, convertir: Boolean(escenario.conversion) }
  }
  const ejecutar = async (id, plan) => {
    if (!buscarCapacidades(escenario, plan.dominio, plan.metrica).some((c) => c.id === id)) throw new Error('Herramienta fuera del registro o no disponible.')
    const r = resolverVariables(plan.variables, escenario.cobertura)
    if (!r.actual) return { id, estado: 'sin_datos', verificado: false, limite: 'No hay período completo cubierto.' }
    const unidad = METRICAS[plan.metrica].unidad === 'moneda' ? escenario.moneda : METRICAS[plan.metrica].unidad
    const procedencia = { escenario: escenario.id, naturaleza: escenario.naturaleza_datos, fuente: escenario.fuente.nombre, metrica: plan.metrica, definicion: METRICAS[plan.metrica].nombre, unidad, periodo: r.actual, comparacion: r.anterior, filtros: plan.variables, corte: corteDe(r.actual) }
    const salida = (datos, verificado = true) => ({ id, estado: verificado ? 'verificado' : 'sin_datos', verificado, procedencia, datos })
    if (!sintetico) {
      const base = await baseUci(plan, r.actual)
      if (!base) return salida({ limite: 'No hay país líder en el período.' }, false)
      if (id === 'get_kpi') {
        const d = await consultas.total(db, base)
        return salida({ valor: d.valor, cobertura: d.estado_cobertura, tabla: d.tabla }, d.valor != null && d.estado_cobertura === 'completo')
      }
      if (id === 'get_timeseries') {
        const d = await consultas.serie(db, base), total = await consultas.total(db, base)
        if (d.puntos.some((p) => p.valor == null) || !concilia(d.puntos.map((p) => p.valor), total.valor)) throw new Error('Serie UCI no concilia.')
        return salida({ puntos: d.puntos, total: total.valor, tabla: d.tabla })
      }
      if (id === 'compare_periods') {
        if (!r.anterior) return salida({ limite: r.motivoComparacion }, false)
        const a = await consultas.total(db, base), b = await consultas.total(db, { ...base, desde: r.anterior.desde, hasta_exclusivo: r.anterior.hasta })
        return salida({ actual: a.valor, anterior: b.valor, diferencia: diferencia(a.valor, b.valor), variacion_pct: cambio(a.valor, b.valor), unidad_diferencia: unidad })
      }
      if (!['pais', 'producto'].includes(plan.entidad)) return salida({ limite: 'UCI no tiene ranking validado de clientes o sucursales.' }, false)
      const d = await consultas.desglose(db, { ...base, dimension: plan.entidad, limite: 6, orden: plan.orden_ranking === 'asc' ? 'asc' : 'desc', comparacion: r.anterior ? { desde: r.anterior.desde, hasta_exclusivo: r.anterior.hasta } : null })
      if (!concilia([...d.filas.map((f) => f.valor), d.resto], d.total)) throw new Error('Ranking UCI no concilia.')
      return salida({ filas: d.filas.map((f) => ({ id: f.id, nombre: f.nombre ?? f.descripcion ?? f.codigo, valor: f.valor, anterior: f.valor_comparacion })), total: d.total, resto: d.resto })
    }
    const t = tablero(plan.variables), g = t.graficos
    if (id === 'get_recent_sales') {
      const facturas = plan.periodo_explicito ? dataset.facturas.filter(f => en(f.fecha, r.actual)) : dataset.facturas
      if (!plan.periodo_explicito) {
        procedencia.periodo = { desde: dataset.cobertura.primer_dia, ultimo_dia: dataset.cobertura.ultimo_dia, corto: 'toda la cobertura' }
        procedencia.corte = dataset.cobertura.ultimo_dia
        procedencia.comparacion = null
        procedencia.filtros = { alcance: 'toda_la_cobertura', limite: 8 }
      }
      const filas = [...facturas].sort((a, b) => b.fecha.localeCompare(a.fecha) || b.id.localeCompare(a.id)).slice(0, 8)
      return salida({ filas: filas.map(f => ({ id: f.id, fecha: f.fecha, sucursal: f.sucursal, cliente: f.cliente, valor: f.venta })), alcance: plan.periodo_explicito ? r.actual.corto : 'toda la cobertura', orden: 'fecha descendente, identificador descendente' }, filas.length > 0)
    }
    const actual = metricaSintetica(dataset, r.actual, plan.metrica)
    if (id === 'get_kpi') {
      const g = tablero(plan.variables).graficos
      const objetivo = plan.metrica === 'venta' ? g.meta : plan.metrica === 'margen' ? g.parametros.margen_meta : null
      const meta = actual != null && Number.isFinite(objetivo) && objetivo > 0 ? { actual, objetivo, porcentaje: actual / objetivo * 100, unidad, periodo: r.actual.corto, fuente: plan.metrica === 'venta' ? 'Presupuesto de ventas sintético' : 'Meta de margen del escenario sintético' } : null
      return salida({ valor: actual, meta, ...(actual == null ? { limite: 'No hay una medición de esa métrica con esa granularidad y fecha; no se interpoló un valor mensual.' } : {}) }, actual != null)
    }
    if (id === 'compare_periods') {
      if (!r.anterior) return salida({ limite: r.motivoComparacion }, false)
      const anterior = metricaSintetica(dataset, r.anterior, plan.metrica)
      if (actual == null || anterior == null) return salida({ limite: 'Falta una medición en uno de los dos períodos; no se sustituyó por cero.' }, false)
      return salida({ actual, anterior, diferencia: actual - anterior, variacion_pct: cambio(actual, anterior), unidad_diferencia: unidad === '%' ? 'pp' : unidad })
    }
    if (id === 'get_timeseries') {
      const puntos = []
      for (let mes = r.actual.desde; mes < r.actual.hasta;) {
        const desde = mes, f = new Date(`${mes}T00:00:00Z`)
        const siguiente = r.actual.dias ? Date.parse(mes) + 86400000 : Date.UTC(f.getUTCFullYear(), f.getUTCMonth() + 1, 1)
        mes = new Date(Math.min(siguiente, Date.parse(r.actual.hasta))).toISOString().slice(0, 10)
        puntos.push({ fecha: desde, valor: metricaSintetica(dataset, { desde, hasta: mes, ...(r.actual.dias ? { dias: 1 } : {}) }, plan.metrica) })
      }
      const aditiva = ['venta', 'costo', 'unidades', 'pagos', 'ebitda','leche_producida','leche_aceptada','leche_retiro','leche_rechazada'].includes(plan.metrica)
      if (aditiva && sum(puntos, 'valor') !== actual) throw new Error('Serie sintética no concilia.')
      return salida({ puntos, total: actual, agregacion: aditiva ? 'suma' : 'razón o saldo al corte, no sumar' }, puntos.every((p) => p.valor != null))
    }
    if (id === 'detect_stockout') return salida({ horizonte_dias: 31, modelo: 'stock − demanda diaria observada + recepciones programadas', filas: g.skus.map((s) => ({ id: s.code, nombre: s.name, stock: s.stock, demanda: s.demand, cobertura_dias: s.cover, dia_quiebre: s.outDay, recepcion: s.next })), naturaleza_resultado: 'proyeccion_condicional, no hecho futuro' })
    if (id === 'rank_entities') {
      let filas, total = actual
      if (plan.dominio === 'ventas') {
        const fs = registrosPeriodo(dataset,'facturas',r.actual), ls = registrosPeriodo(dataset,'lineas',r.actual)
        const origen = plan.entidad === 'producto' ? ls : fs
        const campo = plan.entidad === 'producto' ? 'nombre_producto' : plan.entidad === 'cliente' ? 'cliente' : plan.entidad === 'sucursal' ? 'sucursal' : null
        if (!campo) return salida({ limite: 'El escenario sintético no tiene países.' }, false)
        if (plan.metrica === 'unidades' && plan.entidad !== 'producto') {
          if (plan.entidad !== 'sucursal') return salida({ limite: 'Las unidades por cliente no tienen capacidad registrada.' }, false)
          filas = [...Map.groupBy(ls, (l) => l.sucursal)].map(([nombre, xs]) => ({ nombre, valor: sum(xs, 'cantidad') }))
        } else filas = [...Map.groupBy(origen, (x) => x[campo])].map(([nombre, xs]) => ({ nombre, valor: sum(xs, plan.metrica === 'unidades' ? 'cantidad' : plan.entidad === 'producto' ? 'valor' : 'venta') }))
      } else if (plan.dominio === 'cobranza') {
        if (plan.metrica === 'pagos') return salida({ limite: 'No hay ranking de pagos por entidad implementado.' }, false)
        if (plan.entidad !== 'cliente') return salida({ limite: 'La cartera se desglosa por cliente.' }, false)
        filas = [...Map.groupBy(g.cartera.filter((f) => plan.metrica !== 'vencida' || f.vencimiento < g.corte), (f) => f.cliente)].map(([nombre, xs]) => ({ nombre, valor: sum(xs, 'saldo') }))
      } else if (plan.dominio === 'inventario') {
        if (plan.entidad !== 'producto') return salida({ limite: 'El ranking de inventario usa productos.' }, false)
        filas = g.skus.map((s) => ({ nombre: s.name, valor: sum(g.stock.filter((x) => x.codigo_producto === s.code), (x) => x.final * x.costo_unitario) }))
      } else {
        if (!['producto', 'sucursal'].includes(plan.entidad) || plan.metrica !== 'margen') return salida({ limite: 'El ranking de rentabilidad disponible es margen por producto o sucursal.' }, false)
        filas = (plan.entidad === 'producto' ? g.productos : g.sucursales).map((x) => ({ nombre: x.nombre, valor: x.margen }))
        total = null // Los porcentajes de margen no son aditivos.
      }
      if (total != null && Math.abs(sum(filas, 'valor') - total) > 0.000001) throw new Error('Ranking sintético no concilia.')
      const orden = plan.orden_ranking === 'asc' ? 'asc' : 'desc'
      filas.sort((a, b) => (orden === 'asc' ? a.valor - b.valor : b.valor - a.valor) || a.nombre.localeCompare(b.nombre))
      return salida({ orden, filas: filas.slice(0, 6), total, resto: total == null ? null : total - sum(filas.slice(0, 6), 'valor') })
    }
    if (!r.anterior) return salida({ limite: r.motivoComparacion }, false)
    if (plan.dominio === 'rentabilidad') {
      if (plan.metrica !== 'margen') return salida({ limite: 'El puente implementado explica margen bruto; no explica EBITDA ni descuentos por proveedor.' }, false)
      const a = registrosPeriodo(dataset,'facturas',r.actual), b = dataset.facturas.filter((f) => en(f.fecha, r.anterior))
      const va = sum(a, 'venta'), vb = sum(b, 'venta'), ca = sum(a, 'costo'), cb = sum(b, 'costo')
      const filas = [{ nombre: 'Variación de venta neta', contribucion: va - vb }, { nombre: 'Variación de costo de venta', contribucion: cb - ca }]
      if (sum(filas, 'contribucion') !== va - ca - (vb - cb)) throw new Error('Puente de margen no concilia.')
      return salida({ filas, diferencia_margen_bruto: va - ca - (vb - cb), unidad_contribucion: escenario.moneda, naturaleza_resultado: 'identidad contable, no causa', margen_actual_pct: actual, margen_anterior_pct: metricaSintetica(dataset, r.anterior, 'margen') })
    }
    if (plan.metrica !== 'venta') return salida({ limite: 'El análisis de contribuciones y anomalías implementado usa venta neta por sucursal.' }, false)
    const actuales = dataset.facturas.filter(f => en(f.fecha, r.actual)), previas = dataset.facturas.filter(f => en(f.fecha, r.anterior))
    const nombres = [...new Set([...actuales, ...previas].map(f => f.sucursal))]
    const filas = nombres.map(nombre => {
      const a = sum(actuales.filter(f => f.sucursal === nombre), 'venta'), b = sum(previas.filter(f => f.sucursal === nombre), 'venta')
      return { nombre, actual: a, anterior: b, diferencia: a - b, variacion_pct: cambio(a, b) }
    }).sort((a, b) => a.diferencia - b.diferencia)
    const anterior = metricaSintetica(dataset, r.anterior, 'venta')
    if (sum(filas, 'actual') !== actual || sum(filas, 'anterior') !== anterior || sum(filas, 'diferencia') !== actual - anterior) throw new Error('Contribuciones no concilian.')
    return salida(id === 'detect_anomalies' ? { umbral_pct: -25, filas: filas.filter((f) => f.variacion_pct != null && f.variacion_pct <= -25 && f.diferencia < 0), naturaleza_resultado: 'señal por umbral de prueba; no causa' } : { filas, diferencia_total: actual - anterior, naturaleza_resultado: 'contribución aritmética; no causa operacional' })
  }
  ejecutar.observar = async (variables, vista) => {
    if (sintetico) {
      const t = tablero(variables)
      return { business: { actual: t.indicadores, objetivos: t.graficos.parametros, presupuesto_ventas: t.graficos.meta, definiciones: t.graficos.procedencia }, componentes: [vista === 'agente' ? 'AnalyticsCard' : { ventas: 'SalesView', rentabilidad: 'ProfitView', cobranza: 'CollectionsView', inventario: 'InventoryView' }[vista]] }
    }
    const dominio = ONTOLOGIA[vista] ? vista : 'ventas'
    if (dominio !== 'ventas') return { business: { actual: null, limite: 'La fuente UCI no mide este dominio.' } }
    const d = await ejecutar('get_kpi', { dominio: 'ventas', metrica: 'venta', variables })
    return { business: { actual: d.verificado ? { valor_neto_lineas: d.datos.valor, moneda: escenario.moneda } : null, advertencias: escenario.advertencias } }
  }
  ejecutar.ultimaFecha = (dominio, metrica) => {
    if (!sintetico) return null
    const registros = dominio === 'cobranza' ? dataset.pagos : dominio === 'inventario' ? [] : dataset.facturas
    return registros.map(r => r.fecha).filter(f => f <= dataset.cobertura.ultimo_dia).sort().at(-1) ?? (dominio === 'inventario' ? dataset.cobertura.ultimo_dia : null)
  }
  ejecutar.mediciones={inventario_diario:Boolean(dataset.stock_diario?.length)}
  return ejecutar
}
