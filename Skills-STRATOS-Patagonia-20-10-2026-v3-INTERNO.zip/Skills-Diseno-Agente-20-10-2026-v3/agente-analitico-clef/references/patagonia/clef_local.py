"""Carga local de Clef-Flash para una GPU de 12 GB compartida y respuesta SystemOne con dispositivo explícito.

Lo usan evaluar.py y servicio.py. Equivale a load_release_model y systemone de la revisión oficial
(17f0b0ad64efb65d273590632833508766b2aae6) con dos diferencias, documentadas abajo: ubicación de pesos y dispositivo.
"""

import sys
from pathlib import Path


class FilasEnCpu:
    """Matriz de salida en CPU: el cabezal solo consulta las filas de los tokens de cada opción."""

    def __init__(self, peso, dispositivo, dtype):
        self.peso, self.dispositivo, self.dtype = peso, dispositivo, dtype

    def __getitem__(self, indices):
        return self.peso[indices.to("cpu")].to(self.dispositivo, self.dtype)


def cargar(ruta, torch, BitsAndBytesConfig):
    sys.path.insert(0, str(ruta))
    """Equivale a load_release_model de la revisión oficial, con otra ubicación de pesos para una GPU de 12 GB.

    bitsandbytes no cuantiza embeddings ni lm_head (248.320 × 4096 cada uno, ~2 GB en BF16): quedan en CPU junto con
    el codificador visual, que una entrada de texto no usa. Las 32 capas del modelo de lenguaje van a la GPU en NF4.
    Los pesos y el cálculo son los mismos; cambia dónde vive cada tensor.
    """
    import json as _json
    from types import SimpleNamespace
    from safetensors.torch import load_file
    from transformers import AutoProcessor, Qwen3_5ForConditionalGeneration
    from joint_schema_model import ClefModel, JointSchemaHead

    cuantizacion = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.bfloat16,
                                      bnb_4bit_use_double_quant=True, llm_int8_enable_fp32_cpu_offload=True)
    ubicacion = {
        "model.visual": "cpu",
        "model.language_model.embed_tokens": "cpu",
        "model.language_model.layers": "cuda:0",
        "model.language_model.norm": "cuda:0",
        "model.language_model.rotary_emb": "cuda:0",
        "lm_head": "cpu",
    }
    backbone = Qwen3_5ForConditionalGeneration.from_pretrained(ruta, dtype=torch.bfloat16, device_map=ubicacion,
                                                               quantization_config=cuantizacion)
    backbone.config.use_cache = False

    # accelerate deja los módulos en CPU como tensores «meta» con ganchos que los suben a la GPU en cada paso
    # (2 GB transitorios). En su lugar se leen las dos matrices del safetensors a RAM y se usan desde allí.
    from accelerate.hooks import remove_hook_from_module
    from safetensors import safe_open

    indice = _json.loads((ruta / "model.safetensors.index.json").read_text())["weight_map"]

    def leer(clave):
        with safe_open(ruta / indice[clave], framework="pt", device="cpu") as archivo:
            return archivo.get_tensor(clave).to(torch.bfloat16)

    class EmbeddingEnCpu(torch.nn.Module):
        def __init__(self, peso):
            super().__init__()
            self.peso = peso

        def forward(self, ids):
            return torch.nn.functional.embedding(ids.to("cpu"), self.peso).to("cuda:0")

    lenguaje = backbone.model.language_model
    # El gancho del modelo de lenguaje toma como dispositivo de ejecución el de su primer parámetro (el embedding
    # «meta») y movería allí los input_ids. Las capas en GPU conservan sus propios ganchos.
    remove_hook_from_module(lenguaje)
    remove_hook_from_module(lenguaje.embed_tokens)
    lenguaje.embed_tokens = EmbeddingEnCpu(leer("model.language_model.embed_tokens.weight"))
    salida = FilasEnCpu(leer("lm_head.weight"), torch.device("cuda:0"), torch.bfloat16)
    backbone.get_output_embeddings = lambda: SimpleNamespace(weight=salida)
    cabezal = JointSchemaHead(**_json.loads((ruta / "joint_head_config.json").read_text()))
    cabezal.load_state_dict(load_file(ruta / "joint_head.safetensors"), strict=True)
    cabezal = cabezal.to(device="cuda:0", dtype=torch.bfloat16)
    return ClefModel(backbone, cabezal).eval(), AutoProcessor.from_pretrained(ruta)


def responder(modelo, procesador, solicitud, torch, max_tokens=16384):
    """Igual que systemone() oficial, pero con el dispositivo explícito: systemone toma el del primer parámetro del
    modelo, que aquí es el codificador visual en CPU.

    max_tokens es el de la revisión oficial (16.384). encode_record recorta el ESTADO en silencio cuando no cabe y
    conserva las preguntas: una decisión sobre un estado recortado no puede presentarse como válida, así que se
    declara en usage.state_truncated para que el cliente la rechace."""
    from joint_schema_model import QUESTION_TYPES, collate_records, encode_record, systemone_answer

    preguntas = solicitud.get("questions")
    if not isinstance(solicitud.get("model"), str) or "state" not in solicitud:
        raise ValueError("model y state son obligatorios")
    if not isinstance(preguntas, dict) or not preguntas or len(preguntas) > 64:
        raise ValueError("se requieren entre 1 y 64 preguntas")
    for id_pregunta, pregunta in preguntas.items():
        if pregunta.get("type") not in QUESTION_TYPES:
            raise ValueError(f"{id_pregunta}: type debe ser noul, choice o score")
        if pregunta["type"] != "noul" and not pregunta.get("criteria"):
            raise ValueError(f"{id_pregunta}: criteria no puede estar vacío")
    codificado = encode_record(procesador.tokenizer, solicitud, max_length=max_tokens, processor=procesador)
    with torch.inference_mode():
        logits = modelo(collate_records([codificado], procesador.tokenizer.pad_token_id, torch.device("cuda:0")))[0]
    respuestas = {
        pregunta.question_id: systemone_answer(preguntas[pregunta.question_id], dict(zip(pregunta.option_ids, valores.float().softmax(-1).tolist())))
        for pregunta, valores in zip(codificado.questions, logits)
    }
    return {"model": solicitud["model"], "answers": respuestas, "usage": {"input_tokens": len(codificado.input_ids), "output_tokens": 0, "max_length": max_tokens, "state_truncated": len(codificado.input_ids) >= max_tokens}}
