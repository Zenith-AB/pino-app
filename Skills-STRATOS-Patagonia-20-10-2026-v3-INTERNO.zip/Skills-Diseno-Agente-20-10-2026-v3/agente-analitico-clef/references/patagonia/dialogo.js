import { randomUUID } from 'node:crypto'

export const LIFECYCLE = Object.freeze(['OPEN', 'WAITING_CLARIFICATION', 'READY', 'EXECUTING', 'COMPLETED', 'CANCELLED', 'FAILED'])
const terminal = new Set(['COMPLETED', 'CANCELLED', 'FAILED'])
const transitions = { OPEN: ['WAITING_CLARIFICATION', 'READY', 'CANCELLED', 'FAILED'], WAITING_CLARIFICATION: ['READY', 'CANCELLED', 'FAILED'], READY: ['EXECUTING', 'WAITING_CLARIFICATION', 'FAILED', 'CANCELLED'], EXECUTING: ['COMPLETED', 'FAILED'] }
export function transition(request, next) {
  if (!LIFECYCLE.includes(next) || request.lifecycle !== next && !transitions[request.lifecycle]?.includes(next)) throw new Error('INVALID_REQUEST_TRANSITION')
  return { ...request, lifecycle: next }
}
export function openRequest(previous, { newTopic = false, id = randomUUID(), turn = 1 } = {}) {
  if (previous && !terminal.has(previous.lifecycle) && !newTopic) return previous
  return { id, lifecycle: 'OPEN', turn, slots: {}, provenance: {}, filters: {}, replaces: previous && !terminal.has(previous.lifecycle) ? { id: previous.id, lifecycle: 'CANCELLED' } : null }
}
export function clarificationContract(request, field, allowedValues, { reason = 'required_by_capability', multivalued = false, metaValues = [], id = randomUUID() } = {}) {
  if (!field || !Array.isArray(allowedValues) || !Array.isArray(metaValues)) throw new Error('INVALID_CLARIFICATION_CONTRACT')
  return { active: true, clarification_id: id, request_id: request.id, field, allowed_values: [...new Set(allowedValues)], required: true, reason, multivalued, meta_values: metaValues }
}
const calendarDate = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value + 'T00:00:00Z')) && new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) === value
const normalize = text => String(text).trim().toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu, '')
const metaLabels = { todo: 'all', todos: 'all', todas: 'all', ninguno: 'none', ninguna: 'none', ambos: 'both', ambas: 'both', anterior: 'keep_previous', 'no aplica': 'not_applicable', 'no se': 'unknown' }
// Exact registered option/label lookup is a selector protocol, not intent classification.
export function resolvePending(contract, message, labels = {}) {
  if (!contract?.active) return { consumed: false }
  const text = normalize(message)
  if (contract.field === 'date' && !contract.allowed_values.length && calendarDate(message.trim())) return { consumed: true, field: 'date', value: message.trim(), clarification_id: contract.clarification_id, request_id: contract.request_id }
  const value = contract.allowed_values.find(v => normalize(v) === text || (labels[v] ?? []).some(label => normalize(label) === text))
  if (value !== undefined) return { consumed: true, field: contract.field, value, clarification_id: contract.clarification_id, request_id: contract.request_id }
  const meta = metaLabels[text] ?? text
  if (meta === 'unknown') return { consumed: false, recognized: true, value: 'unknown' }
  if (!contract.meta_values.includes(meta)) return { consumed: false }
  if (meta === 'both' && (!contract.multivalued || contract.allowed_values.length !== 2)) return { consumed: false }
  if (meta === 'all' && !contract.multivalued) return { consumed: false }
  return { consumed: true, field: contract.field, value: meta, clarification_id: contract.clarification_id, request_id: contract.request_id }
}
export function requiredSlots(capability, slots) {
  if (!capability || !Array.isArray(capability.required_slots) || !Array.isArray(capability.optional_slots)) throw new Error('MISSING_CAPABILITY_CONTRACT')
  return capability.required_slots.filter(field => slots[field] === undefined || slots[field] === null || ['unknown', ''].includes(slots[field]) || ['none', 'not_applicable'].includes(slots[field]) && !(capability.allowed_values?.[field] ?? []).includes(slots[field]))
}
export function assertClarificationConsumed(previous, resolution, next) {
  if (resolution.consumed && previous?.active && next?.active && previous.request_id === next.request_id && previous.field === next.field) throw new Error('CRITICAL_CLARIFICATION_LOOP')
}
export const SLOT_FIELDS = Object.freeze(['domain', 'metric', 'metric_group', 'intent', 'entity', 'entity_id', 'period', 'date', 'comparison_period', 'ranking', 'scope'])
export function reduceState(previous = {}, delta = {}, { turn = 1, source = 'clef', domains = {}, defaults = {}, newTopic = false } = {}) {
  const slots = { ...previous }, provenance = { ...(previous.provenance ?? {}) }
  for (const key of Object.keys(slots)) if (!SLOT_FIELDS.includes(key)) delete slots[key]
  if (newTopic) for (const field of SLOT_FIELDS) { delete slots[field]; delete provenance[field] }
  const nextDomain = delta.domain && !['keep', 'keep_previous', 'unknown'].includes(delta.domain) ? delta.domain : slots.domain
  const changedDomain = nextDomain && nextDomain !== slots.domain
  if (changedDomain) {
    if (slots.metric && domains[slots.metric] !== nextDomain) { delete slots.metric; delete provenance.metric }
    if (nextDomain === 'inventario' || slots.domain === 'inventario') for (const field of ['entity', 'entity_id', 'ranking', 'intent', 'date', 'metric_group']) { delete slots[field]; delete provenance[field] }
    if (slots.intent === 'due' && nextDomain !== 'cobranza') for (const field of ['intent', 'date']) { delete slots[field]; delete provenance[field] }
  }
  for (const field of SLOT_FIELDS) {
    let value = delta[field]
    if (value === undefined || value === 'keep' || value === 'keep_previous') { if (slots[field] !== undefined) provenance[field] = { value: slots[field], source: 'inherited', turn, origin: previous.provenance?.[field]?.origin ?? previous.provenance?.[field]?.turn ?? turn - 1 }; continue }
    if (value === 'unknown') continue
    if (field === 'date' && value != null && !['none', 'not_applicable'].includes(value) && !calendarDate(value)) throw new Error('INVALID_DATE_SLOT')
    if (value === null || value === 'none' && field !== 'scope') { delete slots[field]; delete provenance[field]; continue }
    if (field === 'metric' && nextDomain && domains[value] && domains[value] !== nextDomain) continue
    // A ranking refinement chooses an entity, not a new metric group.
    if (field === 'metric' && value === 'branch_performance' && delta.intent === 'rank') continue
    if (field === 'entity' && slots.entity && slots.entity !== value) { delete slots.entity_id; delete provenance.entity_id }
    slots[field] = value; provenance[field] = { value, source, turn, origin: turn }
  }
  if (slots.intent === 'rank' && slots.metric === 'branch_performance') { delete slots.metric; delete provenance.metric }
  if (!slots.metric && slots.domain && defaults[slots.domain]) { slots.metric = defaults[slots.domain]; provenance.metric = { value: slots.metric, source: 'default', turn, origin: turn } }
  if (slots.entity_id) { slots.entity = 'sucursal'; delete slots.ranking; if (slots.intent === 'rank') slots.intent = 'inspect' }
  if (slots.ranking && delta.intent === 'inspect' && delta.ranking === 'keep') slots.intent = 'rank'
  if (slots.intent === 'due' && slots.domain === 'cobranza') slots.metric = 'vencida'
  // Provenance must describe the final normalized value, never an overwritten candidate.
  for (const field of SLOT_FIELDS) if (slots[field] !== undefined && provenance[field]?.value !== slots[field]) provenance[field] = { value: slots[field], source: 'default', turn, origin: turn }
  for (const field of Object.keys(provenance)) if (slots[field] === undefined) delete provenance[field]
  return { ...slots, provenance }
}

// Formal selector grammar over registered values; no synonyms, topic dictionary or semantic fallback.
export function resolveFieldSelector(message, previous, parsed, { domains = [], entities = {}, monthLabels = [] } = {}) {
  let text = normalize(message).replace(/[¿?]/g, '').trim()
  const prefixed = /^(ahora |no,? |y |solo |por )/.test(text)
  text = text.replace(/^(ahora |no,? |y |solo |por )/, '').trim()
  const type = previous.metric || previous.intent ? 'REFINEMENT' : 'NEW_REQUEST'
  const domain = domains.find(v => normalize(v) === text)
  if (domain) return { domain, metric: 'keep', intent: 'keep', entity: 'keep', ranking: 'keep', _turn_type: type }
  const entity = Object.keys(entities).find(v => normalize(v) === text || entities[v].some(label => normalize(label) === text))
  if (entity) return { entity, intent: 'rank', ranking: previous.ranking ?? 'best', _turn_type: type }
  if (parsed.period && monthLabels.some(label => normalize(label) === text)) return { period: parsed.period, _turn_type: prefixed && normalize(message).startsWith('no') ? 'CORRECTION' : type }
  if (parsed.entity_id && /^sucursal\s+(?:no\.?\s*|n[ºo]\s*|numero\s*|#\s*)?\d+$/.test(text)) return { entity: 'sucursal', entity_id: parsed.entity_id, intent: 'inspect', ranking: 'none', _turn_type: type }
  return null
}
