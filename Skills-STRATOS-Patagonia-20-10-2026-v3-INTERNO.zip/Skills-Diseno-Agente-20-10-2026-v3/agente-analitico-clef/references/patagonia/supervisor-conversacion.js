export const newTurnId = () => globalThis.crypto.randomUUID?.() ?? Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, '0')).join('')
const randomUUID = newTurnId

export const LIMITS = Object.freeze({ plannerMs: 30000, toolMs: 6000, judgeMs: 10000, turnMs: 55000, maxAttempts: 2, clarificationTurnTTL: 2, maxQueued: 8, maxHistory: 128, historyTTL: 30 * 60000 })
const closed = new Set(['RESPONDED', 'FAILED_RECOVERABLE', 'FAILED_FATAL', 'CANCELLED', 'TIMED_OUT', 'SUPERSEDED'])
export class Failure extends Error {
  constructor(type, { recoverable = true, phase, cause } = {}) { super(type, { cause }); this.error_type = type; this.recoverable = recoverable; this.phase = phase }
}
// Deadline releases the caller even if an adapter ignores AbortSignal. Late results never commit.
// Actual cancellation of DB/model resources belongs to the adapter; no automatic write retries.
export async function bounded(work, { ms, signal, phase }) {
  const controller = new AbortController()
  let timer, abort
  const stop = new Promise((_, reject) => {
    abort = () => { controller.abort(); reject(new Failure('CANCELLED', { phase })) }
    if (signal?.aborted) abort()
    else signal?.addEventListener('abort', abort, { once: true })
    timer = setTimeout(() => { controller.abort(); reject(new Failure(`${phase}_TIMEOUT`, { phase })) }, ms)
  })
  try { return await Promise.race([stop, Promise.resolve().then(() => {
    if (controller.signal.aborted) throw new Failure('CANCELLED', { phase })
    return work(controller.signal)
  })]) }
  finally { clearTimeout(timer); signal?.removeEventListener('abort', abort) }
}
const normalized = message => message.trim().toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu, '').replace(/[.!?¿]/g, '')
// Explicit control protocol only; business intent still belongs to Clef.
export function controlTurn(message) {
  const text = normalized(message)
  if (['cancel', 'cancela', 'olvida eso', 'dejalo', 'no importa', 'dejemos eso'].includes(text)) return 'CANCEL'
  if (['reinicia esta consulta', 'nueva consulta', 'mejor otra cosa'].includes(text)) return 'RESET_REQUEST'
  if (/^(mejor muestrame |ahora quiero |nono,? muestrame |olvida eso[,;] )/.test(text)) return 'INTERRUPT'
  return 'CONTINUE'
}
const copy = value => structuredClone(value)
const clearRequest = state => ({ ...state, pending_clarification: null, pending: null, active_request: null })

export class ConversationSupervisor {
  constructor({ actor, scenario, initialState = {}, run, limits = {}, stage = 'G', onTrace = () => {} }) {
    if (!actor || !scenario || typeof run !== 'function') throw new Failure('INVALID_SESSION_OWNER', { recoverable: false })
    this.actor = actor; this.scenario = scenario; this.run = run; this.limits = { ...LIMITS, ...limits }; this.stage = 'ABCDEFG'.indexOf(stage)
    if (this.stage < 1) throw new Failure('INVALID_SUPERVISOR_STAGE')
    this.state = copy(initialState); this.version = 0; this.session = { status: 'READY', last_successful_turn: null }; this.request = null
    this.queue = []; this.history = new Map(); this.running = null; this.counter = 0; this.generation = 0; this.onTrace = onTrace
  }
  snapshot() { return { session: copy(this.session), request: copy(this.request), committed_state: copy(this.state), state_version: this.version, queue_depth: this.queue.length } }
  submit({ message, turn_id = randomUUID(), timestamp = Date.now(), metadata = {} }) {
    if (typeof message !== 'string' || !message.trim() || typeof turn_id !== 'string' || !turn_id || turn_id.length > 128) return Promise.resolve(this.reject(turn_id, 'INVALID_TURN'))
    this.prune()
    if (this.stage >= 6 && this.history.has(turn_id)) {
      const old = this.history.get(turn_id)
      return old.message === message ? old.promise : Promise.resolve(this.reject(turn_id, 'IDEMPOTENCY_CONFLICT'))
    }
    const control = this.stage >= 2 ? controlTurn(message) : 'CONTINUE'
    if (this.stage >= 6 && control !== 'CONTINUE') this.interrupt()
    if (this.queue.length >= this.limits.maxQueued) return Promise.resolve(this.reject(turn_id, 'QUEUE_FULL'))
    if (this.stage >= 6 && this.history.size >= this.limits.maxHistory) {
      const oldest = [...this.history].find(([, record]) => record.done)
      if (oldest) this.history.delete(oldest[0])
      else return Promise.resolve(this.reject(turn_id, 'IDEMPOTENCY_CAPACITY'))
    }
    let resolve
    const promise = new Promise(done => { resolve = done })
    const item = { message, turn_id, request_id: randomUUID(), timestamp, metadata, control, promise, resolve, accepted_turn: ++this.counter }
    if (this.stage >= 6) this.history.set(turn_id, { promise, message, created: Date.now(), done: false })
    this.queue.push(item); this.drain(); return promise
  }
  reject(turn_id, type) { return { turn_id, request_id: randomUUID(), outcome: 'FAILED_RECOVERABLE', accepted: false, session_status: this.session.status, state_version: this.version, error: { error_type: type, recoverable: true }, response: type === 'QUEUE_FULL' ? 'Hay demasiadas consultas pendientes. Vuelve a enviar este mensaje.' : 'No pude aceptar esa consulta. Puedes hacer otra pregunta.' } }
  prune() { for (const [id, item] of this.history) if (item.done && Date.now() - item.created > this.limits.historyTTL) this.history.delete(id) }
  interrupt() {
    this.generation++
    if (this.running) this.running.controller.abort()
    for (const item of this.queue.splice(0)) this.finish(item, { outcome: 'SUPERSEDED', response: 'Consulta reemplazada por una nueva petición.' })
  }
  finish(item, output) {
    if (item.finished) return
    item.finished = true
    const result = { turn_id: item.turn_id, request_id: output.request_id ?? item.request_id, timestamp: item.timestamp, accepted: true, session_status: 'READY', state_version: this.version, ...output }
    this.request = { id: result.request_id, status: result.trace?.request_status ?? result.outcome, turn_id: item.turn_id };
    const record = this.history.get(item.turn_id); if (record) record.done = true
    try { this.onTrace(result.trace ?? { turn_id: item.turn_id, terminal_outcome: result.outcome, new_state_version: this.version }) } catch { /* Logging cannot lock a session. */ }
    item.resolve(result)
  }
  async drain() {
    if (this.running) return
    const item = this.queue.shift(); if (!item) { this.session.status = 'READY'; return }
    const controller = new AbortController(), generation = this.generation
    this.running = { item, controller }; this.session.status = 'PROCESSING'
    try { this.finish(item, await this.process(item, controller.signal, generation)) }
    catch (cause) { this.finish(item, { outcome: 'FAILED_RECOVERABLE', error: { error_type: 'SUPERVISOR_FAILURE', recoverable: true }, response: 'No pude completar esa consulta. Puedes hacer otra pregunta.' }) }
    finally { this.running = null; this.session.status = 'READY'; this.drain() }
  }
  async process(item, signal, generation) {
    const started = performance.now(), previousVersion = this.version, before = copy(this.state)
    let working = copy(before), request_id = item.request_id, output, outcome, error, classification = item.control
    this.request = { id: request_id, status: 'OPEN', turn_id: item.turn_id }
    const trace = { turn_id: item.turn_id, request_id, session_status: ['READY', 'PROCESSING'], previous_state_version: previousVersion, pending_clarification: before.pending_clarification ?? null, interrupt_classification: classification, proposed_delta: null, selected_capability: null, tool_state: 'NOT_RUN', judge_state: 'NOT_RUN' }
    try {
      if (this.stage >= 2) {
        const pending = working.pending_clarification
        const coherent = pending?.active && working.active_request?.id === pending.request_id && working.active_request?.lifecycle === 'WAITING_CLARIFICATION'
        if (pending?.active && (!coherent || item.accepted_turn - (pending.created_turn ?? item.accepted_turn) > this.limits.clarificationTurnTTL)) { working = clearRequest(working); trace.expired_pending = true }
        if (item.control !== 'CONTINUE') { working = clearRequest(working); trace.replaced_request_id = before.active_request?.id ?? null }
      }
      if (item.control === 'CANCEL' || item.control === 'RESET_REQUEST') {
        output = { state_after: working, response: item.control === 'CANCEL' ? 'Consulta cancelada. Puedes hacer otra pregunta.' : 'Consulta reiniciada. Puedes hacer otra pregunta.' }; outcome = 'CANCELLED'
      } else {
        const execute = (runSignal = signal) => this.run({ message: item.message, previous: working, turn: item.accepted_turn, turn_id: item.turn_id, metadata: item.metadata, request_id, signal: runSignal, supervisor: this, stage: this.stage, trace })
        output = this.stage >= 3 ? await bounded(execute, { ms: this.limits.turnMs, signal, phase: 'TURN' }) : await execute()
        if (!output || !output.state_after || typeof output.state_after !== 'object' || !output.status) throw new Failure('MALFORMED_RESULT')
        request_id = output.state_after.active_request?.id ?? request_id
        trace.proposed_delta = output.delta ?? null; trace.selected_capability = output.tool ?? null
        if (this.stage >= 2 && output.status === 'clarify') {
          const next = output.state_after.pending_clarification, old = working.pending_clarification
          if (!next?.active) throw new Failure('INVALID_PENDING_CONTRACT')
          const same = old?.active && old.request_id === next.request_id && old.field === next.field
          if (same && output.pending_consumed) throw new Failure('DIALOGUE_DEADLOCK')
          const attempts = same ? (old.attempts ?? 1) + 1 : 1
          if (attempts > this.limits.maxAttempts) throw new Failure('CLARIFICATION_EXHAUSTED')
          next.attempts = attempts; next.max_attempts = this.limits.maxAttempts; next.created_turn = same ? old.created_turn ?? item.accepted_turn : item.accepted_turn
          if (same) output.response = `Todavía falta precisar ${next.field}. Puedes elegir una opción o hacer otra consulta.`
        }
        outcome = ['answer', 'clarify', 'partial_result'].includes(output.status) ? 'RESPONDED' : output.status === 'blocked' ? 'FAILED_FATAL' : 'FAILED_RECOVERABLE'
      }
      if (signal.aborted || generation !== this.generation || previousVersion !== this.version) throw new Failure('SUPERSEDED')
      if (this.stage >= 5) this.watchdog(output)
      if (this.stage < 4 || ['RESPONDED', 'CANCELLED'].includes(outcome)) { this.state = copy(output.state_after); this.version++ }
      else {
        // A valid no-data answer does not invalidate resolved conversational slots.
        // Retain context only, never a partial result or an active execution.
        this.state = clearRequest(output.status === 'no_data' ? output.state_after : before); this.version++
      }
      if (outcome === 'RESPONDED' && output.status === 'answer') this.session.last_successful_turn = item.turn_id
    } catch (cause) {
      const type = cause.error_type ?? (cause.message === 'STALE_PENDING_CONTRACT' ? 'INVALID_PENDING_CONTRACT' : 'REQUEST_FAILURE')
      outcome = ['CANCELLED', 'SUPERSEDED'].includes(type) ? 'CANCELLED' : type.endsWith('_TIMEOUT') ? 'TIMED_OUT' : cause.recoverable === false ? 'FAILED_FATAL' : 'FAILED_RECOVERABLE'
      error = { error_type: type, recoverable: cause.recoverable !== false, phase: cause.phase }
      if (generation === this.generation && previousVersion === this.version) { this.state = this.stage >= 4 ? clearRequest(before) : clearRequest(working); this.version++ }
      output = { response: outcome === 'CANCELLED' ? 'Consulta cancelada o reemplazada.' : typeof cause.user_message === 'string' ? cause.user_message.slice(0, 400) : 'No pude completar esa consulta. Puedes hacer otra pregunta.' }
    }
    if (!closed.has(outcome)) throw new Failure('INVALID_TERMINAL_OUTCOME')
    trace.request_id = request_id; trace.request_status = output.status === 'clarify' ? 'WAITING_CLARIFICATION' : outcome; trace.terminal_outcome = outcome
    trace.new_state_version = this.version; trace.session_status.push('READY'); trace.error = error ?? null; trace.latency_ms = performance.now() - started
    return { request_id, outcome, error, response: output.response, output, trace }
  }
  watchdog(output) {
    const state = output.state_after, pending = state.pending_clarification
    if (!state || typeof state !== 'object' || Array.isArray(state)) throw new Failure('INVALID_STATE_SCHEMA')
    const active = state.active_request
    if (active && (typeof active.id !== 'string' || !['OPEN', 'READY', 'WAITING_CLARIFICATION', 'EXECUTING', 'COMPLETED', 'FAILED', 'CANCELLED'].includes(active.lifecycle))) throw new Failure('INVALID_REQUEST_SCHEMA')
    if (active?.lifecycle === 'WAITING_CLARIFICATION' && !pending?.active) throw new Failure('INVALID_PENDING_CONTRACT')
    if (pending?.active && (!pending.field || !Array.isArray(pending.allowed_values) || pending.request_id !== state.active_request?.id || state.active_request?.lifecycle !== 'WAITING_CLARIFICATION')) throw new Failure('INVALID_PENDING_CONTRACT')
    if (!pending?.active && ['OPEN', 'READY', 'EXECUTING'].includes(state.active_request?.lifecycle)) throw new Failure('NON_TERMINAL_REQUEST')
    if (state.active_request?.slots && typeof state.active_request.slots !== 'object') throw new Failure('INVALID_STATE_SCHEMA')
  }
  async phase(phase, work, signal, trace) {
    const key = phase === 'TOOL' ? 'tool_state' : phase === 'JUDGE' ? 'judge_state' : 'planner_state'
    trace[key] = 'EXECUTING'
    this.request = { ...this.request, status: { PLANNER: 'PLANNING', TOOL: 'EXECUTING', JUDGE: 'JUDGING' }[phase] }
    try {
      const ms = { PLANNER: this.limits.plannerMs, TOOL: this.limits.toolMs, JUDGE: this.limits.judgeMs }[phase]
      const result = this.stage >= 3 ? await bounded(work, { ms, signal, phase }) : await work(signal)
      trace[key] = 'COMPLETED'; return result
    } catch (cause) { trace[key] = cause.error_type ?? 'FAILED'; throw cause }
  }
}
// Adapter around the existing backend. Exactly one planner and at most one judge.
export function resilientDependencies(deps, { supervisor, signal, trace }) {
  let pre = 0, post = 0, tools = 0
  return { ...deps,
    resolveDelta: args => { if (++pre > 1) throw new Failure('PLANNER_BUDGET_EXCEEDED'); return supervisor.phase('PLANNER', s => deps.resolveDelta({ ...args, signal: s }), signal, trace) },
    execute: (id, frame) => { if (++tools > 1) throw new Failure('TOOL_BUDGET_EXCEEDED'); return supervisor.phase('TOOL', s => deps.execute(id, frame, { signal: s }), signal, trace) },
    ...(deps.judge ? { judge: async args => {
      if (++post > 1) throw new Failure('JUDGE_BUDGET_EXCEEDED')
      try {
        const result = await supervisor.phase('JUDGE', s => deps.judge({ ...args, signal: s }), signal, trace)
        if (typeof result?.evidence_sufficient !== 'boolean') throw new Failure('MALFORMED_JUDGE_RESULT', { phase: 'JUDGE' })
        return result
      }
      catch (cause) {
        if (signal.aborted || supervisor.stage < 3) throw cause
        trace.judge_state = cause.error_type ?? 'JUDGE_FAILURE'
        trace.judge_error = { error_type: cause.error_type ?? 'JUDGE_FAILURE', recoverable: true }
        // Factual lookup/comparison may survive; never synthesize causal interpretation.
        return { evidence_sufficient: ['inspect', 'compare'].includes(args.resolved_request.intent), degraded: true }
      }
    } } : {}),
  }
}
