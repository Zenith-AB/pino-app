// Gramática de calendario: resuelve fechas, nunca intención empresarial ni cifras.
const MESES = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre']
const DAY = 86400000
const iso = t => new Date(t).toISOString().slice(0,10)
const date = s => /^\d{4}-\d{2}-\d{2}$/.test(s) && Number.isFinite(Date.parse(s)) && iso(Date.parse(s)) === s
const monthStart = (year, month) => `${year}-${String(month).padStart(2,'0')}-01`
export const hoyOperacional = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date())
// Períodos EN CURSO: referencias vivas («este año», «este mes») que se resuelven cada vez contra el reloj operacional y,
// en resolverPeriodo, contra la cobertura. Al llegar registros nuevos, la misma referencia abarca más días.
export function periodoEnCurso(id, hoy = hoyOperacional()) {
  const tipo = /^en_curso:(anio|mes)$/.exec(id ?? '')?.[1]
  if (!tipo || !date(hoy)) return null
  const desde = tipo === 'anio' ? `${hoy.slice(0,4)}-01-01` : `${hoy.slice(0,7)}-01`
  const corto = tipo === 'anio' ? `${hoy.slice(0,4)} a la fecha` : `${MESES[Number(hoy.slice(5,7))-1].slice(0,3)}. ${hoy.slice(0,4)} a la fecha`
  return { desde, hasta: iso(Date.parse(hoy)+DAY), en_curso: tipo, corto, titulo: corto, rotulo: tipo === 'anio' ? 'Año en curso' : 'Mes en curso' }
}
export function opcionTemporal(id) {
  if (typeof id !== 'string') return null
  if (id.startsWith('en_curso:')) return periodoEnCurso(id)
  if (/^mes:\d{4}-(0[1-9]|1[0-2])$/.test(id)) {
    const [year,month]=id.slice(4).split('-').map(Number)
    return { desde: monthStart(year,month), hasta: iso(Date.UTC(year,month,1)), meses: 1, corto: `${MESES[month-1].slice(0,3)}. ${year}`, titulo: `${MESES[month-1]} de ${year}`, rotulo: `${MESES[month-1]} ${year}` }
  }
  if (/^dia:/.test(id) && date(id.slice(4))) {
    const desde=id.slice(4)
    return { desde, hasta:iso(Date.parse(desde)+DAY), dias:1, corto:desde, titulo:desde, rotulo:desde }
  }
  const match=/^rango:(\d{4}-\d{2}-\d{2}):(\d{4}-\d{2}-\d{2})$/.exec(id)
  if (match && date(match[1]) && date(match[2]) && match[1]<match[2] && Date.parse(match[2])-Date.parse(match[1])<=366*DAY) {
    const [,desde,hasta]=match,corto=`${desde} a ${iso(Date.parse(hasta)-DAY)}`
    const meses=(Number(hasta.slice(0,4))-Number(desde.slice(0,4)))*12+Number(hasta.slice(5,7))-Number(desde.slice(5,7))
    return {desde,hasta,...(desde.endsWith('-01') && hasta.endsWith('-01') ? { meses } : {dias:(Date.parse(hasta)-Date.parse(desde))/DAY}),corto,titulo:corto,rotulo:corto}
  }
  return null
}
export function interpretarCalendario(texto, {cobertura, activo, ultimaFecha, anioReferencia, modoActual = false, fechaActual = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Santiago', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date()), anioActual = Number(fechaActual.slice(0,4))}) {
  const numeros={un:1,uno:1,una:1,dos:2,tres:3,cuatro:4,cinco:5,seis:6,siete:7,ocho:8,nueve:9,diez:10,once:11,doce:12}
  const s=texto.normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().replace(/\b(un|uno|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|once|doce)\s+(meses|dias)\b/g,(_,n,u)=>`${numeros[n]} ${u}`)
  if (modoActual && !MESES.some(m => new RegExp(`\\b${m}\\b`).test(s)) && !/\d{4}-\d{2}-\d{2}/.test(s)) {
    if (/\b(hora|horas|horario|horaria)\b/.test(s)) return {error:'La fuente no registra horas. No se distribuyeron los totales diarios entre horas.'}
    const desde = /\b(este|presente) ano\b/.test(s) && !/\bsemana|\bmes\b/.test(s) ? `${anioActual}-01-01` : /\b(este|presente) mes\b/.test(s) ? `${fechaActual.slice(0,7)}-01` : /\bhoy\b/.test(s) ? fechaActual : /\bayer\b/.test(s) ? iso(Date.parse(fechaActual)-DAY) : null
    if (desde) {
      const solicitadaHasta = iso(Date.parse(/\bayer\b/.test(s) ? desde : fechaActual)+DAY)
      const corte = cobertura.ultimo_dia
      // Con perfil, «este mes» es el mes del calendario y no se reemplaza por otro (PERFILES_LECTURA.md).
      // Sin registros, se dice en palabras qué falta y se ofrece el último mes completo como alternativa explícita.
      if (desde > corte && /\b(este|presente) mes\b/.test(s)) {
        const c = new Date(Date.parse(corte)), completo = new Date(Date.parse(corte) + DAY).getUTCDate() === 1
        const base = completo ? c : new Date(Date.UTC(c.getUTCFullYear(), c.getUTCMonth() - 1, 1))
        const r = opcionTemporal(`mes:${base.getUTCFullYear()}-${String(base.getUTCMonth() + 1).padStart(2, '0')}`)
        const fechaCorte = new Intl.DateTimeFormat('es-CL', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(Date.parse(corte)))
        if (r && r.desde >= cobertura.primer_dia) return { error: `No hay datos de ${MESES[Number(desde.slice(5, 7)) - 1]} de ${desde.slice(0, 4)}: la fuente termina el ${fechaCorte}. Puedes revisar ${r.titulo}, el último mes completo.`, alternativa: { titulo: r.titulo } }
      }
      if (desde > corte || solicitadaHasta <= cobertura.primer_dia) return {error:`No hay datos para ${desde} a ${iso(Date.parse(solicitadaHasta)-DAY)}. El último registro es ${corte}; no se sustituyó por otro período.`}
      const observadoDesde = desde < cobertura.primer_dia ? cobertura.primer_dia : desde
      const hasta = solicitadaHasta > iso(Date.parse(corte)+DAY) ? iso(Date.parse(corte)+DAY) : solicitadaHasta
      const parcial = observadoDesde !== desde || hasta !== solicitadaHasta
      // «Este año» y «este mes» quedan como referencias en curso: el tablero conectado avanza solo con los registros.
      const enCurso = /\b(hoy|ayer)\b/.test(s) ? null : /\b(este|presente) mes\b/.test(s) ? 'en_curso:mes' : 'en_curso:anio'
      return {periodo: enCurso ?? `rango:${observadoDesde}:${hasta}`, solicitado:{desde,hasta:solicitadaHasta}, observado:{desde:observadoDesde,hasta}, motivo:enCurso ? 'calendario actual en curso' : 'calendario actual', ...(parcial && {aviso:`Período parcial: solicitado ${desde} a ${iso(Date.parse(solicitadaHasta)-DAY)}; observado ${observadoDesde} a ${iso(Date.parse(hasta)-DAY)}.`})}
    }
  }
  const named=new RegExp(`\\b(${MESES.join('|')})\\b`,'g'), found=[...s.matchAll(named)]
  const compara=/\b(vs|versus|contra|comparar|compara|comparado|frente)\b/.test(s)
  // El año explícitamente relativo al presente prevalece sobre un filtro heredado.
  const relativo = /\b(?:este|del presente) ano\b/.test(s) ? anioActual : /\bano (?:pasado|anterior)\b/.test(s) ? anioActual - 1 : null
  const contexto = { cobertura, activo, ultimaFecha, anioReferencia: relativo ?? anioReferencia, anioActual, fechaActual }
  // Dos intervalos se resuelven por la misma gramática, sin convertirlos en dos meses.
  const separador = /\b(?:vs|versus|contra|frente a)\b/.exec(s)
  if ((found.length === 4 || found.length === 2 && /\bsemana\b/.test(s)) && separador) {
    const a = interpretarCalendario(s.slice(0, separador.index).replace(/\b(?:compara|comparar|comparado)\b/g, ''), contexto)
    const b = interpretarCalendario(s.slice(separador.index + separador[0].length), contexto)
    if (a?.error || b?.error) return { error: a?.error ?? b.error }
    if (!a?.periodo || !b?.periodo) return { error: 'Indica los dos rangos completos que quieres comparar.' }
    return { ...a, comparacion: b.periodo, motivo: 'comparación explícita de intervalos' }
  }
  const conector = found.length === 2 ? s.slice(found[0].index + found[0][0].length, found[1].index) : ''
  const rangoMeses = found.length === 2 && /\b(?:desde|de|entre)\s+$/.test(s.slice(0, found[0].index)) && /^(?:\s*(?:de\s+)?20\d{2})?\s+(?:a|al|hasta|hasta el|y)\s+$/.test(conector)
  if (rangoMeses) {
    const years = found.map(f => s.slice(f.index + f[0].length).match(/^\s*(?:de\s+)?(20\d{2})\b/)?.[1])
    const compartido = years[0] ?? years[1] ?? relativo ?? anioReferencia ?? cobertura.ultimo_dia.slice(0,4)
    const y1 = Number(years[0] ?? compartido), y2 = Number(years[1] ?? compartido)
    const m1 = MESES.indexOf(found[0][1]), m2 = MESES.indexOf(found[1][1])
    const periodo = `rango:${iso(Date.UTC(y1,m1,1))}:${iso(Date.UTC(y2,m2+1,1))}`
    const r = opcionTemporal(periodo)
    if (!r) return { error: 'El rango debe estar ordenado y abarcar como máximo un año. Indica los años si cruza diciembre.' }
    if (r.desde < cobertura.primer_dia || r.hasta > iso(Date.parse(cobertura.ultimo_dia)+DAY)) return { error: `La fuente cubre ${cobertura.primer_dia} a ${cobertura.ultimo_dia}; no hay datos verificados para ${r.corto}.` }
    return { periodo, motivo: 'rango inclusivo de meses completos', ...r }
  }
  if (found.length === 2 && compara) {
    // El año relativo («del año pasado») califica solo al mes que lo lleva; el otro usa su año explícito o el de referencia.
    const periodos = found.map((f, i) => {
      const resto = s.slice(f.index + f[0].length, found[i + 1]?.index ?? s.length)
      const propio = /^\s*(?:de |del )?ano (?:pasado|anterior)\b/.test(resto) ? anioActual - 1 : /^\s*(?:de |del )?(?:este|presente) ano\b/.test(resto) ? anioActual : null
      const year = Number(resto.match(/^\s*(?:de\s+)?(20\d{2})\b/)?.[1] ?? propio ?? anioReferencia ?? cobertura.ultimo_dia.slice(0,4))
      return `mes:${year}-${String(MESES.indexOf(f[1])+1).padStart(2,'0')}`
    })
    const [actual, anterior] = periodos.map(opcionTemporal)
    if ([actual, anterior].some(r => r.desde < cobertura.primer_dia || r.hasta > iso(Date.parse(cobertura.ultimo_dia)+DAY))) return {error:'Uno de los períodos de comparación está fuera de la cobertura; no se sustituyó por otro mes.'}
    return {periodo:periodos[0],comparacion:periodos[1],motivo:'comparación explícita de meses',...actual}
  }
  // Las semanas relativas al reloj no se reemplazan por semanas de la fuente.
  const semanaRegistrada = /\bultima semana (?:completa )?(?:registrada|con datos|disponible)\b/.test(s)
  const semanaActual = /\b(?:esta semana|semana actual)\b/.test(s)
  const semanaAnterior = /\b(?:ultima semana|semana pasada|semana anterior)\b/.test(s)
  if (found.length === 0 && (semanaRegistrada || semanaActual || semanaAnterior)) {
    if (!date(fechaActual)) return { error: 'La fecha operacional del servidor no es válida.' }
    const lunesDe = f => { const t=Date.parse(f); return t-((new Date(t).getUTCDay()+6)%7)*DAY }
    const finFuente=Date.parse(cobertura.ultimo_dia)+DAY
    const ultimaCompleta=lunesDe(cobertura.ultimo_dia)+(new Date(Date.parse(cobertura.ultimo_dia)).getUTCDay()===0?0:-7*DAY)
    const inicio=semanaRegistrada?ultimaCompleta:lunesDe(fechaActual)-(semanaAnterior?7*DAY:0)
    const fin=inicio+7*DAY, solicitado={desde:iso(inicio),hasta:iso(fin)}
    const desde=iso(Math.max(inicio,Date.parse(cobertura.primer_dia))),hasta=iso(Math.min(fin,finFuente))
    if (desde>=hasta) return {error:`La semana solicitada es ${iso(inicio)} a ${iso(fin-DAY)}. La fuente cubre ${cobertura.primer_dia} a ${cobertura.ultimo_dia}; no hay registros para esa semana. Puedes pedir «la última semana completa registrada» (${iso(ultimaCompleta)} a ${iso(ultimaCompleta+6*DAY)}).`,solicitado,fecha_referencia:fechaActual}
    const periodo=`rango:${desde}:${hasta}`, r=opcionTemporal(periodo)
    const parcial=desde!==solicitado.desde||hasta!==solicitado.hasta
    return {periodo,...r,solicitado,fecha_referencia:fechaActual,motivo:semanaRegistrada?'última semana completa cubierta por la fuente':'semana de lunes a domingo respecto de la fecha operacional en America/Santiago',parcial,
      aviso:parcial?`Semana solicitada: ${iso(inicio)} a ${iso(fin-DAY)}. Resultado parcial: sólo hay registros de ${desde} a ${iso(Date.parse(hasta)-DAY)}; la fuente termina el ${cobertura.ultimo_dia}.`:null}
  }
  let periodo=null, motivo=null
  const explicitDates=s.match(/\b\d{4}-\d{2}-\d{2}\b/g)??[]
  if (explicitDates.some(d => !date(d))) return {error:'La fecha no es válida. Indica fechas completas.'}
  if (explicitDates.length > 2 || explicitDates.length === 2 && !compara && !/\b(entre|desde|del)\b/.test(s)) return {error:'Indica si esas fechas forman un rango o una comparación; no se modificó el período.'}
  if (explicitDates.length===2 && compara) {
    const r=opcionTemporal(`dia:${explicitDates[0]}`), b=opcionTemporal(`dia:${explicitDates[1]}`)
    if([r,b].some(p => p.desde<cobertura.primer_dia || p.hasta>iso(Date.parse(cobertura.ultimo_dia)+DAY))) return {error:'Las fechas de comparación deben estar dentro de la cobertura.'}
    return {periodo:`dia:${explicitDates[0]}`,comparacion:`dia:${explicitDates[1]}`,motivo:'comparación explícita de días',...r}
  } else if (explicitDates.length===2 && /\b(entre|desde|del)\b/.test(s) && !/compar/.test(s)) {
    periodo=`rango:${explicitDates[0]}:${iso(Date.parse(explicitDates[1])+DAY)}`;motivo='rango explícito inclusivo'
  } else if (explicitDates.length===1) {periodo=`dia:${explicitDates[0]}`;motivo='fecha explícita'}
  else if (found.length === 0 && /\bultimo dia(?: (registrado|con datos|disponible))?\b/.test(s)) {if (!ultimaFecha) return {pendiente:'ultima_fecha'};periodo=`dia:${ultimaFecha}`;motivo='última fecha registrada por la herramienta'}
  else if (/\bultimos? (\d+) dias?\b/.test(s)) {
    const n=Number(/\bultimos? (\d+) dias?\b/.exec(s)[1])
    if(n>=1&&n<=366&&ultimaFecha) {periodo=`rango:${iso(Date.parse(ultimaFecha)-(n-1)*DAY)}:${iso(Date.parse(ultimaFecha)+DAY)}`;motivo='ventana respecto a la última fecha registrada'}
  } else if (found.length===1) {
    const m=MESES.indexOf(found[0][1])+1, year=Number(s.match(/\b(20\d{2})\b/)?.[1]??relativo??anioReferencia??cobertura.ultimo_dia.slice(0,4))
    const days=/\b(?:del|desde el) (\d{1,2}) (?:al|hasta el) (\d{1,2})\b/.exec(s)
    const day=new RegExp(`\\b(\\d{1,2}) (?:de )?${found[0][1]}\\b`).exec(s)
    if (days && !date(`${monthStart(year,m).slice(0,8)}${days[2].padStart(2,'0')}`)) return {error:'La fecha final del rango no es válida.'}
    if (/\bsemana (?:del|de|que contiene)\b/.test(s)) {
      if (!day) return { error: 'Indica el día y mes de la semana que quieres consultar.' }
      const fecha = `${monthStart(year,m).slice(0,8)}${day[1].padStart(2,'0')}`
      if (!date(fecha)) return { error: 'La fecha de referencia de la semana no es válida.' }
      const t = Date.parse(fecha), lunes = t - ((new Date(t).getUTCDay()+6)%7)*DAY
      periodo = `rango:${iso(lunes)}:${iso(lunes+7*DAY)}`
    }
    else if (/ultimo dia de/.test(s)) periodo=`dia:${iso(Date.UTC(year,m,0))}`
    else if(days) periodo=`rango:${monthStart(year,m).slice(0,8)}${days[1].padStart(2,'0')}:${iso(Date.UTC(year,m-1,Number(days[2])+1))}`
    else if(day) periodo=`dia:${monthStart(year,m).slice(0,8)}${day[1].padStart(2,'0')}`
    else periodo=`mes:${year}-${String(m).padStart(2,'0')}`
    motivo=/\bsemana (?:del|de|que contiene)\b/.test(s) ? 'semana de lunes a domingo que contiene la fecha indicada' : s.match(/\b20\d{2}\b/)?'calendario explícito':relativo != null ? `año relativo resuelto con referencia ${anioActual}` : anioReferencia ? 'año del período explícito activo' : 'año de referencia de la cobertura, declarado en la respuesta'
  } else if (/\b(?:ultimos? (\d+) meses|(?:los )?(\d+) meses anteriores|hace (\d+) meses)\b/.test(s)) {
    const parts=/\b(?:ultimos? (\d+) meses|(?:los )?(\d+) meses anteriores|hace (\d+) meses)\b/.exec(s), n=Number(parts[1]??parts[2]??parts[3])
    if(n<1||n>12) return {error:'Selecciona entre 1 y 12 meses para este rango.'}
    const anchor = parts[1] ? cobertura.ultimo_dia : activo?.desde ?? cobertura.ultimo_dia
    const y=Number(anchor.slice(0,4)), m=Number(anchor.slice(5,7))-1
    if(parts[3]) periodo=`mes:${iso(Date.UTC(y,m-n,1)).slice(0,7)}`
    else periodo=`rango:${iso(Date.UTC(y,m-(parts[1]?n-1:n),1))}:${iso(Date.UTC(y,m+(parts[1]?1:0),1))}`
    motivo='meses de calendario respecto a cobertura o período activo'
  } else if (/\bmes (anterior|pasado)\b/.test(s) && activo) {
    periodo=`mes:${iso(Date.UTC(Number(activo.desde.slice(0,4)),Number(activo.desde.slice(5,7))-2,1)).slice(0,7)}`;motivo='mes anterior al período activo'
  }
  if (periodo) {
    const r=opcionTemporal(periodo)
    if(!r) return {error:'La fecha o el rango no son válidos. Indica fechas completas.'}
    if(r.desde<cobertura.primer_dia||r.hasta>iso(Date.parse(cobertura.ultimo_dia)+DAY)) return {error:`La fuente cubre ${cobertura.primer_dia} a ${cobertura.ultimo_dia}; no hay datos verificados para ${r.corto}.`}
    return {periodo,motivo,...r}
  }
  if (/meses (anteriores|pasados)/.test(s)) return {error:'Indica cuántos meses anteriores o el rango exacto de fechas que quieres revisar.'}
  if(found.length>1) return {error:'Indica las fechas de inicio y fin del rango, o los dos períodos completos que quieres comparar. No cambié el período.'}
  if(/\b(lunes|martes|miercoles|jueves|viernes|sabado|domingo) \d{1,2}\b/.test(s)) return {error:'Necesito el mes y el año de ese día. Una fecha fuera de la cobertura requiere un pronóstico validado; no hay un modelo de estimación de ventas registrado.'}
  if (/\b(ayer|anteayer|hoy|manana|semana|semanas|quincena|hace)\b/.test(s)) return {error:'Indica las fechas completas para esa referencia temporal. No se sustituyó por el último mes de la fuente.'}
  return null
}
