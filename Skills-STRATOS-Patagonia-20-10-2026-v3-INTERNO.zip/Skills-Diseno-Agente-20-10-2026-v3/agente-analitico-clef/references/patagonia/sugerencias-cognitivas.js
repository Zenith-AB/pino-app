import { esTableroEnlazado } from './tipos-escenario.js'
import { METRICAS, ONTOLOGIA, buscarCapacidades } from './registro-cognitivo.js'
export function candidatasSugerencias(escenario, dominio, metrica = ONTOLOGIA[dominio]?.principal) {
  if (!METRICAS[metrica] || METRICAS[metrica].dominio !== dominio) return {}
  const ids = buscarCapacidades(escenario, dominio, metrica).map(c => c.id)
  return {
    ...(ids.includes('compare_periods') ? { comparar: 'Comparar la métrica activa con el mismo período del año anterior' } : {}),
    ...(ids.includes('get_timeseries') && ['venta','unidades','margen'].includes(metrica) ? { tendencia: 'Revisar la evolución temporal de la métrica activa' } : {}),
    ...(ids.includes('rank_entities') ? { ranking: 'Revisar qué entidades concentran la métrica activa' } : {}),
    ...(ids.includes('get_kpi') ? { resumen: 'Revisar todas las métricas disponibles del dominio activo' } : {}),
    ninguna: 'No hay un siguiente análisis útil o falta resolver una aclaración',
  }
}
export function seleccionarSugerencias(respuesta, escenario, plan, resultados = []) {
  const candidatas = candidatasSugerencias(escenario, plan.dominio, plan.metrica)
  const decision = respuesta?.answers?.siguiente_pregunta
  if (!decision?.probabilities || decision.choice === 'ninguna') return []
  const nombre = METRICAS[plan.metrica]?.nombre
  const entidad = plan.dominio === 'inventario' ? 'productos' : esTableroEnlazado(escenario.id) ? 'sucursales' : 'países'
  const textos = { comparar: `Compara ${nombre} con el mismo período del año anterior`, tendencia: `Muestra la evolución de ${nombre}`, ranking: `Muestra el ranking de ${nombre} por ${entidad}`, resumen: `Muestra todas las métricas de ${plan.dominio}` }
  const labels = { comparar: 'Comparar períodos', tendencia: 'Ver tendencia', ranking: `Ver ${entidad}`, resumen: `Resumen de ${plan.dominio}` }
  const realizadas = new Set(resultados.filter(r => r.verificado).map(r => r.id))
  const herramientas = {comparar:'compare_periods',tendencia:'get_timeseries',ranking:'rank_entities'}
  return Object.entries(decision.probabilities).filter(([id,p]) => id !== 'ninguna' && candidatas[id] && !realizadas.has(herramientas[id]) && !(id === 'resumen' && plan.metricas?.length > 1) && Number.isFinite(p) && p > 0)
    .sort((a,b) => b[1]-a[1]).slice(0,2).map(([id,probabilidad]) => ({id,label:labels[id],texto:textos[id],probabilidad,seleccion:'clef-flash'}))
}

// Ideas de preguntas para el inicio del Agente, antes de cualquier respuesta de Clef.
// Una por dominio con capacidad registrada en la fuente: no ofrece análisis que la fuente no soporta.
export function sugerenciasIniciales(escenario, dominios = ['ventas', 'rentabilidad', 'cobranza', 'inventario'], limite = 4) {
  if (!escenario?.id) return []
  const enFrase = (nombre) => nombre[0].toLowerCase() + nombre.slice(1)
  const salida = []
  for (const dominio of dominios) {
    const metrica = ONTOLOGIA[dominio]?.principal, nombre = METRICAS[metrica]?.nombre
    if (!nombre) continue
    const c = candidatasSugerencias(escenario, dominio, metrica)
    const entidad = dominio === 'inventario' ? 'productos' : esTableroEnlazado(escenario.id) ? 'sucursales' : 'países'
    const textos = { comparar: `Compara ${enFrase(nombre)} con el mismo período del año anterior`, ranking: `Muestra el ranking de ${enFrase(nombre)} por ${entidad}`, resumen: `Resume ${enFrase(nombre)}` }
    // Variedad: cada dominio prefiere un análisis distinto; si la fuente no lo soporta, usa el siguiente registrado.
    const orden = { ventas: ['comparar', 'ranking', 'resumen'], rentabilidad: ['ranking', 'comparar', 'resumen'], cobranza: ['resumen', 'ranking', 'comparar'], inventario: ['ranking', 'resumen', 'comparar'] }[dominio] ?? ['comparar', 'ranking', 'resumen']
    const elegida = orden.find((id) => c[id])
    if (elegida) salida.push({ id: `${dominio}-${elegida}`, texto: textos[elegida] })
  }
  return salida.slice(0, limite)
}
