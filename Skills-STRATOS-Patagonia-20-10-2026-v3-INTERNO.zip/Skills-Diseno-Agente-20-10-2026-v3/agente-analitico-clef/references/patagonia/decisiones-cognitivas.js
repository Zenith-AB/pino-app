import { esTableroEnlazado } from './tipos-escenario.js'
import { DOMINIOS, METRICAS, ONTOLOGIA } from './registro-cognitivo.js'
import { solicitudVariables } from './variables.js'
import { candidatasSugerencias } from './sugerencias-cognitivas.js'

// Valores iniciales conservadores: probabilidades relativas, NO confianza calibrada.
// restrictiva: mínimo para bloquear o declarar sin pronóstico (fallo seguro). rechazoFirme: un rechazo del judge
// a la métrica que obliga a preguntar aunque el planner estuviera seguro.
export const POLITICA_DECISION = Object.freeze({ minimo: 0.55, separacion: 0.12, variable: 0.4, binario: 0.65, restrictiva: 0.45, rechazoFirme: 0.15, maxInferencias: 4, maxHerramientas: 7, maxRondas: 2 })
export function eleccion(respuesta, id, opciones, minimo = POLITICA_DECISION.minimo) {
  const r = respuesta?.answers?.[id]
  if (r?.type !== 'choice' || !r.probabilities) return { valor: null, incierta: true, probabilidades: r?.probabilities ?? {} }
  const ps = Object.entries(r.probabilities)
  if (ps.length !== opciones.length || ps.some(([k, p]) => !opciones.includes(k) || !Number.isFinite(p) || p < 0 || p > 1) || Math.abs(ps.reduce((s, [, p]) => s + p, 0) - 1) > 0.02) throw new Error(`Distribución inválida de Clef: ${id}`)
  ps.sort((a, b) => b[1] - a[1])
  if (r.choice !== ps[0][0]) throw new Error(`Elección inconsistente de Clef: ${id}`)
  const incierta = ps[0][1] < minimo || ps[0][1] - (ps[1]?.[1] ?? 0) < POLITICA_DECISION.separacion
  return { valor: incierta ? null : ps[0][0], incierta, probabilidad: ps[0][1], probabilidades: r.probabilities }
}
// Opciones distintas pueden designar el mismo valor: «contexto» es la métrica activa del dominio,
// «continuar» es resumir la métrica ya consultada. Exigir separación entre ellas convierte en duda
// lo que es acuerdo. Se suman sus probabilidades por valor designado y se aplica la misma política.
export function eleccionResuelta(respuesta, id, opciones, designa, minimo = POLITICA_DECISION.minimo) {
  const base = eleccion(respuesta, id, opciones, minimo)
  const acumulado = {}
  for (const [opcion, p] of Object.entries(base.probabilidades ?? {})) { const valor = designa(opcion) ?? opcion; acumulado[valor] = (acumulado[valor] ?? 0) + p }
  const ps = Object.entries(acumulado).sort((a, b) => b[1] - a[1])
  if (!ps.length) return base
  const incierta = ps[0][1] < minimo || ps[0][1] - (ps[1]?.[1] ?? 0) < POLITICA_DECISION.separacion
  return { ...base, valor: incierta ? null : ps[0][0], incierta, probabilidad: ps[0][1], designadas: acumulado }
}
export function binaria(respuesta, id) {
  const r = respuesta?.answers?.[id]
  if (r?.type !== 'noul' || !Number.isFinite(r.noul) || r.noul < 0 || r.noul > 1) return { valor: false, incierta: true, probabilidad: null }
  return { valor: r.noul >= POLITICA_DECISION.binario, incierta: r.noul > 1 - POLITICA_DECISION.binario && r.noul < POLITICA_DECISION.binario, probabilidad: r.noul }
}
export function validarDecision(respuesta, solicitud) {
  const answers = respuesta?.answers
  if (!answers || Object.keys(answers).length !== Object.keys(solicitud.questions).length || Object.keys(answers).some((id) => !solicitud.questions[id])) throw new Error('Contrato de decisión incompleto o ajeno al registro.')
  for (const [id, q] of Object.entries(solicitud.questions)) {
    const a = answers[id]
    if (a?.type !== q.type) throw new Error(`Tipo de decisión inválido: ${id}`)
    if (q.type === 'choice') {
      if (!a.probabilities || typeof a.probabilities !== 'object') throw new Error(`Distribución ausente: ${id}`)
      eleccion(respuesta, id, Object.keys(q.criteria))
    }
    else if (q.type === 'noul') {
      if (binaria(respuesta, id).probabilidad == null) throw new Error(`Probabilidad binaria inválida: ${id}`)
    } else {
      const claves = q.criteria.map((_, i) => String(i))
      const ps = Object.entries(a.probabilities ?? {})
      if (ps.length !== claves.length || ps.some(([k, p]) => !claves.includes(k) || !Number.isFinite(p) || p < 0 || p > 1) || Math.abs(ps.reduce((s, [, p]) => s + p, 0) - 1) > 0.02 || !Number.isFinite(a.score) || Math.abs(ps.reduce((s, [k, p]) => s + Number(k) * p, 0) - a.score) > 0.01 || claves.some((k) => a.legend?.[k] !== q.criteria[Number(k)])) throw new Error(`Escala de decisión inválida: ${id}`)
    }
  }
  return respuesta
}
export const PERIODOS_SEMANTICOS = Object.freeze({ month: 'ultimo_mes_completo', quarter: 'ultimo_trimestre_completo', year: 'ultimo_anio_completo', context: 'sin_cambio' })
const choice = (criteria, instructions) => ({ type: 'choice', instructions, criteria })
const noul = (instructions) => ({ type: 'noul', instructions })
// Proyección de world state para routing: metadatos relevantes, sin repetir símbolos de
// filtros ni miles de cifras que pueden anclar al modelo al período visible.
// Solo lo que decide: nombre, dominio y métricas del perfil. Prioridades y límites redactados son texto para personas.
const perfilCompacto = (p) => p ? { nombre: p.nombre, dominio: p.dominio, metricas: p.metricas } : null
function contextoDecision(e, routing = false) {
  const conversation = Object.fromEntries(Object.entries(e.conversation).filter(([k]) => k !== 'pregunta_anterior_no_verificada'))
  delete conversation.ultima_solicitud_resuelta
  if (!conversation.periodo_explicito) delete conversation.periodo_explicito
  // IDs are useful in traces, not semantic evidence; omit random identifiers from inference.
  for (const key of ['active_request', 'pending_clarification', 'resolved_clarification']) {
    if (conversation[key]) conversation[key] = Object.fromEntries(Object.entries(conversation[key]).filter(([k]) => !['id', 'request_id', 'clarification_id'].includes(k)))
  }
  return {
    user_request: e.request,
    user: { rol: e.user.rol, perfil_lectura: perfilCompacto(e.user.perfil_lectura), empresa: e.user.empresa, permisos: e.user.permisos, permisos_escritura: e.user.permisos_escritura },
    session: { module: e.session.vista, period: e.session.periodo?.corto, comparison: e.session.comparacion?.corto, visible_components: e.session.componentes_visibles },
    conversation,
    business: { naturaleza: e.business.naturaleza, identidad_empresa: e.business.identidad_empresa, actual: e.business.actual ?? null, targets: e.business.objetivos ?? null, presupuesto_ventas: e.business.presupuesto_ventas ?? null },
    data: { escenario: e.data.escenario, moneda: e.data.moneda, cobertura: e.data.cobertura, fuente: e.data.fuente, faltantes: e.data.faltantes },
    // La decisión conjunta elige métricas y flags; las herramientas se derivan del registro. Basta su identificador.
    // Las relaciones de la ontología repiten las descripciones de dominio y métrica de las preguntas.
    ...(!routing && { ontology: e.ontology }),
    available_capabilities: routing ? e.available_capabilities.map((c) => c.id) : e.available_capabilities.map((c) => ({ id: c.id, descripcion: c.descripcion, required_slots: c.required_slots, optional_slots: c.optional_slots, tipo: c.tipo })),
    rules: ['User request specifies intent and explicit scope. Context resolves omitted references, never overrides explicitly requested scope.', ...(ONTOLOGIA[e.session.vista] ? [`The visible module (${e.session.vista}) resolves omitted or ambiguous domain references between concepts of several domains.`] : []), ...(e.session.vista === 'inventario' ? ['Products sold use sales units, whereas available inventory uses stock.'] : []), 'Read-only. Existing registered capabilities and components only. Missing roles and business facts are unknown.'],
  }
}
export function solicitudEnrutador(estado, escenario) {
  const base = solicitudVariables(estado.request, estado.session.filtros, escenario)
  delete base.questions.destino; delete base.questions.intencion
  base.questions.periodo = choice({
    month: 'Monthly scope: this month, latest month, monthly results. Resolve to the latest complete month in source coverage.',
    quarter: 'Quarterly scope: this quarter, latest quarter, quarterly results.',
    year: 'Annual scope: this year, latest year, yearly results.',
    context: 'The user does not specify a time scope. Preserve the active period.',
  }, 'Which time scope does the USER REQUEST ask for? Read the request, not the active filter. An explicitly requested month is monthly even when the active filter is quarterly.')
  return { model: 'clef-flash', state: contextoDecision(estado, true), questions: {
    ...base.questions,
    ...(estado.user.perfil_lectura && { revision_desempeno: noul('¿La solicitud pide un balance general de cómo fue el desempeño del negocio o equipo, sin especificar una métrica, ranking, causa ni acción? TRUE para una revisión general según el perfil de lectura; FALSE para consultas concretas o continuar una métrica anterior. No conceder permisos por el rol.') }),
    // Todos los dominios registrados: una materia que la fuente no mide debe poder nombrarse para responder
    // «la fuente no lo mide», en vez de forzarla al dominio medible más parecido.
    dominio: choice(DOMINIOS, 'Dominio explícito de la solicitud, aunque la fuente activa no lo mida. Para una pregunta general sobre la vista actual, contexto. No decidir aún qué métrica o herramienta usar.'),
    cambia_periodo: noul('Does the USER REQUEST explicitly specify a time scope? TRUE even if that scope already matches the active filter; FALSE only when no time scope is mentioned.'),
    cambia_comparacion: noul('Does the request explicitly specify a comparison baseline? Asking why a metric changed needs analysis, but does not itself request changing the existing comparison filter.'),
    cambia_dominio: noul('¿El usuario menciona una materia empresarial distinta del dominio activo de la pantalla o conversación? Si es una pregunta general sobre la vista actual, FALSE.'),
    intencion: choice({ navegar: 'Ajustar filtros o abrir una vista', resumir: 'Consultar valores o totales, métricas, registros o rankings. Una petición breve hereda la métrica y dominio activos cuando no pide cambiarlos', comparar: 'Comparación', diagnosticar: 'Investigar una señal o explicación', predecir: 'Pronóstico futuro', ejecutar: 'Modificar registros o ejecutar una acción', continuar: 'Continuar la consulta ya respondida del contexto, conservando su dominio y métrica; no requiere repetir su nombre', incierta: 'No se puede interpretar' }, 'Qué necesita lograr el usuario usando el estado completo. No seleccionar herramientas aún.'),
    needs_clarification: noul('¿Existe una ambigüedad material del dominio o intención que el contexto no resuelve?'),
    siguiente_pregunta: choice(Object.assign({}, ...Object.keys(ONTOLOGIA).map(d => candidatasSugerencias(escenario, d))), 'Ordena las preguntas de seguimiento por utilidad para esta petición y su contexto operacional. No repitas lo que el usuario acaba de pedir; prioriza contexto, hallazgos previos, objetivos y capacidades disponibles. Elige ninguna si hace falta aclarar o no hay seguimiento útil. Las probabilidades ordenarán hasta dos sugerencias; no son confianza calibrada.'),
  } }
}
export function interpretarEnrutador(respuesta, estado, solicitud) {
  const cambia = binaria(respuesta, 'cambia_dominio')
  const activo = estado.conversation.active_request?.lifecycle === 'COMPLETED' && ONTOLOGIA[estado.conversation.dominio] ? estado.conversation.dominio : ONTOLOGIA[estado.session.vista] ? estado.session.vista : estado.conversation.dominio
  // La ambigüedad declarada por el router se evalúa contra lo que el usuario nombró, no contra el valor fusionado.
  const dominioNombrado = eleccion(respuesta, 'dominio', Object.keys(solicitud.questions.dominio.criteria))
  const dominioElegido = eleccionResuelta(respuesta, 'dominio', Object.keys(solicitud.questions.dominio.criteria), (o) => o === 'contexto' && ONTOLOGIA[activo] ? activo : o)
  const continuacion = METRICAS[estado.conversation.metrica] && ONTOLOGIA[estado.conversation.dominio] ? 'resumir' : 'incierta'
  const intencion = eleccionResuelta(respuesta, 'intencion', Object.keys(solicitud.questions.intencion.criteria), (o) => o === 'continuar' ? continuacion : o)
  // A concrete registered choice takes precedence over an auxiliary change flag.
  const dominio = ONTOLOGIA[dominioElegido.valor] ? dominioElegido.valor : dominioElegido.valor === 'contexto' || !cambia.valor && !cambia.incierta ? activo : dominioElegido.valor
  const continuacionResuelta = intencion.valor === 'resumir' && !cambia.valor && !cambia.incierta && dominio === estado.conversation.dominio && estado.conversation.active_request?.lifecycle === 'COMPLETED' && METRICAS[estado.conversation.metrica]?.dominio === dominio
  const cambios = {}, decisionesVariables = {}
  for (const id of ['periodo', 'comparacion', 'listado', 'foco']) {
    const q = solicitud.questions[id]
    if (!q) continue
    const e = eleccion(respuesta, id, Object.keys(q.criteria), POLITICA_DECISION.variable)
    // La compuerta auxiliar solo decide elecciones débiles: una base de comparación concreta y concluyente
    // (mínimo y separación de la política) no se descarta porque la pregunta binaria la subestime.
    if (id === 'comparacion' && !binaria(respuesta, 'cambia_comparacion').valor && !(e.valor && e.valor !== 'sin_cambio' && eleccion(respuesta, id, Object.keys(q.criteria)).valor === e.valor)) e.valor = 'sin_cambio'
    // Si el usuario sí especificó un alcance temporal pero la elección quedó repartida, se decide entre los alcances
    // concretos (sin «context»), con la misma política. Si aun así no es concluyente, el filtro no cambia.
    if (id === 'periodo' && !e.valor && binaria(respuesta, 'cambia_periodo').valor) {
      const concretos = Object.entries(e.probabilidades ?? {}).filter(([k]) => k !== 'context'), total = concretos.reduce((t, [, p]) => t + p, 0)
      const [[k1, p1] = [], [, p2 = 0] = []] = concretos.map(([k, p]) => [k, p / (total || 1)]).sort((x, y) => y[1] - x[1])
      if (total >= 0.5 && p1 >= POLITICA_DECISION.minimo && p1 - p2 >= POLITICA_DECISION.separacion) Object.assign(e, { valor: k1, incierta: false, probabilidad: p1, condicional: true })
    }
    if (id === 'periodo' && e.valor) e.valor = PERIODOS_SEMANTICOS[e.valor]
    decisionesVariables[id] = e
    if (e.valor && e.valor !== 'sin_cambio' && e.valor !== estado.session.filtros[id]) cambios[id] = { desde: estado.session.filtros[id], hacia: e.valor, probabilidad: e.probabilidad }
  }
  const lecturaAmbigua = !intencion.valor && intencion.probabilidades.ejecutar < 0.15 && (intencion.probabilidades.predecir < 0.2 || dominio === 'inventario') && ['navegar', 'resumir', 'comparar', 'diagnosticar', 'continuar', ...(dominio === 'inventario' ? ['predecir'] : [])].reduce((s, id) => s + (intencion.probabilidades[id] ?? 0), 0) >= POLITICA_DECISION.minimo
  // Política asimétrica: bloquear una escritura o declarar que no hay pronóstico es un fallo seguro, así que una
  // intención restrictiva ganadora y separada basta con un mínimo menor. Nunca habilita una acción.
  const [restrictiva, pRestrictiva] = Object.entries(intencion.probabilidades ?? {}).sort((a, b) => b[1] - a[1])[0] ?? []
  const segunda = Object.values(intencion.probabilidades ?? {}).sort((a, b) => b - a)[1] ?? 0
  const intencionRestrictiva = !intencion.valor && ['ejecutar', 'predecir'].includes(restrictiva) && pRestrictiva >= POLITICA_DECISION.restrictiva && pRestrictiva - segunda >= POLITICA_DECISION.separacion ? restrictiva : null
  // Ambigüedad SOLO de dominio (la intención sí se resolvió): el planner puede resolverla si nombra una métrica.
  const intencionResuelta = (intencion.valor || intencionRestrictiva || lecturaAmbigua) && intencion.valor !== 'incierta'
  const dominioIncierto = intencionResuelta && (binaria(respuesta, 'needs_clarification').valor && !ONTOLOGIA[dominioNombrado.valor] && !ONTOLOGIA[estado.session.vista] || !ONTOLOGIA[dominio])
  const candidato = Object.entries(dominioElegido.probabilidades ?? {}).filter(([d]) => ONTOLOGIA[d]).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'ventas'
  return { dominio: dominioIncierto && !ONTOLOGIA[dominio] ? candidato : dominio, dominio_incierto: dominioIncierto, continuacion_resuelta: continuacionResuelta, intencion: intencion.valor ?? intencionRestrictiva ?? (lecturaAmbigua ? 'lectura_ambigua' : null), cambio_periodo: binaria(respuesta, 'cambia_periodo').valor && !decisionesVariables.periodo?.valor, cambios, decisionesVariables, elecciones: { dominio: dominioElegido, intencion }, needs_clarification: binaria(respuesta, 'needs_clarification').valor && !ONTOLOGIA[dominioNombrado.valor] && !ONTOLOGIA[estado.session.vista] || !ONTOLOGIA[dominio] || !intencion.valor && !intencionRestrictiva && !lecturaAmbigua || intencion.valor === 'incierta' }
}
// Métricas que el planner puede nombrar en esta fuente: todo el catálogo, no solo el dominio que propuso el router.
// La métrica es el concepto más específico; el dominio se deriva de ella. Las no medidas por la fuente siguen
// siendo nombrables para responder «la fuente no lo mide» en lugar de sustituirlas por otra.
export const metricasPlanner = (escenario) => Object.entries(METRICAS).filter(([, m]) => !m.escenarios || m.escenarios.includes(escenario.id))
const ENTIDADES_DOMINIO = { produccion: ['sucursal'], cobranza: ['cliente'], inventario: ['producto'] }
export function solicitudPlanner(estado, escenario, ruta) {
  const metricas = Object.fromEntries(metricasPlanner(escenario).map(([id, m]) => [id, `${m.descripcion ?? m.nombre} [${m.dominio}]`]))
  const conversacion = estado.conversation?.active_request?.lifecycle === 'COMPLETED' && estado.conversation.metrica
  // El dominio del router solo se entrega si fue una elección concluyente: uno incierto anclaría la métrica.
  // La consulta anterior resuelta permite decidir continuaciones elípticas sin reglas de frases.
  const previa = estado.conversation?.ultima_solicitud_resuelta
  return { model: 'clef-flash', state: { ...contextoDecision(estado, true), ...(ruta.elecciones && { semantic_resolution: { ...(ruta.elecciones.dominio?.valor && !ruta.elecciones.dominio.incierta && { dominio_propuesto: ruta.dominio }), intencion: ruta.intencion, cambios: ruta.cambios } }), ...(previa && { previous_resolved_request: { consulta: previa.consulta, metrica: previa.metrica, dominio: previa.dominio, periodo: previa.periodo?.corto ?? previa.periodo ?? null, balance_de_perfil: estado.conversation.paquete === 'perfil' } }) }, questions: {
    ...(ruta.cambio_periodo ? { periodo: choice(solicitudEnrutador(estado, escenario).questions.periodo.criteria, 'El usuario pidió CAMBIAR el período. Elige mes, trimestre o año según su petición, sin anclarte al valor activo.') } : {}),
    // Paquete de lectura del perfil: lo decide el modelo con la conversación a la vista, en la misma inferencia.
    ...(estado.user.perfil_lectura ? { paquete: choice({ perfil: 'Overall performance review of the business or team (how did we do, general balance, results of a period) without naming a specific business metric. A stated date or period still uses this package.', ...(conversacion ? { continuar: 'Continue or adjust the previous query of the conversation (same indicator with another period, filter or entity; elliptical follow-ups such as asking about another month or why it changed).' } : {}), especifica: 'Names a business metric, ranking, cause investigation or action requiring its own capability. A date alone does NOT qualify.' }, 'Choose the registered reading package for the CURRENT request, given the conversation.') } : {}),
    alcance: choice({ agregado: 'Aggregated business measures: totals, KPIs, overviews, performance and rankings of branches or products. Default for a general business question.', registros: 'Individual sales invoices or transactions, listed by registration date. Only when the user asks to see individual recorded sales; not performance, best/worst entities or a total.', no_disponible: 'Individual records other than sales invoices; do not replace them with a KPI' }, 'Decide el alcance de la petición actual. Totales y KPIs son agregado. Últimas ventas registradas son registros individuales. Sólo hereda el alcance anterior cuando la petición no lo cambia; una petición explícita de total prevalece sobre registros anteriores.'),
    cambia_metrica: noul('¿Se pide una métrica DISTINTA de la activa de la conversación o de la principal del dominio propuesto? Si no pide cambiarla, FALSE.'),
    cambia_entidad: noul('¿El usuario solicita una entidad o dimensión DISTINTA de la activa? Si no nombra una entidad distinta o continúa una referencia conocida, FALSE.'),
    metrica: choice({ ...metricas, contexto: 'Solo cuando la petición no nombra ni describe ninguna medida (por ejemplo, una pregunta general o una continuación elíptica como otro mes): la métrica activa de la conversación o la principal. Si la petición nombra o describe una medida, aunque sea con otras palabras, elegir esa métrica y no contexto.', incierta: 'No se puede identificar' }, 'Selecciona la medida solicitada en CUALQUIER dominio, aunque no aparezca su nombre literal y aunque difiera del dominio propuesto o de la conversación. Ventas sin otra medida explícita significa venta neta. Un ranking de cantidad vendida requiere unidades. No calcular.'),
    entidad: choice({ sucursal: 'Sucursal, predio o planta', producto: 'Producto o artículo', pais: 'País', cliente: 'Cliente o deudor', contexto: 'Entidad activa o dimensión visible', incierta: 'Referencia sin antecedente' }, 'Select an entity CATEGORY, not a named record. General questions about products need product, without requiring a product name. Resolve pronouns from conversation. If no entity is specified, contexto.'),
    needs_clarification: noul('Is an unresolved metric or entity CATEGORY necessary to answer? Do not require a specific product/customer name for a general overview or ranking. Use defaults from the resolved domain when no specific entity is requested.'),
    needs_comparison: noul('¿Resolver la solicitud exige comparar períodos?'),
    needs_timeseries: noul('¿Resolver la solicitud exige evolución temporal?'),
    needs_ranking: noul('Does the user ask for a breakdown by an entity category (for example by branch or by product), the largest, biggest, smallest, top or bottom entities, or a ranking? Elliptical follow-ups such as asking about the big ones require ranking within the active metric and entity.'),
    orden_ranking: choice({ ninguno: 'Consulta sin ranking ni selección de mayor o menor.', desc: 'Ranking de entidades grandes, mejores, mayores o más vendidas: mayor valor primero.', asc: 'Ranking de entidades pequeñas, menores o menos vendidas: menor valor primero.' }, 'Resuelve el orden del ranking dentro de la métrica y entidad activas, incluyendo referencias como los grandes. Si no solicita ordenar o seleccionar extremos, ninguno.'),
    needs_anomaly: noul('¿Resolver la solicitud exige buscar una señal inusual?'),
    needs_drivers: noul('¿Resolver la solicitud exige investigar contribuciones a un cambio?'),
    needs_stockout: noul('¿Resolver la solicitud exige evaluar riesgo proyectado de quiebre?'),
    risk: { type: 'score', criteria: ['lectura', 'analisis', 'accion_operacional', 'destructiva'], instructions: 'Riesgo; consultar no autoriza modificar datos.' },
  } }
}
export function interpretarPlanner(respuesta, estado, solicitud, ruta) {
  const alcanceElegido = eleccion(respuesta, 'alcance', Object.keys(solicitud.questions.alcance.criteria), 0.85)
  const alcance = alcanceElegido.valor ?? 'agregado'
  const cambiaMetrica = binaria(respuesta, 'cambia_metrica')
  const activaDe = (d) => estado.conversation.dominio === d ? estado.conversation.metrica ?? ONTOLOGIA[d]?.principal : ONTOLOGIA[d]?.principal
  const opcionesMetrica = Object.keys(solicitud.questions.metrica.criteria)
  const metricaActiva = activaDe(ruta.dominio)
  const seguro = (p1, p2) => p1 >= POLITICA_DECISION.minimo && p1 - p2 >= POLITICA_DECISION.separacion
  // Métrica NOMBRADA por el usuario. Elección jerárquica: con muchas métricas la masa se reparte y un mínimo absoluto
  // castiga al catálogo grande. Si el modelo afirma que se nombró una medida (masa concreta mayoritaria), se decide
  // primero el dominio entre las concretas y luego la métrica condicionada a ese dominio, con la misma política.
  let nombrada = eleccion(respuesta, 'metrica', opcionesMetrica)
  if (!METRICAS[nombrada.valor]) {
    const concretas = Object.entries(nombrada.probabilidades ?? {}).filter(([id]) => METRICAS[id])
    const total = concretas.reduce((s, [, p]) => s + p, 0)
    const porDominio = {}
    for (const [id, p] of concretas) porDominio[METRICAS[id].dominio] = (porDominio[METRICAS[id].dominio] ?? 0) + p / (total || 1)
    const [[d, pd] = [], [, pd2 = 0] = []] = Object.entries(porDominio).sort((a, b) => b[1] - a[1])
    if (total >= 0.5 && seguro(pd, pd2)) {
      const dentro = concretas.filter(([id]) => METRICAS[id].dominio === d).map(([id, p]) => [id, p / (pd * total)]).sort((a, b) => b[1] - a[1])
      if (seguro(dentro[0][1], dentro[1]?.[1] ?? 0)) nombrada = { valor: dentro[0][0], incierta: false, probabilidad: dentro[0][1], probabilidades: nombrada.probabilidades, jerarquica: { dominio: d, p_dominio: pd } }
    }
  }
  // Sin métrica nombrada, «contexto» designa la activa; opciones que designan lo mismo se suman.
  const eleccionMetrica = METRICAS[nombrada.valor] ? nombrada : eleccionResuelta(respuesta, 'metrica', opcionesMetrica, (o) => o === 'contexto' && METRICAS[metricaActiva] ? metricaActiva : o)
  // El dominio sale de la métrica cuando ésta es concluyente. Si no, de la masa de probabilidad por dominio
  // («contexto» cuenta para el dominio propuesto); si tampoco alcanza la política, se conserva el del router.
  const masa = {}
  for (const [opcion, p] of Object.entries(eleccionMetrica.probabilidades ?? {})) {
    const d = opcion === 'contexto' ? ruta.dominio : METRICAS[opcion]?.dominio
    if (d) masa[d] = (masa[d] ?? 0) + p
  }
  const [[dominioMasa, pMasa] = [], [, pSegundo = 0] = []] = Object.entries(masa).sort((a, b) => b[1] - a[1])
  let dominio = METRICAS[eleccionMetrica.valor] ? METRICAS[eleccionMetrica.valor].dominio
    : ONTOLOGIA[dominioMasa] && seguro(pMasa, pSegundo) ? dominioMasa : ruta.dominio
  const contextual = estado.conversation.dominio === dominio ? estado.conversation.entidad : null
  const entidadActiva = contextual ?? (ENTIDADES_DOMINIO[dominio]?.[0] ?? (esTableroEnlazado(estado.data.escenario) ? estado.session.filtros.listado === 'productos' ? 'producto' : 'sucursal' : estado.session.filtros.listado === 'productos' ? 'producto' : 'pais'))
  const elecciones = {
    metrica: eleccionMetrica,
    entidad: eleccionResuelta(respuesta, 'entidad', Object.keys(solicitud.questions.entidad.criteria), (o) => o === 'contexto' ? entidadActiva : o),
  }
  // Una selección concreta confiable identifica la métrica; la pregunta auxiliar de cambio
  // solo resuelve elecciones no concluyentes con contexto, nunca borra una selección concreta.
  let metrica = METRICAS[elecciones.metrica.valor] ? elecciones.metrica.valor : !cambiaMetrica.valor && !cambiaMetrica.incierta ? activaDe(dominio) : null
  // Contradicción: el modelo afirma que se pide otra métrica, pero la elección cae en la activa sin nombrarla.
  // Responder la activa sería una respuesta silenciosamente equivocada; se pregunta.
  const contradiccion = cambiaMetrica.valor && !METRICAS[nombrada.valor] && metrica === metricaActiva
  if (contradiccion) metrica = null

  const cambiaEntidad = binaria(respuesta, 'cambia_entidad')
  let entidad = elecciones.entidad.valor && elecciones.entidad.valor !== 'incierta' ? elecciones.entidad.valor : !cambiaEntidad.valor && !cambiaEntidad.incierta ? entidadActiva : elecciones.entidad.valor
  // Dominios con una sola dimensión registrada: una categoría ajena se reemplaza por la registrada.
  if (ENTIDADES_DOMINIO[dominio] && entidad && entidad !== 'incierta' && !ENTIDADES_DOMINIO[dominio].includes(entidad)) entidad = ENTIDADES_DOMINIO[dominio][0]
  const eleccionEntidad = eleccion(respuesta, 'entidad', Object.keys(solicitud.questions.entidad.criteria)), entidadNombrada = eleccionEntidad.valor
  const paquete = solicitud.questions.paquete ? eleccion(respuesta, 'paquete', Object.keys(solicitud.questions.paquete.criteria)) : null
  if (solicitud.questions.periodo) {
    const e = eleccion(respuesta, 'periodo', Object.keys(solicitud.questions.periodo.criteria), POLITICA_DECISION.variable)
    if (e.valor) e.valor = PERIODOS_SEMANTICOS[e.valor]
    if (e.valor && e.valor !== 'sin_cambio') ruta.cambios.periodo = { desde: estado.session.filtros.periodo, hacia: e.valor, probabilidad: e.probabilidad }
    else ruta.periodo_incierto = true
  }
  const flags = Object.fromEntries(Object.keys(solicitud.questions).filter((id) => solicitud.questions[id].type === 'noul').map((id) => [id, binaria(respuesta, id)]))
  // Una capacidad de análisis registrada para un solo dominio define su métrica cuando el usuario no nombró otra:
  // el riesgo de quiebre se evalúa sobre existencias (detect_stockout solo existe en inventario).
  if (flags.needs_stockout?.valor && !METRICAS[nombrada.valor] && (!METRICAS[metrica] || METRICAS[metrica].dominio !== 'inventario')) { dominio = 'inventario'; metrica = ONTOLOGIA.inventario.principal; if (!ENTIDADES_DOMINIO.inventario.includes(entidad)) entidad = 'producto' }
  const aclarar = ruta.periodo_incierto || flags.needs_clarification.valor || !METRICAS[metrica] || ['incierta', null].includes(entidad) || METRICAS[metrica]?.dominio !== dominio
  let ordenRanking = eleccion(respuesta, 'orden_ranking', ['ninguno', 'desc', 'asc'])
  if (['asc', 'desc'].includes(ordenRanking.valor)) flags.needs_ranking.valor = true
  // Si el ranking es necesario y el orden quedó incierto, «ninguno» no es un orden posible: se renormaliza entre ascendente y descendente.
  if (flags.needs_ranking.valor && ordenRanking.incierta) {
    const { desc = 0, asc = 0 } = ordenRanking.probabilidades ?? {}, total = desc + asc
    if (total > 0) { const [mayor, menor] = [Math.max(desc, asc) / total, Math.min(desc, asc) / total]; const incierta = mayor < POLITICA_DECISION.minimo || mayor - menor < POLITICA_DECISION.separacion; ordenRanking = { ...ordenRanking, valor: incierta ? null : desc >= asc ? 'desc' : 'asc', incierta, probabilidad: mayor } }
  }
  return { ...ruta, dominio, dominio_router: ruta.dominio, orden_ranking: ordenRanking.valor ?? 'desc', alcance, alcance_heredado: alcanceElegido.valor === estado.conversation.alcance, metrica, metrica_nombrada: METRICAS[nombrada.valor] ? nombrada.valor : null, entidad, entidad_nombrada: ['sucursal', 'producto', 'pais', 'cliente'].includes(entidadNombrada) ? entidadNombrada : null, entidad_probabilidad: eleccionEntidad.probabilidad ?? null, paquete: paquete?.valor ?? null, needs_clarification: aclarar || flags.needs_ranking.valor && ordenRanking.incierta, flags, elecciones: { ...ruta.elecciones, ...elecciones, orden_ranking: ordenRanking, alcance: alcanceElegido, ...(paquete && { paquete }) }, riesgo: respuesta.answers?.risk ?? null }
}
export function compactarResultados(resultados) {
  return resultados.map((r) => {
    const datos = { ...r.datos }
    for (const key of ['filas', 'puntos']) if (Array.isArray(datos[key])) {
      datos[`${key}_total`] = datos[key].length
      datos[`${key}_recortados`] = datos[key].length > 3
      datos[key] = key === 'puntos' ? datos[key].slice(-3) : datos[key].slice(0, 3)
    }
    return { id: r.id, referencia: r.referencia, estado: r.estado, verificado: r.verificado, procedencia: { fuente: r.procedencia?.fuente, unidad: r.procedencia?.unidad, periodo: r.procedencia?.periodo?.corto, comparacion: r.procedencia?.comparacion?.corto, metrica: r.procedencia?.metrica, definicion: r.procedencia?.definicion, corte: r.procedencia?.corte }, datos }
  })
}
export function solicitudJudge(estado, plan, resultados, componentes, pendientes, ronda) {
  return {
    model: 'clef-flash', state: { request: estado.request, perfil_lectura: perfilCompacto(estado.user.perfil_lectura), conversation: estado.conversation, business: { objetivos: estado.business.objetivos ?? null, presupuesto_ventas: estado.business.presupuesto_ventas ?? null, naturaleza: estado.business.naturaleza }, alcance: { dominio: plan.dominio, metrica: plan.metrica, entidad: plan.entidad, periodo: estado.session.periodo }, result_state: compactarResultados(resultados), componentes: componentes.map((c) => ({ id: c.id, descripcion: c.descripcion })), capacidades_pendientes: pendientes.map((c) => ({ id: c.id, descripcion: c.descripcion })), presupuesto: { ronda, max_rondas: POLITICA_DECISION.maxRondas }, reglas: ['Evalúa solo resultados recibidos. Una suma conciliada prueba una contribución, nunca una causa operacional.', 'No inventar cifras ni capacidades. No pedir datos ya obtenidos. No escribir código ni cambiar el diseño.', 'Al agotar evidencia o presupuesto, detenerse indicando los límites.'] },
    questions: {
      addresses_request: noul(plan.dominio === 'produccion'
        ? 'Is the selected dairy metric the business concept the user asked about? Milk produced, milk accepted in plant, milk rejected at reception, milk excluded for withdrawal and cows in withdrawal are different concepts. Judge ONLY the concept: a missing cause, diagnosis, forecast or partial answer does not make the metric wrong. FALSE only for a different concept.'
        : 'Is the selected metric the business concept the user asked about? Distinguish outstanding unpaid balances from payments collected, revenue from units, and margin from discounts or cost. Judge ONLY the concept: an unproven cause, a missing explanation or a partial answer does not make the metric wrong. FALSE only when the metric measures a different concept.'),
      responde_completo: noul('Do the verified results fully answer the request, including any requested comparison, ranking, target or explanation? FALSE when only part is answered or a requested cause cannot be demonstrated with these results. This does not mean the metric is wrong.'),
      evidence_sufficient: noul('¿Los resultados permiten comunicar hechos verificados con sus límites, aunque NO esté demostrada una causa? TRUE si hay métricas verificadas; no confundir falta de causa con falta de datos.'),
      continue_investigation: noul('¿Una capacidad pendiente disponible agregaría evidencia material? No continuar si no hay capacidades pendientes.'),
      siguiente_herramienta: choice({ ninguna: 'Detener investigación', ...Object.fromEntries(pendientes.map((c) => [c.id, c.descripcion])) }, 'Elegir una sola capacidad pendiente; ninguna si la evidencia ya alcanza.'),
      componente: choice(Object.fromEntries(componentes.map((c) => [c.id, c.descripcion])), 'Elegir un componente ya implementado apto para el resultado. AgentDock si ninguna visualización representa la entidad o capacidad.'),
      plantilla: choice({ direct_metric: 'Valor y alcance', comparison: 'Variación y referencia', diagnosis: 'Hallazgo verificado y límites de causalidad', recommendation: 'Siguiente revisión sustentada, sin ejecutar', insufficient_evidence: 'Evidencia insuficiente y fuente faltante' }, 'Respuesta determinística más breve que expresa lo verificado.'),
      severidad: { type: 'score', criteria: ['informativa', 'baja', 'media', 'alta', 'critica'], instructions: 'Prioridad relativa del hallazgo; no reemplaza umbrales de negocio ni implica emergencia demostrada.' },
      needs_llm: noul('¿Se necesita redacción libre que ninguna plantilla existente pueda representar? El redactor no está conectado; no inventar una respuesta.'),
    },
  }
}

// Router y planner en UNA inferencia: mismo estado, preguntas unidas. Sus decisiones se interpretan por separado y
// con la misma política; solo se renombra la única pregunta repetida. Ahorra una pasada completa del modelo.
const RENOMBRES = { needs_clarification: 'needs_clarification_metrica' }
export function solicitudConjunta(ruta, plan) {
  const questions = { ...ruta.questions }
  for (const [id, q] of Object.entries(plan.questions)) {
    if (id === 'periodo') continue
    const destino = RENOMBRES[id] ?? id
    if (questions[destino]) throw new Error(`Pregunta duplicada en la inferencia conjunta: ${destino}`)
    questions[destino] = q
  }
  return { model: 'clef-flash', state: plan.state, questions }
}
export function separarRespuesta(respuesta, ruta, plan) {
  const parte = (ids, nombre = (id) => id) => ({ ...respuesta, answers: Object.fromEntries(ids.filter((id) => respuesta.answers?.[nombre(id)]).map((id) => [id, respuesta.answers[nombre(id)]])) })
  return [parte(Object.keys(ruta.questions)), parte(Object.keys(plan.questions).filter((id) => id !== 'periodo'), (id) => RENOMBRES[id] ?? id)]
}
