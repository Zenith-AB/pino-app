import { esTableroEnlazado } from './tipos-escenario.js'
// Contratos de lógica: estos identificadores apuntan a componentes y posiciones ya implementados.
// No contienen código de render, estilos ni capacidades hipotéticas habilitadas.
export const VERSION_COGNITIVA = 'patagonia-clef-2'
export const DOMINIOS = {
  produccion: 'Lechería: ordeña, litros producidos, leche aceptada o rechazada en planta, exclusión por retiro sanitario y vacas en retiro. Disponible únicamente en la fuente lechera.',
  ventas: 'Ingresos, facturación, unidades vendidas y ranking de productos por cantidad vendida (más o menos vendido), incluso consultados desde Inventario', rentabilidad: 'Margen, costo, descuentos y resultado',
  cobranza: 'Dinero pendiente de clientes, deudores y vencimientos, y dinero cobrado o recaudado de clientes (pagos recibidos)', inventario: 'Existencias disponibles, valor de stock, cobertura y reposición. La cantidad vendida se mide con las capacidades de ventas.',
  contexto: 'Continuar el dominio activo de la sesión o conversación', incierto: 'No hay contexto suficiente para identificar el dominio',
}
export const METRICAS = {
  leche_producida:{dominio:'produccion',nombre:'Leche ordeñada',unidad:'L',escenarios:['lechera_sintetica_clp'], descripcion: 'Litros de leche ordeñados en los predios durante el período (producción primaria).'},
  leche_aceptada:{dominio:'produccion',nombre:'Leche aceptada en planta',unidad:'L',escenarios:['lechera_sintetica_clp'], descripcion: 'Litros de leche recibidos y aceptados por la planta durante el período.'},
  leche_retiro:{dominio:'produccion',nombre:'Leche excluida por retiro',unidad:'L',escenarios:['lechera_sintetica_clp'], descripcion: 'Litros de leche excluidos por retiro sanitario de animales en tratamiento durante el período.'},
  leche_rechazada:{dominio:'produccion',nombre:'Leche rechazada en recepción',unidad:'L',escenarios:['lechera_sintetica_clp'], descripcion: 'Litros de leche rechazados en la recepción de planta durante el período.'},
  vacas_retiro:{dominio:'produccion',nombre:'Vacas en retiro al corte',unidad:'animales',escenarios:['lechera_sintetica_clp'], descripcion: 'Cantidad de animales (vacas) en retiro o resguardo sanitario al corte. Cuenta animales, no litros.'},
  venta: { dominio: 'ventas', nombre: 'Venta neta', unidad: 'moneda', descripcion: 'Venta neta: importe facturado o ingresos por ventas del período, en moneda. Ventas sin otra medida explícita significa venta neta. No es el dinero cobrado ni la cantidad de artículos.' },
  unidades: { dominio: 'ventas', nombre: 'Unidades vendidas', unidad: 'unidades', descripcion: 'Unidades vendidas: cantidad de artículos vendidos en el período (volumen, no dinero). El producto más o menos vendido se mide por cantidad.' },
  margen: { dominio: 'rentabilidad', nombre: 'Margen bruto', unidad: '%', descripcion: 'Margen bruto: (venta neta − costo de venta) / venta neta, en %. Cuánto se gana sobre lo vendido.' },
  costo: { dominio: 'rentabilidad', nombre: 'Costo de venta', unidad: 'moneda', descripcion: 'Costo de venta: costo de los productos vendidos en el período, en moneda.' },
  descuento: { dominio: 'rentabilidad', nombre: 'Descuentos sobre venta bruta', unidad: '%', descripcion: 'Descuentos: rebajas otorgadas sobre la venta bruta (precio de lista) en el período, en % de la venta bruta.' },
  ebitda: { dominio: 'rentabilidad', nombre: 'EBITDA sintético presupuestado', unidad: 'moneda', descripcion: 'EBITDA sintético presupuestado: venta − costo − gasto presupuestado del período, en moneda.' },
  cartera: { dominio: 'cobranza', nombre: 'Cuentas por cobrar al corte', unidad: 'moneda', descripcion: 'Cuentas por cobrar: saldo que los clientes aún deben al corte (pendiente de pago), vencido o por vencer. Es un saldo, no lo cobrado.' },
  vencida: { dominio: 'cobranza', nombre: 'Cartera vencida al corte', unidad: 'moneda', descripcion: 'Cartera vencida: parte del saldo por cobrar al corte cuya fecha de vencimiento ya pasó.' },
  pagos: { dominio: 'cobranza', nombre: 'Pagos recibidos en el período', unidad: 'moneda', descripcion: 'Pagos recibidos: dinero efectivamente cobrado o recaudado de clientes durante el período (entradas de caja de cobranza). Es un flujo, no el saldo pendiente ni lo facturado.' },
  stock: { dominio: 'inventario', nombre: 'Valor de existencias al corte', unidad: 'moneda', descripcion: 'Valor de existencias: inventario disponible al corte, valorizado a costo.' },
}
export const ONTOLOGIA = {
  produccion: {principal:'leche_producida',relaciones:['predio','ordeña','recepción','calidad','retiro sanitario']},
  ventas: { principal: 'venta', relaciones: ['unidades', 'precio medio', 'producto', 'sucursal', 'pais', 'canal', 'cliente'] },
  rentabilidad: { principal: 'margen', relaciones: ['venta', 'costo', 'descuento', 'mezcla de productos', 'logística no medida'] },
  cobranza: { principal: 'cartera', relaciones: ['vencida', 'pagos', 'cliente', 'promesas', 'antigüedad'] },
  inventario: { principal: 'stock', relaciones: ['demanda', 'producto', 'recepciones', 'cobertura', 'quiebres proyectados'] },
}
export const COMPONENTES = Object.freeze({
  AnalyticsCard: { preset: 'agente', slot: 'analytics', dominios: ['ventas', 'rentabilidad'], props: { metrica: ['venta', 'margen', 'unidades'], modo: ['line', 'bars'], periodo: ['year', 'quarter'] }, descripcion: 'KPIs y TrendChart existentes del tablero del agente' },
  DetailCard: { preset: 'agente', slot: 'detail', dominios: ['ventas'], props: { listado: ['paises', 'productos'] }, descripcion: 'Detalle existente por sucursal, país o producto' },
  SalesView: { preset: 'ventas', slot: 'vista', dominios: ['ventas'], props: {}, descripcion: 'Seis gráficos originales, KPIs y listado de Ventas' },
  ProfitView: { preset: 'rentabilidad', slot: 'vista', dominios: ['rentabilidad'], props: {}, descripcion: 'Margen, Sankey y tendencias originales de Rentabilidad' },
  CollectionsView: { preset: 'cobranza', slot: 'vista', dominios: ['cobranza'], props: {}, descripcion: 'Embudo, vencimientos, antigüedad y pagos originales de Cobranza' },
  InventoryView: { preset: 'inventario', slot: 'vista', dominios: ['inventario'], props: {}, descripcion: 'StockProjection, movimientos y cobertura originales de Inventario' },
  AgentDock: { preset: null, slot: 'chat_existente', dominios: Object.keys(ONTOLOGIA), props: {}, descripcion: 'Texto estructurado en la conversación existente, sin crear un componente' },
})
export const PRESETS = Object.freeze({
  agente: ['AnalyticsCard', 'DetailCard', 'AgentDock'], ventas: ['SalesView', 'AgentDock'],
  rentabilidad: ['ProfitView', 'AgentDock'], cobranza: ['CollectionsView', 'AgentDock'], inventario: ['InventoryView', 'AgentDock'],
})
export const CAPACIDADES = Object.freeze({
  get_recent_sales: { required_slots: ['domain'], optional_slots: ['period'], tipo: 'read', dominios: ['ventas'], descripcion: 'Últimas ocho facturas sintéticas ordenadas por fecha e identificador. Sin período explícito, últimos registros de toda la cobertura; no devuelve un agregado anual.' },
  get_kpi: { required_slots: ['domain', 'metric', 'period'], optional_slots: ['entity', 'comparison_period'], tipo: 'read', dominios: Object.keys(ONTOLOGIA), descripcion: 'Recuperar una métrica registrada del período o corte; devuelve valor, unidad y procedencia.' },
  get_timeseries: { required_slots: ['domain', 'metric', 'period'], optional_slots: ['entity', 'comparison_period'], tipo: 'read', dominios: Object.keys(ONTOLOGIA), descripcion: 'Serie mensual cubierta de la métrica, sin inventar puntos futuros.' },
  compare_periods: { required_slots: ['domain', 'metric', 'period'], optional_slots: ['entity', 'comparison_period'], tipo: 'analysis', dominios: Object.keys(ONTOLOGIA), descripcion: 'Comparar dos períodos cubiertos, con diferencias calculadas y unidad.' },
  rank_entities: { required_slots: ['domain', 'metric', 'period', 'entity'], optional_slots: ['comparison_period'], tipo: 'analysis', dominios: Object.keys(ONTOLOGIA), descripcion: 'Ordenar entidades disponibles: países/productos/sucursales/clientes; no crea una tabla nueva.' },
  detect_anomalies: { required_slots: ['domain', 'metric', 'period'], optional_slots: ['entity', 'comparison_period'], tipo: 'analysis', dominios: ['ventas'], descripcion: 'Umbral de caída del 25 % por sucursal; señal de prueba, sin causalidad.' },
  find_drivers: { required_slots: ['domain', 'metric', 'period'], optional_slots: ['entity', 'comparison_period'], tipo: 'analysis', dominios: ['ventas', 'rentabilidad'], descripcion: 'Contribuciones aditivas conciliadas a la variación de ventas o margen bruto; no prueba una causa.' },
  detect_stockout: { required_slots: ['domain', 'metric', 'period'], optional_slots: ['entity', 'comparison_period'], tipo: 'analysis', dominios: ['inventario'], descripcion: 'Riesgo proyectado desde stock, demanda y recepciones existentes.' },
})
export const NO_IMPLEMENTADAS = Object.freeze(['forecast_metric', 'detect_change_point', 'segment_customers', 'retrieve_documents', 'search_entities_por_nombre', 'acciones_de_escritura', 'llm_redactor'])
export function buscarCapacidades(escenario, dominio, metrica) {
  const sintetico = esTableroEnlazado(escenario.id)
  return Object.entries(CAPACIDADES).filter(([id, c]) => c.dominios.includes(dominio)
    && (!METRICAS[metrica]?.escenarios || METRICAS[metrica].escenarios.includes(escenario.id))
    && (dominio !== 'produccion' || escenario.id === 'lechera_sintetica_clp' && ['get_kpi','get_timeseries','compare_periods'].includes(id))
    && (sintetico || dominio === 'ventas' && ['venta', 'unidades'].includes(metrica) && ['get_kpi', 'get_timeseries', 'compare_periods', 'rank_entities'].includes(id)))
    .map(([id, c]) => ({ id, ...c, entradas: [...c.required_slots, ...c.optional_slots], salida: 'resultado verificado con procedencia', efectos: 'ninguna escritura' }))
}
export function buscarComponentes(dominio) {
  return Object.entries(COMPONENTES).filter(([, c]) => c.dominios.includes(dominio)).map(([id, c]) => ({ id, ...c }))
}
export function validarPresentacion(plan) {
  const c = COMPONENTES[plan?.componente]
  if (Object.keys(plan ?? {}).some((k) => !['componente', 'preset', 'props', 'slots', 'capacidades_no_cubiertas'].includes(k)) || plan?.slots && plan.slots !== c?.slot) throw new Error('Configuración visual fuera del registro.')
  if (!c || plan.preset !== c.preset || c.preset && !PRESETS[c.preset].includes(plan.componente)) throw new Error('Componente o preset fuera del registro.')
  for (const [key, value] of Object.entries(plan.props ?? {})) if (!c.props[key]?.includes(value)) throw new Error('Propiedad visual fuera del registro.')
  return plan
}

// Gráficos internos existentes: configuración de datos para el slot AgentCard.
// No altera las opciones del planner ni autoriza crear componentes.
export const GRAFICOS_AGENTE = Object.freeze({
  Columns: { archivo:'Charts.jsx', representacion:'barras' },
  SmoothTrend: { archivo:'Charts.jsx', representacion:'tendencia' },
})
