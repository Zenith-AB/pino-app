// El registro define capacidades ejecutables. Clef decide la intención; estas funciones calculan y verifican.
// No hay SQL libre, gráficos arbitrarios ni acciones de escritura en este contrato.
import { DATASET_SINTETICO, tableroSintetico } from './sintetico.js'

export const REGISTRO_HERRAMIENTAS = Object.freeze({
  get_kpi: { escenarios: ['uci_online_retail_ii', 'uci_online_retail_ii_clp', 'patagonia_sintetico_clp'], descripcion: 'Indicadores calculados desde registros del escenario.' },
  compare_periods: { escenarios: ['uci_online_retail_ii', 'uci_online_retail_ii_clp', 'patagonia_sintetico_clp'], descripcion: 'Variación entre períodos cubiertos.' },
  detect_anomalies: { escenarios: ['patagonia_sintetico_clp'], descripcion: 'Desviaciones por sucursal frente al mismo período del año anterior.' },
  find_drivers: { escenarios: ['patagonia_sintetico_clp'], descripcion: 'Contribución aritmética de cada sucursal a la variación.' },
  rank_entities: { escenarios: ['uci_online_retail_ii', 'uci_online_retail_ii_clp', 'patagonia_sintetico_clp'], descripcion: 'Orden de países, productos o sucursales según el escenario.' },
})

const sumar = (filas, campo) => filas.reduce((total, fila) => total + fila[campo], 0)
const enPeriodo = (fecha, periodo) => fecha >= periodo.desde && fecha < periodo.hasta
const variacion = (actual, anterior) => anterior ? (actual - anterior) / Math.abs(anterior) * 100 : null
const dinero = (valor) => new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1 }).format(valor / 1000000) + ' MM$'
const porcentaje = (valor) => new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1 }).format(Math.abs(valor)) + ' %'

export function diagnosticarSintetico(variables, dataset = DATASET_SINTETICO) {
  const tablero = tableroSintetico(variables, dataset)
  const { periodo, comparacion } = tablero
  if (!comparacion) return { estado: 'sin_comparacion', texto: `No hay un período comparable cubierto para ${periodo.corto}.`, herramientas: ['get_kpi'], evidencia: [] }
  const actuales = dataset.facturas.filter((f) => enPeriodo(f.fecha, periodo))
  const anteriores = dataset.facturas.filter((f) => enPeriodo(f.fecha, comparacion))
  const sucursales = [...new Set(dataset.facturas.map((f) => f.sucursal))]
  const detalle = sucursales.map((nombre) => {
    const actual = sumar(actuales.filter((f) => f.sucursal === nombre), 'venta')
    const anterior = sumar(anteriores.filter((f) => f.sucursal === nombre), 'venta')
    return { nombre, actual, anterior, diferencia: actual - anterior, variacion_pct: variacion(actual, anterior) }
  }).sort((a, b) => a.diferencia - b.diferencia)
  const totalActual = sumar(actuales, 'venta')
  const totalAnterior = sumar(anteriores, 'venta')
  const verificado = totalActual === tablero.indicadores.venta
    && totalAnterior === tablero.indicadores.venta_anterior
    && sumar(detalle, 'actual') === totalActual
    && sumar(detalle, 'anterior') === totalAnterior
    && sumar(detalle, 'diferencia') === totalActual - totalAnterior
  if (!verificado || detalle.some((f) => !Number.isFinite(f.variacion_pct))) throw new Error('El diagnóstico no concilia con las facturas.')
  const anomalias = detalle.filter((f) => f.variacion_pct <= -25 && f.diferencia < 0)
  const principal = anomalias[0] ?? null
  const cambio = variacion(totalActual, totalAnterior)
  const texto = principal
    ? `En ${periodo.corto}, la venta fue ${dinero(totalActual)} (${cambio < 0 ? 'bajó' : 'subió'} ${porcentaje(cambio)} frente a ${comparacion.corto}). ${principal.nombre} registró ${dinero(principal.actual)}, una baja de ${porcentaje(principal.variacion_pct)}; su diferencia de ${dinero(Math.abs(principal.diferencia))} es la mayor contribución negativa. Conviene revisar sus facturas y demanda. Es una señal del escenario sintético, no una causa demostrada.`
    : `En ${periodo.corto}, la venta fue ${dinero(totalActual)} frente a ${dinero(totalAnterior)} en ${comparacion.corto}. Ninguna sucursal superó el umbral de caída del 25 % usado en esta prueba.`
  return {
    estado: principal ? 'hallazgo' : 'sin_hallazgo',
    texto,
    destino: 'agente',
    herramientas: ['get_kpi', 'compare_periods', 'detect_anomalies', 'find_drivers', 'rank_entities'],
    metodo: 'Variación de venta por sucursal frente al período comparable; caída de 25 % o más. Contribuciones aditivas verificadas.',
    periodo: periodo.corto, comparacion: comparacion.corto, moneda: 'CLP', naturaleza_datos: 'sintetico',
    evidencia: { venta_actual: totalActual, venta_anterior: totalAnterior, variacion_pct: cambio, sucursales: detalle },
    principal,
  }
}
