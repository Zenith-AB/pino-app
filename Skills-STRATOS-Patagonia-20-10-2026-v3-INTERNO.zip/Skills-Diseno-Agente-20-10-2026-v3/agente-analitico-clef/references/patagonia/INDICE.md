# Índice de anexos · patagonia-05-motor-cognitivo-clef

Copia literal del proyecto al 19-10-2026 (salvo los parches, que viven en `../parches/`).
La descripción es la primera línea significativa de cada archivo.

| Archivo | Tamaño | Descripción |
|---|---:|---|
| `ORQUESTACION_ERP.md` | 12 KiB | Clef como orquestador de Patagonia ERP |
| `README-clef.md` | 8 KiB | El circuito ERP vigente se documenta en [ORQUESTACION_ERP.md](ORQUESTACION_ERP.md): world state, planner, herramientas v |
| `aclaraciones-cognitivas.js` | 7 KiB | const labels = Object.fromEntries(Object.entries(METRICAS).map(([id, m]) => [id, [m.nombre]])) |
| `calendario.js` | 17 KiB | Gramática de calendario: resuelve fechas, nunca intención empresarial ni cifras. |
| `ciclo-cognitivo.js` | 43 KiB | const flagsHerramientas = { needs_comparison: 'compare_periods', needs_timeseries: 'get_timeseries', needs_ranking: 'ran |
| `contratos.md` | 2 KiB | Anexo · contratos verbatim del motor cognitivo (snapshot 19-10-2026) |
| `decisiones-cognitivas.js` | 36 KiB | Valores iniciales conservadores: probabilidades relativas, NO confianza calibrada. |
| `dialogo.js` | 9 KiB | const terminal = new Set(['COMPLETED', 'CANCELLED', 'FAILED']) |
| `estado-cognitivo.js` | 5 KiB | El navegador no puede inventar roles, permisos, hallazgos ni entidades. La memoria es firmada, |
| `herramientas-cognitivas.js` | 17 KiB | const sum = (xs, key) => xs.reduce((s, x) => s + (typeof key === 'function' ? key(x) : x[key]), 0) |
| `orquestador.js` | 5 KiB | El registro define capacidades ejecutables. Clef decide la intención; estas funciones calculan y verifican. |
| `perfiles-lectura.js` | 3 KiB | Perfiles de prueba: prioridades de lectura, nunca permisos operacionales. |
| `registro-cognitivo.js` | 11 KiB | Contratos de lógica: estos identificadores apuntan a componentes y posiciones ya implementados. |
| `respuestas-cognitivas.js` | 7 KiB | const fmt = (n) => n == null ? 'sin medición' : new Intl.NumberFormat('es-CL', { maximumFractionDigits: 2 }).format(Numb |
| `sugerencias-cognitivas.js` | 4 KiB | if (!METRICAS[metrica] \|\| METRICAS[metrica].dominio !== dominio) return {} |
| `supervisor-conversacion.js` | 15 KiB | const randomUUID = newTurnId |
| `variables.js` | 14 KiB | Variables de la vista Ventas: referencias simbólicas que se resuelven contra la cobertura cada vez que se abre |
| `vinculo.js` | 8 KiB | Vínculo vivo entre una respuesta de Clef y el tablero. Clef decide UNA vez qué conectar (dominio, métricas, entidad, |
