import { esTableroEnlazado } from './tipos-escenario.js'
// Variables de la vista Ventas: referencias simbólicas que se resuelven contra la cobertura cada vez que se abre
// la vista. Clef (u otra persona) elige opciones de este catálogo; nunca escribe fechas ni cifras. Si los datos
// avanzan, la misma elección resuelve a otro período sin reescribirla.
// Lo comparten el servicio de datos (preguntas para Clef y validación) y la interfaz (resolución y rótulos).

import { opcionTemporal, periodoEnCurso } from './calendario.js'
export const SIN_CAMBIO = 'sin_cambio'
export const DESTINOS = {
  agente: 'Tablero del agente: síntesis de indicadores y exploración general',
  ventas: 'Ventas: ingresos, facturas, productos y sucursales',
  rentabilidad: 'Rentabilidad: margen, costos y resultado bruto',
  cobranza: 'Cobranza: cartera, vencimientos, pagos y mora',
  inventario: 'Inventario: existencias, entradas, salidas y valor de stock',
}

export const INTENCIONES = {
  navegar: 'Abrir una sección o ajustar sus variables sin pedir un diagnóstico.',
  diagnosticar: 'Investigar cambios inusuales, causas o algo que debería preocupar.',
  comparar: 'Comparar indicadores entre períodos o segmentos.',
  resumir: 'Dar una lectura breve del estado del negocio con cifras.',
  sin_cambio: 'La petición no permite elegir una acción sustentada.',
}

export const VARIABLES_VENTAS = {
  periodo: {
    nombre: 'Período',
    instrucciones: '¿Qué período pide la consulta? Si no menciona un período, elige sin_cambio.',
    opciones: {
      ultimo_trimestre_completo: { rotulo: 'Último trimestre completo', criterio: 'El trimestre calendario completo más reciente.' },
      ultimo_mes_completo: { rotulo: 'Último mes completo', criterio: 'El mes calendario completo más reciente.' },
      ultimo_anio_completo: { rotulo: 'Último año completo', criterio: 'El año calendario completo más reciente.' },
    },
    predeterminada: 'ultimo_trimestre_completo',
  },
  comparacion: {
    nombre: 'Comparación',
    instrucciones: '¿Contra qué período pide comparar la consulta? Si no menciona una comparación, elige sin_cambio.',
    opciones: {
      mismo_periodo_anio_anterior: { rotulo: 'Mismo período del año anterior', criterio: 'Comparar con el mismo período un año antes (interanual).' },
      periodo_anterior: { rotulo: 'Período inmediatamente anterior', criterio: 'Comparar con el período de igual duración justo antes (por ejemplo, el mes o trimestre previo).' },
    },
    predeterminada: 'mismo_periodo_anio_anterior',
  },
  listado: {
    nombre: 'Listado',
    instrucciones: '¿Por qué dimensión pide ver el detalle la consulta? Si no lo menciona, elige sin_cambio.',
    opciones: {
      paises: { rotulo: 'Países', criterio: 'Detalle por país, mercado o destino.' },
      productos: { rotulo: 'Productos', criterio: 'Detalle por producto, artículo o referencia.' },
    },
    predeterminada: 'paises',
  },
  foco: {
    nombre: 'Foco',
    instrucciones: '¿La consulta pide concentrarse en el país principal o volver a ver todos los países? Si no lo menciona, elige sin_cambio.',
    opciones: {
      todos: { rotulo: 'Todos los países', criterio: 'Sin filtro de país: el total del negocio.' },
      pais_principal: { rotulo: 'País principal', criterio: 'Solo el país con mayor venta del período, que el sistema identifica al abrir la vista.' },
    },
    predeterminada: 'todos',
  },
}

export const variablesPredeterminadas = () => Object.fromEntries(Object.entries(VARIABLES_VENTAS).map(([id, v]) => [id, v.predeterminada]))
VARIABLES_VENTAS.periodo.opciones = new Proxy(VARIABLES_VENTAS.periodo.opciones, { get: (opciones, id) => opciones[id] ?? opcionTemporal(id) })
VARIABLES_VENTAS.comparacion.opciones = new Proxy(VARIABLES_VENTAS.comparacion.opciones, { get: (opciones, id) => opciones[id] ?? opcionTemporal(id) })

// Acepta solo opciones del catálogo; lo desconocido vuelve al valor predeterminado.
export function validarVariables(entrada = {}) {
  const resultado = variablesPredeterminadas()
  for (const [id, definicion] of Object.entries(VARIABLES_VENTAS)) {
    if (typeof entrada[id] === 'string' && definicion.opciones[entrada[id]]) resultado[id] = entrada[id]
  }
  // Con foco en un país, un listado por países tendría una sola fila: el detalle pasa a productos.
  if (resultado.foco === 'pais_principal') resultado.listado = 'productos'
  return resultado
}

/* ---------- Resolución contra la cobertura ---------- */

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
const ORDINAL = ['Primer', 'Segundo', 'Tercer', 'Cuarto']
const iso = (fecha) => fecha.toISOString().slice(0, 10)
const sumarMeses = (texto, meses) => {
  const f = new Date(`${texto}T00:00:00Z`)
  return iso(new Date(Date.UTC(f.getUTCFullYear(), f.getUTCMonth() + meses, 1)))
}
const MESES_DE = { ultimo_trimestre_completo: 3, ultimo_mes_completo: 1, ultimo_anio_completo: 12 }

function describir(desde, meses) {
  const anio = Number(desde.slice(0, 4))
  const mes = Number(desde.slice(5, 7))
  if (meses === 12) return { corto: String(anio), titulo: `Año ${anio}` }
  if (meses === 3) { const t = Math.floor((mes - 1) / 3) + 1; return { corto: `${t}T ${anio}`, titulo: `${ORDINAL[t - 1]} trimestre`, numero: t } }
  if (meses !== 1) { const corto = `${desde} a ${iso(new Date(Date.parse(sumarMeses(desde, meses)) - 864e5))}`; return { corto, titulo: corto } }
  return { corto: `${MESES[mes - 1].slice(0, 3)}. ${anio}`, titulo: `${MESES[mes - 1][0].toUpperCase()}${MESES[mes - 1].slice(1)} de ${anio}` }
}

// Período completo más reciente dentro de la cobertura, alineado al calendario (trimestres y años naturales).
// El fin es el día 1 del mes en que termina la cobertura, llevado hacia atrás hasta un límite del calendario:
// un mes con datos incompletos nunca entra.
export function resolverPeriodo(opcion, { primer_dia, ultimo_dia }, hoy) {
  // En curso: desde el inicio del año o mes del reloj hasta el último registro cubierto (inclusive).
  if (String(opcion).startsWith('en_curso:')) {
    const r = periodoEnCurso(opcion, hoy)
    if (!r) return null
    const desde = r.desde < primer_dia ? primer_dia : r.desde
    const finCobertura = iso(new Date(Date.parse(`${ultimo_dia}T00:00:00Z`) + 864e5))
    const hasta = r.hasta < finCobertura ? r.hasta : finCobertura
    if (desde >= hasta) return null
    const alineado = desde.endsWith('-01') && hasta.endsWith('-01')
    const meses = alineado ? (Number(hasta.slice(0, 4)) - Number(desde.slice(0, 4))) * 12 + Number(hasta.slice(5, 7)) - Number(desde.slice(5, 7)) : null
    const corto = `${r.corto} (hasta ${iso(new Date(Date.parse(hasta) - 864e5))})`
    return { desde, hasta, ...(meses ? { meses } : { dias: (Date.parse(hasta) - Date.parse(desde)) / 864e5 }), en_curso: r.en_curso, corto, titulo: corto }
  }
  const calendario = opcionTemporal(opcion)
  if (calendario) return calendario.desde >= primer_dia && calendario.hasta <= iso(new Date(Date.parse(ultimo_dia) + 864e5)) ? calendario : null
  const meses = MESES_DE[opcion]
  if (!meses) return null
  const finCobertura = iso(new Date(Date.parse(`${ultimo_dia}T00:00:00Z`) + 864e5))
  const inicioMes = `${finCobertura.slice(0, 7)}-01`
  const hasta = sumarMeses(inicioMes, -((Number(inicioMes.slice(5, 7)) - 1) % meses))
  const desde = sumarMeses(hasta, -meses)
  if (desde < primer_dia) return null
  return { desde, hasta, meses, ...describir(desde, meses) }
}

export function resolverVariables(variables, cobertura) {
  const v = validarVariables(variables)
  const actual = resolverPeriodo(v.periodo, cobertura)
  if (!actual) return { variables: v, actual: null, anterior: null, motivoComparacion: 'La cobertura no tiene un período completo de ese largo.' }
  if (opcionTemporal(v.comparacion)) {
    const anterior = resolverPeriodo(v.comparacion, cobertura)
    return { variables: v, actual, anterior, motivoComparacion: anterior ? null : 'El período de comparación está fuera de la cobertura.' }
  }
  const desplazamiento = v.comparacion === 'periodo_anterior' ? -actual.meses : -12
  const desde = actual.meses ? sumarMeses(actual.desde, desplazamiento) : v.comparacion === 'periodo_anterior' ? iso(new Date(Date.parse(actual.desde) - actual.dias * 864e5)) : actual.desde.replace(/^\d{4}/, String(Number(actual.desde.slice(0,4))-1))
  const hasta = actual.meses ? sumarMeses(actual.hasta, desplazamiento) : v.comparacion === 'periodo_anterior' ? actual.desde : actual.hasta.replace(/^\d{4}/, String(Number(actual.hasta.slice(0,4))-1))
  const calendarioAnterior = actual.meses ? null : opcionTemporal(actual.dias === 1 ? `dia:${desde}` : `rango:${desde}:${hasta}`)
  const anterior = desde >= cobertura.primer_dia && (actual.meses || calendarioAnterior) ? actual.meses ? { desde, hasta, meses: actual.meses, ...describir(desde, actual.meses) } : calendarioAnterior : null
  return {
    variables: v,
    actual,
    anterior,
    motivoComparacion: anterior ? null : `Sin comparación: la cobertura empieza el ${cobertura.primer_dia}.`,
  }
}

/* ---------- Preguntas para Clef ---------- */

// Una pregunta choice por variable, con la opción sin_cambio. El estado lleva la consulta, las variables vigentes
// y la cobertura; no lleva cifras, porque Clef elige referencias y no calcula.
export function solicitudVariables(consulta, actuales, escenario, contexto = {}) {
  const vigentes = validarVariables(actuales)
  const questions = Object.fromEntries(Object.entries(VARIABLES_VENTAS).map(([id, definicion]) => [id, {
    type: 'choice',
    instructions: definicion.instrucciones,
    criteria: {
      ...Object.fromEntries(Object.entries(definicion.opciones).map(([opcion, o]) => [opcion, o.criterio])),
      [SIN_CAMBIO]: `La consulta no pide cambiar ${definicion.nombre.toLowerCase()}; se mantiene «${definicion.opciones[vigentes[id]].rotulo}».`,
    },
  }]))
  if (esTableroEnlazado(escenario?.id)) {
    delete questions.foco
    questions.listado.criteria.paises = 'Detalle por sucursal de la empresa sintética.'
  }
  questions.destino = {
    type: 'choice',
    instructions: 'Elige la pestaña que responde a la intención principal del usuario. Si no pide una materia concreta, elige sin_cambio. No propongas vistas sin respaldo en el escenario.',
    criteria: {
      ...DESTINOS,
      [SIN_CAMBIO]: 'Mantener la pestaña actual; la consulta solo ajusta período, comparación o detalle.',
    },
  }
  questions.intencion = {
    type: 'choice',
    instructions: 'Clasifica la acción principal. No infieras que existe una herramienta no listada.',
    criteria: INTENCIONES,
  }
  return {
    model: 'clef-flash',
    state: {
      consulta_usuario: consulta,
      pantalla_actual: contexto.vista ?? 'desconocida',
      consulta_anterior: contexto.anterior ?? null,
      vista: 'ERP Patagonia: tablero del agente, Ventas, Rentabilidad, Cobranza e Inventario',
      disponibilidad: esTableroEnlazado(escenario?.id)
        ? 'Datos sintéticos de ventas, costo, pagos e inventario en CLP; todas las pestañas principales medibles.'
        : 'Ventas reales disponibles. Rentabilidad, Cobranza e Inventario no están medidos en UCI.',
      herramientas_disponibles: esTableroEnlazado(escenario?.id)
        ? ['get_kpi', 'compare_periods', 'detect_anomalies', 'find_drivers', 'rank_entities']
        : ['get_kpi', 'compare_periods', 'rank_entities'],
      variables_vigentes: Object.fromEntries(Object.entries(vigentes).map(([id, opcion]) => [VARIABLES_VENTAS[id].nombre, VARIABLES_VENTAS[id].opciones[opcion].rotulo])),
      cobertura_datos: escenario?.cobertura ? `${escenario.cobertura.primer_dia} a ${escenario.cobertura.ultimo_dia}` : 'desconocida',
    },
    questions,
  }
}

// Umbral elegido con el conjunto de desarrollo (servicios/clef/informe_variables.md): la mejor opción concreta se
// propone si su probabilidad relativa alcanza 0,4; si no, sin_cambio. No es una confianza calibrada.
export const UMBRAL_PROPUESTA = 0.4

// Respuesta SystemOne → propuesta de cambios. Solo opciones del catálogo; sin_cambio conserva la vigente.
// Con umbral, decide por probabilidades; sin umbral, usa la opción ganadora de la respuesta.
export function interpretarRespuesta(respuesta, actuales, { umbral, consulta = '' } = {}) {
  const vigentes = validarVariables(actuales)
  const cambios = {}
  for (const [id, definicion] of Object.entries(VARIABLES_VENTAS)) {
    const r = respuesta?.answers?.[id]
    if (!r || r.type !== 'choice') continue
    let elegida = r.choice
    let probabilidad = r.confidence
    if (umbral != null && r.probabilities) {
      const [mejor, p] = Object.entries(r.probabilities).filter(([o]) => o !== SIN_CAMBIO).sort((x, y) => y[1] - x[1])[0]
      elegida = p >= umbral ? mejor : SIN_CAMBIO
      probabilidad = p
    }
    if (elegida !== SIN_CAMBIO && !definicion.opciones[elegida]) throw new Error(`Respuesta fuera del catálogo para ${id}: ${elegida}`)
    if (elegida !== SIN_CAMBIO && elegida !== vigentes[id]) cambios[id] = { desde: vigentes[id], hacia: elegida, probabilidad }
  }
  const propuestas = validarVariables({ ...vigentes, ...Object.fromEntries(Object.entries(cambios).map(([id, c]) => [id, c.hacia])) })
  const respuestaDestino = respuesta?.answers?.destino
  const probabilidades = respuestaDestino?.probabilities ?? {}
  const [mejorDestino, probabilidadDestino] = Object.entries(probabilidades).filter(([id]) => id !== SIN_CAMBIO && id in DESTINOS).sort((a, b) => b[1] - a[1])[0] ?? []
  const eleccionModelo = respuestaDestino?.type === 'choice'
    ? (umbral == null ? respuestaDestino.choice : probabilidadDestino >= umbral ? mejorDestino : SIN_CAMBIO)
    : SIN_CAMBIO
  const destino = eleccionModelo in DESTINOS ? eleccionModelo : SIN_CAMBIO
  const respuestaIntencion = respuesta?.answers?.intencion
  const intencion = respuestaIntencion?.type === 'choice' && respuestaIntencion.confidence >= 0.55 && respuestaIntencion.choice in INTENCIONES
    ? respuestaIntencion.choice : 'navegar'
  return { cambios, variables: propuestas, destino, intencion }
}
