El circuito ERP vigente se documenta en [ORQUESTACION_ERP.md](ORQUESTACION_ERP.md): world state, planner, herramientas verificadas y judge; presentación limitada a componentes existentes. Las evaluaciones de variables anteriores son históricas y no calibran este circuito.

# Clef-Flash en Patagonia: variables y orquestación

**Estado actual (6/10/2026):** Clef construye decisiones de routing y planificación sobre contexto operacional, ejecuta herramientas permitidas y juzga resultados compactos. La respuesta usa plantillas y componentes de demo registrados. Los capítulos de evaluación de variables que siguen describen el adaptador anterior; no calibran esta arquitectura.

Clef no genera el dashboard ni escribe cifras. Elige **variables** del tablero fijo del Agente y de Ventas entre opciones de un catálogo compartido. Las variables son referencias simbólicas, como «último trimestre completo» o «mismo período del año anterior», que la aplicación resuelve contra la cobertura de los datos cada vez que se abre la vista. Si los datos avanzan, la misma elección muestra otro período sin reescribirla: con cobertura hasta el 9/12/2011 se resuelve como 3T 2011 frente a 3T 2010; con cobertura hasta el 3/4/2012 sería 1T 2012 frente a 1T 2011 (prueba en `servicios/datos/test/variables.test.js`).

## Piezas

| Pieza | Qué hace |
| --- | --- |
| [`../datos/src/variables.js`](../datos/src/variables.js) | Catálogo (`periodo`, `comparacion`, `listado`, `foco`), resolución contra la cobertura, preguntas SystemOne con `sin_cambio`, validación y regla de decisión. Lo comparten el servicio de datos y la interfaz. |
| `GET /escenarios/{id}/variables/ventas/propuesta` | En el servicio de datos: arma la pregunta desde el catálogo, consulta a Clef y devuelve una propuesta estructurada, cómo se resolvería y las probabilidades. El endpoint no escribe datos ni preferencias. |
| [`servicio.py`](servicio.py) | Endpoint local compatible con SystemOne (`POST /v1/systemone`) en 127.0.0.1:4185, con secreto. Carga el modelo en la primera solicitud y termina tras 10 minutos sin uso; systemd lo deja en reposo sin tocar la GPU. |
| [`clef_local.py`](clef_local.py) | Carga NF4 para la RTX 4070 compartida y respuesta con dispositivo explícito. |
| Interfaz | Inicio, tablero del Agente y chat comparten las variables del escenario. Una selección vigente se aplica de inmediato y la vista vuelve a consultar la fuente. Si el escenario o las variables cambiaron mientras respondía Clef, la respuesta se descarta. Una intención explícita puede abrir la pestaña correspondiente. |

Recorrido UCI: elegir el escenario desde Ventas o un tablero, volver al inicio y enviar «Quiero ver solo el país principal en el último mes». El período pasa a «nov. 2011», el detalle a productos y el foco a United Kingdom; el valor neto proviene de `serie` y `desglose`. Clef puede abrir **Ventas** por la intención explícita. El diseño del tablero permanece fijo: Clef no envía componentes, estilos, posiciones ni HTML. Mientras llegan los nuevos datos se atenúan solo los valores; si falla la consulta, el tablero conserva los anteriores y señala el error. UCI sigue sin medir margen, cobranza o inventario.

## Ejecución en denoise-server (actualizado el 9/10/2026)

- **Contexto completo.** `clef_local.responder` usaba `max_tokens=4096`; `encode_record` recorta el ESTADO en silencio cuando no cabe (conserva las preguntas). Ahora usa el valor oficial (16.384) y devuelve `usage.state_truncated`; el ciclo rechaza cualquier decisión tomada sobre un estado recortado.
- **Kernels.** `~/clef-env` es un venv que reutiliza los paquetes de `ai-env` mediante `zz-ai-env.pth` y agrega `flash-linear-attention` 0.5.2 (+ `fla-core`, `einops`) sin modificar el entorno compartido. Misma solicitud conjunta real (4.389 tokens, 8 repeticiones): 1,77 s → 1,44 s (−19 %), mismas elecciones, diferencia máxima de probabilidad 0,022. `causal-conv1d` no compila: los headers de glibc del sistema son incompatibles con CUDA 13.1 (`rsqrt`); queda en la implementación de referencia.
- **Precarga.** `GET /precargar` (con secreto) carga el modelo en segundo plano; el servicio de datos lo expone como `/clef/precargar` y la interfaz lo llama al abrir y al volver a la pestaña (cada 8 min como máximo). Evita la carga en frío tras los 10 minutos de inactividad.

```sh
# crear clef-env (una vez)
python3.14 -m venv ~/clef-env
echo /home/denoise/ai-env/lib/python3.14/site-packages > ~/clef-env/lib/python3.14/site-packages/zz-ai-env.pth
~/clef-env/bin/pip install --no-deps flash-linear-attention fla-core einops
cp servicios/clef/patagonia-clef.service ~/.config/systemd/user/ && systemctl --user daemon-reload && systemctl --user restart patagonia-clef
```

## Ejecución en denoise-server (medido el 5/10/2026, histórico)

La revisión oficial carga el modelo completo en GPU (≈19 GB en BF16). En INT4 con bitsandbytes, el embedding y el `lm_head` (248.320 × 4096) no se cuantizan y no caben junto al servicio vecino (`stratos`, ≈3 GB). `clef_local.py` deja embedding, `lm_head` y codificador visual en RAM y lleva a la GPU solo las filas que el cabezal consulta. Los pesos y el cálculo son los mismos; cambia dónde vive cada tensor. Además, `systemone()` oficial toma el dispositivo del primer parámetro, que aquí queda en CPU, así que `responder()` lo pasa explícito.

| Medida | Valor |
| --- | --- |
| GPU con el modelo cargado | 3,56 GiB asignados, pico 3,81 GiB; 4,1 GB visibles en `nvidia-smi` |
| Carga | ≈5 s (archivos en caché); primera decisión ≈7,7 s con calentamiento |
| Decisión | 0,2–0,4 s mediana; falta `flash-linear-attention` y se usa la implementación de referencia, más lenta (no se instaló: el entorno de IA es compartido) |
| Después de 10 minutos sin uso | el proceso termina; la GPU vuelve a los 2.994 MiB del servicio vecino |

## Evaluación ([`informe_variables.md`](informe_variables.md))

Se puntúa el efecto final sobre las cuatro variables. Hay dos conjuntos: desarrollo (40 consultas, con el que se diseñaron las reglas y las variantes) y validación (30 consultas escritas y congeladas antes de ajustar nada). El umbral se eligió solo con desarrollo.

| Validación (30) | Exactas | Cambios indebidos | Omitidos |
| --- | ---: | ---: | ---: |
| Reglas por palabras clave | 22 (73 %) | 1 | 9 |
| Clef v1 + umbral 0,4 (en producción) | 19 (63 %) | 0 | 16 |
| Clef v2 (sí/no + opción) | 21 (70 %) | 0 | 13 |

**Lectura.** En esta tarea acotada, Clef en INT4 no supera a las reglas. A cambio, la variante en uso no cambió una sola variable que no se pidiera en 70 consultas: falla quedándose quieto. Sus fallos típicos son verbos sin sustantivo («cambia a vista mensual», «pásalo a trimestres»), anclaje en el valor vigente y «restablecer». Las cifras del fabricante corresponden a BF16 en H200, no a este INT4. La interfaz aplica automáticamente una selección vigente; un fallo de interpretación puede omitir el cambio pedido. La persona puede corregir las variables con los selectores de Ventas y el diseño nunca depende de la salida del modelo.

**Próximos pasos razonables:** probar v2 con un tercer conjunto nuevo, porque v2 se eligió viendo validación; medir BF16 con descarga parcial o el endpoint alojado; e instalar `flash-linear-attention` en un entorno propio, no en el compartido.

## Comandos

```sh
node evaluacion.mjs preparar casos_variables.json        # 140 solicitudes: 2 conjuntos × 2 esquemas
scp casos_variables.json evaluar.py clef_local.py denoise@denoise-server:/tmp/clef-prueba/
# en el servidor: /home/denoise/ai-env/bin/python evaluar.py casos_variables.json resultados_variables.json
node evaluacion.mjs puntuar resultados_variables.json informe_variables.md
```

Servicio: `~/.config/patagonia-erp/clef.env` (`CLEF_SECRETO`, `CLEF_PUERTO`, `CLEF_INACTIVIDAD_S`, `CLEF_VRAM_MAXIMA_GB`, en `0600`), unidad de usuario [`patagonia-clef.service`](patagonia-clef.service). El servicio de datos lo usa con `CLEF_URL` y `CLEF_SECRETO` en `datos.env`. Sin esas variables, solo la propuesta responde 503 y los selectores manuales siguen funcionando.
