import { randomUUID } from 'node:crypto'
import { METRICAS, ONTOLOGIA } from './registro-cognitivo.js'
import { clarificationContract, resolvePending } from './dialogo.js'

const labels = Object.fromEntries(Object.entries(METRICAS).map(([id, m]) => [id, [m.nombre]]))
export function prepararContinuidad(entrada) {
  const previous = entrada.conversacion
  let pending = previous?.pending_clarification, active = previous?.active_request
  const turn = (previous?.turn ?? 0) + 1
  // Upgrade already-issued signed scalar questions only within their offered catalog.
  if (pending?.field === 'metric' && pending.allowed_values?.length && pending.allowed_values.every(id => METRICAS[id]?.dominio === previous.dominio)) pending = { ...pending, multivalued: true, meta_values: ['all'] }
  // Upgrade old signed sessions only for an exact registered selector. The old
  // request goal is unavailable, so do not invent it or replay a stale question.
  if (previous?.aclaracion_pendiente && !pending && !active) {
    const request = { id: randomUUID(), lifecycle: 'WAITING_CLARIFICATION', consulta: entrada.consulta, variables: entrada.variables, entidad: previous.entidad }
    for (const [field, values] of [['metric', Object.keys(METRICAS).filter(id => METRICAS[id].dominio === previous.dominio)], ['domain', Object.keys(ONTOLOGIA)]]) {
      const contract = { ...clarificationContract(request, field, values, { reason: 'legacy_registered_selector' }), created_turn: turn - 1 }
      if (resolvePending(contract, entrada.consulta, labels).consumed) { active = request; pending = contract; break }
    }
  }
  // A completed multi-selection can be repeated without reopening an old question.
  if (!pending && previous?.active_request?.lifecycle === 'COMPLETED' && previous.alcance !== 'registros' && ONTOLOGIA[previous.dominio]) {
    const request = { ...previous.active_request, id: randomUUID(), lifecycle: 'WAITING_CLARIFICATION' }
    const contract = { ...clarificationContract(request, 'metric', Object.keys(METRICAS).filter(id => METRICAS[id].dominio === previous.dominio), { multivalued: true, metaValues: ['all'] }), created_turn: turn }
    if (resolvePending(contract, entrada.consulta, labels).value === 'all') { active = request; pending = contract }
  }
  // Exact catalog labels are selector values, not free-form semantic classification.
  if (!pending) {
    const request = { id: randomUUID(), lifecycle: 'WAITING_CLARIFICATION', consulta: entrada.consulta, variables: entrada.variables, entidad: previous?.entidad }
    const contract = { ...clarificationContract(request, 'metric', Object.keys(METRICAS)), created_turn: turn, source: 'registered_selector' }
    const answer = resolvePending(contract, entrada.consulta, labels)
    if (answer.consumed) { active = request; pending = contract }
  }
  const coherent = pending?.active && active?.id === pending.request_id && active.lifecycle === 'WAITING_CLARIFICATION' && turn - pending.created_turn <= 2
  let resolution = coherent ? resolvePending(pending, entrada.consulta, labels) : { consumed: false }
  if (coherent && !resolution.consumed && pending.field === 'domain') {
    const metricAnswer = resolvePending({ ...pending, field: 'metric', allowed_values: Object.keys(METRICAS), meta_values: [], multivalued: false }, entrada.consulta, labels)
    const domain = METRICAS[metricAnswer.value]?.dominio
    if (metricAnswer.consumed && pending.allowed_values.includes(domain)) resolution = { ...metricAnswer, field: 'domain', value: domain, metric: metricAnswer.value }
  }
  if (resolution.consumed && pending.source) resolution.source = pending.source
  const slots = { ...(previous ?? {}) }
  if (!resolution.consumed) {
    // A clarification is a soft contract, not the goal of every later message.
    if (pending?.active || active?.lifecycle !== 'COMPLETED') slots.active_request = null
    slots.pending_clarification = null
    slots.aclaracion_pendiente = false
    if (pending?.active) slots.consulta = null
  }
  if (resolution.consumed) {
    if (resolution.field === 'domain') {
      slots.dominio = resolution.value
      slots.metrica = resolution.metric ?? ONTOLOGIA[resolution.value]?.principal
      slots.entidad = resolution.value === 'cobranza' ? 'cliente' : resolution.value === 'inventario' ? 'producto' : active.entidad
    }
    if (resolution.field === 'metric') {
      slots.metricas = resolution.value === 'all' ? pending.allowed_values.filter(id => METRICAS[id]?.dominio === slots.dominio) : [resolution.value]
      slots.metrica = slots.metricas[0]
      if (resolution.source === 'registered_selector') { slots.dominio = METRICAS[slots.metrica].dominio; slots.alcance = 'agregado' }
    }
    if (resolution.field === 'entity') slots.entidad = resolution.value
  }
  return { turn, resolution, previous: coherent ? pending : null,
    request_id: resolution.consumed ? active.id : randomUUID(),
    original: resolution.consumed ? active.consulta : entrada.consulta,
    variables: resolution.consumed ? active.variables : entrada.variables,
    temporal: resolution.consumed ? active.temporal_resolution ?? null : null,
    conversation: previous || resolution.consumed ? slots : null,
    request: resolution.consumed ? `${active.consulta}\nAclaración resuelta por el usuario: ${entrada.consulta}` : entrada.consulta }
}

export function crearAclaracion({ continuidad, plan, variables, field, reason, dominios = Object.keys(ONTOLOGIA) }) {
  // Solo se ofrecen dominios que la fuente mide: elegir uno no medido no podría responderse.
  const values = field === 'domain' ? dominios
    : field === 'metric' ? Object.keys(METRICAS).filter(id => METRICAS[id].dominio === plan.dominio)
      : plan.dominio === 'cobranza' ? ['cliente'] : plan.dominio === 'inventario' ? ['producto'] : ['sucursal', 'producto', 'pais', 'cliente']
  const repeated = continuidad.previous?.field === field && JSON.stringify(continuidad.previous.allowed_values) === JSON.stringify(values) && !continuidad.resolution.consumed
  const attempts = repeated ? (continuidad.previous.attempts ?? 1) + 1 : 1
  if (attempts > 2 || continuidad.resolution.consumed && (continuidad.resolution.field === field || field === 'metric' && continuidad.resolution.metric)) return null
  const request = { id: continuidad.request_id, lifecycle: 'WAITING_CLARIFICATION', consulta: continuidad.original.slice(0, 300), variables,
    dominio: plan.dominio, metrica: plan.metrica, entidad: plan.entidad, intencion: plan.intencion }
  const pending = { ...clarificationContract(request, field, values, { reason, multivalued: field === 'metric', metaValues: field === 'metric' ? ['all'] : [] }), attempts, created_turn: continuidad.turn }
  const names = values.map(id => field === 'metric' ? METRICAS[id].nombre.toLowerCase() : id)
  return { request, pending, text: `¿${field === 'domain' ? 'Qué dominio' : field === 'metric' ? 'Qué métrica' : 'Qué entidad'} quieres revisar: ${names.join(', ')}${field === 'metric' && values.length > 1 ? ', o todas' : ''}?` }
}
