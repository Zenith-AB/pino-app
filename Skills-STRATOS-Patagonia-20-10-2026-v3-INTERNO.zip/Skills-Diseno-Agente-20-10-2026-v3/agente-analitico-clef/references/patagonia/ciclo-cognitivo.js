import { esTableroEnlazado } from './tipos-escenario.js'
import { ErrorSolicitud } from './parametros.js'
import { VERSION_COGNITIVA, METRICAS, ONTOLOGIA, COMPONENTES, buscarCapacidades, buscarComponentes, validarPresentacion } from './registro-cognitivo.js'
import { construirEstado } from './estado-cognitivo.js'
import { POLITICA_DECISION, solicitudEnrutador, interpretarEnrutador, solicitudPlanner, interpretarPlanner, solicitudJudge, solicitudConjunta, separarRespuesta, eleccion, binaria, validarDecision } from './decisiones-cognitivas.js'
import { validarVariables, resolverVariables } from './variables.js'
import { componerRespuesta, componerBalance } from './respuestas-cognitivas.js'
import { prepararContinuidad, crearAclaracion } from './aclaraciones-cognitivas.js'
import { bounded, controlTurn } from './supervisor-conversacion.js'
import { interpretarCalendario } from './calendario.js'
import { seleccionarSugerencias } from './sugerencias-cognitivas.js'
import { crearVinculo } from './vinculo.js'

const flagsHerramientas = { needs_comparison: 'compare_periods', needs_timeseries: 'get_timeseries', needs_ranking: 'rank_entities', needs_anomaly: 'detect_anomalies', needs_drivers: 'find_drivers', needs_stockout: 'detect_stockout' }
const resolver = (v, e) => { const r = resolverVariables(v, e.cobertura); return { actual: r.actual?.corto ?? null, anterior: r.anterior?.corto ?? null, motivo_comparacion: r.motivoComparacion } }
// Alternativa temporal explícita: la misma pregunta con el mes indicado, para ofrecerla como sugerencia.
// Solo reemplaza la expresión de calendario que la gramática ya reconoció; no interpreta la intención.
function alternativaTemporal(original, alternativa) {
  if (!alternativa?.titulo) return null
  const texto = /\b(de|del)\s+(este|presente)\s+mes\b/i.test(original) ? original.replace(/\b(de|del)\s+(este|presente)\s+mes\b/i, `de ${alternativa.titulo}`) : original.replace(/\b(este|presente)\s+mes\b/i, `en ${alternativa.titulo}`)
  return texto === original ? null : [{ id: 'ultimo_mes_cubierto', label: `Ver ${alternativa.titulo}`, texto, seleccion: 'calendario' }]
}
export async function orquestarPeticion(entrada, { decidir, ejecutar, ahora = () => Date.now(), signal, timeouts = {} }) {
  const inicio = ahora(), frames = [], resultados = [], limites = [], capacidadesFaltantes = []
  const wallStart = Date.now(), budget = { turnMs: 40000, plannerMs: 30000, toolMs: 6000, judgeMs: 8000, ...timeouts }
  const phase = async (name, work) => {
    try {
      const remaining = budget.turnMs - (Date.now() - wallStart)
      if (remaining <= 0) { const error = new Error('TURN_TIMEOUT'); error.error_type = 'TURN_TIMEOUT'; throw error }
      return await bounded(work, { ms: Math.max(1, Math.min(remaining, budget[name === 'TOOL' ? 'toolMs' : name === 'JUDGE' ? 'judgeMs' : 'plannerMs'])), signal, phase: name })
    } catch (cause) {
      if (!cause.error_type) throw cause
      const error = new ErrorSolicitud('No pude completar esa consulta a tiempo. Puedes hacer otra pregunta.', 503)
      error.error_type = cause.error_type; error.recoverable = true
      throw error
    }
  }
  const continuidad = prepararContinuidad(entrada)
  const control = controlTurn(entrada.consulta)
  let aclaracion = null, temporal = null
  const vigente = validarVariables({ ...continuidad.variables, ...(esTableroEnlazado(entrada.escenario.id) && { foco: 'todos' }) })
  const observacion = ['CANCEL', 'RESET_REQUEST'].includes(control) ? {} : await phase('TOOL', s => ejecutar.observar?.(vigente, entrada.vista, { signal: s })) ?? {}
  const estado = construirEstado({ ...entrada, consulta: continuidad.request, conversacion: continuidad.conversation, variables: vigente, observacion })
  if (continuidad.resolution.consumed) estado.conversation.resolved_clarification = continuidad.resolution
  // El catálogo es pequeño; se entrega el conjunto disponible, nunca capacidades inexistentes como ejecutables.
  estado.available_capabilities = Object.keys(ONTOLOGIA).flatMap((d) => buscarCapacidades(entrada.escenario, d, ONTOLOGIA[d].principal)).filter((c, i, xs) => xs.findIndex((x) => x.id === c.id) === i)
  const inferir = async (fase, solicitud) => {
    if (frames.length >= POLITICA_DECISION.maxInferencias || ahora() - inicio > budget.turnMs) throw new ErrorSolicitud('Se agotó el presupuesto de decisión; conserva los datos visibles y vuelve a consultar.', 503)
    const recibida = await phase(fase === 'judge' ? 'JUDGE' : 'PLANNER', s => decidir(solicitud, { signal: s }))
    let respuesta
    try { respuesta = validarDecision(recibida, solicitud) } catch { throw new ErrorSolicitud('Clef devolvió una decisión inválida; no se ejecutó ese plan.', 503) }
    // Una decisión sobre un estado recortado no vio la petición completa: no se ejecuta.
    if (respuesta.usage?.state_truncated) throw new ErrorSolicitud('El contexto de la decisión excedió el límite de Clef; no se ejecutó ese plan.', 503)
    frames.push({ fase, respuestas: respuesta.answers, ms: respuesta.ms ?? null, tokens: respuesta.usage?.input_tokens ?? null })
    return respuesta
  }
  let respuesta = { model: 'clef-flash', answers: {} }
  let plan = { dominio: estado.conversation.dominio, metrica: estado.conversation.metrica, entidad: estado.conversation.entidad, intencion: 'cancelar' }
  const calendarioInicial = continuidad.temporal ?? interpretarCalendario(continuidad.original, { modoActual: Boolean(entrada.perfil), cobertura: entrada.escenario.cobertura, activo: resolverVariables(vigente, entrada.escenario.cobertura).actual })
  if (calendarioInicial?.error) return finalizar({ tipo: 'unsupported', texto: calendarioInicial.error, plan, variables: vigente, cambios: {}, presentacion: { componente: 'AgentDock', preset: null, props: {} }, plantilla: 'unsupported', sugerenciasFijas: alternativaTemporal(continuidad.original, calendarioInicial.alternativa) })
  if (['CANCEL', 'RESET_REQUEST'].includes(control)) return finalizar({ tipo: 'cancelled', texto: control === 'CANCEL' ? 'Consulta cancelada. Puedes hacer otra pregunta.' : 'Consulta reiniciada. Puedes hacer otra pregunta.', plan, variables: vigente, cambios: {}, presentacion: { componente: 'AgentDock', preset: null, props: {} }, plantilla: 'cancelled' })
  // Router y planner comparten estado: una sola inferencia con ambas preguntas, interpretadas por separado.
  const solicitudRuta = solicitudEnrutador(estado, entrada.escenario)
  const solicitud = solicitudPlanner(estado, entrada.escenario, { dominio: estado.conversation.dominio ?? (ONTOLOGIA[entrada.vista] ? entrada.vista : 'ventas'), cambios: {} })
  respuesta = await inferir('plan', solicitudConjunta(solicitudRuta, solicitud))
  const [respuestaRuta, respuestaPlan] = separarRespuesta(respuesta, solicitudRuta, solicitud)
  plan = interpretarEnrutador(respuestaRuta, estado, solicitudRuta)
  if (continuidad.resolution.consumed && plan.intencion !== 'ejecutar') {
    plan.dominio = continuidad.conversation.dominio
    plan.intencion = plan.intencion ?? entrada.conversacion.active_request?.intencion ?? 'resumir'
    plan.needs_clarification = false
  }
  const salidaTemprana = (tipo, texto) => finalizar({ tipo, texto, plan, variables: vigente, cambios: {}, presentacion: { componente: 'AgentDock', preset: null, props: {} }, plantilla: tipo, necesitaAclaracion: tipo === 'clarification' })
  const preguntar = (field, reason) => {
    const candidatas = validarVariables({ ...vigente, ...Object.fromEntries(Object.entries(plan.cambios ?? {}).map(([k, v]) => [k, v.hacia])) })
    aclaracion = crearAclaracion({ continuidad, plan, variables: candidatas, field, reason, dominios: Object.keys(ONTOLOGIA).filter(d => buscarCapacidades(entrada.escenario, d, ONTOLOGIA[d].principal).length) })
    if (aclaracion && temporal?.periodo) aclaracion.request.temporal_resolution = temporal
    return aclaracion ? salidaTemprana('clarification', aclaracion.text) : salidaTemprana('insufficient_evidence', 'No pude completar la interpretación de esa consulta. Puedes hacer otra pregunta; no se modificaron los datos.')
  }
  temporal = continuidad.temporal ?? interpretarCalendario(continuidad.original, { modoActual: Boolean(entrada.perfil), cobertura: entrada.escenario.cobertura, activo: resolverVariables(vigente, entrada.escenario.cobertura).actual, anioReferencia: vigente.periodo.includes(':') ? resolverVariables(vigente, entrada.escenario.cobertura).actual?.desde.slice(0,4) : null, ultimaFecha: ejecutar.ultimaFecha?.(plan.dominio, estado.conversation.metrica) })
  if (temporal?.pendiente) return salidaTemprana('unsupported', 'La fuente no expone la última fecha registrada para ese dominio; no se sustituyó por el cierre del mes.')
  if (temporal?.error) return salidaTemprana('unsupported', temporal.error)
  if (temporal?.periodo) { plan.periodo_incierto = false; plan.cambio_periodo = false; plan.cambios.periodo = { desde: vigente.periodo, hacia: temporal.periodo, origen: 'calendario' } }
  if (temporal?.periodo) estado.session.periodo = temporal
  if (temporal?.comparacion) estado.session.comparacion = resolverVariables({ ...vigente, periodo: temporal.periodo, comparacion: temporal.comparacion }, entrada.escenario.cobertura).anterior
  if (temporal?.comparacion) plan.cambios.comparacion = { desde: vigente.comparacion, hacia: temporal.comparacion, origen: 'calendario' }
  if (plan.intencion === 'ejecutar') return salidaTemprana('blocked_action', 'Esta capa solo permite consultar y analizar. La acción solicitada no se ejecutó: no hay una herramienta de escritura autorizada ni permisos operacionales disponibles.')
  // Un pronóstico no disponible se declara antes de pedir aclaraciones: preguntar el dominio no lo haría posible.
  if (plan.intencion === 'predecir' && plan.dominio !== 'inventario') {
    capacidadesFaltantes.push('forecast_metric')
    return salidaTemprana('unsupported', 'No hay un modelo de pronóstico validado para esta petición. Puedo consultar los datos históricos disponibles; no generaré cifras futuras.')
  }
  // Solo el dominio quedó sin resolver: la métrica que nombre el planner puede resolverlo. Sin métrica nombrada, se pregunta.
  const dominioPendiente = plan.needs_clarification && plan.dominio_incierto
  if (plan.needs_clarification && !dominioPendiente) return preguntar('domain', 'unresolved_domain_or_intent')
  if (!dominioPendiente && !buscarCapacidades(entrada.escenario, plan.dominio, ONTOLOGIA[plan.dominio].principal).length) {
    capacidadesFaltantes.push(`medicion_dominio:${plan.dominio}`)
    return salidaTemprana('unsupported', `La fuente ${entrada.escenario.nombre} no mide ${plan.dominio}. Se necesita una fuente operacional que lo registre; no se reutilizan cifras de demo.`)
  }
  // A resolved domain switch must not send incompatible old metrics/entities to Planner/Judge.
  const reiniciarConversacion = (dominio) => { if (estado.conversation.dominio !== dominio) estado.conversation = { dominio, metrica: ONTOLOGIA[dominio].principal, entidad: null, ultimas_entidades: [], hallazgos: [], periodo_anterior: estado.conversation.periodo_anterior, resolved_clarification: estado.conversation.resolved_clarification, active_request: estado.conversation.active_request, paquete: estado.conversation.paquete } }
  const conversacionPrevia = estado.conversation
  if (!dominioPendiente) reiniciarConversacion(plan.dominio)
  plan = interpretarPlanner(respuestaPlan, estado, solicitud, plan)
  if (dominioPendiente) {
    if (!plan.metrica_nombrada) { plan.needs_clarification = true; return preguntar('domain', 'unresolved_domain_or_intent') }
    plan.needs_clarification = false
  }
  // La métrica nombrada fijó otro dominio: se valida la fuente y se reinicia el contexto incompatible.
  if (!buscarCapacidades(entrada.escenario, plan.dominio, ONTOLOGIA[plan.dominio].principal).length) {
    capacidadesFaltantes.push(`medicion_dominio:${plan.dominio}`)
    return salidaTemprana('unsupported', `La fuente ${entrada.escenario.nombre} no mide ${plan.dominio}. Se necesita una fuente operacional que lo registre; no se reutilizan cifras de demo.`)
  }
  reiniciarConversacion(plan.dominio)
  // Paquete del perfil: lo eligió el planner con la conversación a la vista. «continuar» repite el paquete
  // solo si la consulta anterior fue un balance. Las cifras salen de get_kpi; no se consulta al judge porque
  // las métricas son exactamente las registradas del perfil.
  // Un balance es una lectura resumida: no sirve a intenciones de diagnóstico, comparación, pronóstico ni acción.
  const intencionDominante = Object.entries(respuestaRuta.answers?.intencion?.probabilities ?? {}).sort((a, b) => b[1] - a[1])[0]?.[0]
  // Balance del perfil: dos lecturas independientes del motor deben coincidir (revisión general del router y paquete
  // del planner); su promedio debe alcanzar la política binaria. La pregunta de paquete, sola, sobreelige «perfil»
  // ante consultas que nombran una medida. Continuar un balance sin nombrar métrica repite el balance; continuar
  // nombrando una métrica, o nombrar otra tras una consulta específica, es un seguimiento específico.
  const previaEspecifica = conversacionPrevia?.active_request?.lifecycle === 'COMPLETED' && conversacionPrevia.paquete !== 'perfil' && METRICAS[conversacionPrevia.metrica]
  const seguimientoEspecifico = Boolean(plan.metrica_nombrada && (plan.paquete === 'continuar' || previaEspecifica && plan.metrica_nombrada !== conversacionPrevia.metrica))
  const acuerdoBalance = ((plan.elecciones?.paquete?.probabilidades?.perfil ?? 0) + (binaria(respuestaRuta, 'revision_desempeno').probabilidad ?? 0)) / 2 >= POLITICA_DECISION.binario
  const continuarBalance = plan.paquete === 'continuar' && conversacionPrevia?.paquete === 'perfil' && !plan.metrica_nombrada
  const balance = estado.user.perfil_lectura && ['resumir', 'navegar', 'continuar'].includes(intencionDominante) && !seguimientoEspecifico && (acuerdoBalance || continuarBalance)
    && !['needs_ranking', 'needs_anomaly', 'needs_drivers', 'needs_stockout'].some(f => plan.flags[f]?.valor)
  if (balance) {
    plan.intencion = 'resumir'; plan.paquete = 'perfil'
    const variables = validarVariables({ ...vigente, ...Object.fromEntries(Object.entries(plan.cambios).filter(([k]) => k !== 'listado' && k !== 'foco').map(([k,v]) => [k,v.hacia])) })
    const periodo = resolverVariables(variables, entrada.escenario.cobertura).actual
    if (!periodo) return salidaTemprana('insufficient_evidence', 'La fuente no contiene datos para el período solicitado.')
    for (const metrica of estado.user.perfil_lectura.metricas) {
      const dominio = METRICAS[metrica].dominio
      if (!buscarCapacidades(entrada.escenario, dominio, metrica).some(c => c.id === 'get_kpi')) continue
      const resultado = await phase('TOOL', s => ejecutar('get_kpi', { ...plan, dominio, metrica, variables }, { signal: s }))
      if (resultado.id !== 'get_kpi' || resultado.procedencia?.metrica !== metrica) throw new Error('Resultado fuera del contrato del perfil.')
      resultados.push({ ...resultado, referencia: `e${resultados.length+1}` })
    }
    plan.metrica = estado.user.perfil_lectura.metricas[0]; plan.dominio = METRICAS[plan.metrica].dominio; plan.variables = variables
    plan.cambios = Object.fromEntries(Object.entries(plan.cambios).filter(([k]) => k !== 'listado' && k !== 'foco'))
    const sinMedicion=estado.user.perfil_lectura.metricas.filter(id=>!resultados.some(r=>r.verificado&&r.procedencia.metrica===id))
    const suficiente = resultados.some(r=>r.verificado) && resultados.every(r=>r.verificado)
    const texto = `${componerBalance({perfil:entrada.perfil,resultados,periodo:periodo.corto,escenario:entrada.escenario})}${sinMedicion.length?`\nSin medición disponible: ${sinMedicion.map(id=>METRICAS[id].nombre).join(', ')}.`:''}${limites.length?`\n${limites.join(' ')}`:''}`
    return finalizar({ tipo: suficiente && !sinMedicion.length ? 'respuesta' : resultados.some(r=>r.verificado) ? 'partial_result' : 'insufficient_evidence', texto, plan, variables, cambios:plan.cambios, presentacion:{componente:'AgentDock',preset:null,props:{}}, plantilla:'revision_perfil', periodo:periodo.corto, suficiente })
  }
  // El listado solo existe en el detalle de Ventas. Fuera de ese dominio es un cambio indebido; dentro, sigue a la
  // categoría de entidad que el usuario nombró (producto → productos; sucursal o país → la dimensión territorial).
  if (plan.dominio !== 'ventas') { delete plan.cambios.listado; delete plan.cambios.foco }
  else if (plan.entidad_nombrada && ['producto', 'sucursal', 'pais'].includes(plan.entidad_nombrada)) {
    const hacia = plan.entidad_nombrada === 'producto' ? 'productos' : 'paises'
    if (hacia !== vigente.listado) plan.cambios.listado = { desde: vigente.listado, hacia, origen: 'entidad', probabilidad: plan.entidad_probabilidad }
    else delete plan.cambios.listado
  }
  if (temporal?.periodo) plan.periodo_explicito = true
  if (temporal?.periodo) plan.cambios.periodo = { desde: vigente.periodo, hacia: temporal.periodo, origen: 'calendario' }
  if (temporal?.comparacion) plan.cambios.comparacion = { desde: vigente.comparacion, hacia: temporal.comparacion, origen: 'calendario' }
  if (continuidad.resolution.consumed) {
    if (continuidad.resolution.field === 'metric') { plan.metrica = continuidad.conversation.metrica; plan.metricas = continuidad.conversation.metricas; if (continuidad.resolution.value === 'all') plan.alcance = 'agregado' }
    if (continuidad.resolution.source === 'registered_selector') { plan.alcance = 'agregado'; plan.intencion = 'resumir'; for (const flag of Object.keys(flagsHerramientas)) plan.flags[flag].valor = false }
    if (continuidad.resolution.metric) plan.metrica = continuidad.resolution.metric
    if (continuidad.resolution.field === 'entity') plan.entidad = continuidad.resolution.value
    if (!plan.entidad) plan.entidad = continuidad.conversation.entidad
    plan.needs_clarification = !METRICAS[plan.metrica] || METRICAS[plan.metrica].dominio !== plan.dominio || plan.flags.needs_ranking.valor && (!plan.entidad || plan.entidad === 'incierta')
  }
  if (plan.needs_clarification) return preguntar(!METRICAS[plan.metrica] || plan.entidad && plan.entidad !== 'incierta' ? 'metric' : 'entity', 'required_by_capability')
  // Prerrequisitos y opciones son referencias del catálogo. No se admiten parámetros, SQL o código del modelo.
  const variables = validarVariables({ ...vigente, ...Object.fromEntries(Object.entries(plan.cambios).map(([k, v]) => [k, v.hacia])), ...(esTableroEnlazado(entrada.escenario.id) && { foco: 'todos' }) })
  plan.variables = variables
  const r = resolverVariables(variables, entrada.escenario.cobertura)
  if (!r.actual) return salidaTemprana('insufficient_evidence', 'La cobertura no contiene un período completo para la selección solicitada.')
  if (r.actual.dias && (plan.metrica === 'ebitda' || plan.dominio === 'inventario' && !ejecutar.mediciones?.inventario_diario && new Date(Date.parse(r.actual.hasta)).getUTCDate() !== 1)) return salidaTemprana('unsupported', 'La fuente registra inventario y gastos presupuestados por mes; no hay medición diaria para esa métrica. No se interpolaron valores.')
  const disponibles = buscarCapacidades(entrada.escenario, plan.dominio, plan.metrica).filter(c => c.id !== 'get_recent_sales' || plan.alcance === 'registros')
  if (!disponibles.length) {
    capacidadesFaltantes.push(`medicion:${plan.metrica}`)
    return salidaTemprana('unsupported', `La fuente ${entrada.escenario.nombre} no mide ${METRICAS[plan.metrica].nombre}. Se necesita una fuente operacional que lo registre; no se reutilizan cifras de demo.`)
  }
  const ejecutarUna = async (id) => {
    if (resultados.some((r) => r.id === id)) return
    if (resultados.length >= POLITICA_DECISION.maxHerramientas || !disponibles.some((c) => c.id === id)) throw new Error('Plan de herramientas fuera del registro o presupuesto.')
    if (['find_drivers', 'detect_anomalies'].includes(id)) await ejecutarUna('compare_periods')
    const resultado = await phase('TOOL', s => ejecutar(id, plan, { signal: s }))
    if (resultado.id !== id || resultado.verificado && resultado.estado !== 'verificado') throw new Error('Resultado de herramienta inconsistente.')
    if (!resultado.verificado) limites.push(resultado.datos?.limite ?? resultado.limite ?? `Sin evidencia verificada en ${id}.`)
    resultados.push({ ...resultado, referencia: `e${resultados.length + 1}` })
  }
  if (plan.alcance === 'no_disponible') return salidaTemprana('unsupported', 'No hay una capacidad registrada para consultar esos registros individuales. Puedo consultar las métricas disponibles del dominio.')
  if (plan.alcance === 'registros') {
    if (plan.dominio !== 'ventas' || plan.metrica !== 'venta' || !disponibles.some(c => c.id === 'get_recent_sales')) return salidaTemprana('unsupported', 'La fuente no dispone de una consulta de ventas individuales recientes; no se sustituye por un total del período.')
    plan.periodo_explicito = Boolean(temporal?.periodo) || binaria(respuestaRuta, 'cambia_periodo').valor || plan.alcance_heredado && estado.conversation.periodo_explicito === true
    await ejecutarUna('get_recent_sales')
    const { texto } = componerRespuesta({ plan, resultados, plantilla: 'recent_records', periodo: r.actual.corto, escenario: entrada.escenario, limites })
    return finalizar({ tipo: resultados.some(x => x.verificado) ? 'respuesta' : 'insufficient_evidence', texto, plan, variables, cambios: plan.cambios, presentacion: { componente: 'AgentDock', preset: null, props: {} }, plantilla: 'recent_records', periodo: resultados[0]?.procedencia?.periodo?.corto ?? r.actual.corto, suficiente: resultados.some(x => x.verificado) })
  }
  if (plan.metricas?.length > 1 && continuidad.resolution.consumed && continuidad.resolution.value === 'all') {
    const textos = []
    const resumen = buscarComponentes(plan.dominio).find(c => c.preset === plan.dominio && c.slot === 'vista')
    const presentacionResumen = resumen ? { componente: resumen.id, preset: resumen.preset, props: {} } : { componente: 'AgentDock', preset: null, props: {} }
    let parcial = !['resumir', 'navegar', 'lectura_ambigua'].includes(plan.intencion) || Object.keys(flagsHerramientas).some(flag => plan.flags[flag]?.valor)
    for (const metrica of plan.metricas) {
      if (!buscarCapacidades(entrada.escenario, plan.dominio, metrica).some(c => c.id === 'get_kpi')) throw new Error('Métrica fuera del contrato de selección.')
      const resultado = await phase('TOOL', s => ejecutar('get_kpi', { ...plan, metrica }, { signal: s }))
      if (resultado.id !== 'get_kpi' || resultado.procedencia?.metrica !== metrica || resultado.verificado && resultado.estado !== 'verificado') throw new Error('Resultado de selección múltiple inconsistente.')
      resultados.push({ ...resultado, referencia: `e${resultados.length + 1}` })
      if (!resultado.verificado) { parcial = true; textos.push(`${METRICAS[metrica].nombre}: sin medición para ${r.actual.corto}. ${resultado.datos?.limite ?? ''}`); continue }
      textos.push(componerRespuesta({ plan: { ...plan, metrica }, resultados: [resultado], plantilla: 'direct_metric', periodo: r.actual.corto, anterior: r.anterior?.corto, escenario: entrada.escenario, limites: [] }).texto)
    }
    // Explicit selection of all offered metrics is a factual lookup, not a diagnosis.
    return finalizar({ tipo: parcial ? 'partial_result' : 'respuesta', texto: textos.join('\n') + (parcial ? '\nSe muestran los valores verificados; la comparación o interpretación solicitada no está completada.' : ''), plan, variables, cambios: plan.cambios, presentacion: validarPresentacion(presentacionResumen), plantilla: 'direct_metric', periodo: r.actual.corto, comparacion: r.anterior?.corto, suficiente: !parcial })
  }
  await ejecutarUna('get_kpi')
  // Componente registrado según métrica y vista, sin inferencia: en el Agente, la pestaña de AnalyticsCard sigue a la
  // métrica (venta, margen, unidades); en otra vista, la vista original del dominio; si no hay una, el chat existente.
  const presentacionDeterminista = () => {
    const vista = buscarComponentes(plan.dominio).find(c => c.preset === plan.dominio && c.slot === 'vista')
    if (entrada.vista === 'agente' && ['ventas', 'rentabilidad'].includes(plan.dominio) && ['venta', 'margen', 'unidades'].includes(plan.metrica)) return validarPresentacion({ componente: 'AnalyticsCard', preset: 'agente', props: { metrica: plan.metrica, periodo: 'quarter', modo: 'line' } })
    return vista ? validarPresentacion({ componente: vista.id, preset: vista.preset, props: {} }) : { componente: 'AgentDock', preset: null, props: {} }
  }
  // Lectura confiable: el planner nombró la métrica de forma concluyente, no pidió análisis adicional y la herramienta
  // la verificó. El judge solo elegiría componente y plantilla; se resuelven del registro y se ahorra una inferencia.
  const seguroPlanner = Boolean(plan.metrica_nombrada === plan.metrica && plan.elecciones?.metrica && !plan.elecciones.metrica.incierta && ((plan.elecciones.metrica.jerarquica ? plan.elecciones.metrica.probabilidad : plan.elecciones.metrica.probabilidades?.[plan.metrica]) ?? 0) >= POLITICA_DECISION.minimo)
  if (seguroPlanner && ['resumir', 'navegar'].includes(plan.intencion) && !Object.keys(flagsHerramientas).some(flag => plan.flags[flag]?.valor) && resultados.length === 1 && resultados[0].verificado) {
    const { texto } = componerRespuesta({ plan, resultados, plantilla: 'direct_metric', periodo: r.actual.corto, escenario: entrada.escenario, limites })
    return finalizar({ tipo: 'respuesta', texto, plan, variables, cambios: plan.cambios, presentacion: presentacionDeterminista(), plantilla: 'direct_metric', periodo: r.actual.corto, suficiente: true })
  }
  const lecturaTemporal = Boolean(temporal?.periodo) && ['resumir', 'navegar', 'lectura_ambigua'].includes(plan.intencion) && (plan.elecciones.metrica.valor === plan.metrica || !plan.flags.cambia_metrica.valor && !plan.flags.cambia_metrica.incierta && plan.metrica === (estado.conversation.metrica ?? ONTOLOGIA[plan.dominio].principal))
  if (((plan.continuacion_resuelta || continuidad.resolution.source === 'registered_selector') && plan.dominio === estado.conversation.dominio && plan.metrica === estado.conversation.metrica || lecturaTemporal) && !Object.keys(flagsHerramientas).some(flag => plan.flags[flag]?.valor) && resultados[0]?.verificado) {
    const resumen = buscarComponentes(plan.dominio).find(c => c.preset === plan.dominio && c.slot === 'vista')
    const { texto } = componerRespuesta({ plan, resultados, plantilla: 'direct_metric', periodo: r.actual.corto, escenario: entrada.escenario, limites })
    return finalizar({ tipo: 'respuesta', texto, plan, variables, cambios: plan.cambios, presentacion: resumen ? { componente: resumen.id, preset: resumen.preset, props: {} } : { componente: 'AgentDock', preset: null, props: {} }, plantilla: 'direct_metric', periodo: r.actual.corto, suficiente: true })
  }
  for (const [flag, id] of Object.entries(flagsHerramientas)) {
    if (!plan.flags[flag].valor) continue
    if (disponibles.some((c) => c.id === id)) await ejecutarUna(id)
    else { capacidadesFaltantes.push(id); limites.push(`La fuente no dispone de ${id}.`) }
  }
  if (lecturaTemporal && plan.flags.needs_timeseries.valor && !Object.keys(flagsHerramientas).filter(flag => flag !== 'needs_timeseries').some(flag => plan.flags[flag]?.valor) && resultados.every(e => e.verificado) && resultados.some(e => e.id === 'get_timeseries') && ['venta', 'unidades', 'margen'].includes(plan.metrica)) {
    const { texto } = componerRespuesta({ plan, resultados, plantilla: 'direct_metric', periodo: r.actual.corto, escenario: entrada.escenario, limites })
    return finalizar({ tipo: 'respuesta', texto, plan, variables, cambios: plan.cambios, presentacion: validarPresentacion({ componente: 'AnalyticsCard', preset: 'agente', props: { metrica: plan.metrica, periodo: 'quarter', modo: 'line' } }), plantilla: 'direct_metric', periodo: r.actual.corto, suficiente: true })
  }
  // Comparar, o explicar un cambio, exige una comparación cubierta: es prerrequisito, no interpretación.
  const diagnostico = plan.intencion === 'diagnosticar' || plan.intencion === 'lectura_ambigua' && Object.entries(plan.elecciones?.intencion?.probabilidades ?? {}).sort((a, b) => b[1] - a[1])[0]?.[0] === 'diagnosticar'
  if ((plan.intencion === 'comparar' || diagnostico) && disponibles.some((c) => c.id === 'compare_periods') && !resultados.some((r) => r.id === 'compare_periods')) await ejecutarUna('compare_periods')
  if (Object.keys(plan.cambios).length && ejecutar.observar) {
    const actualizado = await ejecutar.observar(variables, entrada.vista)
    estado.business = { ...estado.business, ...actualizado.business }
  }
  const capacidadesVisualesFaltantes = []
  let componentes = buscarComponentes(plan.dominio)
  // Mantener el preset activo cuando basta su gráfico existente; reducir opciones equivalentes.
  if (entrada.vista === 'agente' && ['ventas', 'rentabilidad'].includes(plan.dominio) && plan.intencion !== 'navegar' && (!continuidad.conversation?.dominio || continuidad.conversation.dominio === plan.dominio)) componentes = componentes.filter((c) => ['AnalyticsCard', ...(plan.flags.needs_ranking.valor ? ['DetailCard'] : []), 'AgentDock'].includes(c.id))
  if (plan.flags.needs_ranking.valor && (plan.entidad === 'cliente' || plan.entidad === 'pais' && esTableroEnlazado(entrada.escenario.id))) {
    capacidadesVisualesFaltantes.push(`ranking:${plan.entidad}`)
    componentes = componentes.filter((c) => c.id === 'AgentDock')
  }
  let juez, solicitudJuez
  for (let ronda = 1; ronda <= POLITICA_DECISION.maxRondas; ronda++) {
    const pendientes = disponibles.filter((c) => !resultados.some((r) => r.id === c.id))
    estado.session.periodo = r.actual; estado.session.comparacion = r.anterior
    solicitudJuez = solicitudJudge(estado, plan, resultados, componentes, pendientes, ronda)
    try { juez = await inferir('judge', solicitudJuez) }
    catch (error) {
      if (signal?.aborted) throw error
      limites.push('No se completó la evaluación del Judge; se muestran únicamente datos verificados, sin interpretación causal ni recomendación.')
      const seguro = resultados.filter(r => r.verificado)
      const { texto } = componerRespuesta({ plan, resultados: seguro, plantilla: 'partial_result', periodo: r.actual.corto, anterior: r.anterior?.corto, escenario: entrada.escenario, limites })
      return finalizar({ tipo: 'partial_result', texto, plan, variables, cambios: plan.cambios, presentacion: { componente: 'AgentDock', preset: null, props: {} }, plantilla: 'partial_result', periodo: r.actual.corto, comparacion: r.anterior?.corto })
    }
    const seguir = binaria(juez, 'continue_investigation')
    const suficiente = binaria(juez, 'evidence_sufficient')
    const siguiente = eleccion(juez, 'siguiente_herramienta', Object.keys(solicitudJuez.questions.siguiente_herramienta.criteria))
    if (suficiente.valor || (!seguir.valor && !seguir.incierta) || !siguiente.valor || siguiente.valor === 'ninguna' || !pendientes.length) break
    if (ronda === POLITICA_DECISION.maxRondas || frames.length >= POLITICA_DECISION.maxInferencias || ahora() - inicio > 23000) { limites.push('Se alcanzó el presupuesto de investigación; no se completó la evidencia solicitada.'); break }
    await ejecutarUna(siguiente.valor)
  }
  const adecuacion = binaria(juez, 'addresses_request')
  // Do not re-ask a confirmed selector on mere uncertainty. Without confirmation,
  // ambiguous concepts still require a targeted question rather than misleading figures.
  const confirmada = continuidad.resolution.consumed && (continuidad.resolution.field === 'metric' || continuidad.resolution.metric)
    || entrada.conversacion?.confirmed_metric?.value === plan.metrica && entrada.conversacion.confirmed_metric.domain === plan.dominio
  // El planner eligió esta métrica de forma explícita y concluyente: la opción concreta, por sí sola, supera el mínimo.
  // «contexto» no cuenta aquí: designa la métrica activa, no una medida nombrada por el usuario.
  const plannerSeguro = Boolean(plan.elecciones?.metrica && !plan.elecciones.metrica.incierta && plan.elecciones.metrica.valor === plan.metrica && ((plan.elecciones.metrica.jerarquica ? plan.elecciones.metrica.probabilidad : plan.elecciones.metrica.probabilidades?.[plan.metrica]) ?? 0) >= POLITICA_DECISION.minimo)
  // Un rechazo fuerte del concepto siempre pregunta. Un rechazo moderado o una duda del judge solo preguntan si
  // el planner tampoco estaba seguro y la métrica no fue confirmada; si no, se responde declarando el límite.
  if (!adecuacion.valor && (adecuacion.probabilidad == null || adecuacion.probabilidad <= POLITICA_DECISION.rechazoFirme || !confirmada && !plannerSeguro)) return preguntar('metric', 'judge_metric_mismatch')
  const suficiente = binaria(juez, 'evidence_sufficient')
  if (!adecuacion.valor && !adecuacion.incierta) limites.push('El juicio de evidencia no confirmó que esta métrica sea el concepto solicitado.')
  if (adecuacion.incierta && !plannerSeguro) { suficiente.valor = false; limites.push('La correspondencia entre petición y métrica sigue siendo incierta.') }
  // Responder la métrica correcta sin demostrar una causa es un resultado con límites, no un error de métrica.
  const completo = binaria(juez, 'responde_completo')
  if (!completo.valor && !completo.incierta && !['diagnosis', 'recommendation'].includes(eleccion(juez, 'plantilla', Object.keys(solicitudJuez.questions.plantilla.criteria)).valor)) limites.push('Los datos verificados responden en parte a lo pedido.')
  const componente = eleccion(juez, 'componente', componentes.map((c) => c.id))
  const plantillaElegida = eleccion(juez, 'plantilla', Object.keys(solicitudJuez.questions.plantilla.criteria))
  if (binaria(juez, 'needs_llm').valor) { capacidadesFaltantes.push('llm_redactor'); limites.push('No hay redactor auxiliar conectado; se utiliza una plantilla con hechos verificados.') }
  const evidenciaVerificada = resultados.filter((r) => r.verificado)
  const hayComparacion = evidenciaVerificada.some((r) => r.id === 'compare_periods')
  let plantilla = suficiente.valor && evidenciaVerificada.length ? plantillaElegida.valor ?? (hayComparacion ? 'comparison' : 'direct_metric') : evidenciaVerificada.length ? 'partial_result' : 'insufficient_evidence'
  if (['comparison', 'diagnosis', 'recommendation'].includes(plantilla) && !hayComparacion) plantilla = 'direct_metric'
  if (['diagnosis', 'recommendation'].includes(plantilla) && !evidenciaVerificada.some((r) => ['find_drivers', 'detect_anomalies', 'detect_stockout'].includes(r.id))) { plantilla = hayComparacion ? 'comparison' : 'direct_metric'; limites.push('Todavía no hay una explicación verificada ni una causa demostrada.') }
  if (!suficiente.valor) limites.push('Clef no determinó que la evidencia disponible fuera suficiente.')
  let id = componente.valor ?? 'AgentDock'
  // A factual overview belongs to its existing domain view even when the Judge
  // selected text; choose only a view still present among the registered candidates.
  if (evidenciaVerificada.length && !plan.flags.needs_ranking.valor && (['cobranza', 'inventario'].includes(plan.dominio) && id === 'AgentDock' || continuidad.conversation?.dominio && continuidad.conversation.dominio !== plan.dominio)) id = componentes.find(c => c.preset === plan.dominio && c.slot === 'vista')?.id ?? id
  if (id === 'AnalyticsCard' && !['venta', 'margen', 'unidades'].includes(plan.metrica)) { capacidadesVisualesFaltantes.push(`tendencia:${plan.metrica}`); id = 'AgentDock' }
  const c = COMPONENTES[id]
  const props = id === 'AnalyticsCard' ? { metrica: ['venta', 'margen', 'unidades'].includes(plan.metrica) ? plan.metrica : 'venta', periodo: 'quarter', modo: 'line' } : id === 'DetailCard' ? { listado: variables.listado } : {}
  if (id === 'AnalyticsCard' && !['venta', 'margen', 'unidades'].includes(plan.metrica)) capacidadesVisualesFaltantes.push(`tendencia:${plan.metrica}`)
  const presentacion = validarPresentacion({ componente: id, preset: c.preset, props, slots: c.preset ? COMPONENTES[id].slot : 'chat_existente', capacidades_no_cubiertas: capacidadesVisualesFaltantes })
  const { texto, principal } = componerRespuesta({ plan, resultados, plantilla, periodo: r.actual.corto, anterior: r.anterior?.corto, escenario: entrada.escenario, limites })
  return finalizar({ tipo: suficiente.valor && evidenciaVerificada.length ? principal ? 'hallazgo' : 'respuesta' : evidenciaVerificada.length ? 'partial_result' : 'insufficient_evidence', texto, plan, variables, cambios: plan.cambios, presentacion, plantilla, principal, periodo: r.actual.corto, comparacion: r.anterior?.corto, suficiente: suficiente.valor && evidenciaVerificada.length > 0, severidad: juez.answers?.severidad })

  function finalizar({ tipo, texto, plan, variables, cambios, presentacion, plantilla, necesitaAclaracion = false, principal, periodo, comparacion, suficiente = false, severidad = null, sugerenciasFijas = null }) {
    const avisoTemporal = (temporal ?? calendarioInicial)?.aviso
    if (avisoTemporal && ['respuesta', 'partial_result'].includes(tipo)) { texto = `${avisoTemporal} ${texto}`; if (!limites.includes(avisoTemporal)) limites.push(avisoTemporal) }
    const memoria = { usuario: entrada.usuario, escenario: entrada.escenario.id, dominio: ONTOLOGIA[plan.dominio] ? plan.dominio : entrada.conversacion?.dominio ?? null, metrica: METRICAS[plan.metrica]?.dominio === plan.dominio ? plan.metrica : entrada.conversacion?.dominio === plan.dominio ? entrada.conversacion.metrica ?? null : null, entidad: plan.entidad && plan.entidad !== 'incierta' ? plan.entidad : entrada.conversacion?.dominio === plan.dominio ? entrada.conversacion.entidad ?? null : null, consulta: entrada.consulta.slice(0, 300), periodo, entidades: resultados.find((r) => r.id === 'rank_entities' && r.verificado)?.datos?.filas.slice(0, 3).map((f) => ({ id: f.id ?? f.nombre, nombre: f.nombre })) ?? (entrada.conversacion?.dominio === plan.dominio && entrada.conversacion?.entidad === plan.entidad ? entrada.conversacion.entidades ?? [] : []), hallazgos: principal ? [{ entidad: principal.nombre, variacion_pct: principal.variacion_pct, periodo, nivel: 'contribucion_verificada_no_causa' }] : [], aclaracion_pendiente: necesitaAclaracion }
    memoria.ultima_solicitud_resuelta = resultados.some(e => e.verificado) && !necesitaAclaracion
      ? { consulta: continuidad.original.slice(0, 300), dominio: memoria.dominio, metrica: memoria.metrica, metricas: plan.metricas ?? [memoria.metrica], alcance: plan.alcance ?? 'agregado', intencion: plan.intencion, entidad: memoria.entidad, periodo: periodo ?? resolver(variables, entrada.escenario).actual }
      : entrada.conversacion?.ultima_solicitud_resuelta ?? null
    memoria.periodo_explicito = plan.periodo_explicito ?? false
    // Un balance de perfil se recuerda como tal para que «¿y en agosto?» repita el balance y no una métrica suelta.
    memoria.paquete = plantilla === 'revision_perfil' ? 'perfil' : resultados.some(e => e.verificado) ? null : entrada.conversacion?.paquete ?? null
    memoria.alcance = plan.alcance ?? 'agregado'
    memoria.metricas = plan.metricas ?? [memoria.metrica].filter(Boolean)
    memoria.turn = continuidad.turn
    memoria.periodo = periodo ?? entrada.conversacion?.periodo ?? resolver(vigente, entrada.escenario).actual
    memoria.active_request = aclaracion?.request ?? { id: continuidad.request_id, lifecycle: tipo === 'cancelled' ? 'CANCELLED' : necesitaAclaracion ? 'WAITING_CLARIFICATION' : tipo === 'insufficient_evidence' ? 'FAILED' : 'COMPLETED', consulta: continuidad.original.slice(0, 300), variables: plan.variables ?? vigente, dominio: plan.dominio, metrica: plan.metrica, entidad: plan.entidad }
    memoria.pending_clarification = aclaracion?.pending ?? null
    if (temporal?.periodo) memoria.active_request.temporal_resolution = temporal
    // La vista operacional es la que envía el usuario, no el preset sugerido.
    memoria.vista = entrada.vista
    memoria.confirmed_metric = continuidad.resolution.consumed && (continuidad.resolution.field === 'metric' || continuidad.resolution.metric)
      ? { value: plan.metrica, domain: plan.dominio, source: 'clarification' }
      : entrada.conversacion?.confirmed_metric?.domain === plan.dominio ? entrada.conversacion.confirmed_metric : null
    return {
      escenario: entrada.escenario.id, consulta: entrada.consulta, vigentes: vigente,
      propuesta: { cambios, variables, destino: presentacion.preset ?? 'sin_cambio', intencion: plan.intencion ?? 'sin_cambio', necesita_aclaracion: necesitaAclaracion },
      resolucion: { vigente: resolver(vigente, entrada.escenario), propuesta: resolver(variables, entrada.escenario) },
      analisis: { estado: tipo, texto, periodo: periodo ?? resolver(variables, entrada.escenario).actual, comparacion, principal, herramientas: resultados.map((r) => r.id), evidencia: resultados, naturaleza_datos: entrada.escenario.naturaleza_datos, limites },
      decision: { version: VERSION_COGNITIVA, modelo: respuesta.model, regla: 'ganador sobre todas las opciones, separación mínima y validación determinística; probabilidades no calibradas', probabilidades: Object.fromEntries(Object.entries(respuesta.answers ?? {}).map(([k, v]) => [k, v.probabilities ?? (v.type === 'noul' ? { true: v.noul, false: 1 - v.noul } : null)])), frames, presupuesto: { inferencias: frames.length, herramientas: resultados.length, ms: ahora() - inicio, politica: POLITICA_DECISION }, dominio: plan.dominio, metrica: plan.metrica, entidad: plan.entidad, riesgo: plan.riesgo, severidad, evidencia_suficiente: suficiente, needs_language_model: frames.some((f) => binaria({ answers: f.respuestas }, 'needs_llm').valor), needs_clarification: necesitaAclaracion, capacidades_faltantes: capacidadesFaltantes },
      response_plan: { version: VERSION_COGNITIVA, plantilla, presentacion, evidencia: resultados.filter((r) => r.verificado).map((r) => r.referencia), limites, sugerencias: sugerenciasFijas ?? (necesitaAclaracion || tipo !== 'respuesta' && tipo !== 'partial_result' ? [] : seleccionarSugerencias({ answers: frames.find(f => f.fase === 'plan')?.respuestas }, entrada.escenario, plan, resultados)) },
      memoria,
      // Qué quedó conectado al tablero (sin cifras). El servidor lo firma; la interfaz lo reevalúa cuando cambian
      // los datos o los filtros, sin volver a consultar a Clef.
      vinculo: necesitaAclaracion ? null : crearVinculo({ tipo, plan, resultados, plantilla, presentacion, escenario: entrada.escenario, perfil: entrada.perfil ?? null, metricasPerfil: estado.user.perfil_lectura?.metricas, consulta: continuidad.original, limitesJuicio: limites.filter((l) => l !== avisoTemporal && !resultados.some((x) => [x.datos?.limite, x.limite].includes(l)) && !/^La fuente no dispone de /.test(l)) }),
      trace: { temporal_resolution: temporal ?? calendarioInicial, previous_request_status: continuidad.conversation?.active_request?.lifecycle ?? null, continuation_resolved: plan.continuacion_resuelta ?? false, alcance: plan.alcance ?? null, scope_probabilities: plan.elecciones?.alcance?.probabilidades ?? null, request_id: continuidad.request_id, pending_consumed: continuidad.resolution.consumed && Boolean(entrada.conversacion?.pending_clarification?.active || entrada.conversacion?.aclaracion_pendiente), selector_consumed: continuidad.resolution.consumed, resolved_clarification: continuidad.resolution.consumed ? continuidad.resolution : null, pending_field: aclaracion?.pending.field ?? null, pending_reason: aclaracion?.pending.reason ?? null, lifecycle: memoria.active_request.lifecycle },
    }
  }
}
