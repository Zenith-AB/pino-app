# Anexo · contratos verbatim del motor cognitivo (snapshot 19-10-2026)

Estos archivos son copia exacta del código fuente de Patagonia ERP en la fecha indicada.
Son el contrato más difícil de re-derivar: los textos de las preguntas a Clef determinan su comportamiento.
Reconstruir: copiar tal cual a servicios/datos/src/ y adaptar sólo si cambia el catálogo.

| Archivo | Qué fija |
|---|---|
| registro-cognitivo.js | dominios, métricas, ontología, componentes, presets, capacidades, no implementadas |
| decisiones-cognitivas.js | política de umbrales, validación de distribuciones, preguntas router/planner/judge |
| perfiles-lectura.js | 7 perfiles de lectura y sus métricas |
| variables.js | catálogo de variables, resolución de períodos, propuesta SystemOne |
| respuestas-cognitivas.js | plantillas de texto |
| ciclo-cognitivo.js | el turno completo (árbol del SKILL.md) |
| herramientas-cognitivas.js | ejecutor de capacidades (sintético, lechera, UCI) con conciliación BigInt |
| estado-cognitivo.js | world state y firma HMAC de la conversación |
| aclaraciones-cognitivas.js, dialogo.js | continuidad, aclaraciones y ciclo de vida de la solicitud |
| sugerencias-cognitivas.js | sugerencias iniciales y de seguimiento |
| supervisor-conversacion.js | cola, presupuesto y control de turnos (también en el navegador) |
| vinculo.js | vínculo vivo firmado y su reevaluación sin Clef |
| calendario.js | gramática temporal en español (único uso permitido de expresiones regulares) |
| orquestador.js | diagnóstico determinístico anterior (compatibilidad/pruebas) |
| ORQUESTACION_ERP.md, README-clef.md | contrato ejecutable y evaluación histórica |
