# Clef como orquestador de Patagonia ERP

Estado: 9 de octubre de 2026 (ver actualización). Desktop; la demo sigue siendo la fuente de verdad visual.

## Contrato ejecutable

`petición → world state → routing → planner Clef → herramientas → result state → judge Clef → plantilla y componente registrado`.

Clef-Flash decide en marcos `choice`, `noul` y `score`; nunca calcula indicadores ni redacta código. Se validan tipos, opciones, distribuciones, escalas y consistencia antes de ejecutar. Las probabilidades completas permanecen en `decision.frames`. Son relativas a las opciones ofrecidas: los umbrales de `POLITICA_DECISION` son provisionales y no una confianza calibrada. [Contrato oficial de Clef-Flash](https://huggingface.co/Cloudflare/clef-flash).

El circuito nuevo vive en [`ciclo-cognitivo.js`](../datos/src/ciclo-cognitivo.js). `orquestador.js` conserva el diagnóstico determinístico anterior para pruebas y compatibilidad; la API de propuestas usa el circuito nuevo.

## Actualización 9 de octubre de 2026: conexión, eficiencia y vínculo vivo

**Una inferencia de plan.** Router y planner comparten estado y van en una sola solicitud SystemOne (`solicitudConjunta`); sus respuestas se separan e interpretan con la misma política. El judge solo se consulta cuando hay análisis (comparación, ranking, diagnóstico, serie) o la métrica no es concluyente; una lectura confiable resuelve el componente registrado por métrica y vista (en el Agente, la pestaña de AnalyticsCard sigue a venta, margen o unidades). Mediana 3,1 s → 2,1 s; 2,8 → 1,4 inferencias por turno.

**La métrica decide el dominio.** El planner elige entre todas las métricas de la fuente (elección jerárquica dominio→métrica con el mismo mínimo y separación) y el dominio se deriva de ella; antes, un dominio elegido primero impedía nombrar «margen» tras una consulta de ventas y se respondía venta sin advertirlo. Si el modelo afirma que cambia la métrica pero no la nombra, se pregunta. El router ofrece todos los dominios para declarar «la fuente no mide…» en lugar de sustituir por ventas. Una base de comparación concreta y concluyente no la anula la compuerta binaria. Pronóstico o acción con intención ganadora separada (mínimo 0,45, fallo seguro) se declaran antes de pedir aclaraciones. El listado solo cambia en Ventas y sigue a la entidad nombrada. `detect_stockout` define su métrica (existencias). Explicar un cambio ejecuta la comparación como prerrequisito.

**Balance del perfil.** Se usa cuando coinciden la revisión general del router y el paquete del planner (promedio ≥ política binaria) y la intención dominante es de lectura; continuar un balance sin nombrar métrica lo repite; nombrar otra métrica es un seguimiento específico. Sin judge: sus métricas son las registradas del perfil.

**Contexto sin recorte.** Clef recorta el estado en silencio si excede `max_length`; ahora es 16.384 (oficial) y `usage.state_truncated` hace que el ciclo rechace la decisión.

**Vínculo vivo.** Cada respuesta con evidencia verificada devuelve un `vinculo` firmado (usuario, fuente, perfil; 30 días) sin cifras: dominio, métricas, entidad, herramientas registradas, plantilla, límites del juicio y componente. `GET /escenarios/:id/vinculo` lo reevalúa con las variables vigentes del tablero, sin Clef, ejecutando solo capacidades registradas y las mismas plantillas. `GET /escenarios/:id/version` identifica la versión de los datos (archivo lechero, semilla sintética o cobertura UCI releída cada 30 s). La interfaz consulta la versión cada 30 s con la pestaña visible y, si cambia, recarga cobertura, tablero y respuesta; al cambiar filtros, la misma respuesta sigue al período; al recargar, se restaura el vínculo de cada fuente. Un archivo lechero nuevo reinicia el servicio de datos de forma ordenada (recargar en caliente duplicaría ~450 MiB bajo el límite de 1 GiB). «Este año» y «este mes» son referencias en curso (`en_curso:anio|mes`) que avanzan con los registros.

**Harness.** `servicios/datos/test/evaluacion-agente.mjs` puntúa la conexión con Clef real: dominio, métrica, herramienta, período/comparación/listado, cambios indebidos, componente, plantilla, aclaraciones innecesarias, incorrectos silenciosos, inferencias, tokens y latencia; entre turnos arrastra variables y contexto como la interfaz. Conjuntos `conexion_desarrollo` y `conexion_control` (este último escrito antes de cambiar código y no usado para ajustar). Resultado con Clef real: control 25→28/28, conexión-control 7→13/14 con 0 respuestas silenciosamente erróneas (antes 5). `conexion.test.js` y `vinculo.test.js` fijan cada corrección; `web/pruebas/vinculo-vivo.mjs` verifica en navegador evento, filtro y recarga sin consultar a Clef. En denoise-server, al publicar otra versión de la base lechera se detectó en 5 s y los vínculos conciliaron exactamente con sumas SQL independientes de cada versión, sin llamadas a Clef.

**Pendiente.** «Este mes» sin registros todavía responde «no hay datos» con alternativa, en vez de conectar un mes en curso vacío. «¿Cuánto cobramos?» se interpreta como venta (probabilidad 0,86, confirmada por el judge): error del modelo, no corregido con reglas de frases.

## Contexto y semántica

[`estado-cognitivo.js`](../datos/src/estado-cognitivo.js) construye identidad autenticada, vista, filtros, período cubierto, conversación, indicadores, objetivos de prueba, ontología y metadatos de fuente. El navegador no concede roles, empresas ni permisos: esas identidades operacionales aún no están disponibles. Las fuentes actuales son sintéticas o UCI, no una empresa real.

La conversación usa una memoria HMAC ligada a usuario y escenario, con vencimiento de 30 minutos. Guarda dominio, métrica, entidad, entidades recientes y hallazgos mínimos. Alteraciones, cambio de usuario/fuente o vencimiento descartan el antecedente. No se crean bases ni tablas nuevas.

Cada marco recibe la proyección de contexto relevante. Routing conserva contexto operacional y catálogos, sin repetir identificadores técnicos de filtros que puedan sesgar el alcance. Los períodos semánticos `month`, `quarter`, `year`, `context` se traducen determinísticamente a filtros existentes. «Este mes» significa el último mes completo **cubierto**, no inventar datos del mes del reloj. Planner recibe el dominio resuelto, contexto y ontología; no una copia de todas las distribuciones anteriores. Judge recibe resultados compactos con procedencia y límites; los recortes de filas y puntos se marcan, y la respuesta conserva las evidencias completas.

No se sobrescriben intenciones o períodos con expresiones regulares. Una referencia usa el antecedente firmado. Las elecciones cercanas conservan incertidumbre; las intenciones de lectura indistinguibles pueden avanzar a planificación de lectura, sin fingir una clasificación precisa. Una contradicción entre dominio explícito y conservación de contexto requiere aclaración. Los cambios de comparación requieren una solicitud explícita; diagnosticar no cambia por sí solo ese filtro.

## Capacidades, datos y evidencia

[`registro-cognitivo.js`](../datos/src/registro-cognitivo.js) descubre capacidades por dominio, métrica y fuente. Declara entradas, salida y efectos. [`herramientas-cognitivas.js`](../datos/src/herramientas-cognitivas.js) ejecuta únicamente identificadores permitidos:

| Capacidad | Sintético | UCI |
| --- | --- | --- |
| `get_kpi`, `get_timeseries`, `compare_periods` | Métricas de ventas, rentabilidad, cobranza e inventario | Venta neta y unidades firmadas |
| `rank_entities` | Dimensiones implementadas de cada dominio; límites explícitos para otras | Países y productos |
| `detect_anomalies` | Caída de venta por sucursal con umbral de prueba del 25 % | No disponible |
| `find_drivers` | Diferencias de venta por sucursal; puente de importe de margen bruto | No disponible |
| `detect_stockout` | Proyección existente: stock menos demanda más recepciones | No disponible |

Cifras sintéticas se derivan de entidades compartidas; UCI reutiliza las consultas y base existente. Las conciliaciones monetarias UCI usan decimales exactos; el modelo no calcula. Ninguna medición UCI de deuda, costo o inventario se reemplaza por números de demo. Saldos y porcentajes no se suman como flujos. Cada evidencia conserva fuente, moneda, definición, período, comparación, filtros y corte.

Anomalías y drivers necesitan una comparación cubierta. Sus diferencias concilian con los agregados. Una contribución contable no demuestra causa operacional; el puente explica el importe del margen, no atribuye causalidad al porcentaje. La proyección de stock es condicional y usa el modelo de la demo, no un pronóstico validado universal.

## Investigación y respuesta

Planner selecciona necesidades conjuntamente. Después de las herramientas, Judge evalúa correspondencia de la métrica con el pedido, hechos, evidencia, siguiente capacidad, severidad, componente y plantilla. Una métrica que no responde al concepto solicitado produce aclaración incluso si sus cifras son correctas. Puede pedir una capacidad pendiente y volver a evaluar. El máximo es cuatro inferencias, siete herramientas y dos rondas de juicio, sin repetir herramientas. Los límites se devuelven con el resultado; no se investiga indefinidamente.

[`respuestas-cognitivas.js`](../datos/src/respuestas-cognitivas.js) ofrece plantillas para valor, comparación, diagnóstico, revisión recomendada, resultado parcial y evidencia insuficiente. Un juicio incierto conserva las cifras verificadas como resultado parcial y expresa sus límites. No hay redactor auxiliar conectado. Una recomendación textual nunca ejecuta una acción.

La respuesta versionada contiene `propuesta`, `analisis.evidencia`, `decision`, `response_plan` y `contexto`. La UI rechaza propuestas obsoletas cuando cambian fuente o filtros; el token solo se reutiliza para su escenario. Las aclaraciones conservan la conversación abierta. Nueva conversación borra memoria y selección, y descarta respuestas de la conversación anterior.

## Presentación obligatoria

El registro contiene solamente componentes **ya implementados**: `AnalyticsCard`, `DetailCard`, `SalesView`, `ProfitView`, `CollectionsView`, `InventoryView` y `AgentDock`. Los presets apuntan a las vistas originales. Se validan componente, preset y propiedades antes de responder y también en el adaptador web.

Clef puede seleccionar y configurar filtros o pestañas existentes. El frontend usa el renderer original; no interpreta HTML, CSS, SVG, JSX ni nombres de componentes libres. Si no hay representación adecuada, devuelve texto en `AgentDock` y registra `capacidades_no_cubiertas`; no desarrolla un gráfico. Las únicas secciones siguen siendo Agente, Ventas, Rentabilidad, Cobranza, Inventario, Vistas guardadas y Reportes. No cambiar estilos, layouts, tipografía, colores o comportamiento responsive.

## Límites deliberados

No están conectados pronósticos estadísticos, cambio de régimen, segmentación, RAG, búsqueda de entidades por nombre, escrituras ERP ni un LLM redactor. Las acciones destructivas o de escritura se bloquean. Faltan permisos y empresa operacional para habilitar acciones reales; no se infieren desde la petición. La ontología es inicial y las capacidades dependen de la fuente. No se promete comprensión universal ni un porcentaje de acierto sin evaluación independiente.

## Verificación

- [`cognitivo.test.js`](../datos/test/cognitivo.test.js): contexto, ciclo iterativo, presupuesto, incertidumbre, memoria firmada, permisos ausentes, conciliaciones, resultados parciales y rechazo de componentes/herramientas ajenos.
- [`evaluacion-cognitiva.mjs`](../datos/test/evaluacion-cognitiva.mjs): regresión exploratoria de paráfrasis. Sus casos también detectaron errores corregidos; no se presentan como holdout estadístico.
- [`contrato.test.js`](../datos/test/contrato.test.js): base UCI y Clef real; alcance mensual, anomalía conciliada, deuda, referencia firmada, bloqueo de escritura y fuente no compatible.
- [`flujo-sintetico.mjs`](../../web/pruebas/flujo-sintetico.mjs): componentes y controles originales en navegador.
- [`verificar.mjs`](../../web/pruebas/verificar.mjs): pruebas locales y comparación visual. Usar `PATAGONIA_SOLO_DESKTOP=1` para este trabajo.

Los casos reales usados para ajustar instrucciones son desarrollo, no calibración ni validación estadística. Antes de fijar umbrales en operación, medir solicitudes independientes por dominio, referencias, cambios indebidos de filtros, herramientas omitidas, latencia y falsos positivos. No reutilizar ejemplos de ajuste para declarar precisión.
