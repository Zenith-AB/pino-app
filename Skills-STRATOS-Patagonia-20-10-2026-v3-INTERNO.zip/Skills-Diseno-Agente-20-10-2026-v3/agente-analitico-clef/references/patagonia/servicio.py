"""Servicio local de Clef-Flash compatible con SystemOne: POST /v1/systemone y GET /salud.

Escucha solo en 127.0.0.1 y exige X-Clef-Secreto. La GPU es compartida, así que:
  - el modelo se carga en la primera solicitud, si hay memoria libre suficiente, con un tope de VRAM por proceso;
  - tras CLEF_INACTIVIDAD_S sin uso el proceso termina y libera incluso el contexto CUDA; systemd lo vuelve a
    levantar en reposo, sin tocar la GPU hasta la siguiente solicitud.
Las solicitudes se atienden de a una: el modelo no se comparte entre hilos.

Variables: CLEF_SECRETO (obligatorio, ≥32), CLEF_PUERTO (4185), CLEF_MODELO, CLEF_VRAM_MAXIMA_GB (6), CLEF_INACTIVIDAD_S (600).
"""

import hmac
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

SECRETO = os.environ.get("CLEF_SECRETO", "")
if len(SECRETO) < 32:
    raise SystemExit("CLEF_SECRETO debe tener al menos 32 caracteres")
PUERTO = int(os.environ.get("CLEF_PUERTO", "4185"))
MODELO = Path(os.environ.get("CLEF_MODELO", "/home/denoise/models/clef-flash"))
VRAM_MAXIMA_GB = float(os.environ.get("CLEF_VRAM_MAXIMA_GB", "6"))
INACTIVIDAD_S = float(os.environ.get("CLEF_INACTIVIDAD_S", "600"))
TAMANO_MAXIMO = 64 * 1024

estado = {"modelo": None, "procesador": None, "torch": None, "ultimo_uso": time.monotonic(), "carga_s": None}
candado = threading.Lock()


class Ocupado(Exception):
    pass


def asegurar_modelo():
    if estado["modelo"] is not None:
        return
    import torch
    from transformers import BitsAndBytesConfig
    from clef_local import cargar

    libre, total = torch.cuda.mem_get_info()
    if libre < (VRAM_MAXIMA_GB + 0.5) * 2**30:
        raise Ocupado(f"GPU sin memoria libre suficiente ({libre / 2**30:.1f} GiB)")
    torch.cuda.set_per_process_memory_fraction(VRAM_MAXIMA_GB * 2**30 / total)
    inicio = time.perf_counter()
    estado["modelo"], estado["procesador"] = cargar(MODELO, torch, BitsAndBytesConfig)
    estado["torch"] = torch
    estado["carga_s"] = round(time.perf_counter() - inicio, 1)
    print(json.dumps({"evento": "modelo_cargado", "segundos": estado["carga_s"], "gib": round(torch.cuda.memory_allocated() / 2**30, 2)}), flush=True)


def precargar():
    try:
        with candado:
            asegurar_modelo()
            estado["ultimo_uso"] = time.monotonic()
    except Ocupado as error:
        print(json.dumps({"evento": "precarga_omitida", "detalle": str(error)}), flush=True)
    except Exception as error:  # noqa: BLE001 - la precarga es opcional
        print(json.dumps({"evento": "precarga_fallida", "tipo": type(error).__name__}), file=sys.stderr, flush=True)


def vigilar_inactividad():
    while True:
        time.sleep(15)
        with candado:
            if estado["modelo"] is not None and time.monotonic() - estado["ultimo_uso"] > INACTIVIDAD_S:
                print(json.dumps({"evento": "salida_por_inactividad"}), flush=True)
                os._exit(0)


class Manejador(BaseHTTPRequestHandler):
    def responder_json(self, codigo, objeto):
        cuerpo = json.dumps(objeto, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def log_message(self, *argumentos):
        pass

    def do_GET(self):
        if self.path == "/salud":
            return self.responder_json(200, {"estado": "disponible", "modelo_cargado": estado["modelo"] is not None})
        if self.path == "/precargar":
            # Carga anticipada cuando alguien abre el Agente: la primera pregunta no paga la carga en frío.
            # No bloquea; cuenta como uso para el temporizador de inactividad.
            if not hmac.compare_digest(self.headers.get("X-Clef-Secreto", ""), SECRETO):
                return self.responder_json(401, {"error": "No autorizado"})
            if estado["modelo"] is not None:
                estado["ultimo_uso"] = time.monotonic()
                return self.responder_json(200, {"estado": "cargado"})
            threading.Thread(target=precargar, daemon=True).start()
            return self.responder_json(202, {"estado": "cargando"})
        self.responder_json(404, {"error": "Ruta no encontrada"})

    def do_POST(self):
        inicio = time.perf_counter()
        codigo = 200
        try:
            if self.path != "/v1/systemone":
                codigo = 404
                return self.responder_json(codigo, {"error": "Ruta no encontrada"})
            if not hmac.compare_digest(self.headers.get("X-Clef-Secreto", ""), SECRETO):
                codigo = 401
                return self.responder_json(codigo, {"error": "No autorizado"})
            largo = int(self.headers.get("Content-Length", "0"))
            if largo <= 0 or largo > TAMANO_MAXIMO:
                codigo = 413
                return self.responder_json(codigo, {"error": "Solicitud vacía o demasiado grande"})
            solicitud = json.loads(self.rfile.read(largo))
            with candado:
                asegurar_modelo()
                from clef_local import responder
                respuesta = responder(estado["modelo"], estado["procesador"], solicitud, estado["torch"])
                estado["ultimo_uso"] = time.monotonic()
            respuesta["ms"] = round((time.perf_counter() - inicio) * 1000, 1)
            self.responder_json(codigo, respuesta)
        except (ValueError, json.JSONDecodeError) as error:
            codigo = 400
            self.responder_json(codigo, {"error": str(error)})
        except Ocupado as error:
            codigo = 503
            self.responder_json(codigo, {"error": str(error)})
        except Exception as error:  # noqa: BLE001 - se registra y se responde sin detalles internos
            codigo = 500
            print(json.dumps({"evento": "error", "tipo": type(error).__name__, "detalle": str(error)[:300]}), file=sys.stderr, flush=True)
            self.responder_json(codigo, {"error": "Error del servicio Clef"})
        finally:
            print(json.dumps({"ruta": self.path, "codigo": codigo, "ms": round((time.perf_counter() - inicio) * 1000)}), flush=True)


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).parent))
    threading.Thread(target=vigilar_inactividad, daemon=True).start()
    print(f"Clef SystemOne en 127.0.0.1:{PUERTO}", flush=True)
    HTTPServer(("127.0.0.1", PUERTO), Manejador).serve_forever()
