---
name: stratos-diseno-instrumental
description: "Aplica el sistema visual STRATOS a interfaces y prototipos solicitados: glass, cards, gráficos científicos, tokens y jerarquía. No impone sus reglas a productos que no pidan ese perfil."
---

# Diseño instrumental STRATOS

Lee [material y composición](references/diseno.md) antes de diseñar y [gráficos y cards](references/graficos-cards.md)
al construir instrumentos. Los valores efectivos viven en el snapshot de `references/codigo/src/styles/tokens.css`;
tipografía en `typography.css`, material en `glass.css`. En STRATOS vivo manda el código destino vigente.

## Decisiones fundamentales

- Lienzo vivo protagonista: mapa o escena submarina. El glass organiza instrumentos sin ocultar el lugar.
- Grafito ligeramente verdoso; Source Sans 3; color semántico escaso; radios de sistema de 20 px.
- Teal ciencia, azul sensor, azul río, magenta centro, violeta modelo, ámbar atención, rojo evento/fallo,
  verde estabilidad. Acompañar color con texto/icono. Un delta positivo no es automáticamente favorable.
- Una card reúne identidad → lectura → unidad → fecha/procedencia/QC → silueta → tendencia → contexto.
  No apilar vidrio dentro de vidrio ni usar cards vacías para rellenar una grilla.
- Las decisiones de diseño nunca convierten un índice en probabilidad ni una boya distante en sensor local.

## Implementación

Reutiliza GlassSurface, los tokens semánticos y los instrumentos del snapshot. Conserva el componente
de card al cambiar selección; reemplaza contenido con un fade breve. La carcasa permanece estable.
Importa sólo las piezas necesarias; revisa imports en el repo destino. Los archivos son referencias,
no un módulo instalable con todos sus proveedores incluidos.

Para adaptar el perfil a otra marca, documenta alias semánticos antes de cambiar color y conserva
legibilidad y jerarquía. No copies la paleta Patagonia simultáneamente. El orbe del agente puede
adoptar el acento STRATOS, conservando su exclusividad como firma de interacción del agente.

## Verificación visual

Inspecciona mapa claro/oscuro, hover, seleccionado, ausente, parcial y error. Comprueba contraste sobre
el fondo compuesto real, no sólo dos tokens. Sin WebKit disponible, registra que Safari queda pendiente.
Prueba DPR 1 y 2; no declares aprobado 4K sin medirlo. Anima transform/opacity, nunca blur a pantalla completa.
El presupuesto de partículas y material se ajusta con los controles de render existentes.

Índice de código y assets: [references/INDICE.md](references/INDICE.md).

Antes de adaptar, leer [contrato de sistema y aceptación](references/contrato-sistema.md).
