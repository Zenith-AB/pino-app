# Gramática de cards y gráficos

## Cards

La ficha integra identidad/disponibilidad, lectura/unidad, hora/fuente/QC, planta o silueta,
tendencia real y variables secundarias. Usar el patrón CenterSensorInstruments/SotracsStationCard.
Disponible, antiguo, parcial y ausente son estados diferentes. «Lectura reciente» no prueba que las
jaulas tengan conectividad directa. No dibujar sparkline si no existe serie.

La orientación del wireframe se deriva de geometría identificada, no del rumbo de la corriente.
Una geometría estimada por imagen no es un levantamiento oficial ni un inventario actualizado.
Miniaturas e ilustraciones deben conservar su naturaleza en el pie de la ficha.

## Selección de gráfico

| Pregunta | Componente de referencia | Contrato |
|---|---|---|
| ¿Qué midió esta sonda? | TrendChart / SignalCharts | unidad, profundidad, QC y huecos reales |
| ¿Cómo varía un forzante? | MiniTrendChart / ThresholdLineChart | mismo soporte temporal, umbral identificado |
| ¿Qué dispersión tiene el ensemble? | EnsembleStepChart | dispersión de miembros ≠ intervalo calibrado |
| ¿Cómo fue pronóstico vs observado? | ForecastVsObservedChart | pares comparables; origen, horizonte y naturaleza |
| ¿Qué cambió en el error? | RollingErrorChart | n/periodo/baseline y unidad; no mezclar objetivos |

No suavizar a través de ausencias, extrapolar ni adornar una serie con una onda inventada.
Compartir escala y tiempo cuando se comparan series; ejes independientes deben estar claramente
separados. Barras desde cero salvo una excepción defendida; series de temperatura pueden usar
rango acotado con eje visible. Umbrales con etiqueta, no sólo línea/color.

Patrón Patagonia transferible: numeral fino, decimales subordinados, rejilla de puntos, histórico
diferenciado, meta fuera del área, herramientas de hover separadas del SVG. No imponer spline
Catmull-Rom a registros ambientales si altera extremos o oculta discontinuidades.

## Interacción y accesibilidad

Tooltip con valor exacto, unidad, fecha, profundidad y fuente; accesible por foco/teclado.
Gráfico con resumen legible y alternativa de datos cuando aporta lectura. No depender sólo del color.
SVG memorizado y hover sin reconstruirlo; ResizeObserver con contenedor de alto estable.
Los cambios de filtro no reaniman cada card ni reinician contadores de números.
