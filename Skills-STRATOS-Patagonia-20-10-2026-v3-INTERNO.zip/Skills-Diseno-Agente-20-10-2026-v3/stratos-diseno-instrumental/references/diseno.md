# Material, tipografía y composición

## Material

Fuente de verdad del snapshot: `codigo/src/styles/tokens.css`, `glass.css` y GlassSurface.
El código tiene variantes de material y perfiles; no mezclar valores de fechas distintas como si fueran
un único preset. Usar alias semánticos, no HEX o rgba ad hoc en cada componente. Las reglas históricas
que acompañan al material son antecedentes; comprobar el valor efectivo en CSS y el resultado renderizado.

Mantener cinco roles de superficie: estructural, instrumento, toolbar, flotante y aviso. Borde óptico
direccional, luz tenue y textura estática; evitar borde blanco duro y múltiples velos. El material debe
dejar reconocer movimiento y geografía sin que compitan con las cifras. Si falta contraste, ajustar el
soporte del rol, no sumar placas translúcidas indiscriminadamente.

## Jerarquía

En cada grupo: contexto pequeño, título identificable, valor principal tabular, unidad separada,
procedencia legible y gráfico. Respetar las clases tipográficas por propósito. Nunca comprimir hasta
volver ilegible para hacer caber una captura: el panel puede desplazarse verticalmente.
Las proporciones de 1920×1080 son referencia de composición, no coordenadas absolutas universales.

El mapa conserva el mayor espacio continuo. Dock izquierdo para contexto y lectura; rail de fuentes
discreto; controles fuera de los datos; instrumentos inferiores comparables. En estrecho se repliegan
secundarios y hay controles explícitos; no reducir todo con transform:scale.

## Movimiento STRATOS conservado

`stageTiming.ts` centraliza el cruce de módulos: blackout 360/100/480 ms; contenido 240/380 ms;
módulos sobre mapa 180/360 ms. No repetir esos números a mano en componentes. El acceso espera el
tablero pintado antes de disolverse (límite 6000 ms). No reemplazar estas decisiones con un preset genérico.
`fadeFlight.ts`: cámara out 220 ms, in 480 ms, asentamiento 160–1600 ms, cancelable y esperando tiles.
No escalar satélite borroso durante un flyTo largo ni dejarlo oculto esperando una capa indefinidamente.

Para nuevas microinteracciones: hover/foco 120 ms; cambio de dato 180–240 ms; panel 280 ms,
ease-out sin rebote. Son recomendaciones para piezas nuevas; prevalecen tokens existentes.
Desactivar movimiento no esencial en reduced-motion; no eliminar estado, foco ni señal de carga textual.
