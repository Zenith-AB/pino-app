# Contrato para construir el sistema visual

## Dirección y transferencia
Perfil de esta demo: STRATOS instrumental, Source Sans 3, grafito verdoso, glass y territorio protagonista. De Patagonia se transfiere la relación inicio/compositor/orbe/dock/evidencia, no Urbanist, la navegación ERP ni sus cifras. Si el usuario cambia la referencia, registrar la nueva dirección y modificar aliases; no apilar dos marcas.

Antes de construir, producir en destino una tabla `referencia → rasgo observado → decisión → componente/token → límite`. Revisar la imagen a tamaño real. Separar lo observado de lo inferido. Una petición de estática no autoriza copiar comportamiento oculto ni conectar servicios.

## Arquitectura de tokens
Reusar nombres/valores del snapshot pertinente o destino vigente. Orden: primitivos → semánticos → rol de superficie → componente → estado. Crear aliases sólo donde falte un rol; ningún color de datos debe depender del índice del array. No inventar un HEX diferente en cada card.

Roles: lienzo (geografía), shell (navegación), instrumento (lectura), flotante (detalle) y aviso (estado). Un contenedor agrupa con espacio y alineación antes de añadir vidrio. No anidar backdrop-filter. En fondos satelitales claros aumentar soporte del material, no oscurecer todas las cifras por igual. Verificar la composición real en costa, agua oscura e imagen brillante.

Source Sans 3 local; peso normal para lectura, semibold para identidad/acción; tabular-nums para valores. Como punto de partida de una nueva demo, texto de lectura 14–16 px, metadatos 12–13 px, títulos 20–28 px y métrica 32–44 px. Son rangos de composición propuestos, no valores recuperados del producto; los tokens reales prevalecen. No escalar toda la app para encajar.

## Composición por vista
| Vista | Foco | Soporte | Evitar |
| --- | --- | --- | --- |
| Mapa | territorio y selección | contexto lateral, leyenda, fecha | grilla que tape toda el agua |
| Centro | identidad y variables válidas | silueta orientada si está verificada, fuente y QC | declarar conexión por tener marcador |
| Submarina | centro lateral, agua y profundidad | sensores vinculados, corrientes, cámaras | render que finja inventario o física |
| Agente inicio | pregunta + contexto activo | sugerencias ejecutables y orbe | métricas de relleno |
| Agente resultado | conclusión y prueba principal | conversación compacta, instrumentos y fuentes | todas las cards al mismo peso |

En 1440/1920 mantener mapa continuo y paneles legibles; al estrechar, replegar secundarios en paneles accesibles y llevar instrumentos al flujo. Nunca esconder cancelar, fuente o estado parcial. El footer SAM/FAN se conserva en el perfil STRATOS. Medir overflow y foco en vez de inferir responsive de una captura.

## Cards y gráficos
Una card responde qué, dónde/profundidad, cuánto/unidad, cuándo, de dónde y qué calidad. Selección no desmonta su carcasa. Ausencia no es cero; una tendencia exige serie real comparable. Mostrar naturaleza observada/modelada/inferida/hipótesis con texto y no sólo color.

Escalas/unidades visibles; vacíos interrumpen la línea; tooltip por teclado; resumen textual o tabla equivalente. No suavizar picos para embellecer, no comparar °C con PSU en el mismo eje, ni convertir intervalo ensemble en confianza calibrada. Bandas, miembro superior y P90 tienen significados diferentes: preservar el algoritmo del instrumento elegido.

## Aceptación visual
Revisar dos tamaños desktop y uno estrecho, datos largos, estados vacío/parcial/error, mapa claro/oscuro y movimiento reducido. Contraste mínimo del texto normal 4.5:1 y de controles/gráficos esenciales 3:1 sobre fondo compuesto; medir, no declarar por intención. Revisar foco visible, orden de lectura y superficie táctil suficiente. Ningún resultado debe quedar tapado por el dock.

La revisión debe entregar capturas realmente inspeccionadas y una tabla problema/corrección/evidencia. Build y screenshots por sí solos no acreditan calidad. Resolver primero legibilidad/jerarquía; luego afinar material, ritmo y movimiento. No añadir animación para esconder datos faltantes.
