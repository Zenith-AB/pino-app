# STRATOS · ficha integrada y evaluación operacional

Fecha: 2026-09-23. Alcance: dock izquierdo y pestaña Modelos; no rediseño del mapa ni nueva familia de tarjetas.

## Decisión de diseño comprobable

La imagen de Vexto entregada por el usuario mide 147 × 192 px (**ancho/alto 0,766**). La captura previa de STRATOS citada en la propuesta adjunta mide 247 × 212 px (**1,165**). Son píxeles de capturas, **no medidas normativas ni dimensiones CSS**. En el perfil cómodo actual, `--left-panel-width` tiene mínimo 470 px, `--panel-padding` 16 px y `--grid-gap` 8 px: cada una de las dos columnas dispone de unos 215 px antes de posibles factores responsivos. Con suelo visual de 256 px, la ficha se acerca a **0,84**. Se conserva la grilla y se admite scroll vertical cuando la pantalla no da altura; no se comprimen los datos para imitar una captura de 147 px.

La [ficha de Vexto de Rondesignlab](https://rondesignlab.com/cases/vexto-telemetry-transit-saas-dashboard-ux-ui-design) describe vehículo, estado GPS/conexión y ruta en una sola unidad de lectura. Su efecto en STRATOS es una **misma superficie** para identidad, lectura, procedencia, silueta técnica y tendencia; no una placa de vidrio dentro de otra. Sus cifras de mejoras de respuesta son declaraciones del estudio de caso, no una expectativa medida para STRATOS. [Apple, Layout](https://developer.apple.com/design/human-interface-guidelines/layout) respalda agrupación, jerarquía por orden de lectura y espacio para lo esencial; [Apple, Materials](https://developer.apple.com/design/human-interface-guidelines/materials) aconseja evitar material superpuesto y preservar legibilidad. La referencia es una pauta de composición, no una implementación literal de Liquid Glass (STRATOS es web).

Anatomía de la ficha de centro: **identidad y disponibilidad → variable y valor → hora/fuente/QC → planta técnica orientada → serie real si existe → variables secundarias**. La disponibilidad dice “lectura reciente”, “parcial o antigua” o “sin lectura válida”; no afirma que el centro esté conectado. La boya usa la misma anatomía, silueta frontal sin rotación geográfica. Cuando no hay serie temporal, no se dibuja una línea ficticia. Variables secundarias conservan `GOOD`/dudoso/ausente de IFOP y las unidades originales.

Para Reloncaví, los dos anillos de `src/data/centers/reloncavi.site.ts` fueron trazados sobre Esri Vivid (2026-03-08). Se calcula el eje axial de la arista larga de cada módulo y su media circular; el SVG norte-arriba gira unos 30°. Es una **estimación de imagen, no rumbo de levantamiento oficial**. Comau no tiene contorno verificado en el repositorio: su wireframe permanece neutro y la interfaz declara “orientación no verificada”. Un norte en la ilustración sólo aparece cuando hay geometría. No se confunde orientación de jaulas con dirección de corriente.

La serie dentro de la ficha es un elemento de contexto, no un “gráfico de ruta”. [Apple, Charting data](https://developer.apple.com/design/human-interface-guidelines/charting-data) recomienda destacar la información importante, evitar saturación y proporcionar descripción accesible; por ello se conserva el gráfico real y su nombre accesible. [Apple, Accessibility](https://developer.apple.com/design/human-interface-guidelines/accessibility) exige contraste y más de un canal para estados: el estado usa texto además de color.

## Evaluación que ahora puede leerse

La pestaña Modelos incorpora una tabla operacional por variable, al mismo horizonte y período seleccionados. Sólo usa `/timesfm/performance/by-variable`, que devuelve puntos `EVALUATED` persistidos. Cada fila expone `n`, sitios, primera/última observación, MAE con unidad y skill MAE contra persistencia y media horaria de 7 días **sobre pares emparejados**. Las filas con alguna baseline mejor quedan arriba para revisión. No se promedian MAE de °C, PSU y mg/m³, ni se mezcla backtest con operación. El mínimo de 25 pares es un umbral del servicio para **mostrar** cifras, no suficiencia científica. Antes de `valid_time` y de la observación correspondiente, el pronóstico sigue pendiente.

Lectura puntual comprobada el 2026-09-23 vía API activa del servidor, `+24 h`, todos los sitios: oxígeno disuelto `n=28`, MAE 1,360 mg/L, skill MAE −0,9 % frente a persistencia y −2,4 % frente a media; fluorescencia `n=28`, MAE 2,500 mg/m³, skill −4,4 % y −66,1 % respectivamente. Sólo cubre desde el 21 hasta el 23 de septiembre: son **señales para investigar**, no diagnóstico de generalización. La interfaz no congela estos valores; vuelve a leer la API.

## Patricio A. Díaz y coautores: hipótesis que sí y no entran

| Evidencia primaria | Implicación técnica | Estado verificable en STRATOS |
|---|---|---|
| [Baldrich et al. 2025, *Harmful Algae*](https://pubmed.ncbi.nlm.nih.gov/40187792/) — Reloncaví, observaciones 0–20 m de *D. acuminata*, estructura de columna y nutrientes | Probar perfiles T/S, posición/espesor de picnoclina, nitrito/silicato y prey, con lag y sitio; no elevar una asociación a regla causal D30 | `datos.py` usa T/S sólo a 5 m; no hay perfil local histórico ni NO₂/Si uniforme |
| [Díaz et al. 2025, *J. Plankton Research*](https://academic.oup.com/plankt/article/47/2/fbae068/8079106) — bloom de *Mesodinium* en 2019 sin crecimiento posterior automático de *Dinophysis* | La presa por sí sola no dispara una alerta; medir coocurrencia en tiempo, espacio y profundidad | *Mesodinium* no figura entre los taxones de la fuente de entrenamiento actual |
| [Pérez-Santos, Díaz et al. 2021, *STOTEN*](https://www.sciencedirect.com/science/article/pii/S004896972104314X) — serie OMARE 2017–2020 y alternancia estuarina/oceánica | Buscar acceso/licencia a perfiles y nutrientes OMARE; versionar fecha de disponibilidad para evitar fuga; contrastar con proxies globales | No hay OMARE incorporado al dataset D30; GLORYS no es perfil del centro |
| [Pérez-Santos, Díaz et al. 2025, *Marine Environmental Research*](https://pubmed.ncbi.nlm.nih.gov/40934805/) — capas finas y ciclos diurnos/semidiurnos en Seno | Preservar hora, profundidad, marea, viento y cizalla; agregación diaria puede borrar el mecanismo | Dos sondas a 5/60 m y corriente de modelo no reconstruyen capa fina ni cizalla local |

El trabajo de [toxinas en bahía Metri, 2024](https://www.sciencedirect.com/science/article/pii/S0048969724025208) refuerza que célula, toxina y cierre no son un solo objetivo. Esta tabla es una **agenda de medición y experimento**, no una promesa de que STRATOS ya prediga FAN D30. El gate local en `services/fan-dinophysis/results/validacion-seno-2026-09-21.json` sigue `passed=false`: B5 tiene un solo pliegue 2025, 81 orígenes, BSS −0,078 y ROC-AUC 0,540. No se publica como probabilidad validada del Seno.

## Próximo experimento, con controles

1. Verificar acceso a OMARE, series DGA y archivos IFOP por fecha/estación/profundidad. Registrar licencias, QC, `observed_at` y `available_at`; no rellenar una ausencia como cero ni asignar ACS1 a las jaulas a 28 km.
2. Construir bloques candidatos **por separado**: historia local de *D. acuminata*, perfiles y estratificación, caudal/mezcla, nutrientes y *Mesodinium*. Cada bloque entra sólo si existe cobertura histórica suficiente, fecha de publicación previa al origen y ablatión positiva en pliegues temporales locales.
3. Evaluar D30 de escalamiento AR<5 → AR≥5 con estación y año futuros, PR-AUC, Brier/BSS, calibración y falsos negativos frente a climatología y AR-only. Mantener alerta FAN desactivada hasta superar gate local y período sombra. TimesFM queda como pronosticador de forzantes ambientales; su tabla no valida el clasificador biológico.

Pruebas mínimas: `node --experimental-strip-types --test src/lib/centers/footprintOrientation.test.ts src/lib/models/operationalOverview.test.ts`; `npm run lint`; `npm run build`; navegador en anchos 1440/1024 y `prefers-reduced-motion`; consulta de API operacional y verificación de `n`/periodo/pares; prueba de anti-fuga para cualquier nueva fuente D30.
