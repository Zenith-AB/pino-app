﻿# SignalCharts

Biblioteca de gráficos STRATOS basada en las referencias del 16-09-2026. Se integra con `OperationalTrendline`: mismo manejo de tiempos, dominios, huecos, clipping, bandas y SVG responsive. No incorpora otra dependencia de gráficos.

## Componentes

- `SignalTrendChart`: señal tenue con una lectura horizontal del último dato. `summary="none"` conserva únicamente el lenguaje visual para gráficos que ya tienen un KPI.
- `SignalTrendStrip`: periodos consecutivos o separados, en una única escala X/Y, con medias muestrales y variaciones entre periodos. La altura de cada línea corresponde a su valor, no a un desplazamiento decorativo.
- `TrendReading`: lectura explícita con `start`, `end`, `value`, `label`, `valueLabel`, `detail` y `tone` opcionales.
- `guide`: serie secundaria explícita, dibujada de forma tenue. Puede representar una media o una consigna; la fuente entrega los puntos y su significado. El componente no inventa esa serie.

## Uso

```tsx
import { SignalTrendChart, SignalTrendStrip } from '../instruments';

<SignalTrendChart
  data={samples}
  summaryLabel="Última muestra"
  formatY={value => `${value.toFixed(1)} °C`}
  yDomain={[5, 25]}
  yTicks={[10, 20]}
  ariaLabel="Temperatura superficial, grados Celsius"
/>

<SignalTrendStrip
  data={samples}
  periods={[
    { id: 'morning', start: '06:00', end: '12:00', label: 'Mañana' },
    { id: 'afternoon', start: '12:00', end: '18:00', label: 'Tarde', tone: 'warning' },
  ]}
  yDomain={[5, 25]}
  formatY={value => `${value.toFixed(1)} °C`}
  ariaLabel="Temperatura por periodo; media de las muestras"
/>
```

Los datos `samples` deben usar las mismas unidades temporales que los periodos. Se aceptan números, horas HH:mm o fechas ISO con zona horaria, según el contrato existente de OperationalTrendline.

## Contrato visual

| Capa | Token / tratamiento |
| --- | --- |
| Serie original | `--signal-raw`, blanco cálido al 16%, trazo de 1 px |
| Grilla | `--signal-grid`, 6%, discontinua |
| Ejes | `--signal-axis`, 48% |
| Guía | `--signal-guide`, ámbar al 30%, 0.8 px |
| Lectura neutral | `--signal-reading`, blanco cálido al 82% |
| Lectura de vigilancia | `--signal-warning`, ámbar apagado |
| Línea de lectura | 1 px compacta, 1.25 px estándar, 1.5 px en periodos |
| Valor | 12 px compacto, 15 px estándar, 24 px en periodos |
| Fondo del intervalo | Tinte del tono al 2.5%, sin borde ni halo |

La señal tenue permite que la lectura principal domine. No añadir puntos a cada muestra ni sombras, perspectivas o blur al SVG. El vidrio pertenece a la superficie contenedora; desenfocar trazos o tipografía perjudicaría su lectura.

## Integridad de datos

- `latestReading` no presenta un valor antiguo como actual cuando la última muestra es inválida.
- Las muestras inválidas abren huecos. No se rellenan con cero.
- Cada periodo usa media aritmética de muestras válidas, no una media ponderada por tiempo. Para muestreo irregular que necesite otra estadística, calcularla fuera y pasar `readings` explícitas.
- Los intervalos son semiabiertos `[inicio, fin)`, salvo el último, que incluye su extremo final. No duplican muestras de la frontera compartida.
- Los periodos solapados o inválidos producen un error de contrato. Un periodo sin datos no tiene línea de resumen ni variación.
- La variación es `(actual - anterior) / abs(anterior) * 100`. No se calcula cuando el periodo anterior está vacío o vale cero. La variación de porcentajes es relativa, no puntos porcentuales.
- El tono debe venir de las reglas del producto. Una subida no es automáticamente una alerta.
- La comparación comparte escala; no combinar magnitudes o unidades distintas en una sola tira.
- Los valores fuera de un dominio explícito se omiten de la capa de lecturas. No se desplazan al borde fingiendo otro valor.

## Tamaño y accesibilidad

Contenedor con altura explícita: 132 px por defecto, 220 px para tira. Debajo de 80 px se mantiene la línea y se omiten etiquetas interiores; el nombre accesible conserva la lectura. Etiquetas de intervalo visibles a partir de 64 px de ancho por segmento, recortadas a su propio intervalo. Para etiquetas largas, aumentar el ancho o acortar el texto de presentación; el nombre accesible contiene el texto completo.

`role="img"` y resumen accesible incluyen las lecturas. Hay variante de contraste aumentado. Los trazos muy tenues de la referencia son contexto visual; no se afirma conformidad de contraste de cada línea al 16%. Para un uso que requiera leer cada muestra con alto contraste, activar el modo aumentado o ajustar los tokens.

## Integraciones y galería

- `MiniTrendChart`: especies, estratificación y series climáticas. Barras conservan su línea base cero y su semántica original.
- Tarjetas principales de FAN e índices climáticos: `summary="none"`, conservan KPI, umbrales y ventanas existentes.
- El pronóstico científico con observaciones y banda de incertidumbre conserva su implementación existente.
- La composición de periodos está disponible para adopción, sin inventar periodos operativos para sensores que no los exponen.

Galería local: `http://localhost:3002/src/dev/charts.html` con el servidor de Vite activo. Incluye lectura individual, tira de dos/tres periodos, series de referencia del proyecto y estados de datos. La fixture sintética está marcada como demostración y no entra en el dashboard. Entrada de desarrollo, no ruta de producción.

Stories incluidas para la convención de catálogo del repositorio; no se añadió una instalación de Storybook.

## Verificación

`npm run test:signals` comprueba periodos, extremos, vacíos, valores negativos y última muestra ausente. `npm run test:instruments` comprueba el motor existente. `npm run lint` y `npm run build` verifican integración.
