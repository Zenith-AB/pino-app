import type { TrendAnalysis, TrendSample, TrendSegment } from '../../../lib/trends/trendTypes.ts';
import { normalizeX } from '../OperationalTrendline/OperationalTrendline.utils.ts';
import type { TrendStructureSegment } from '../OperationalTrendline/OperationalTrendline.types.ts';

/** Registros arbitrarios → muestras numéricas. Valores ausentes quedan como NaN (hueco, nunca cero). */
export function toSamples<T extends object>(data: ReadonlyArray<T>, xKey: string, yKey: string): TrendSample[] {
  const out: TrendSample[] = [];
  for (const record of data) {
    const rawX = (record as Record<string, unknown>)[xKey];
    const rawY = (record as Record<string, unknown>)[yKey];
    const x = typeof rawX === 'number' || typeof rawX === 'string' ? normalizeX(rawX) : NaN;
    const y = typeof rawY === 'number' ? rawY : rawY == null ? NaN : Number(rawY);
    if (Number.isFinite(x)) out.push({ x, y: Number.isFinite(y) ? y : NaN });
  }
  return out.sort((a, b) => a.x - b.x);
}

/** Regímenes → tramos dibujables. Sólo un régimen direccional activo lleva acento. */
export function toStructure(analysis: TrendAnalysis, emphasis: 'active' | 'none'): TrendStructureSegment[] {
  const last = analysis.segments.length - 1;
  const structure = analysis.segments.map((segment, index) => ({
    id: `${segment.startIndex}-${segment.endIndex}`,
    x0: segment.startTime,
    y0: segment.startValue,
    x1: segment.endTime,
    y1: segment.endValue,
    kind: segment.type,
    emphasis: emphasis === 'active' && index === last && segment.type !== 'stable',
  }));
  // Sólo dibujo: una rampa que nace o muere en una meseta arranca en su nivel. La
  // recta ajustada suele quedar unos décimos por debajo o por encima y dibujaba una
  // muesca en la esquina; si la diferencia es material, el salto se conserva.
  const snap = 0.1 * analysis.scale;
  for (let index = 0; index < structure.length - 1; index++) {
    const a = structure[index];
    const b = structure[index + 1];
    if (a.kind === 'stable' && b.kind !== 'stable' && Math.abs(b.y0 - a.y1) < snap) b.y0 = a.y1;
    if (a.kind !== 'stable' && b.kind === 'stable' && Math.abs(a.y1 - b.y0) < snap) a.y1 = b.y0;
  }
  return structure;
}

export function segmentAt(analysis: TrendAnalysis, x: number): TrendSegment | null {
  const { segments } = analysis;
  if (!segments.length) return null;
  for (let index = 0; index < segments.length; index++) {
    const next = segments[index + 1];
    // El hueco entre el último punto de un régimen y el primero del siguiente pertenece al que empieza.
    if (x >= segments[index].startTime && (!next || x < next.startTime)) return segments[index];
  }
  return x < segments[0].startTime ? segments[0] : null;
}

const decimal = (value: number, digits = 1) => new Intl.NumberFormat('es-CL', { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(value);

export function formatDuration(ms: number | undefined) {
  if (ms === undefined || !Number.isFinite(ms)) return undefined;
  const hours = ms / 3_600_000;
  if (hours < 48) return `${Math.max(1, Math.round(hours))} h`;
  const days = hours / 24;
  return `${days < 10 ? decimal(days, days % 1 < 0.05 ? 0 : 1) : Math.round(days)} días`;
}

const CONFIDENCE = { high: 'Confianza alta', medium: 'Confianza media', low: 'Confianza baja' } as const;

/** Líneas del tooltip para un régimen: tipo, cambio, duración y confianza. */
export function segmentSummary(segment: TrendSegment, unit: string | undefined, formatter: (value: number) => string) {
  const sign = segment.delta > 0 ? '+' : segment.delta < 0 ? '−' : '±';
  // Un cambio de una magnitud ya porcentual se expresa en puntos, no en % de %.
  const change = unit === '%'
    ? `${sign}${decimal(Math.abs(segment.delta))} pp`
    : segment.deltaPercent !== undefined && segment.type !== 'stable'
      ? `${sign}${decimal(Math.abs(segment.deltaPercent))} %`
      : `${sign}${formatter(Math.abs(segment.delta))}${unit ? ` ${unit}` : ''}`;
  return {
    label: segment.type === 'stable'
      ? 'Estable'
      : `Tendencia ${segment.type === 'ascending' ? 'ascendente' : 'descendente'}${segment.strength === 'slight' ? ' leve' : segment.strength === 'strong' ? ' marcada' : ''}`,
    change: segment.type === 'stable' ? undefined : change,
    duration: formatDuration(segment.durationMs),
    confidence: CONFIDENCE[segment.confidenceLevel],
  };
}
