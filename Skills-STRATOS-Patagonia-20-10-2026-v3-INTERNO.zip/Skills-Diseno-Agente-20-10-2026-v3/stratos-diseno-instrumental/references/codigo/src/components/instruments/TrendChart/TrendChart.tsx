import { useEffect, useMemo } from 'react';
import { useTrendAnalysis } from '../../../hooks/useTrendAnalysis';
import { downsampleLTTB } from '../../../lib/trends/downsample';
import { trendLabel } from '../../../lib/trends/trendAnalysis';
import { formatBlockDelta, toDecimalPoint } from '../../../lib/trends/trendBlocks';
import { OperationalTrendline } from '../OperationalTrendline/OperationalTrendline';
import type { TrendHover } from '../OperationalTrendline/OperationalTrendline.types';
import type { TrendChartProps } from './TrendChart.types';
import { segmentAt, segmentSummary, toSamples, toStructure } from './TrendChart.utils';
import styles from './TrendChart.module.css';

const DEFAULT_FORMAT = (value: number) => new Intl.NumberFormat('es-CL', { maximumFractionDigits: 2 }).format(value);
const IS_DEV = (() => {
  try {
    return Boolean((import.meta as unknown as { env?: { DEV?: boolean } }).env?.DEV);
  } catch {
    return false;
  }
})();

/**
 * Serie temporal con interpretación: la señal medida queda como contexto de bajo
 * contraste y encima se dibuja su estructura —estable, ascenso, descenso— calculada
 * por `useTrendAnalysis`. Adquisición, análisis y dibujo están separados: este
 * componente sólo traduce el análisis a capas del motor `OperationalTrendline`.
 */
export function TrendChart<T extends object = { x: number | string; y: number }>({
  data,
  xKey = 'x' as keyof T & string,
  yKey = 'y' as keyof T & string,
  analysisData,
  unit,
  mode = 'auto',
  presentation = 'blocks',
  xUnitMs,
  maxBlocks,
  deltaScale = 'auto',
  analysisOptions,
  showTrend = true,
  showTooltip = true,
  showAxes = true,
  formatter = DEFAULT_FORMAT,
  formatTime,
  emphasis = 'active',
  maxRenderPoints = 800,
  onTrendChange,
  onHoverChange,
  debugTrend = false,
  className = '',
  ariaLabel,
  xTicks,
  yTicks,
  formatX,
  formatY,
  ...engineProps
}: TrendChartProps<T>) {
  const renderSamples = useMemo(() => toSamples(data, xKey, yKey), [data, xKey, yKey]);
  const analysisSamples = useMemo(
    () => (analysisData ? toSamples(analysisData, xKey, yKey) : renderSamples),
    [analysisData, renderSamples, xKey, yKey],
  );
  const useBlocks = presentation === 'blocks';
  const debug = debugTrend && IS_DEV;
  // Por bloques la interpretación no se dibuja (sólo va al nombre accesible): salvo que
  // alguien la escuche o se depure, se calcula en tiempo ocioso y no bloquea el pintado.
  const analysis = useTrendAnalysis(
    analysisSamples,
    { ...analysisOptions, mode, xUnitMs },
    useBlocks && !onTrendChange && !onHoverChange && !debug ? 'idle' : 'sync',
  );
  // Se reduce lo que se dibuja, nunca lo que se analiza.
  const drawn = useMemo(() => downsampleLTTB(renderSamples, maxRenderPoints), [renderSamples, maxRenderPoints]);
  const resolvedDeltaScale = useMemo<'relative' | 'absolute'>(() => {
    if (deltaScale !== 'auto') return deltaScale;
    const finite = analysisSamples.map((sample) => sample.y).filter(Number.isFinite);
    return finite.length > 0 && finite.every((value) => value > 0) ? 'relative' : 'absolute';
  }, [deltaScale, analysisSamples]);
  const structure = useMemo(
    () => (showTrend && !useBlocks ? toStructure(analysis, emphasis) : []),
    [analysis, emphasis, showTrend, useBlocks],
  );
  const blocks = useMemo(
    () =>
      useBlocks
        ? {
            // Los bloques resumen la serie interpretada (p. ej. observado hasta hoy + modelo).
            samples: analysisSamples,
            xUnitMs,
            minBlockPx: engineProps.density === 'compact' ? 48 : 110,
            maxBlocks,
            // El naranjo no es decoración del último tramo: sólo marca un cambio anómalo (o el puntero).
            defaultActive: emphasis === 'none' ? ('none' as const) : ('anomaly' as const),
            valueLabel: (level: number) => `${toDecimalPoint(formatter(level))}${unit === '%' ? '%' : ''}`,
            deltaLabel: (block: Parameters<typeof formatBlockDelta>[0]) => formatBlockDelta(block, unit, formatter, resolvedDeltaScale),
          }
        : undefined,
    [useBlocks, analysisSamples, xUnitMs, maxBlocks, engineProps.density, emphasis, formatter, unit, resolvedDeltaScale],
  );

  useEffect(() => {
    onTrendChange?.(analysis);
  }, [analysis, onTrendChange]);

  useEffect(() => {
    if (!debug) return;
    console.groupCollapsed(`[STRATOS:trend] ${ariaLabel ?? 'serie'} · ${analysis.mode} · ${analysis.segments.length} régimen(es)`);
    console.table(
      analysis.segments.map((segment) => ({
        tipo: trendLabel(segment),
        desde: segment.startTime,
        hasta: segment.endTime,
        puntos: segment.points,
        pendiente: segment.slope,
        'pendiente norm.': segment.normalizedSlope,
        inicio: segment.startValue,
        fin: segment.endValue,
        nivel: segment.representativeValue,
        confianza: segment.confidence,
      })),
    );
    console.log({ escala: analysis.scale, ruido: analysis.noise, cambios: analysis.changePoints });
    console.groupEnd();
  }, [analysis, ariaLabel, debug]);

  const active = analysis.activeSegment;
  const trendSummary =
    showTrend && active
      ? `Tendencia: ${trendLabel(active)}${analysis.segments.length > 1 ? `, ${analysis.segments.length} regímenes` : ''}`
      : undefined;
  const timeLabel = formatTime ?? ((value: number) => (formatX ? formatX(value) : String(value)));

  /*
   * Por bloques, sin dominio explícito la escala se ciñe a lo medido: apenas un
   * margen para que el trazo no toque el borde. El aire de los rótulos lo resuelve
   * la franja del motor, así que aquí un margen generoso sólo aplanaría la señal
   * —y una serie de base alta (oxígeno, salinidad) quedaría como una recta.
   */
  const thresholdValues = (engineProps.thresholds ?? []).map((threshold) => threshold.value).join(',');
  const blockDomain = useMemo<[number, number] | undefined>(() => {
    if (!useBlocks) return undefined;
    const values = analysisSamples.map((sample) => sample.y).filter(Number.isFinite);
    if (!values.length) return undefined;
    // Un umbral fuera de lo medido también cuenta: si no, desaparece sin aviso.
    const reference = [...values, ...thresholdValues.split(',').filter(Boolean).map(Number)];
    const min = Math.min(...reference);
    const max = Math.max(...reference);
    const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
    const pad = Math.max((max - min) * 0.05, Math.abs(mean) * 0.004, 1e-6);
    return [min - pad, max + pad];
  }, [useBlocks, analysisSamples, thresholdValues]);

  // Por bloques la lectura ya está en el gráfico: el puntero sólo elige el bloque.
  const renderHover = showTooltip && !useBlocks
    ? (hover: TrendHover) => {
        const segment = showTrend ? segmentAt(analysis, hover.x) : null;
        const summary = segment ? segmentSummary(segment, unit, formatter) : null;
        const meta = summary ? [summary.change, summary.duration].filter(Boolean).join(' · ') : '';
        return (
          <>
            {hover.point && (
              <>
                <span className={styles.tipTime}>{timeLabel(hover.point.x)}</span>
                <span className={styles.tipValue}>
                  {formatter(hover.point.y)}
                  {unit && <span className={styles.tipUnit}>{unit === '%' ? '%' : ` ${unit}`}</span>}
                </span>
              </>
            )}
            {summary && segment && (
              <span
                className={styles.tipTrend}
                // El acento del texto sigue al del trazo: sólo el régimen activo direccional.
                data-emphasis={emphasis === 'active' && segment === analysis.activeSegment && segment.type !== 'stable'}
              >
                <span>{summary.label}</span>
                {meta && <span className={styles.tipMeta}>{meta}</span>}
                <span className={styles.tipMeta}>{summary.confidence}</span>
              </span>
            )}
          </>
        );
      }
    : undefined;

  return (
    <OperationalTrendline
      {...engineProps}
      yDomain={engineProps.yDomain ?? blockDomain}
      data={drawn}
      blocks={blocks}
      structure={structure}
      renderHover={renderHover}
      onHoverChange={onHoverChange ? (hover) => onHoverChange(hover && { ...hover, segment: segmentAt(analysis, hover.x) }) : undefined}
      debugMarks={
        debug
          ? {
              changeXs: analysis.changePoints.map((index) => analysis.samples[index].x),
              smoothed: analysis.samples.map((sample, index) => ({ x: sample.x, y: analysis.smoothed[index] })),
            }
          : undefined
      }
      xTicks={showAxes ? xTicks : []}
      yTicks={showAxes ? yTicks : []}
      formatX={formatX}
      formatY={formatY ?? formatter}
      ariaLabel={[ariaLabel, trendSummary].filter(Boolean).join('. ') || undefined}
      className={`${styles.trendChart} ${className}`}
    />
  );
}
