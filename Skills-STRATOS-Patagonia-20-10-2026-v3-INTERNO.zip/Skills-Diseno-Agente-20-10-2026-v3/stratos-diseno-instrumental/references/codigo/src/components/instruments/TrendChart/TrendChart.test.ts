import assert from 'node:assert/strict';
import test from 'node:test';
import { analyzeTrend } from '../../../lib/trends/trendAnalysis.ts';
import { formatDuration, segmentAt, segmentSummary, toSamples, toStructure } from './TrendChart.utils.ts';

test('TrendChart: registros con claves propias, ISO, ausentes y desorden', () => {
  const samples = toSamples(
    [
      { t: '2026-09-16T02:00:00Z', v: 3 },
      { t: '2026-09-16T00:00:00Z', v: 1 },
      { t: '2026-09-16T01:00:00Z', v: null },
      { t: 'no es fecha', v: 9 },
    ],
    't',
    'v',
  );
  assert.equal(samples.length, 3);
  assert.ok(samples[0].x < samples[1].x);
  assert.ok(Number.isNaN(samples[1].y), 'ausente es hueco, nunca cero');
});

test('TrendChart: la estructura sigue a los regímenes y sólo el activo direccional lleva acento', () => {
  const values = [...Array(25).fill(40), ...Array.from({ length: 25 }, (_, i) => 40 + i * 2)];
  const analysis = analyzeTrend(values.map((y, x) => ({ x, y })), { mode: 'segmented' });
  const structure = toStructure(analysis, 'active');
  assert.deepEqual(structure.map((s) => s.kind), ['stable', 'ascending']);
  assert.deepEqual(structure.map((s) => Boolean(s.emphasis)), [false, true]);
  assert.equal(structure[0].y0, structure[0].y1, 'un régimen estable es horizontal');
  assert.ok(toStructure(analysis, 'none').every((s) => !s.emphasis));

  const stableOnly = analyzeTrend(Array.from({ length: 20 }, (_, x) => ({ x, y: 5 })));
  assert.ok(toStructure(stableOnly, 'active').every((s) => !s.emphasis), 'estable nunca es acento');
});

test('TrendChart: régimen bajo el cursor, también entre muestras', () => {
  const values = [...Array(25).fill(40), ...Array.from({ length: 25 }, (_, i) => 40 + i * 2)];
  const analysis = analyzeTrend(values.map((y, x) => ({ x, y })), { mode: 'segmented' });
  const boundary = analysis.segments[1].startTime;
  assert.equal(segmentAt(analysis, 2)?.type, 'stable');
  assert.equal(segmentAt(analysis, boundary - 0.5)?.type, 'stable');
  assert.equal(segmentAt(analysis, boundary)?.type, 'ascending');
  assert.equal(segmentAt(analyzeTrend([]), 3), null);
});

test('TrendChart: resumen del tooltip en pp para porcentajes y duración legible', () => {
  const analysis = analyzeTrend(Array.from({ length: 13 }, (_, i) => ({ x: i * 0.5, y: 60 + i * 2 })), { xUnitMs: 86_400_000, mode: 'short' });
  const summary = segmentSummary(analysis.activeSegment!, '%', String);
  assert.equal(summary.change, '+24,0 pp');
  assert.equal(summary.duration, '6 días');
  assert.equal(summary.label, 'Tendencia ascendente marcada');
  assert.equal(formatDuration(3 * 3_600_000), '3 h');
  assert.equal(formatDuration(undefined), undefined);
});

test('TrendChart: la rampa nace en el nivel de la meseta vecina (sin muesca)', () => {
  const values = [...Array(30).fill(40), ...Array.from({ length: 30 }, (_, i) => 40 + (i + 1) * 1.5 + (i % 2 ? 0.4 : -0.4))];
  const analysis = analyzeTrend(values.map((y, x) => ({ x, y })), { mode: 'segmented' });
  const [plateau, ramp] = toStructure(analysis, 'active');
  assert.equal(ramp.y0, plateau.y1);
});
