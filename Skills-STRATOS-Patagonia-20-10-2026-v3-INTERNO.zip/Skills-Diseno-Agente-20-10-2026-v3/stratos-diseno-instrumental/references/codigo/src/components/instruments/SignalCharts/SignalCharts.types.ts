﻿import type { OperationalTrendlineProps, TrendPoint, TrendReading, TrendTone } from '../OperationalTrendline/OperationalTrendline.types';

export interface SignalTrendChartProps extends OperationalTrendlineProps {
  interactive?: boolean;
  periodCount?: number;
  /** Last sample is a reading, not an average or a target. */
  summary?: 'latest' | 'none';
  summaryLabel?: string;
  tone?: TrendTone;
}
export interface SignalPeriod {
  id: string;
  start: number | string;
  end: number | string;
  label: string;
  tone?: TrendTone;
}
export interface SignalTrendStripProps extends Omit<SignalTrendChartProps, 'readings' | 'summary' | 'summaryLabel'> {
  /** Disjoint temporal intervals, in chronological order. Final endpoint is inclusive. */
  periods: SignalPeriod[];
  /** Arithmetic sample mean, not a time-weighted mean. */
  showChange?: boolean;
}
export type { TrendPoint, TrendReading, TrendTone };
