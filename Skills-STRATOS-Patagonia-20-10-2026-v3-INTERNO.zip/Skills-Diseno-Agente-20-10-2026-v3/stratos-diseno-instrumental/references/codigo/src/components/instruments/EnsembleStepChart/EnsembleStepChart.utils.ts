/*
 * Geometría del gráfico por capas del pico D14, en el lenguaje de la
 * lectura por ventanas: el ancho se reparte en una ventana por día y cada capa
 * se dibuja dentro de su ventana.
 *
 *   1. Onda: los miembros del ensemble de cada día, uno tras otro a lo ancho de
 *      su ventana y unidos en zigzag. Cada vértice es un miembro real; su
 *      posición dentro de la ventana es su número de miembro, no una hora.
 *   2. Figura: una meseta por ventana en el miembro más alto (sin miembros, el
 *      P90), unidas por rampas que corren siempre dentro de la ventana más baja:
 *      la envolvente nunca queda bajo una punta de la onda. Se construye de
 *      izquierda a derecha al entrar.
 *   3. Tramos: la mediana de cada ventana, de borde a borde, con el valor arriba
 *      y el cambio frente a la ventana anterior abajo.
 *
 * Con `windows`, varios días comparten ventana: el horizonte se agrupa en bloques
 * contiguos, el tramo toma la mayor mediana diaria del bloque (así el pico del
 * horizonte sigue a la vista) y la onda pone los miembros de sus días uno tras
 * otro.
 *
 * La posición vertical siempre es el valor: el dominio no se remapea para que
 * quepan los rótulos, así que la escala puede afirmarse. Se ciñe a los datos con
 * un tramo mínimo, para que la onda se lea y dos puntos no parezcan un episodio.
 */

export interface SeriesPoint {
  x: number;
  y: number | null;
}

export interface EnsembleStepInput {
  /** Mediana por día (x en días, 0 = hoy). */
  median: SeriesPoint[];
  members?: Array<{ id: string; points: SeriesPoint[] }>;
  /** P10–P90 por día. `hi` sostiene la figura; sin miembros, la banda es el fondo. */
  band?: Array<{ x: number; lo: number; hi: number }>;
  /** Dominio fijo del eje. Sin él, se ciñe a los datos (ver `niceDomain`). */
  yDomain?: [number, number];
  /** Límites que el dominio ajustado nunca cruza (p. ej. 0–100 de un índice). */
  yClamp?: [number, number];
  /** Tramo mínimo del dominio ajustado, en unidades del valor. */
  minSpan?: number;
  yTicks?: number[];
  /** Número de ventanas: agrupa los días en bloques contiguos. Sin él, una por día. */
  windows?: number;
}

export interface EnsembleStep {
  /** Primer día de la ventana. */
  x: number;
  /** Días que agrupa la ventana, en orden. */
  days: number[];
  x1: number;
  x2: number;
  y: number;
  value: number;
  /** Cambio relativo frente al día anterior, en %; null el primer día o desde 0. */
  change: number | null;
  /** Subida marcada de la favorabilidad: el único tramo que toma el acento. */
  rising: boolean;
}

export interface EnsembleStepGeometry {
  wave: string;
  band: string;
  figure: string;
  steps: EnsembleStep[];
  scale: Array<{ value: number; y: number }>;
}

export const ENSEMBLE_VIEWBOX = { width: 600, height: 150 } as const;
// El eje derecho conserva su canal propio; la serie aprovecha el resto del ancho.
const PLOT_LEFT = 10;
const PLOT_RIGHT = 566;
const PLOT_TOP = 26;
const PLOT_BOTTOM = 126;
/** Separación entre tramos contiguos, apenas para que no se fundan. */
const STEP_GAP = 2;
/** Fracción de la ventana que ocupa cada rampa de la figura. */
const RAMP = 0.16;
/* Holgura de la figura sobre la punta más alta, para que el trazo no la roce. */
const PEAK_CLEARANCE = 1.5;
/*
 * En esta tarjeta el ámbar es atención, no «bajó»: una caída de la favorabilidad
 * es la buena noticia. Lo que merece el acento es una subida marcada, medida en
 * puntos para que un índice bajo (24→27, «+13 %») no tiña medio gráfico.
 */
export const RISE_ACCENT_POINTS = 10;

const finite = (value: number | null | undefined): value is number => typeof value === 'number' && Number.isFinite(value);
const fixed = (value: number) => value.toFixed(2);

export function relativeChange(previous: number | undefined, current: number): number | null {
  if (!finite(previous) || previous === 0) return null;
  return Math.round(((current - previous) / Math.abs(previous)) * 100);
}

export function formatStepChange(change: number | null): string {
  if (change === null) return '—';
  if (change === 0) return '0%';
  return `${change > 0 ? '+' : '−'}${Math.abs(change)}%`;
}

/** Dominio en múltiplos de 10 alrededor de los datos, con tramo mínimo y límites. */
export function niceDomain(lo: number, hi: number, minSpan = 0, clamp?: [number, number]): [number, number] {
  let min = Math.floor(lo / 10) * 10;
  let max = Math.ceil(hi / 10) * 10;
  if (max - min < minSpan) {
    const grow = minSpan - (max - min);
    min -= Math.ceil(grow / 20) * 10;
    max += Math.ceil(grow / 20) * 10;
  }
  if (clamp) {
    if (min < clamp[0]) { max = Math.min(clamp[1], max + (clamp[0] - min)); min = clamp[0]; }
    if (max > clamp[1]) { min = Math.max(clamp[0], min - (max - clamp[1])); max = clamp[1]; }
  }
  return max > min ? [min, max] : [min, min + 10];
}

/** Reparte `days` en `windows` bloques contiguos de tamaño casi igual. */
export function splitWindows<T>(days: T[], windows?: number): T[][] {
  const count = Math.min(days.length, Math.max(1, Math.round(windows ?? days.length)));
  return Array.from({ length: count }, (_, index) =>
    days.slice(Math.round((index * days.length) / count), Math.round(((index + 1) * days.length) / count)));
}

export function buildEnsembleStepGeometry(input: EnsembleStepInput): EnsembleStepGeometry | null {
  const median = input.median.filter((point): point is { x: number; y: number } => finite(point.y));
  if (!median.length) return null;

  const members = input.members ?? [];
  const band = input.band ?? [];
  const groups = splitWindows(median, input.windows);
  const width = (PLOT_RIGHT - PLOT_LEFT) / groups.length;
  const windowOf = (index: number) => [PLOT_LEFT + index * width, PLOT_LEFT + (index + 1) * width] as const;

  const memberValues = (day: number) =>
    members
      .map((member) => member.points.find((point) => point.x === day)?.y)
      .filter(finite);
  const bandOf = (day: number) => band.find((point) => point.x === day && finite(point.lo) && finite(point.hi));
  const windowMembers = groups.map((group) => group.flatMap((point) => memberValues(point.x)));

  const [yMin, yMax] = (() => {
    if (input.yDomain) return input.yDomain;
    const values = [
      ...median.map((point) => point.y),
      ...windowMembers.flat(),
      ...band.flatMap((point) => [point.lo, point.hi]).filter(finite),
    ];
    return niceDomain(Math.min(...values), Math.max(...values), input.minSpan, input.yClamp);
  })();
  const yOf = (y: number) => PLOT_BOTTOM - ((y - yMin) / (yMax - yMin || 1)) * (PLOT_BOTTOM - PLOT_TOP);

  // Capa 1 · onda: los miembros de cada ventana, día tras día, unidos en zigzag.
  const wavePoints: string[] = [];
  windowMembers.forEach((values, index) => {
    const [x0] = windowOf(index);
    const pitch = width / Math.max(values.length, 1);
    values.forEach((value, k) => wavePoints.push(`${fixed(x0 + (k + 0.5) * pitch)} ${fixed(yOf(value))}`));
  });
  const wave = wavePoints.length > 1 ? `M${wavePoints.join(' L')}` : '';

  const bandWindows = groups.map((group, index) => {
    const points = group.map((point) => bandOf(point.x)).filter((point) => point !== undefined);
    return points.length
      ? { index, lo: Math.min(...points.map((point) => point.lo)), hi: Math.max(...points.map((point) => point.hi)) }
      : null;
  }).filter((entry) => entry !== null);
  const bandPath = !wave && bandWindows.length
    ? `M${bandWindows.flatMap(({ index, hi }) => windowOf(index).map((x) => `${fixed(x)} ${fixed(yOf(hi))}`)).join(' L')} L${[...bandWindows]
        .reverse()
        .flatMap(({ index, lo }) => [...windowOf(index)].reverse().map((x) => `${fixed(x)} ${fixed(yOf(lo))}`))
        .join(' L')} Z`
    : '';

  // Capa 2 · figura: meseta en lo más alto de cada ventana; la rampa va en la más baja.
  const levels = groups.map((group, index) => {
    const tops = [
      ...windowMembers[index],
      ...(windowMembers[index].length ? [] : group.map((point) => bandOf(point.x)?.hi).filter(finite)),
      ...group.map((point) => point.y),
    ];
    return yOf(Math.max(...tops)) - PEAK_CLEARANCE;
  });
  const ramp = width * RAMP;
  const figurePoints: Array<[number, number]> = [[windowOf(0)[0], levels[0]]];
  levels.forEach((y, index) => {
    const next = levels[index + 1];
    if (next === undefined || next === y) return;
    const edge = windowOf(index)[1];
    // y menor es más alto: si la siguiente sube, la rampa ocurre antes del borde.
    if (next < y) figurePoints.push([edge - ramp, y], [edge, next]);
    else figurePoints.push([edge, y], [edge + ramp, next]);
  });
  figurePoints.push([windowOf(groups.length - 1)[1], levels.at(-1) as number]);
  const figure = `M${figurePoints.map(([x, y]) => `${fixed(x)} ${fixed(y)}`).join(' L')}`;

  const steps = groups.map((group, index): EnsembleStep => {
    const value = Math.max(...group.map((point) => point.y));
    const previous = index ? Math.max(...groups[index - 1].map((point) => point.y)) : undefined;
    const [x0, x1] = windowOf(index);
    return {
      x: group[0].x,
      days: group.map((point) => point.x),
      x1: x0 + (index === 0 ? 0 : STEP_GAP / 2),
      x2: x1 - STEP_GAP / 2,
      y: yOf(value),
      value,
      change: relativeChange(previous, value),
      rising: finite(previous) && value - previous >= RISE_ACCENT_POINTS,
    };
  });

  const ticks = input.yTicks ?? [yMax, (yMin + yMax) / 2, yMin];
  return {
    wave,
    band: bandPath,
    figure,
    steps,
    scale: ticks.filter((value) => value >= yMin && value <= yMax).map((value) => ({ value, y: yOf(value) })),
  };
}
