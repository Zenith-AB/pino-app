import assert from 'node:assert/strict';
import test from 'node:test';
import {
  buildEnsembleStepGeometry,
  ENSEMBLE_VIEWBOX,
  formatStepChange,
  niceDomain,
  relativeChange,
  splitWindows,
} from './EnsembleStepChart.utils.ts';

const median = [35, 40, 36, 36, 30, 45, 55].map((y, x) => ({ x, y }));

test('EnsembleStepChart: tramos contiguos, uno por día, con su cambio', () => {
  const geometry = buildEnsembleStepGeometry({ median, yDomain: [0, 100] });
  assert.ok(geometry);
  assert.equal(geometry.steps.length, 7);
  assert.deepEqual(geometry.steps.map((step) => step.change), [null, 14, -10, 0, -17, 50, 22]);
  // Cada tramo empieza casi donde termina el anterior: lectura por ventanas.
  for (let i = 1; i < geometry.steps.length; i += 1) {
    assert.ok(geometry.steps[i].x1 - geometry.steps[i - 1].x2 <= 2.01);
  }
  // La altura es el valor: 55 queda más arriba que 30.
  assert.ok(geometry.steps[6].y < geometry.steps[4].y);
});

test('EnsembleStepChart: serie y marcas del rango quedan dentro del gráfico', () => {
  const geometry = buildEnsembleStepGeometry({ median, yDomain: [0, 100] });
  assert.ok(geometry);
  assert.ok(geometry.steps[0].x1 > 0);
  assert.ok(geometry.steps.at(-1)!.x2 < ENSEMBLE_VIEWBOX.width - 30);
  assert.ok(geometry.scale.every((mark) => mark.y > 0 && mark.y < ENSEMBLE_VIEWBOX.height));
});

test('EnsembleStepChart: el acento es atención, sólo subidas de 10 puntos o más', () => {
  const geometry = buildEnsembleStepGeometry({ median });
  assert.deepEqual(geometry?.steps.map((step) => step.rising), [false, false, false, false, false, true, true]);
});

test('EnsembleStepChart: la onda tiene un vértice por miembro y día', () => {
  const members = ['a', 'b', 'c'].map((id, k) => ({
    id,
    points: median.map((point) => ({ x: point.x, y: (point.y as number) + k - 1 })),
  }));
  const geometry = buildEnsembleStepGeometry({ median, members });
  assert.equal(geometry?.wave.match(/[ML]/g)?.length, 3 * 7);
  assert.equal(geometry?.band, '', 'con miembros no se dibuja además la banda');
});

test('EnsembleStepChart: un miembro sin dato ese día no inventa un vértice', () => {
  const members = [
    { id: 'a', points: median.map((point) => ({ x: point.x, y: point.y })) },
    { id: 'b', points: median.map((point) => ({ x: point.x, y: point.x === 3 ? null : point.y })) },
  ];
  const geometry = buildEnsembleStepGeometry({ median, members });
  assert.equal(geometry?.wave.match(/[ML]/g)?.length, 2 * 7 - 1);
});

test('EnsembleStepChart: sin miembros el fondo es la banda y la figura sigue el P90', () => {
  const band = median.map((point) => ({ x: point.x, lo: (point.y as number) - 5, hi: (point.y as number) + 5 }));
  const geometry = buildEnsembleStepGeometry({ median, band, yDomain: [0, 100] });
  assert.ok(geometry?.band.startsWith('M'));
  assert.equal(geometry?.wave, '');
  // La figura queda por encima de la mediana (y menor en pantalla).
  const firstFigureY = Number(geometry?.figure.split(' ')[1]);
  assert.ok(firstFigureY < (geometry?.steps[0].y ?? 0));
});

test('EnsembleStepChart: 14 días caben en 6 bloques contiguos sin perder el pico', () => {
  assert.deepEqual(splitWindows([...Array(14).keys()], 6).map((group) => group.length), [2, 3, 2, 2, 3, 2]);
  const fortnight = [37, 30, 32, 48, 47, 53, 55, 52, 58, 57, 60, 59, 58, 60].map((y, x) => ({ x: x + 1, y }));
  const geometry = buildEnsembleStepGeometry({ median: fortnight, windows: 6 });
  assert.equal(geometry?.steps.length, 6);
  assert.deepEqual(geometry?.steps.map((step) => step.days.length), [2, 3, 2, 2, 3, 2]);
  assert.equal(Math.max(...(geometry?.steps.map((step) => step.value) ?? [])), 60);
});

test('EnsembleStepChart: la figura nunca queda bajo una punta de la onda', () => {
  const fortnight = [37, 30, 32, 48, 47, 53, 55, 52, 58, 57, 60, 59, 58, 60].map((y, x) => ({ x: x + 1, y }));
  // Miembros dispersos: la punta más alta de cada día supera holgadamente al P90.
  const members = Array.from({ length: 31 }, (_, k) => ({
    id: String(k),
    points: fortnight.map((point) => ({ x: point.x, y: point.y + ((k * 37) % 23) - 11 })),
  }));
  for (const windows of [undefined, 6]) {
    const geometry = buildEnsembleStepGeometry({ median: fortnight, members, windows });
    assert.ok(geometry);
    const parse = (path: string) => path.slice(1).split(' L').map((pair) => pair.split(' ').map(Number) as [number, number]);
    const figure = parse(geometry.figure);
    const figureAt = (x: number) => {
      const i = figure.findIndex(([fx], k) => k > 0 && fx >= x);
      const [[xa, ya], [xb, yb]] = [figure[Math.max(0, i - 1)], figure[i]];
      return xb === xa ? Math.max(ya, yb) : ya + ((x - xa) / (xb - xa)) * (yb - ya);
    };
    // y crece hacia abajo: la figura debe tener y menor o igual en cada vértice de la onda.
    for (const [x, y] of parse(geometry.wave)) assert.ok(figureAt(x) <= y + 1e-6, `figura bajo la onda en x=${x}`);
  }
});

test('EnsembleStepChart: sin mediana no hay gráfico', () => {
  assert.equal(buildEnsembleStepGeometry({ median: [{ x: 0, y: null }] }), null);
});

test('EnsembleStepChart: rótulos de cambio', () => {
  assert.equal(relativeChange(undefined, 4), null);
  assert.equal(relativeChange(0, 4), null);
  assert.equal(formatStepChange(null), '—');
  assert.equal(formatStepChange(0), '0%');
  assert.equal(formatStepChange(12), '+12%');
  assert.equal(formatStepChange(-8), '−8%');
});

test('EnsembleStepChart: el eje se ciñe a los datos sin exagerar ni salir de 0–100', () => {
  assert.deepEqual(niceDomain(24, 61, 20, [0, 100]), [20, 70]);
  assert.deepEqual(niceDomain(41, 43, 20, [0, 100]), [30, 60]);
  assert.deepEqual(niceDomain(2, 8, 20, [0, 100]), [0, 30]);
  assert.deepEqual(niceDomain(92, 99, 20, [0, 100]), [70, 100]);
});
