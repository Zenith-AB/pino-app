﻿import type { TrendPoint, TrendReading } from '../OperationalTrendline/OperationalTrendline.types.ts';
import { normalizeX, prepareData } from '../OperationalTrendline/OperationalTrendline.utils.ts';
import type { SignalPeriod } from './SignalCharts.types.ts';

/** Missing samples are never zero; missing latest data must not display an old current value. */
export function latestReading(data: TrendPoint[], label = 'Última muestra'): TrendReading[] {
  const points = prepareData(data);
  const last = points.at(-1);
  if (!last || !Number.isFinite(last.y)) return [];
  return [{ id: 'latest', start: points[0].x === last.x ? last.x - 0.5 : points[0].x, end: points[0].x === last.x ? last.x + 0.5 : last.x, value: last.y, label }];
}

/** Periods must not overlap: double-counting would turn the strip into a false comparison. */
export function summarizePeriods(data: TrendPoint[], periods: SignalPeriod[], showChange = true): TrendReading[] {
  const points = prepareData(data);
  const ordered = periods.map(p => ({ ...p, start: normalizeX(p.start), end: normalizeX(p.end) })).sort((a, b) => a.start - b.start);
  const result: TrendReading[] = [];
  let previous: number | undefined;
  for (let index = 0; index < ordered.length; index++) {
    const period = ordered[index];
    if (!Number.isFinite(period.start) || !Number.isFinite(period.end) || period.start >= period.end) throw new RangeError('Cada periodo necesita inicio y fin válidos, en orden.');
    if (index && period.start < ordered[index - 1].end) throw new RangeError('Los periodos de una comparación no pueden solaparse.');
    const samples = points.filter(p => Number.isFinite(p.y) && p.x >= period.start && (p.x < period.end || (index === ordered.length - 1 && p.x === period.end)));
    if (!samples.length) { previous = undefined; continue; }
    const mean = samples.reduce((total, p) => total + p.y, 0) / samples.length;
    const change = previous !== undefined && previous !== 0 ? (mean - previous) / Math.abs(previous) * 100 : undefined;
    result.push({ ...period, value: mean, label: period.label, detail: showChange && change !== undefined ? `${change > 0 ? '+' : ''}${new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1 }).format(change)}% · vs. tramo anterior` : undefined });
    previous = mean;
  }
  return result;
}

/** Fixed temporal bins retain missing intervals; summaries are computed from actual samples. */
export function interactionReadings(data: TrendPoint[], count = 3): TrendReading[] {
  const points = prepareData(data);
  if (points.length < 2 || points[0].x === points.at(-1)!.x) return [];
  const bins = Math.max(1, Math.min(6, Math.floor(count) || 3));
  const start = points[0].x;
  const span = points.at(-1)!.x - start;
  const periods = Array.from({length: bins}, (_, index) => ({id:`segment-${index}`,start:start + span * index / bins,end:start + span * (index + 1) / bins,label:`Media del tramo ${index + 1}`}));
  return summarizePeriods(data, periods).map(reading => {
    const samples = points.filter(p => p.x >= Number(reading.start) && (p.x < Number(reading.end) || (Number(reading.end) === points.at(-1)!.x && p.x === Number(reading.end))) && Number.isFinite(p.y));
    return {...reading, low:Math.min(...samples.map(p=>p.y)), high:Math.max(...samples.map(p=>p.y)), label:reading.detail?.split(' · ')[0] ?? 'Base', detail:reading.label};
  });
}
