import type { TrendAnalysis, TrendAnalysisOptions, TrendSegment } from '../../../lib/trends/trendTypes';
import type { OperationalTrendlineProps, TrendHover } from '../OperationalTrendline/OperationalTrendline.types';

export interface TrendChartProps<T extends object = { x: number | string; y: number }>
  extends Omit<
    OperationalTrendlineProps,
    'data' | 'structure' | 'renderHover' | 'onHoverChange' | 'debugMarks' | 'readings' | 'interactiveReadings' | 'blocks'
  > {
  /** Serie base. Cada registro aporta un instante y un valor. */
  data: ReadonlyArray<T>;
  /** Campo del instante: número (epoch ms, días, índice) o ISO-8601 explícito. Por defecto `x`. */
  xKey?: keyof T & string;
  /** Campo del valor. Por defecto `y`. */
  yKey?: keyof T & string;
  /**
   * Serie sobre la que se interpreta, si difiere de la dibujada (p. ej. observado
   * hasta hoy + modelo después). Por defecto, `data`.
   */
  analysisData?: ReadonlyArray<T>;
  unit?: string;
  mode?: 'auto' | 'short' | 'segmented';
  /**
   * `blocks` (defecto): un tramo recto por ventana temporal con su media, el valor
   * arriba, el cambio abajo y la huella de las muestras detrás; sólo el bloque
   * activo (vigente o bajo el puntero) toma el acento.
   * `regimes`: la interpretación por regímenes sobre la señal continua.
   */
  presentation?: 'blocks' | 'regimes';
  /** Milisegundos por unidad de x (86 400 000 si x son días). Epoch ms se detecta solo. */
  xUnitMs?: number;
  /**
   * Tope de bloques de `presentation="blocks"`. Por defecto los decide el ancho;
   * una serie corta (un punto por horizonte) fija aquí un bloque por muestra.
   */
  maxBlocks?: number;
  /**
   * Cómo se rotula el cambio entre bloques. `auto` (defecto): relativo (%) si toda
   * la serie es positiva, absoluto (en `unit`) si cruza cero. Las anomalías e
   * índices declaran `absolute` aunque el tramo visible sea positivo.
   */
  deltaScale?: 'auto' | 'relative' | 'absolute';
  /** Ajustes del análisis (umbrales normalizados, duración mínima…). */
  analysisOptions?: Omit<TrendAnalysisOptions, 'mode' | 'xUnitMs'>;
  showTrend?: boolean;
  showTooltip?: boolean;
  /** Sin ejes: sparkline. */
  showAxes?: boolean;
  /** Formato de valores en el tooltip (la unidad se agrega aparte). También de los ejes si no hay `formatY`. */
  formatter?: (value: number) => string;
  /** Formato del instante en el tooltip. Por defecto `formatX`. */
  formatTime?: (x: number) => string;
  /** Qué régimen usa el acento: sólo el activo direccional (defecto) o ninguno. */
  emphasis?: 'active' | 'none';
  /** Presupuesto de puntos dibujados; el análisis siempre usa la serie completa. */
  maxRenderPoints?: number;
  onTrendChange?: (analysis: TrendAnalysis) => void;
  onHoverChange?: (hover: (TrendHover & { segment: TrendSegment | null }) | null) => void;
  /** Sólo en desarrollo: puntos de cambio, suavizado y tabla de regímenes en consola. */
  debugTrend?: boolean;
}
