﻿import { SignalTrendChart, SignalTrendStrip } from './SignalCharts';
import type { SignalTrendChartProps } from './SignalCharts.types';

const data = [20,28,19,32,27,40,25,36,34,31,43,37].map((y,x)=>({x,y}));
export default { title: 'Instruments/SignalCharts', component: SignalTrendChart, args: { data, ariaLabel: 'Serie ilustrativa de la biblioteca' } };
export const Neutral = { args: { summaryLabel: 'Última muestra' } };
export const Warning = { args: { tone: 'warning', summaryLabel: 'En vigilancia' } };
export const Compact = { args: { density: 'compact' }, render: (args: SignalTrendChartProps) => <div style={{width:240}}><SignalTrendChart {...args}/></div> };
export const Periods = { render: () => <SignalTrendStrip data={data} periods={[{id:'a',start:0,end:4,label:'Periodo A',tone:'warning'},{id:'b',start:4,end:8,label:'Periodo B'},{id:'c',start:8,end:11,label:'Periodo C'}]} ariaLabel="Medias de una serie ilustrativa"/> };
export const NoData = { args: { data: [] } };
export const MissingLatest = { args: { data: [{x:0,y:20},{x:1,y:NaN}] } };
