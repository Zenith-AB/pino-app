import { useMemo } from 'react';
import type { CSSProperties } from 'react';
import {
  buildEnsembleStepGeometry,
  ENSEMBLE_VIEWBOX,
  formatStepChange,
  type EnsembleStepInput,
} from './EnsembleStepChart.utils';
import styles from './EnsembleStepChart.module.css';

export interface EnsembleStepChartProps extends EnsembleStepInput {
  formatValue?: (value: number) => string;
  /** Nombre del día de cada tramo (x en días), para el título al pasar el puntero. */
  formatDay?: (x: number) => string | null;
  ariaLabel?: string;
  emptyLabel?: string;
  firstStepLabel?: string;
  /** Densidad de rótulos visibles; todos los días conservan su tramo y tooltip. */
  labelEvery?: number;
  className?: string;
}

type Vars = CSSProperties & Record<`--${string}`, string | number>;
const pct = (value: number, of: number) => `${(value / of) * 100}%`;
const DEFAULT_FORMAT = (value: number) => new Intl.NumberFormat('es-CL', { maximumFractionDigits: 0 }).format(value);

/**
 * Lectura por ventanas: la onda del ensemble al fondo, su figura construyéndose
 * encima y, sobre todo, un tramo por día con su total. Reglas en `.utils.ts`.
 */
export function EnsembleStepChart({
  formatValue = DEFAULT_FORMAT,
  formatDay,
  ariaLabel,
  emptyLabel = 'Sin serie de pronóstico',
  firstStepLabel = 'hoy',
  labelEvery = 1,
  className = '',
  median,
  members,
  band,
  yDomain,
  yClamp,
  minSpan,
  yTicks,
  windows,
}: EnsembleStepChartProps) {
  const geometry = useMemo(
    () => buildEnsembleStepGeometry({ median, members, band, yDomain, yClamp, minSpan, yTicks, windows }),
    [median, members, band, yDomain, yClamp, minSpan, yTicks, windows],
  );
  // Si cambian los datos, la figura vuelve a construirse desde la izquierda.
  const signature = geometry ? geometry.steps.map((step) => step.value).join(',') : '';
  const { width, height } = ENSEMBLE_VIEWBOX;
  const dayName = (x: number) => formatDay?.(x) ?? `Día ${x}`;
  const windowName = (days: number[]) =>
    days.length > 1 ? `${dayName(days[0])} – ${dayName(days[days.length - 1])}` : dayName(days[0]);

  if (!geometry) {
    return (
      <figure className={`${styles.root} ${className}`} role="img" aria-label={emptyLabel}>
        <span className={styles.empty}>{emptyLabel}</span>
      </figure>
    );
  }

  return (
    <figure
      className={`${styles.root} ${className}`}
      role="img"
      aria-label={ariaLabel}
      data-layer={geometry.wave ? 'members' : geometry.band ? 'band' : 'none'}
      key={signature}
      style={{ '--step-count': geometry.steps.length } as Vars}
    >
      <svg className={styles.svg} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" aria-hidden="true">
        {/* Capa 1 · onda: cada pico es un miembro del ensemble. */}
        {geometry.wave && <path className={styles.wave} d={geometry.wave} />}
        {geometry.band && <path className={styles.band} d={geometry.band} />}
        {/* Capa 2 · figura: envolvente alta, construyéndose. */}
        <path className={styles.figure} d={geometry.figure} />
        {/* Capa 3 · un tramo por ventana. */}
        {geometry.steps.map((step, index) => (
          <line
            className={styles.step}
            data-rising={step.rising || undefined}
            style={{ '--step-index': index } as Vars}
            x1={step.x1}
            x2={step.x2}
            y1={step.y}
            y2={step.y}
            key={step.x}
          ><title>{windowName(step.days)}: {formatValue(step.value)}</title></line>
        ))}
      </svg>

      <div className={styles.labels}>
        {geometry.steps.map((step, index) => (index % labelEvery === 0 && index + labelEvery <= geometry.steps.length || index === geometry.steps.length - 1) && (
          <span
            className={styles.stepLabel}
            data-rising={step.rising || undefined}
            style={{ '--x': pct(step.x1, width), '--y': pct(step.y, height), '--step-index': index } as Vars}
            title={windowName(step.days)}
            aria-hidden="true"
            key={step.x}
          >
            <span className={styles.stepValue}>{formatValue(step.value)}</span>
            <span className={styles.stepChange}>{index === 0 ? firstStepLabel : formatStepChange(step.change)}</span>
          </span>
        ))}
      </div>

      <div className={styles.scale} aria-hidden="true">
        {geometry.scale.map((mark) => (
          <span className={styles.scaleLabel} style={{ '--y': pct(mark.y, height) } as Vars} key={mark.value}>
            {formatValue(mark.value)}
          </span>
        ))}
      </div>
    </figure>
  );
}
