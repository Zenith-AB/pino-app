﻿import { OperationalTrendline } from '../OperationalTrendline/OperationalTrendline';
import { interactionReadings, latestReading, summarizePeriods } from './SignalCharts.utils';
import { prepareData } from '../OperationalTrendline/OperationalTrendline.utils';
import type { SignalTrendChartProps, SignalTrendStripProps } from './SignalCharts.types';
import './SignalCharts.css';

/** Quiet measured signal + explicit reading. Shares the scientific SVG engine. */
export function SignalTrendChart({ interactive = false, periodCount = 3, summary = 'latest', summaryLabel = 'Última muestra', tone = 'neutral', readings, className = '', ...props }: SignalTrendChartProps) {
  const resolved = readings ?? (summary === 'latest' ? latestReading(props.data, summaryLabel).map(r => ({ ...r, tone })) : []);
  const points = prepareData(props.data);
  const xDomain = props.xDomain ?? (points.length === 1 && !props.comparisons?.length ? [points[0].x - 0.5, points[0].x + 0.5] as [number, number] : undefined);
  return <OperationalTrendline {...props} xDomain={xDomain} readings={interactive ? [] : resolved}
    interactiveReadings={interactive ? interactionReadings(props.data, periodCount) : props.interactiveReadings}
    className={`signal-chart ${interactive ? 'signal-chart-interactive' : ''} ${className}`} />;
}

/** Adjacent periods on one temporal/value scale; no independent scaling between segments. */
export function SignalTrendStrip({ periods, showChange = true, className = '', ariaLabel, ...props }: SignalTrendStripProps) {
  const readings = summarizePeriods(props.data, periods, showChange);
  return <SignalTrendChart {...props} summary="none" readings={readings}
    className={`signal-chart-strip ${className}`}
    ariaLabel={`${ariaLabel ?? 'Comparación temporal'}. Media aritmética de las muestras por tramo. Los periodos sin muestras no tienen lectura.`} />;
}
