﻿import assert from 'node:assert/strict';
import test from 'node:test';
import { latestReading, summarizePeriods } from './SignalCharts.utils.ts';

const periods = [{id:'a',start:0,end:2,label:'A'},{id:'b',start:2,end:4,label:'B'}];
test('latest missing sample is not replaced with a stale current value', () => {
  assert.deepEqual(latestReading([{x:0,y:5},{x:1,y:NaN}]), []);
  assert.deepEqual(latestReading([]), []);
  assert.equal(latestReading([{x:2,y:8},{x:1,y:3}])[0].value, 8);
});
test('period means count shared boundaries once and include the final endpoint', () => {
  const readings=summarizePeriods([{x:0,y:10},{x:1,y:20},{x:2,y:30},{x:3,y:40},{x:4,y:50}],periods);
  assert.deepEqual(readings.map(r=>r.value), [15,40]);
  assert.match(readings[1].detail!, /166,7%/);
});
test('missing samples are excluded, not treated as zero; empty periods break comparison', () => {
  const readings=summarizePeriods([{x:0,y:10},{x:1,y:NaN},{x:5,y:30}], [...periods,{id:'c',start:4,end:6,label:'C'}]);
  assert.deepEqual(readings.map(r=>r.value),[10,30]);
  assert.equal(readings[1].detail,undefined);
});
test('a zero baseline has no relative percentage and negative baselines keep direction', () => {
  assert.equal(summarizePeriods([{x:0,y:0},{x:3,y:10}],periods)[1].detail,undefined);
  assert.match(summarizePeriods([{x:0,y:-10},{x:3,y:-5}],periods)[1].detail!,/^\+50%/);
});
test('invalid and overlapping intervals are rejected instead of misleading comparisons', () => {
  assert.throws(()=>summarizePeriods([],[{id:'a',start:2,end:0,label:'A'}]),RangeError);
  assert.throws(()=>summarizePeriods([],[periods[0],{...periods[1],start:1}]),RangeError);
});
test('a single valid sample gets a readable interval; duplicate time uses the last sample', () => {
  assert.deepEqual(latestReading([{x:2,y:5},{x:2,y:8}])[0],{id:'latest',start:1.5,end:2.5,value:8,label:'Última muestra'});
});
