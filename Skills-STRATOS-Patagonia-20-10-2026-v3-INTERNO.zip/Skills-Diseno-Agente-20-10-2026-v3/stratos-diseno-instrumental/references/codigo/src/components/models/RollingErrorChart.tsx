import { useMemo } from 'react';
import { OperationalTrendline } from '../instruments/OperationalTrendline';
import { PillSelector } from '../molecules/stratos';
import type { PillOption } from '../molecules/stratos';
import type { RollingError } from '../../data/models/modelMetrics.types';
import { formatInteger, formatLead, formatMetric, formatShortDate } from './modelFormat';

const WINDOW_OPTIONS: PillOption<'7' | '30'>[] = [
  { id: '7', label: 'Ventana 7 días' },
  { id: '30', label: 'Ventana 30 días' },
];

interface RollingErrorChartProps {
  data: RollingError | null;
  windowDays: 7 | 30;
  onWindowChange: (days: 7 | 30) => void;
  sufficient: boolean;
  emptyLabel: string;
}

/** MAE móvil por fecha de validez: una subida sostenida es degradación del modelo. */
export function RollingErrorChart({ data, windowDays, onWindowChange, sufficient, emptyLabel }: RollingErrorChartProps) {
  const series = useMemo(() => {
    const toPoints = (points: Array<{ time: string; mae: number }> = []) => points.map(point => ({ x: point.time, y: point.mae }));
    return {
      timesfm: toPoints(data?.series.timesfm),
      persistence: toPoints(data?.series.persistence),
    };
  }, [data]);
  const counts = data?.series.timesfm.map(point => point.n) ?? [];
  const unit = data?.variable.unit ?? '';
  const ticks = series.timesfm.length ? [series.timesfm[0].x, series.timesfm.at(-1)!.x] : [];

  return (
    <div className="models-card models-chart-card models-chart-content">
      <header className="models-card-header">
        <h3 className="models-card-title">Error en el tiempo <span className="models-card-title-meta">(MAE móvil{data ? ` · ${formatLead(data.lead_hours)}` : ''})</span></h3>
        <PillSelector
          id="models-rolling-window"
          options={WINDOW_OPTIONS}
          selectedId={String(windowDays) as '7' | '30'}
          onSelect={id => onWindowChange(Number(id) as 7 | 30)}
          menuTitle="Ventana"
        />
      </header>
      {!sufficient || series.timesfm.length === 0 ? (
        <p className="models-empty">{emptyLabel}</p>
      ) : (
        <>
          <div className="models-chart models-chart-line">
            <OperationalTrendline
              data={series.timesfm}
              comparisons={[{ id: 'persistence', label: 'Persistencia', data: series.persistence, tone: 'muted', dashed: true }]}
              xTicks={ticks}
              formatX={value => formatShortDate(typeof value === 'number' ? new Date(value).toISOString() : String(value))}
              formatY={value => `${formatMetric(value)} ${unit}`}
              yAxisSide="right"
              ariaLabel={`MAE móvil de ${windowDays} días de TimesFM y persistencia, en ${unit}`}
            />
          </div>
          <ul className="models-legend" aria-hidden="true">
            <li><span className="models-legend-line" />TimesFM 2.5</li>
            <li><span className="models-legend-line is-muted" />Persistencia</li>
          </ul>
          <p className="models-footnote">
            Cada punto promedia los pares con fecha de validez en los {windowDays} días previos · n por ventana {formatInteger(Math.min(...counts))}–{formatInteger(Math.max(...counts))}.
          </p>
        </>
      )}
    </div>
  );
}
