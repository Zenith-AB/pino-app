import { useMemo } from 'react';
import { OperationalTrendline } from '../instruments/OperationalTrendline';
import type { ForecastDetail } from '../../data/models/modelMetrics.types';
import { formatDateTime, formatInteger, formatLead, formatMetric, formatShortDate } from './modelFormat';

interface ForecastVsObservedChartProps {
  forecast: ForecastDetail;
  unit: string;
}

const SOURCE_LABEL = { observation: 'Observado', model: 'Serie de modelo', satellite: 'Satélite' } as const;

/**
 * Lo observado (antes y después de la emisión), la mediana P50 y la banda P10–P90.
 * La línea vertical punteada es el origen temporal: a su izquierda está el
 * contexto que vio el modelo; a su derecha, lo que pronosticó y lo que pasó.
 */
export function ForecastVsObservedChart({ forecast, unit }: ForecastVsObservedChartProps) {
  const { observed, p50, band } = useMemo(() => {
    const predictions = forecast.predictions.filter(point => point.p50 !== null);
    return {
      observed: (forecast.observed ?? []).map(point => ({ x: point.time, y: point.value })),
      p50: predictions.map(point => ({ x: point.valid_time, y: point.p50 as number })),
      band: predictions
        .filter(point => point.p10 !== null && point.p90 !== null)
        .map(point => ({ x: point.valid_time, lo: point.p10 as number, hi: point.p90 as number })),
    };
  }, [forecast]);

  const end = forecast.predictions.at(-1)?.valid_time;
  const start = forecast.observed?.[0]?.time ?? forecast.issue_time;
  const kind = forecast.observed_kind ? SOURCE_LABEL[forecast.observed_kind] : 'Observado';
  const standard = forecast.predictions.filter(point => point.status !== null);
  const evaluated = standard.filter(point => point.status === 'EVALUATED').length;

  return (
    <div className="models-forecast-chart">
      <div className="models-chart models-chart-tall">
        <OperationalTrendline
          data={observed}
          comparisons={[{ id: 'p50', label: 'Pronóstico P50', data: p50, tone: 'accent' }]}
          uncertainty={band}
          forecastFromX={forecast.issue_time}
          annotation={`Origen del pronóstico ${formatDateTime(forecast.issue_time)} UTC`}
          xTicks={[start, forecast.issue_time, ...(end ? [end] : [])]}
          formatX={value => formatShortDate(typeof value === 'number' ? new Date(value).toISOString() : String(value))}
          formatY={value => `${formatMetric(value)} ${unit}`}
          yAxisSide="right"
          ariaLabel={`${kind} y pronóstico TimesFM con banda P10–P90, en ${unit}`}
        />
      </div>
      <ul className="models-legend" aria-hidden="true">
        <li><span className="models-legend-line is-base" />{kind}</li>
        <li><span className="models-legend-line" />P50 (mediana)</li>
        <li><span className="models-legend-band" />Banda P10–P90</li>
        <li><span className="models-legend-rule" />Origen</li>
      </ul>
      <dl className="models-spec models-spec-compact">
        <div><dt>Contexto</dt><dd>{formatInteger(forecast.context_metadata.context_length)} pasos desde {formatDateTime(forecast.context_metadata.context_start)}</dd></div>
        <div><dt>Interpolados</dt><dd>{formatInteger(forecast.context_metadata.n_interpolated)} pasos</dd></div>
        <div><dt>Fuente</dt><dd>{forecast.source_metadata.description ?? forecast.source_metadata.source_target}</dd></div>
        <div><dt>Horizontes evaluados</dt><dd>{formatInteger(evaluated)} de {formatInteger(standard.length)} (hasta {standard.length ? formatLead(standard.at(-1)!.lead_hours) : '—'})</dd></div>
        <div><dt>Inferencia</dt><dd>{forecast.inference_time_ms ? `${formatInteger(Math.round(forecast.inference_time_ms))} ms · ${forecast.device ?? ''}` : '—'}</dd></div>
        <div><dt>Emitido (reloj)</dt><dd>{formatDateTime(forecast.created_at)}</dd></div>
      </dl>
    </div>
  );
}
