import { useMemo, useState } from 'react';
import { TrendChart } from '../instruments';
import { PillSelector } from '../molecules/stratos';
import type { PillOption } from '../molecules/stratos';
import type { ModelName, PerformanceByHorizon } from '../../data/models/modelMetrics.types';
import { MODEL_ENTRIES } from './ModelSelector';
import { formatBias, formatLead, formatMetric } from './modelFormat';

type MetricId = 'mae' | 'rmse' | 'bias' | 'pinball';

const METRIC_OPTIONS: PillOption<MetricId>[] = [
  { id: 'mae', label: 'MAE' },
  { id: 'rmse', label: 'RMSE' },
  { id: 'bias', label: 'Sesgo' },
  { id: 'pinball', label: 'Pinball (media de deciles)' },
];

interface ForecastHorizonChartProps {
  data: PerformanceByHorizon;
  selectedId: ModelName;
}

/**
 * Error por horizonte con el mismo instrumento que «Probabilidad FAN» (TrendChart
 * por bloques). Un bloque por horizonte con evidencia suficiente; los horizontes
 * que no la tienen no se dibujan. Los horizontes se ubican por posición, no en
 * escala lineal, para que los cortos no queden apilados.
 */
export function ForecastHorizonChart({ data, selectedId }: ForecastHorizonChartProps) {
  const [metric, setMetric] = useState<MetricId>('mae');
  const model = MODEL_ENTRIES.find(entry => entry.id === selectedId) ?? MODEL_ENTRIES[0];
  const effectiveMetric: MetricId = metric === 'pinball' && selectedId !== 'timesfm' ? 'mae' : metric;
  const unit = data.variable.unit;
  const leads = data.horizons.map(horizon => horizon.lead_hours);

  const { series, skipped } = useMemo(() => {
    const points: Array<{ x: number; y: number }> = [];
    const missing: string[] = [];
    data.horizons.forEach((horizon, index) => {
      const block = horizon.models.find(candidate => candidate.model === selectedId);
      const metrics = block?.sufficient ? block.metrics : null;
      const value = effectiveMetric === 'pinball' ? metrics?.pinball_mean : metrics?.[effectiveMetric];
      if (value === null || value === undefined) missing.push(formatLead(horizon.lead_hours));
      else points.push({ x: index, y: value });
    });
    return { series: points, skipped: missing };
  }, [data, selectedId, effectiveMetric]);

  const label = METRIC_OPTIONS.find(option => option.id === effectiveMetric)!.label;
  const format = effectiveMetric === 'bias' ? formatBias : formatMetric;

  return (
    <div className="models-card models-chart-card models-chart-content">
      <header className="models-card-header">
        <h3 className="models-card-title">Rendimiento por horizonte <span className="models-card-title-meta">(+24 h a +30 d)</span></h3>
        <PillSelector<MetricId>
          id="models-horizon-metric"
          options={selectedId === 'timesfm' ? METRIC_OPTIONS : METRIC_OPTIONS.filter(option => option.id !== 'pinball')}
          selectedId={effectiveMetric}
          onSelect={setMetric}
          menuTitle="Métrica"
        />
      </header>
      {series.length === 0 ? (
        <p className="models-empty">Sin evidencia suficiente en ningún horizonte para {model.name}.</p>
      ) : (
        <div className="models-chart">
          <TrendChart
            data={series}
            unit={unit}
            formatter={format}
            maxBlocks={leads.length}
            deltaScale="absolute"
            xTicks={leads.map((_, index) => index)}
            formatX={value => formatLead(leads[Number(value)])}
            yTicks={[]}
            formatY={value => `${format(value)} ${unit}`}
            annotation={skipped.length ? `Sin evidencia suficiente: ${skipped.join(', ')}` : undefined}
            ariaLabel={`${label} de ${model.name} por horizonte de pronóstico, en ${unit}`}
          />
        </div>
      )}
      <p className="models-footnote">
        {model.name} · {label}{effectiveMetric === 'pinball' ? ' sobre los 9 deciles nativos' : ''} en {unit}. Menor es mejor
        {effectiveMetric === 'bias' ? '; en el sesgo, más cerca de 0' : ''}.
      </p>
    </div>
  );
}
