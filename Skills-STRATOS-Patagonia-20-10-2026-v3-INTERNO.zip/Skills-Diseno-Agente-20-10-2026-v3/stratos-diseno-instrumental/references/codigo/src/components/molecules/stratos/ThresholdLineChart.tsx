import { useId } from 'react';
import type { AxisTick, ChartPoint } from '../../../data/stratosTypes';

export interface ChartSeries {
  id: string;
  points: ChartPoint[];
  variant: 'primary' | 'muted' | 'amber';
}

interface ThresholdLineChartProps {
  series: ChartSeries[];
  xDomain: [number, number];
  yDomain?: [number, number];
  xTicks: AxisTick[];
  yTicks: AxisTick[];
  threshold?: AxisTick;
  band?: Array<{ x: number; lo: number; hi: number }>;
  /** Desde esta x el fondo se tiñe como zona proyectada. */
  forecastFromX?: number;
  marker?: { x: number; y: number } | null;
  endDot?: boolean;
  yAxis?: 'left' | 'right';
  className?: string;
  ariaLabel: string;
}

/**
 * Gráfico temporal científico integrado al glass. El SVG sólo dibuja trazos
 * (escala libre, trazo no escalable); textos y puntos viven en HTML para que
 * nunca se deformen con el tamaño de la card.
 */
export function ThresholdLineChart({
  series,
  xDomain,
  yDomain = [0, 100],
  xTicks,
  yTicks,
  threshold,
  band,
  forecastFromX,
  marker,
  endDot = false,
  yAxis = 'left',
  className = '',
  ariaLabel,
}: ThresholdLineChartProps) {
  const uid = useId().replace(/:/g, '');
  const [x0, x1] = xDomain;
  const [y0, y1] = yDomain;
  const px = (x: number) => ((x - x0) / (x1 - x0 || 1)) * 100;
  const py = (y: number) => (1 - (Math.min(y1, Math.max(y0, y)) - y0) / (y1 - y0 || 1)) * 100;

  const pathFor = (points: ChartPoint[]) => {
    let d = '';
    let pen = false;
    for (const point of points) {
      if (point.y == null) {
        pen = false;
        continue;
      }
      d += `${pen ? 'L' : 'M'}${px(point.x).toFixed(3)} ${py(point.y).toFixed(3)} `;
      pen = true;
    }
    return d.trim();
  };

  const primary = series.find((item) => item.variant === 'primary') ?? series[0];
  const lastPrimary = primary ? [...primary.points].reverse().find((point) => point.y != null) : undefined;
  const bandPath = band?.length
    ? `${band.map((p, i) => `${i ? 'L' : 'M'}${px(p.x)} ${py(p.hi)}`).join(' ')} ${[...band]
        .reverse()
        .map((p) => `L${px(p.x)} ${py(p.lo)}`)
        .join(' ')} Z`
    : null;

  return (
    <div className={`threshold-chart y-axis-${yAxis} ${className}`} role="img" aria-label={ariaLabel}>
      <div className="threshold-chart-y" aria-hidden="true">
        {yTicks.map((tick) => (
          <span key={tick.value} style={{ top: `${py(tick.value)}%` }}>
            {tick.label}
          </span>
        ))}
      </div>

      <div className="threshold-chart-plot">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <defs>
            <linearGradient id={`forecast-${uid}`} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--trend-critical)" stopOpacity="0.22" />
              <stop offset="100%" stopColor="var(--trend-critical)" stopOpacity="0.02" />
            </linearGradient>
          </defs>

          {forecastFromX != null && (
            <rect x={px(forecastFromX)} y="0" width={100 - px(forecastFromX)} height="100" fill={`url(#forecast-${uid})`} />
          )}

          {yTicks.map((tick) => (
            <line
              key={tick.value}
              className="threshold-chart-grid"
              x1="0"
              x2="100"
              y1={py(tick.value)}
              y2={py(tick.value)}
              vectorEffect="non-scaling-stroke"
            />
          ))}

          {bandPath && <path className="threshold-chart-band" d={bandPath} />}

          {threshold && (
            <line
              className="threshold-chart-threshold"
              x1="0"
              x2="100"
              y1={py(threshold.value)}
              y2={py(threshold.value)}
              vectorEffect="non-scaling-stroke"
            />
          )}

          {marker && (
            <line
              className="threshold-chart-today"
              x1={px(marker.x)}
              x2={px(marker.x)}
              y1="0"
              y2="100"
              vectorEffect="non-scaling-stroke"
            />
          )}

          {series.map((item) => (
            <path
              key={item.id}
              className={`threshold-chart-line is-${item.variant}`}
              d={pathFor(item.points)}
              vectorEffect="non-scaling-stroke"
            />
          ))}
        </svg>

        {threshold && (
          <span className="threshold-chart-threshold-label" style={{ top: `${py(threshold.value)}%` }}>
            {threshold.label}
          </span>
        )}

        {endDot && lastPrimary && lastPrimary.y != null && (
          <span className="threshold-chart-dot" style={{ left: `${px(lastPrimary.x)}%`, top: `${py(lastPrimary.y)}%` }} />
        )}

        {marker && (
          <span className="threshold-chart-marker" style={{ left: `${px(marker.x)}%`, top: `${py(marker.y)}%` }} />
        )}
      </div>

      <div className="threshold-chart-x" aria-hidden="true">
        {xTicks.map((tick) => (
          <span key={tick.value} style={{ left: `${px(tick.value)}%` }}>
            {tick.label}
          </span>
        ))}
      </div>
    </div>
  );
}
