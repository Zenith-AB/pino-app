import { SignalTrendChart, TrendChart } from '../../instruments';
import type { StratosTone } from '../../../data/stratosTypes';

interface MiniTrendChartProps {
  values: number[];
  tone?: StratosTone;
  variant?: 'line' | 'area' | 'bars';
  recentBars?: number;
  endDot?: boolean;
  grid?: boolean;
  className?: string;
  ariaLabel?: string;
  unit?: string;
  relative?: boolean;
}

const cardNumber = (value: number) =>
  new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1, notation: Math.abs(value) >= 1000 ? 'compact' : 'standard' }).format(value);

/**
 * Serie de tarjeta. Una tendencia (línea) usa el mismo instrumento que las
 * tarjetas de centro y la Probabilidad FAN: bloques con su nivel y su cambio.
 * Las barras siguen siendo barras —días discretos con base cero, no una tendencia—.
 */
export function MiniTrendChart({ values, variant = 'line', recentBars = 0, grid = true, className = '', ariaLabel, unit, relative }: MiniTrendChartProps) {
  if (variant !== 'bars') {
    return <TrendChart
      data={values.map((y, x) => ({ x, y }))}
      unit={unit}
      density="compact"
      showGrid={grid}
      yTicks={[]}
      xTicks={[]}
      formatter={cardNumber}
      formatTime={value => `Muestra ${value + 1}`}
      className={className}
      ariaLabel={`${ariaLabel ?? 'Serie de muestras'}${unit ? `, ${unit}` : ''}`}
    />;
  }
  const valid = values.filter(Number.isFinite);
  const min = variant === 'bars' ? 0 : Math.min(...valid);
  const max = Math.max(...valid);
  const padding = (max - min || Math.abs(max) || 1) * .15;
  const formatter = (value: number) => new Intl.NumberFormat('es-CL', { maximumFractionDigits: 1, notation: Math.abs(value) >= 1000 ? 'compact' : 'standard' }).format(value);
  return <SignalTrendChart
    summary={variant === 'bars' ? 'none' : 'latest'}
    data={values.map((y, x) => ({ x, y }))}
    variant={variant === 'bars' ? 'bars' : 'line'}
    windows={variant === 'bars' && recentBars > 0 && values.length ? [{ id: 'recent-samples', start: Math.max(0, values.length - recentBars), end: values.length - 1, tone: 'neutral', showBand: false, showMarkers: false }] : []}
    yDomain={valid.length ? [variant === 'bars' ? 0 : min - padding, max + padding] : undefined}
    yTicks={valid.length ? [...new Set([min, max])] : []}
    xTicks={values.length > 1 ? [0, values.length - 1] : values.length ? [0] : []}
    formatX={value => `M${Number(value) + 1}`}
    formatY={formatter}
    annotation={variant === 'bars' && !relative ? `Muestras${unit ? ` · ${unit}` : ''}` : undefined}
    density="compact"
    showGrid={grid}
    className={className}
    ariaLabel={`${ariaLabel ?? 'Serie de muestras'}. ${relative ? 'Escala relativa, sin conversión a caudal físico' : unit ?? ''}. M indica el número de muestra; no se asignan fechas no disponibles`}
  />;
}
