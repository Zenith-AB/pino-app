/*
 * Filtro SVG del liquid glass, montado una vez por documento.
 *
 * Traducción de polidario/Frontend-Projects · liquid-glass-vue (AppCard.vue):
 * `backdrop-filter: brightness() blur() url(#filtro)` con feTurbulence +
 * feDisplacementMap: turbulence 0.01 y dos octavas como el original; la escala
 * baja de 200 a 14 a pedido del usuario: refracción apenas perceptible (vidrio
 * esmerilado con refracción leve). Los navegadores que no aceptan url() en backdrop-filter
 * usan el blur de respaldo declarado antes en .stratos-liquid.
 */

export const LIQUID_GLASS_FILTER_ID = 'stratos-liquid-glass';

export function LiquidGlassDefs() {
  return (
    <svg width="0" height="0" aria-hidden="true" focusable="false" style={{ position: 'absolute', width: 0, height: 0, overflow: 'hidden' }}>
      {/* Large stationary surfaces: broad, subtle refraction, no animated noise. */}
      <filter id="stratos-shell-glass" x="-5%" y="-5%" width="110%" height="110%" colorInterpolationFilters="sRGB">
        <feTurbulence type="fractalNoise" baseFrequency="0.008" numOctaves="1" seed="7" result="shellNoise" />
        <feDisplacementMap in="SourceGraphic" in2="shellNoise" scale="4" xChannelSelector="R" yChannelSelector="G" />
      </filter>
      <filter id="stratos-shell-glass-dense" x="-5%" y="-5%" width="110%" height="110%" colorInterpolationFilters="sRGB">
        <feTurbulence type="fractalNoise" baseFrequency="0.008" numOctaves="1" seed="7" result="denseNoise" />
        <feDisplacementMap in="SourceGraphic" in2="denseNoise" scale="6" xChannelSelector="R" yChannelSelector="G" />
      </filter>
      <filter id="stratos-liquid-glass-soft" x="-5%" y="-5%" width="110%" height="110%" colorInterpolationFilters="sRGB">
        <feTurbulence type="fractalNoise" baseFrequency="0.008" numOctaves="1" seed="7" result="softNoise" />
        <feDisplacementMap in="SourceGraphic" in2="softNoise" scale="4" xChannelSelector="R" yChannelSelector="G" />
      </filter>
      <filter id={LIQUID_GLASS_FILTER_ID}>
        <feTurbulence type="turbulence" baseFrequency="0.01" numOctaves="2" result="turbulence" />
        <feDisplacementMap in="SourceGraphic" in2="turbulence" scale="14" xChannelSelector="R" yChannelSelector="G" />
      </filter>
    </svg>
  );
}
