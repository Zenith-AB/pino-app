import React from 'react';
import './glass.css';

export type GlassVariant = 'structural' | 'instrument' | 'toolbar' | 'panel' | 'card' | 'selected' | 'floating' | 'pill';

export interface GlassSurfaceProps extends React.HTMLAttributes<HTMLElement> {
  variant?: GlassVariant;
  as?: 'div' | 'span';
  interactive?: boolean;
  className?: string;
  contentClassName?: string;
  children?: React.ReactNode;
}

export const GlassSurface = React.forwardRef<HTMLElement, GlassSurfaceProps>(({
  variant = 'card',
  as: Element = 'div',
  interactive = false,
  className = '',
  contentClassName = '',
  children,
  ...props
}, ref) => {
  const ContentElement = Element === 'span' ? 'span' : 'div';
  const variantClass = {
    structural: 'glass-surface glass-surface-structural',
    instrument: 'glass-surface glass-surface-instrument',
    toolbar: 'glass-surface glass-surface-toolbar',
    panel: 'glass-surface glass-surface-panel',
    card: 'glass-surface glass-surface-card',
    selected: 'glass-surface glass-surface-selected',
    floating: 'glass-surface glass-surface-floating',
    pill: 'glass-surface glass-surface-pill',
  }[variant];

  const interactiveClass = interactive
    ? 'cursor-pointer transition-[filter,transform] duration-200 hover:brightness-105 active:scale-[0.995]'
    : '';

  return (
    <Element
      ref={ref as React.Ref<HTMLDivElement> & React.Ref<HTMLSpanElement>}
      className={`${variantClass} ${interactiveClass} ${className}`}
      {...props}
    >
      <ContentElement className={`glass-content h-full w-full ${contentClassName}`}>
        {children}
      </ContentElement>
    </Element>
  );
});

GlassSurface.displayName = 'GlassSurface';
