/*
 * Ficha de una estación SOTRACS, al hacer click en su boya.
 *
 * Muestra sólo lo que se sabe: identificación, naturaleza, sector, región y
 * posición. Ninguna variable oceanográfica todavía — la estación está enchufada
 * a la API de ACS por su `buoyCode`, pero mientras no se pidan las series no se
 * dibuja un número que no se ha medido.
 */

import { IconX } from '@tabler/icons-react';
import { MapMarker } from '../markers/MapMarker';
import {
  formatCoordinates,
  SOTRACS_ATTRIBUTION,
  type SotracsStation,
} from '../../../data/sotracsStations';
import type { CenterSensorLink } from '../../../lib/map/centerSensorLinks';
import type { ReloncaviExplanationState } from '../../../hooks/useReloncaviExplanation';
import './sotracsStationCard.css';

interface SotracsStationCardProps {
  station: SotracsStation;
  connection?: CenterSensorLink | null;
  reloncavi?: ReloncaviExplanationState;
  onClose: () => void;
}

const EXPLANATION_TIME = new Intl.DateTimeFormat('es-CL', {
  day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
});

export function SotracsStationCard({ station, connection, reloncavi, onClose }: SotracsStationCardProps) {
  const explanation = reloncavi?.data ?? null;
  return (
    <div
      className="stratos-buoy-card"
      data-reloncavi={station.buoyCode === 'acs1' || undefined}
      role="dialog"
      aria-label={station.name}
    >
      <header className="stratos-buoy-card-head">
        <span className="stratos-buoy-card-mark" aria-hidden="true">
          <MapMarker
            kind="oceanographic_buoy"
            state={station.active === false ? 'offline' : 'unknown'}
            link={connection?.linkStatus}
            size={26}
          />
        </span>
        <div className="stratos-buoy-card-title">
          <h3>{station.id}</h3>
          <p>{SOTRACS_ATTRIBUTION}</p>
        </div>
        <button type="button" onClick={onClose} aria-label="Cerrar ficha de estación">
          <IconX size={14} />
        </button>
      </header>

      <dl className="stratos-buoy-card-facts">
        {connection && (
          <>
            <div>
              <dt>Alimenta</dt>
              <dd>{connection.center.name}</dd>
            </div>
            <div>
              <dt>Distancia</dt>
              <dd className="stratos-buoy-card-coords">
                {connection.distanceKm.toLocaleString('es-CL', { maximumFractionDigits: 1 })} km
              </dd>
            </div>
          </>
        )}
        <div>
          <dt>Sector</dt>
          <dd>{station.sector}</dd>
        </div>
        <div>
          <dt>Región</dt>
          <dd>{station.region}</dd>
        </div>
        <div>
          <dt>Operador</dt>
          <dd>{station.operator}</dd>
        </div>
        <div>
          <dt>Posición</dt>
          <dd className="stratos-buoy-card-coords">
            {formatCoordinates(station.lat, station.lon)}
            {station.position?.kind === 'last-known' && (
              <small className="stratos-buoy-card-position-note">
                Último fondeo verificado ({station.position.since}). El catálogo IFOP publica hoy{' '}
                {station.position.reportedLat}, {station.position.reportedLon}, que no es una posición en la red.
              </small>
            )}
          </dd>
        </div>
      </dl>

      <p className="stratos-buoy-card-pending">
        {connection
          ? connection.linkStatus === 'online' ? 'Transmitiendo a la red del centro.' : 'Última conexión disponible.'
          : 'Fuente ACS disponible sin asociación a un centro.'}
      </p>

      {station.buoyCode === 'acs1' && (
        <section className="reloncavi-chain" aria-labelledby="reloncavi-chain-title" aria-live="polite">
          <div className="reloncavi-chain-head">
            <div>
              <h4 id="reloncavi-chain-title">Cadena Seno–Estuario</h4>
              <p>Lectura regional, no atribuida al centro de cultivo.</p>
            </div>
            {explanation?.updatedAt && (
              <time dateTime={explanation.updatedAt}>
                {EXPLANATION_TIME.format(new Date(explanation.updatedAt)).replace(',', ' ·')}
              </time>
            )}
          </div>

          {reloncavi?.state === 'loading' && !explanation && (
            <p className="reloncavi-chain-message">Leyendo caudal, columna de agua y observaciones…</p>
          )}
          {reloncavi?.state === 'error' && (
            <p className="reloncavi-chain-message" data-state="missing">{reloncavi.error}</p>
          )}

          {explanation && (
            <>
              <ol className="reloncavi-chain-steps">
                {explanation.steps.filter((step) => step.id !== 'decision').map((step) => (
                  <li key={step.id} data-state={step.state}>
                    <span className="reloncavi-chain-node" aria-hidden="true" />
                    <div>
                      <span className="reloncavi-chain-label">{step.label}</span>
                      <strong>{step.value}</strong>
                      <p>{step.detail}</p>
                      <small>{step.source}</small>
                    </div>
                  </li>
                ))}
              </ol>
              <div className="reloncavi-chain-decision" data-state={explanation.decision.state}>
                <span aria-hidden="true" />
                <div>
                  <strong>{explanation.decision.label}</strong>
                  <p>{explanation.decision.reason}</p>
                </div>
              </div>
            </>
          )}
        </section>
      )}
    </div>
  );
}
