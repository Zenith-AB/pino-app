/*
 * Curva de la ficha de condiciones: lo observado en trazo lleno con un área suave
 * debajo y la proyección a 14 días en trazo discontinuo, separadas por «hoy».
 *
 * Se dibuja aquí y no con TrendChart porque la ficha flota sobre el mapa con
 * liquid glass: la serie necesita más contraste (trazo de 1,75 px, área y punto de
 * hoy) que la de los paneles, y una continuación pronosticada que el renderer
 * compartido no tiene. Sin líneas de referencia ni bandas (brief .ui-craft).
 */

import { useId } from 'react';
import type { TrendPoint } from '../../instruments/OperationalTrendline/OperationalTrendline.types';

interface PrecursorSparkProps {
  past: TrendPoint[];
  forecast?: TrendPoint[];
  /** Por encima de este valor el trazo pasa a ámbar (índice: 50). */
  threshold?: number;
  /** Dominio fijo (índice: 0–100); si falta, se ajusta a los datos. */
  domain?: [number, number];
  /** Trazo ámbar entero: el componente está alto. */
  accent?: boolean;
  /** Fecha de hoy (ms): la raya que separa lo pasado de lo proyectado. */
  now?: number;
  formatX: (value: number) => string;
  ariaLabel: string;
}

const finite = (point: TrendPoint): point is TrendPoint & { x: number } => typeof point.x === 'number' && Number.isFinite(point.y);

export function PrecursorSpark({ past, forecast = [], threshold, domain, accent = false, now, formatX, ariaLabel }: PrecursorSparkProps) {
  const id = useId().replace(/:/g, '');
  const observed = past.filter(finite);
  const projected = forecast.filter(finite);
  const all = [...observed, ...projected];
  if (all.length < 2) return null;

  const x0 = Math.min(...all.map((p) => p.x));
  const x1 = Math.max(...all.map((p) => p.x));
  let [y0, y1] = domain ?? [Math.min(...all.map((p) => p.y)), Math.max(...all.map((p) => p.y))];
  if (!domain) {
    const pad = (y1 - y0 || Math.abs(y1) || 1) * 0.12;
    y0 -= pad;
    y1 += pad;
  }
  const X = (x: number) => (x1 === x0 ? 50 : ((x - x0) / (x1 - x0)) * 100);
  const Y = (y: number) => 100 - ((y - y0) / (y1 - y0 || 1)) * 100;
  const line = (points: Array<{ x: number; y: number }>) => points.map((p, i) => `${i ? 'L' : 'M'}${X(p.x).toFixed(2)},${Y(p.y).toFixed(2)}`).join(' ');
  const area = (points: Array<{ x: number; y: number }>) =>
    points.length < 2 ? '' : `${line(points)} L${X(points[points.length - 1].x).toFixed(2)},100 L${X(points[0].x).toFixed(2)},100 Z`;

  const lastObserved = observed[observed.length - 1];
  // La proyección arranca en el último punto observado para que no quede un hueco.
  const ahead = lastObserved && projected.length ? [lastObserved, ...projected] : projected;
  // El punto de hoy: el valor del día de hoy si existe (observado o analizado), si no el último observado.
  const today = (now != null ? all.find((p) => Math.abs(p.x - now) < 43_200_000) : undefined) ?? lastObserved;
  const showToday = projected.length > 0 && today != null;
  const stroke = threshold != null ? `url(#${id}-split)` : accent ? 'var(--fan-amber)' : 'rgb(240 238 234 / 92%)';
  const splitAt = threshold != null ? Y(threshold) : 0;
  const end = projected[projected.length - 1];

  return (
    <div className="precursor-spark" role="img" aria-label={ariaLabel}>
      <div className="precursor-spark-plot">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <defs>
          <linearGradient id={`${id}-area`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={accent ? 'var(--fan-amber)' : 'rgb(240 238 234)'} stopOpacity={threshold != null ? 0.14 : 0.28} />
            <stop offset="1" stopColor={accent ? 'var(--fan-amber)' : 'rgb(240 238 234)'} stopOpacity="0" />
          </linearGradient>
          {threshold != null && (
            <linearGradient id={`${id}-split`} gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="100">
              <stop offset={splitAt / 100} stopColor="var(--fan-amber)" />
              <stop offset={splitAt / 100} stopColor="rgb(240 238 234 / 92%)" />
            </linearGradient>
          )}
        </defs>
        {observed.length > 1 && <path d={area(observed)} fill={`url(#${id}-area)`} />}
        {ahead.length > 1 && <path d={area(ahead)} fill={`url(#${id}-area)`} opacity="0.45" />}
        {showToday && <line className="precursor-spark-today" x1={X(today.x)} x2={X(today.x)} y1="0" y2="100" />}
        {observed.length > 1 && <path className="precursor-spark-line" d={line(observed)} stroke={stroke} />}
        {ahead.length > 1 && <path className="precursor-spark-line is-forecast" d={line(ahead)} stroke={stroke} />}
      </svg>
      {today && <i className="precursor-spark-dot" style={{ left: `${X(today.x)}%`, top: `${Y(today.y)}%` }} data-accent={accent || (threshold != null && today.y >= threshold) || undefined} />}
      {end && <i className="precursor-spark-dot is-forecast" style={{ left: `${X(end.x)}%`, top: `${Y(end.y)}%` }} />}
      </div>
      <div className="precursor-spark-axis" aria-hidden="true">
        <span>{formatX(x0)}</span>
        {showToday && <span className="is-today" style={{ left: `${X(today.x)}%` }}>hoy</span>}
        <span>{formatX(x1)}</span>
      </div>
    </div>
  );
}
