import type { CSSProperties } from 'react';

/**
 * Tiempos del cambio de módulo (Mapa Vivo ⇄ ENSO / SAM). Se declaran una sola
 * vez aquí porque los reparten dos autoridades distintas: JavaScript decide
 * *cuándo* cambia el lienzo y CSS *cómo* se ve el cambio. Si divergen, el mapa
 * nuevo aparece antes de que el negro lo tape.
 */
export const STAGE_BLACKOUT = {
  /** El lienzo saliente se apaga hasta el negro. */
  coverMs: 360,
  /** Negro sostenido: el lienzo cambia a oscuras, sin que se vea el corte. */
  holdMs: 100,
  /** El lienzo entrante emerge del negro con el mismo gesto. */
  revealMs: 480,
} as const;

/**
 * Los datos de una carcasa. La carcasa no participa: su vidrio y su geometría
 * siguen ahí durante todo el cruce (ver `mainStage.css`).
 */
export const CONTEXT_FADE = {
  /** Se van antes de que el negro termine de cerrar. */
  outMs: 240,
  /** Y vuelven con la luz. */
  inMs: 380,
  /** Cambio de contexto dentro del mismo módulo: sin lienzo que esperar. */
  shellDelayMs: 40,
} as const;

/**
 * Mapa Vivo ⇄ Modelos. El mapa no participa —sigue vivo detrás—: se van las
 * carcasas del tablero y, ya fuera, entra el panel de Modelos (o al revés).
 */
export const MODULE_FADE = {
  /** Breve: el mapa no debe quedar solo; lo nuevo entra apenas se ha ido lo anterior. */
  outMs: 180,
  inMs: 360,
  inDelayMs: 0,
} as const;

/**
 * Acceso ⇄ tablero. No es un cambio de pestaña: el mapa del acceso y el del
 * tablero son la misma imagen, así que primero se retira el formulario, luego
 * el vidrio —el mapa queda nítido— y recién entonces las carcasas del tablero
 * se asientan una tras otra. Nada se corta a negro.
 */
export const SESSION_ENTER = {
  /** Se va el formulario, apenas hay sesión. */
  formOutMs: 200,
  /** Se levanta el vidrio y el mapa del acceso queda limpio. */
  glassOutMs: 380,
  glassDelayMs: 60,
  /**
   * El acceso sólo se disuelve cuando el tablero ya está pintado detrás. Por
   * reloj no sirve: montar el tablero tarda lo que tarde la máquina, y si el
   * acceso se va antes queda un vacío oscuro en medio de la entrada.
   */
  loginOutMs: 520,
  /**
   * Respiro entre «el tablero ya dibuja» y el relevo: sus partículas nacen en un
   * lienzo vacío y tardan un instante en formar estelas. Sin esta pausa el campo
   * se ve ralo justo mientras el acceso se disuelve.
   */
  readyGraceMs: 280,
  /** Si el tablero no da señales, se entra igual: nadie se queda en el cruce. */
  readyTimeoutMs: 6000,
  /** Entran las carcasas, escalonadas, mientras el acceso se disuelve. */
  shellInMs: 460,
  shellDelayMs: 120,
  shellStepMs: 70,
} as const;

/** Cambio de módulo: los datos nuevos esperan al primer rayo de luz del lienzo. */
const stageDelayMs = STAGE_BLACKOUT.coverMs + STAGE_BLACKOUT.holdMs - CONTEXT_FADE.outMs;

export type SwapPace = 'shell' | 'stage';

/** Cuánto dura la entrada completa —espera incluida— para poder darla por terminada. */
export function contextFadeDuration(pace: SwapPace) {
  return CONTEXT_FADE.inMs + (pace === 'stage' ? stageDelayMs : CONTEXT_FADE.shellDelayMs);
}

/** Los mismos números, en el lenguaje de la hoja de estilos. */
export const stageTimingVars = {
  '--stage-blackout-cover': `${STAGE_BLACKOUT.coverMs}ms`,
  '--stage-blackout-hold': `${STAGE_BLACKOUT.holdMs}ms`,
  '--stage-blackout-reveal': `${STAGE_BLACKOUT.revealMs}ms`,
  '--context-fade-out': `${CONTEXT_FADE.outMs}ms`,
  '--context-fade-in': `${CONTEXT_FADE.inMs}ms`,
  '--context-fade-shell-delay': `${CONTEXT_FADE.shellDelayMs}ms`,
  '--context-fade-stage-delay': `${stageDelayMs}ms`,
  '--module-fade-out': `${MODULE_FADE.outMs}ms`,
  '--module-fade-in': `${MODULE_FADE.inMs}ms`,
  '--module-fade-delay': `${MODULE_FADE.inDelayMs}ms`,
} as CSSProperties;

/** Los tiempos de la entrada a la sesión, para `sessionTransition.css`. */
export const sessionEnterVars = {
  '--session-form-out': `${SESSION_ENTER.formOutMs}ms`,
  '--session-glass-out': `${SESSION_ENTER.glassOutMs}ms`,
  '--session-glass-delay': `${SESSION_ENTER.glassDelayMs}ms`,
  '--session-login-out': `${SESSION_ENTER.loginOutMs}ms`,
  '--session-shell-in': `${SESSION_ENTER.shellInMs}ms`,
  '--session-shell-delay': `${SESSION_ENTER.shellDelayMs}ms`,
  '--session-shell-step': `${SESSION_ENTER.shellStepMs}ms`,
} as CSSProperties;

/** Sin animación no hay nada que sincronizar: el cambio es inmediato. */
export function prefersReducedMotion() {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}
