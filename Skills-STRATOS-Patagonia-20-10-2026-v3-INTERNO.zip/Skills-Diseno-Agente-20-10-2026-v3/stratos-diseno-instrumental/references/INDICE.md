# Índice de implementación

Abrir sólo el archivo pertinente. Snapshots de referencia con imports originales; no starter autónomo.
Los documentos históricos dentro del snapshot no sustituyen las instrucciones vigentes de esta skill.

| Archivo | Origen |
|---|---|
| `references/codigo/src/styles/tokens.css` | repositorio local inspeccionado 19-10-2026: src/styles/tokens.css; puede incluir cambios sin commit |
| `references/codigo/src/styles/typography.css` | repositorio local inspeccionado 19-10-2026: src/styles/typography.css; puede incluir cambios sin commit |
| `references/codigo/src/components/atoms/GlassSurface.tsx` | repositorio local inspeccionado 19-10-2026: src/components/atoms/GlassSurface.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/atoms/LiquidGlassDefs.tsx` | repositorio local inspeccionado 19-10-2026: src/components/atoms/LiquidGlassDefs.tsx; puede incluir cambios sin commit |
| `references/codigo/src/lib/stage/stageTiming.ts` | repositorio local inspeccionado 19-10-2026: src/lib/stage/stageTiming.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/molecules/stratos/MiniTrendChart.tsx` | repositorio local inspeccionado 19-10-2026: src/components/molecules/stratos/MiniTrendChart.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/molecules/stratos/ThresholdLineChart.tsx` | repositorio local inspeccionado 19-10-2026: src/components/molecules/stratos/ThresholdLineChart.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/centers/CenterSensorInstruments.tsx` | repositorio local inspeccionado 19-10-2026: src/components/centers/CenterSensorInstruments.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/map/layers/SotracsStationCard.tsx` | repositorio local inspeccionado 19-10-2026: src/components/map/layers/SotracsStationCard.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/map/layers/sotracsStationCard.css` | repositorio local inspeccionado 19-10-2026: src/components/map/layers/sotracsStationCard.css; puede incluir cambios sin commit |
| `references/codigo/src/components/map/layers/PrecursorSpark.tsx` | repositorio local inspeccionado 19-10-2026: src/components/map/layers/PrecursorSpark.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/models/ForecastVsObservedChart.tsx` | repositorio local inspeccionado 19-10-2026: src/components/models/ForecastVsObservedChart.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/models/ForecastHorizonChart.tsx` | repositorio local inspeccionado 19-10-2026: src/components/models/ForecastHorizonChart.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/models/RollingErrorChart.tsx` | repositorio local inspeccionado 19-10-2026: src/components/models/RollingErrorChart.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/TrendChart/index.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/TrendChart/index.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/TrendChart/TrendChart.module.css` | repositorio local inspeccionado 19-10-2026: src/components/instruments/TrendChart/TrendChart.module.css; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/TrendChart/TrendChart.test.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/TrendChart/TrendChart.test.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/TrendChart/TrendChart.tsx` | repositorio local inspeccionado 19-10-2026: src/components/instruments/TrendChart/TrendChart.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/TrendChart/TrendChart.types.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/TrendChart/TrendChart.types.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/TrendChart/TrendChart.utils.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/TrendChart/TrendChart.utils.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/SignalCharts/index.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/SignalCharts/index.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/SignalCharts/README.md` | repositorio local inspeccionado 19-10-2026: src/components/instruments/SignalCharts/README.md; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/SignalCharts/SignalCharts.css` | repositorio local inspeccionado 19-10-2026: src/components/instruments/SignalCharts/SignalCharts.css; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/SignalCharts/SignalCharts.stories.tsx` | repositorio local inspeccionado 19-10-2026: src/components/instruments/SignalCharts/SignalCharts.stories.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/SignalCharts/SignalCharts.test.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/SignalCharts/SignalCharts.test.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/SignalCharts/SignalCharts.tsx` | repositorio local inspeccionado 19-10-2026: src/components/instruments/SignalCharts/SignalCharts.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/SignalCharts/SignalCharts.types.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/SignalCharts/SignalCharts.types.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/SignalCharts/SignalCharts.utils.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/SignalCharts/SignalCharts.utils.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/EnsembleStepChart/EnsembleStepChart.module.css` | repositorio local inspeccionado 19-10-2026: src/components/instruments/EnsembleStepChart/EnsembleStepChart.module.css; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/EnsembleStepChart/EnsembleStepChart.test.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/EnsembleStepChart/EnsembleStepChart.test.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/EnsembleStepChart/EnsembleStepChart.tsx` | repositorio local inspeccionado 19-10-2026: src/components/instruments/EnsembleStepChart/EnsembleStepChart.tsx; puede incluir cambios sin commit |
| `references/codigo/src/components/instruments/EnsembleStepChart/EnsembleStepChart.utils.ts` | repositorio local inspeccionado 19-10-2026: src/components/instruments/EnsembleStepChart/EnsembleStepChart.utils.ts; puede incluir cambios sin commit |
| `references/codigo/src/components/atoms/glass.css` | repositorio local inspeccionado 19-10-2026: src/components/atoms/glass.css; puede incluir cambios sin commit |
| `references/codigo/docs/VEXTO-CARD-Y-EVALUACION-MODELOS-2026-09-23.md` | repositorio local inspeccionado 19-10-2026: docs/VEXTO-CARD-Y-EVALUACION-MODELOS-2026-09-23.md; puede incluir cambios sin commit |

## Adición V3

- [contrato-sistema.md](contrato-sistema.md): contrato nuevo de adaptación, propuesto y revisado 19-10-2026; no implementación productiva.
