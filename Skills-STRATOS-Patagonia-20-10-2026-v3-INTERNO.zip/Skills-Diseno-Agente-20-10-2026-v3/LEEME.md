# Entrega V3 — leer primero

Entrada para otro agente: **EMPEZAR-AQUI-AGENTE.txt**. Dictamen y limitaciones: **AUDITORIA-CRITICA-V3.txt**.
La v3 conserva las seis skills y snapshots originales. Añade contratos de sistema, storyboard de la vista,
runtime/evaluación, guardia endurecida y correcciones del recorrido del atlas. No instala ni despliega sobre productos.
VALIDACION.json y EVIDENCIA-VISUAL/atlas-*.png son antecedentes v2; resultados nuevos en VALIDACION-V3.json.
PRIVADO/copernicus-credentials.txt conserva las credenciales internas solicitadas y verificadas contra el servidor;
no se imprime su contenido, no se instala y no lo sirve ver-demo.py. Autenticación no probada.

El manifiesto global incluye instrucciones, scripts, assets y archivo privado; el verificador revisa su integridad.
Después de instalar las seis skills en un destino limpio, verifica sus fuentes por carpeta. El TXT de entrada
permanece en la distribución y puede indicarse por ruta a agentes sin descubrimiento automático.

El atlas sigue siendo una demostración sintética sin Clef ni fuentes ambientales conectadas. El foco y doble clic
se implementan en esta muestra; no implican que el frontend productivo haya cambiado.

---

## Instrucciones y antecedentes conservados de V2

# Skills de diseño y agente · v3 · uso interno

Entrega preparada el 19-10-2026 para el prototipo demostrable del 20-10-2026.
Prioridad: diseño del sistema, vista del agente, glass, gráficos, mapa y recorrido submarino.

## Empezar

Pedir al agente: «Usa prototipo-desde-referencias de este paquete. Construye un prototipo visual con
perfil STRATOS y mecánicas de agente Patagonia. Lee las referencias pertinentes; conserva la diferencia
entre implementación, propuesta y demostración. Sigue el recorrido del contrato-demo.»

Las seis carpetas de skill son autocontenidas. No es necesario instalar las 27 skills anteriores para
utilizarlas. El código pertinente de STRATOS y Patagonia ya viene incluido, con hashes y procedencia.
Los snapshots preservan imports del producto original: son referencia para adaptar, no una app instalable.

## Instalación y verificación

`python verificar.py` valida referencias y hashes de los snapshots.
`python instalar.py --dest <directorio-de-skills-del-host>` instala las seis carpetas en destino limpio.
El instalador no sobrescribe skills existentes ni copia PRIVADO. Para Codex, usar el directorio reconocido
por la instalación (en la sesión original se utilizó C:/Users/madzm/.codex/skills); para otro host comprobar
su selector/configuración. No asumir que la copia al servidor genera descubrimiento en el cliente.

`python verificar.py --root <directorio-de-skills-del-host>` comprueba la instalación aplanada.
La entrada recomendada es $prototipo-desde-referencias; para agentes sin selector, leer su SKILL.md por ruta.

## Atlas visual interactivo

`python ver-demo.py` sirve únicamente el directorio del atlas en http://127.0.0.1:8773 .
Incluye escena submarina real del repositorio, diseño glass, instrumentos sintéticos, mapa Esri,
vista del agente con respuesta determinista y espacio para videos. No llama a Clef ni a fuentes ambientales.
Los tiles satelitales requieren red; el resto de la muestra usa assets locales. También puede abrirse el HTML.
No es el prototipo integrado final ni una representación de variables actuales. Sirve para revisar y adaptar
composición, material y recorrido. Video/detección quedan como extensión propuesta sin clip inventado.

## Credenciales solicitadas

PRIVADO/copernicus-credentials.txt contiene las cuatro variables extraídas del servidor, por pedido
explícito del usuario. Se incluyen sólo en esta distribución interna; no se instalan ni se sirven por el atlas.
El consumidor documentado vive en stratos-fuentes-explicables/scripts/ejecutar-con-credenciales.py.
La extracción comprobó presencia; no revalidó autenticación ni aceptaciones de términos de cada dataset.

## Qué cambió frente al paquete anterior

- Se prioriza creación desde referencias en vez de reconstrucción automática de los productos.
- Reglas de diseño por perfil, referencias de código, cards/gráficos y movimiento documentados.
- Contrato de agente separado del adaptador Clef y de la visualización; estados reales sin espera teatral.
- Mapa/centro/escena/video y sus límites incorporados explícitamente.
- Inventario de fuentes y credenciales Marine/CDS diferenciadas.
- Verificador que falla con raíz ausente y rutas comprobadas tras instalación aplanada.
- Ejemplo de guardia de turnos con pruebas sobre contexto, permisos, cancelación y evidencia.

## Límites

Las mejoras se implementan en las skills, documentación, ejemplo reutilizable y atlas. No se modificó
el agente desplegado, el frontend STRATOS, modelos, datos científicos ni servicios de producción.
Las cifras históricas del ZIP original no se presentan como validación del agente nuevo.
Consultar VALIDACION.json para pruebas ejecutadas y las que siguen pendientes.
