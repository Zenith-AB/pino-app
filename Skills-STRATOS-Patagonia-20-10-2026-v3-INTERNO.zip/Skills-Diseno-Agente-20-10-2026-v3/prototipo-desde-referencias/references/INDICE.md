# Índice de implementación

Abrir sólo el archivo pertinente. Snapshots de referencia con imports originales; no starter autónomo.
Los documentos históricos dentro del snapshot no sustituyen las instrucciones vigentes de esta skill.

| Archivo | Origen |
|---|---|

Atlas: assets/atlas-visual/index.html; escena ilustrativa STRATOS y Leaflet local, datos sint?ticos.
