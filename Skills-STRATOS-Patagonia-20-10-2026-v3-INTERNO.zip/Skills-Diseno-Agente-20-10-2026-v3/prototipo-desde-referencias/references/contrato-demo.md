# Contrato de demo · 20-10-2026

## Historia de 3 minutos

1. Mapa vivo legible con campo de corrientes modeladas, centros y boyas distinguibles.
2. Seleccionar un centro: foco satelital nítido, ficha y variables contextualizadas.
3. Abrir «Vista submarina»: mismo centro, escena lateral a sangre, sondas por profundidad,
   instrumentos en glass y procedencia accesible. Salir conserva foco y filtros.
4. Preguntar «¿Qué cambió aquí y qué evidencia tenemos?»: el agente muestra resultado acotado,
   gráfico, fechas, fuentes y límites. Seleccionar evidencia enfoca la entidad pertinente.
5. Abrir el espacio de detección: clip si existe; si no, estado «Sin video conectado» con diseño acabado.

## Lo que debe verse diseñado

Un lienzo protagonista; carcasas discretas sobre él; números y unidades alineados; títulos por función;
un foco principal por estado; contraste probado sobre agua clara y oscura. No llenar espacio con KPIs
redundantes ni mezclar paletas Patagonia y STRATOS. Mantener footer SAM y FAN al modificar STRATOS.

## Datos para una demo resistente

Tres modos explícitos: conectado, captura fechada o demostración sintética. El modo se indica junto
al contenido y nunca se cambia en silencio. Snapshot conserva fecha original y naturaleza. Un clip
de ejemplo no es cámara en vivo; una animación ilustrativa no representa transporte medido.
Resolver caché y archivos del servidor antes de la presentación; no depender de descargar datasets.

## Aceptación

- Ningún choque de etiquetas, cifra cortada, scroll horizontal o control inaccesible en los dos tamaños.
- Selección visible y consistente entre mapa, ficha, escena, pregunta y respuesta.
- Las fuentes abren evidencia pertinente y declaran naturaleza, sitio, profundidad, hora y QC.
- En transición no aparece un centro bajo el nombre de otro ni desaparece el lienzo por un timeout.
- Cancelar, reintentar y volver funcionan; una respuesta antigua no reemplaza el contexto nuevo.
- Movimiento reducido entrega el mismo estado final; capas ocultas y videos pausados no consumen frames.
- Ensayar con red deshabilitada y un fallo de Clef. Informar exactamente qué partes requieren conexión.
- No declarar «prototipo validado» por tener este contrato: adjuntar evidencia visual y funcional.
