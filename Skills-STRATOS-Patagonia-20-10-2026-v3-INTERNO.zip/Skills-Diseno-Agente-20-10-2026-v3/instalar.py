"""Instala sólo las seis skills; no copia PRIVADO, atlas fuera de skills ni configuración del host."""
from pathlib import Path
import argparse
import shutil
import sys

NAMES = ('prototipo-desde-referencias', 'stratos-diseno-instrumental', 'stratos-centro-inmersivo',
         'stratos-fuentes-explicables', 'agente-analitico-clef', 'agente-vista-visual')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dest', required=True, type=Path, help='Directorio de skills reconocido por el host')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    target = args.dest.expanduser().resolve()
    if target == source or target.is_relative_to(source):
        parser.error('El destino debe estar fuera de esta distribución')
    # Preflight all paths before writing any skill.
    for name in NAMES:
        if not (source/name/'SKILL.md').is_file():
            parser.error('Fuente incompleta: '+name)
        if (target/name).exists():
            parser.error('Ya existe '+name+'; conservarlo y elegir un destino limpio')
    target.mkdir(parents=True, exist_ok=True)
    for name in NAMES:
        shutil.copytree(source/name, target/name, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    print('6 skills instaladas en',target)
    print('PRIVADO no se instaló. Confirmar descubrimiento en el selector del host.')
    return 0

if __name__ == '__main__':
    sys.exit(main())
